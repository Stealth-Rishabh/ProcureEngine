﻿var BidTypeID = 0;
var BidForID = 0;
var Duration = '0.00';
var form1 = $('#FormparticipateAir');
var error1 = $('.alert-danger', form1);
var success1 = $('.alert-success', form1);
var _isBidStarted = true;
jQuery('#bid_EventID').html("Event ID : " + sessionStorage.getItem("BidID"));
function handlevalidation() {
  
    form1.validate({
        errorElement: 'span', //default input error message container
        errorClass: 'help-block', // default input error message class
        focusInvalid: false, // do not focus the last invalid input
        rules: {
            txtrentalquote: {
                required: true,
                number:true
            },
            txtmanpowerquote: {
                required: true,
                number:true
            },
            txtinfrastructurequote: {
                required: true,
                number: true
            },
            txtutilityquote: {
                required: true,
                number: true
            },
            txtfeequote: {
                required: true,
                number: true
            }
        },

        messages: {
            txtrentalquote: {
                required: "Please enter amount",
                number: "number only"
            },
            txtmanpowerquote: {
                required: "Please enter amount",
                number: "number only"
            },
            txtinfrastructurequote: {
                required: "Please enter amount",
                number: "number only"
            },
            txtutilityquote: {
                required: "Please enter amount",
                number: "number only"
            },
            txtfeequote: {
                required: "Please enter amount",
                number: "number only"
            }
        },

        invalidHandler: function (event, validator) { //display error alert on form submit   
            success1.hide();
            error1.show();
           // App.scrollTo(error1, -300);
            
        },

        highlight: function (element) { // hightlight error inputs
            $(element)
                    .closest('.form-body').addClass('has-error'); // set error class to the control group
        },
        unhighlight: function (element) { // revert the change done by hightlight
            $(element)
                    .closest('.form-body').removeClass('has-error'); // set error class to the control group
        },
        success: function (label) {
            label
                    .closest('.form-body').removeClass('has-error'); // set success class to the control group
        },

        submitHandler: function (form) {
           
            InsUpdQuotewarehouse();
        }
    });
}
function fetchVendorDetails() {
 var tncAttachment = '';
 var anyotherAttachment = '';
 //alert(sessionStorage.getItem("APIPath") + "VendorParticipation/FetchBidDetails/?BidID=" + sessionStorage.getItem("BidID") + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("UserID")))
 jQuery.ajax({
     type: "GET",
     contentType: "application/json; charset=utf-8",
     url: sessionStorage.getItem("APIPath") + "VendorParticipation/FetchBidDetails/?BidID=" + sessionStorage.getItem("BidID") + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("VendorId")),
     beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
     cache: false,
     crossDomain: true,
     dataType: "json",
     success: function(data, status, jqXHR) {
         //alert(JSON.stringify(data));
         if (data.length == 1) {
             $('#tblParticipantsVender').show();
             tncAttachment = data[0].TermsConditions.replace(/\s/g, "%20");
             anyotherAttachment = data[0].Attachment.replace(/\s/g, "%20");

             jQuery("label#lblitem1").text(data[0].BidFor);
             jQuery("#lblbidsubject").text(data[0].BidSubject);
             jQuery("#lblbidDetails").text(data[0].BidDetails);
             jQuery("#lblbiddate").text(data[0].BidDate);
             jQuery("#lblbidtime").text(data[0].BidTime);
             jQuery("#lblbidtype").text(data[0].BidTypeName);
             jQuery("#lblbidfor").text(data[0].BidFor);

             jQuery("a#lnkTermsAttachment").text(data[0].TermsConditions);
             jQuery("a#lnkTermsAttachment").attr("href", "PortalDocs/Bid/" + sessionStorage.getItem("BidID") + "/" + tncAttachment)

             jQuery("a#lnkAnyOtherAttachment").text(data[0].Attachment);
             jQuery("a#lnkAnyOtherAttachment").attr("href", "PortalDocs/Bid/" + sessionStorage.getItem("BidID") + "/" + anyotherAttachment)


             jQuery("#lblbidduration").text(data[0].BidDuration);
             jQuery("#lblcurrency").text(data[0].CurrencyName);
             jQuery("#lblConvRate").text(data[0].ConversionRate);
             jQuery("#lblstatus").text(data[0].ConversionRate);
             jQuery("#lblConvRate").text(data[0].ConversionRate);
             _isBidStarted = true;
             $(".lbltimetextdutch").show();
             BidTypeID = data[0].BidTypeID;
             BidForID = data[0].BidForID;
             $('#lblTimeLeftBeforeBid').html('').hide('');
             display = document.querySelector('#lblTimeLeft');
             //debugger;
             if (BidForID == 81) {
                 $(".lbltimetextdutch").hide();
                 fetchBidSummaryVendorScrap();
                 $("#captionAuctionType").html('').html('<i class="fa fa-reorder"></i> H1 indicates you have entered best buying price');
                 startTimer((parseInt(data[0].TimeLeft)), display);
             }  // for English Type auction

             else {
                 $(".lbltimetextdutch").show();
                 $("#captionAuctionType").html('').html('<i class="fa fa-reorder"></i> Bid Items & Offered price');
                 fetchBidSummaryVendorScrapDutch();
                 startTimerDutch((parseInt(data[0].TimeLeft)), display);
             } // For Dutch Type Auction
            
         }
         else if (data.length > 1 || data.length == 0) {
             _isBidStarted = false;
             $(".lbltimetextdutch").hide();
             $('#lblTimeLeftBeforeBid').html('Bid is not  started.').css('color', 'red');
             //$('#lblTimeLeft').html('Bid has been not started yet.').css('color', 'red');
             
             $('#tblParticipantsVender').hide();
             fetchBidHeaderDetails(sessionStorage.getItem("BidID"));
             //fetchDetailsonly();
         }
         
     },
    
     error: function (xhr, status, error) {
         jQuery("#error").text(xhr.d);
     var err = eval("(" + xhr.responseText + ")");
     if (xhr.status === 401) {
         error401Messagebox(err.Message);
     }
     jQuery.unblockUI();

    }
 });

}


var count;

function fetchBidSummaryVendorScrap() {
    count = 0;
    var url = '';
   // if (sessionStorage.getItem("ContactEmailID") == 'null' || sessionStorage.getItem("ContactEmailID") == '') {

    url = sessionStorage.getItem("APIPath") + "VendorParticipation/BidSummaryPefa/?VendorID=" + encodeURIComponent(sessionStorage.getItem("VendorId")) + "&BidID=" + sessionStorage.getItem("BidID") + "&UserType=" + sessionStorage.getItem("UserType") + "&AthenticationToken=''";

    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: url,
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function(data, status, jqXHR) {
        
            jQuery("#tblParticipantsVender").empty();
            if (_isBidStarted == false) {
                jQuery("#tblParticipantsVender").append("<thead> <tr style='background: gray; color: #FFF'><th>Item/Product</th><th>Quantity</th><th>UOM</th><th class='hide'>Bid Start Price (" + $('#lblcurrency').text() + ")</th></thead>");
                //$("#bidStartPrice").addClass('hide');
                for (var i = 0; i < data.length; i++) {
                    _offeredPrice = (data[i].OfferedPrice < 0) ? 'NA' : data[i].OfferedPrice;
                    jQuery("#tblParticipantsVender").append("<tr><td class=hide id=ceilingprice" + i + ">" + data[i].CeilingPrice + "</td><td class=hide id=minimuminc" + i + ">" + data[i].MinimumIncreament + "</td><td class=hide id=incon" + i + ">" + data[i].IncreamentOn + "</td><td class=hide id=psid" + i + ">" + data[i].PSID + "</td><td>" + data[i].ShortName + "</td><td>" + thousands_separators(data[i].Quantity) + "</td><td>" + data[i].UOM + "</td><td id=psid" + i + " class='display-none'>" + data[i].PSID + "</td><td id='offeredprice" + i + "'  class='hide'>" + data[i].Remarks + "</td></tr>");
                }
                $(".lbltimetextdutch").hide();
            } else {
                if (data.length > 0) {
                 
                    jQuery("#tblParticipantsVender").append("<thead> <tr style='background: gray; color: #FFF'><th>Item/Product</th><th>Quantity</th><th>UOM</th><th id='bidStartPrice'>Bid start price</th><th class=hide>Target Price</th><th>Minimum Increament</th><th>Last Quote</th><th>H1 Price</th><th> Status (H1/ Not H1)</th><th>Quote</th><th>Action</th></thead>");
                    for (var i = 0; i < data.length; i++) {
                      
                        var IQuote = data[i].IQQuotedPrice == '0' ? '' : data[i].IQQuotedPrice;
                        var MqQuote = data[i].MQQuotedPrice == '0' ? '' : data[i].MQQuotedPrice;
                        var decreamentOn = data[i].IncreamentOn == "A" ? jQuery("#lblcurrency").text() : '%';
                        jQuery("#tblParticipantsVender").append("<tr><td class=hide id=ceilingprice" + i + ">" + data[i].CeilingPrice + "</td><td class=hide id=minimuminc" + i + ">" + data[i].MinimumIncreament + "</td><td class=hide id=incon" + i + ">" + data[i].IncreamentOn + "</td><td class=hide id=psid" + i + ">" + data[i].PSID + "</td><td>" + data[i].ShortName + "</td><td>" + thousands_separators(data[i].Quantity) + "</td><td>" + data[i].UOM + "</td><td id=tdBidStartPrice"+i+">" + thousands_separators(data[i].CeilingPrice) + " " + jQuery("#lblcurrency").text() + "</td><td id=targetprice" + i + " class=hide>" + data[i].TargetPrice + " " + jQuery("#lblcurrency").text() + "</td><td>" + thousands_separators(data[i].MinimumIncreament) + " " + decreamentOn + "</td><td id=lastQuote" + i + ">" + thousands_separators(MqQuote) + "</td><td id=H1Price" + i + ">" + thousands_separators(data[i].H1Price) +"</td><td><label class=control-label id=lblstatus" + i + ">" + data[i].MOQuotedPrice + "</label></td><td> <input type=text class='form-control clsdisable' autocomplete=off  id=txtquote" + i + " name=txtquote" + i + " onkeyup='thousands_separators_input(this)' /> <span id=spanamount" + i + "   style=color:#a94442></span></td><td id=psid" + i + " class='display-none'>" + data[i].PSID + "</td><td><button id='btnsubmit'  type='button' class='btn yellow col-lg-offset-5 clsdisable' onclick='InsUpdQuoteScrap(" + i + ")'>Submit</button></td></tr>");

                        $('#spanamount' + i).addClass('hide spanclass');
                       // $('#txtquote' + i).val(thousands_separators(data[i].MQQuotedPrice));
                        //sessionStorage.setItem("PSHeaderID" + i, data[i].PSHeaderID)
                        if (data[i].MOQuotedPrice == 'H1') {
                            jQuery('#lblstatus' + i).css('color', 'Blue');
                        }
                        else {

                            jQuery('#lblstatus' + i).css('color', 'Red');
                        }
                        if (data[i].ShowHLPrice == 'N') {
                            $("#H1Price" + i).html('Not Disclosed');
                        }
                        if (data[i].ShowStartPrice == "N") {
                            $("#tdBidStartPrice" + i).html('Not Disclosed');
                        }
                        count = count + 1;
                    }
                    
                } else {
                    jQuery("#tblParticipantsVender").append("<tr><td>Nothing Participation</td></tr>")
                }
            }
        },
        error: function (xhr, status, error) {
           
            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            jQuery.unblockUI();

        }
    });
}



function fetchBidSummaryVendorScrapDutch() {
    
        count = 0;
        var url = '';
       // if (sessionStorage.getItem("ContactEmailID") == 'null' || sessionStorage.getItem("ContactEmailID") == '') {

    url = sessionStorage.getItem("APIPath") + "VendorParticipation/BidSummaryPefaDutch/?VendorID=" + encodeURIComponent(sessionStorage.getItem("VendorId")) + "&BidID=" + sessionStorage.getItem("BidID") + "&UserType=" + sessionStorage.getItem("UserType") + "&AthenticationToken=''";

        //} else {

        //    url = sessionStorage.getItem("APIPath") + "VendorParticipation/BidSummaryPefaDutch/?VendorID=" + encodeURIComponent(sessionStorage.getItem("BidUserID")) + "&BidID=" + sessionStorage.getItem("BidID") + "&UserType=" + sessionStorage.getItem("UserType") + "&AthenticationToken=''";
        //}
        //alert(url)
        jQuery.ajax({
            type: "GET",
            contentType: "application/json; charset=utf-8",
            url: url,
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            cache: false,
            crossDomain: true,
            dataType: "json",
            success: function (data, status, jqXHR) {
                //alert(JSON.stringify(data))
                jQuery("#tblParticipantsVender").empty();
                if (data.length > 0) {

                    var _offeredPrice;
                    
                    jQuery("#tblParticipantsVender >tbody").empty();
                    if (_isBidStarted == false) {

                        jQuery("#tblParticipantsVender").append("<thead> <tr style='background: gray; color: #FFF'><th>Item/Product</th><th>Quantity</th><th>UOM</th><th class=hide>Offered Unit Price (" + $('#lblcurrency').text() + ")</th></thead>");
                        //$("#bidStartPrice").addClass('hide');
                        for (var i = 0; i < data.length; i++) {
                            _offeredPrice = (data[i].OfferedPrice < 0) ? 'NA' : data[i].OfferedPrice;
                            jQuery("#tblParticipantsVender").append("<tr><td class=hide id=ceilingprice" + i + ">" + data[i].CeilingPrice + "</td><td class=hide id=minimuminc" + i + ">" + data[i].MinimumIncreament + "</td><td class=hide id=incon" + i + ">" + data[i].IncreamentOn + "</td><td class=hide id=psid" + i + ">" + data[i].PSID + "</td><td>" + data[i].ShortName + "</td><td>" + thousands_separators(data[i].Quantity) + "</td><td>" + data[i].UOM + "</td><td id=psid" + i + " class='display-none'>" + data[i].PSID + "</td><td id='offeredprice" + i + "' class=hide>" + thousands_separators(_offeredPrice) + "</td></tr>");
                        }
                        $(".lbltimetextdutch").hide()
                    }
                    else {
                       
                        jQuery("#tblParticipantsVender").append("<thead> <tr style='background: gray; color: #FFF'><th>Item/Product</th><th>Quantity</th><th>UOM</th><th id=THTarget>Target Price</th><th class=hide>Show L1 Price</th><th>Offered Unit Price (" + $('#lblcurrency').text() + ")</th><th>Action</th></thead>");
                        for (var i = 0; i < data.length; i++) {
                            _offeredPrice = (data[i].OfferedPrice < 0) ? 'NA' : data[i].OfferedPrice;
                            if (data[i].Flag != 'Y') {
                                jQuery("#tblParticipantsVender").append("<tr><td class=hide id=ceilingprice" + i + ">" + data[i].CeilingPrice + "</td><td class=hide id=minimuminc" + i + ">" + data[i].MinimumIncreament + "</td><td class=hide id=incon" + i + ">" + data[i].IncreamentOn + "</td><td class=hide id=psid" + i + ">" + data[i].PSID + "</td><td>" + data[i].ShortName + "</td><td>" + thousands_separators(data[i].Quantity) + "</td><td>" + data[i].UOM + "</td><td id=tdtarget" + i + ">" + thousands_separators(data[i].Targetprice) + "</td><td id=L1Price"+i+" class=hide>" + thousands_separators(data[i].L1Price) + "</td><td id=psid" + i + " class='display-none'>" + data[i].PSID + "</td><td id='offeredprice" + i + "'>" + thousands_separators(_offeredPrice) + "</td><td><button id='btnsubmit' type='button' class='btn yellow col-lg-offset-5 clsdisable' onclick='InsUpdQuoteScrapDutch(" + i + ")' onkeyup='thousands_separators_input(this)'>Accept </button></td></tr>");

                                $('#spanamount' + i).addClass('hide spanclass');
                                if (data[i].MaskVendor == "Y") {
                                    $('#tdtarget' + i).addClass('hide')
                                    $('#THTarget').addClass('hide')
                                }
                                else {
                                    $('#tdtarget' + i).removeClass('hide')
                                    $('#THTarget').removeClass('hide')
                                }
                                if (data[i].ShowHLPrice == "N") {
                                    $("#L1Price" + i).html('Not Disclosed');
                                }
                                
                                $('#txtquote' + i).val(thousands_separators(data[i].MQQuotedPrice));
                                //sessionStorage.setItem("PSHeaderID" + i, data[i].PSHeaderID)
                                if (data[i].MOQuotedPrice == 'H1') {
                                    jQuery('#lblstatus' + i).css('color', 'Blue');
                                }
                                else {

                                    jQuery('#lblstatus' + i).css('color', 'Red');
                                }
                                count = count + 1;
                            }
                        }
                    }

                }
                else {
                    //jQuery("#tblParticipantsVender").append("<tr><td>Nothing Participation</td></tr>")
                    closeBidAir();
                }
            },
            error: function (xhr, status, error) {
               
                var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }
                jQuery.unblockUI();

            }
        });
    
}

function refreshColumnsStaus() {
    var url = '';
    //if (sessionStorage.getItem("ContactEmailID") == 'null' || sessionStorage.getItem("ContactEmailID") == '') {
    //    if (BidForID ==81) {
    //        url = sessionStorage.getItem("APIPath") + "VendorParticipation/BidSummaryPefa/?VendorID=" + encodeURIComponent(sessionStorage.getItem("VendorId")) + "&BidID=" + sessionStorage.getItem("BidID") + "&UserType=" + sessionStorage.getItem("UserType") + "&AthenticationToken=''";
    //        jQuery.ajax({
    //            type: "GET",
    //            contentType: "application/json; charset=utf-8",
    //            url: url,
    //            cache: false,
    //            crossDomain: true,
    //            dataType: "json",
    //            success: function (data, status, jqXHR) {

    //                if (data.length > 0) {

    //                    for (var i = 0; i < data.length; i++) {

    //                        if (data[i].NoOfExtension >= 1) {

    //                            jQuery('#lblTimeLeft').css('color', 'red');
    //                            jQuery('#lblTimeLeftTxt').removeClass('display-none');
    //                            jQuery('#lblTimeLeftTxt').html('<b>Bid Time Extended.</b>').css('color', 'red')
    //                        }
    //                        else {
    //                            jQuery('#lblTimeLeftTxt').addClass('display-none');
    //                            jQuery('#lblTimeLeft').css('color', '');
    //                        }
    //                        display = document.querySelector('#lblTimeLeft');
    //                        startTimer(data[i].TimeLeft, display);

    //                        $("#iqquote" + i).html(data[i].IQQuotedPrice == '0' ? '' : thousands_separators(data[i].IQQuotedPrice))
    //                        $("#lastQuote" + i).html(data[i].MQQuotedPrice == '0' ? '' : thousands_separators(data[i].MQQuotedPrice))
    //                        $("#lblstatus" + i).html(thousands_separators(data[i].MOQuotedPrice))

    //                        if (data[i].MOQuotedPrice == 'H1') {
    //                            jQuery('#lblstatus' + i).css('color', 'Blue');
    //                        }
    //                        else {

    //                            jQuery('#lblstatus' + i).css('color', 'Red');

    //                        }
    //                        if (data[i].ShowHLPrice == "N") {
    //                            $("#H1Price" + i).html('Not Disclosed');
    //                        }
                           
                            
    //                       // display = document.querySelector('#lblTimeLeft');
    //                       // startTimer(data[i].TimeLeft, display);



    //                    }




    //                }


    //            }, error: function (data, status, jqXHR) {

    //            }
    //        });
    //    }else{
    //        fetchBidSummaryVendorScrapDutch();
    //    }
    //}
    //else {
        if (BidForID == 81) {
            url = sessionStorage.getItem("APIPath") + "VendorParticipation/BidSummaryPefa/?VendorID=" + encodeURIComponent(sessionStorage.getItem("VendorId")) + "&BidID=" + sessionStorage.getItem("BidID") + "&UserType=" + sessionStorage.getItem("UserType") + "&AthenticationToken=''";//BidUserID

            jQuery.ajax({
                type: "GET",
                contentType: "application/json; charset=utf-8",
                url: url,
                beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
                cache: false,
                crossDomain: true,
                dataType: "json",
                success: function (data, status, jqXHR) {

                    if (data.length > 0) {

                        for (var i = 0; i < data.length; i++) {

                            if (data[i].NoOfExtension >= 1) {

                                jQuery('#lblTimeLeft').css('color', 'red');
                                jQuery('#lblTimeLeftTxt').removeClass('display-none');
                                jQuery('#lblTimeLeftTxt').html('<b>Bid Time Extended.</b>').css('color', 'red')
                            }
                            else {
                                jQuery('#lblTimeLeftTxt').addClass('display-none');
                                jQuery('#lblTimeLeft').css('color', '');
                            }
                            display = document.querySelector('#lblTimeLeft');
                            startTimer(data[i].TimeLeft, display);


                            $("#iqquote" + i).html(data[i].IQQuotedPrice == '0' ? '' : thousands_separators(data[i].IQQuotedPrice))
                            $("#lastQuote" + i).html(data[i].MQQuotedPrice == '0' ? '' : thousands_separators(data[i].MQQuotedPrice))
                            $("#lblstatus" + i).html(thousands_separators(data[i].MOQuotedPrice))

                            if (data[i].MOQuotedPrice == 'H1') {
                                jQuery('#lblstatus' + i).css('color', 'Blue');
                            }
                            else {

                                jQuery('#lblstatus' + i).css('color', 'Red');

                            }
                            if (data[i].ShowHLPrice == "N") {
                                $("#H1Price" + i).html('Not Disclosed');
                            }
                            //  $('#hdnnoofextension').val(data[i].NoOfExtension)
                            //display = document.querySelector('#lblTimeLeft');
                            //startTimer(data[i].TimeLeft, display);

                         }




                    }


                }, error: function (xhr, status, error) {
                    
                    var err = eval("(" + xhr.responseText + ")");
                    if (xhr.status === 401) {
                        error401Messagebox(err.Message);
                    }
                    jQuery.unblockUI();

                }
            });
        }
        else {
            fetchBidSummaryVendorScrapDutch();

        }
    //}
    
    


}


var mytime = 0;
function startTimer(duration, display) {
    clearInterval(mytime)
    var timer = 0, hours = 0, minutes = 0, seconds = 0;
    timer = duration;
   
    mytime = setInterval(function () {
        refreshColumnsStaus();
        hours = parseInt(timer / 3600, 10)
        minutes = parseInt(timer / 60, 10) - (hours * 60)
        seconds = parseInt(timer % 60, 10);

        hours = hours < 10 ? "0" + hours : hours;
        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;

        if (hours > 0) {
            display.textContent = hours + ":" + minutes + ":" + seconds;
        }
        else {
            display.textContent = minutes + ":" + seconds;
        }
        if ((seconds.toString().substring(1, 2) == '0') || (seconds.toString().substring(1, 2) == '5')) {

            refreshColumnsStaus()
            if (sessionStorage.getItem("UserType") == 'E') {
                fetchUserChats($('#hddnVendorId').val(), 'S');
            } else {
                fetchUserChats(sessionStorage.getItem('UserID'), 'S');
            }

        }
        refreshColumnsStaus();
       // console.log(timer)
       // setTimeout(function () {
          
           // else {
            //    $('.clsdisable').removeAttr('disabled')
           // }
        // },1000)
       
            if (timer <= 0) {
                $('.clsdisable').attr('disabled', 'disabled')
            }
                setTimeout(function () {
                    if (--timer < -3) {
                        timer = -3;
                        if (timer == -3) {
                            closeBidAir();
                        }
                    }
                }, 1000);
          ///  }
            
        $('#hdnval').val(timer)

    }, 1000);

}
function fetchBidTime() {
    var display = document.querySelector('#lblTimeLeft');

    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "VendorParticipation/FetchBidTimeLeft/?BidID=" + sessionStorage.getItem("BidID"),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
            if (data.length > 0) {
                //alert(data[0].TimeLeft)
               startTimerDutch((parseInt(data[0].TimeLeft)), display);
               
            }
        },
        error: function (xhr, status, error) {
         
            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            jQuery.unblockUI();

        }
    });
}
function startTimerDutch(duration, display) {
    clearInterval(mytime)
    var timer = duration;
    var hours, minutes, seconds;
    mytime = setInterval(function () {
        fetchBidTime()
        hours = parseInt(timer / 3600, 10)
        minutes = parseInt(timer / 60, 10) - (hours * 60)
        seconds = parseInt(timer % 60, 10);

        hours = hours < 10 ? "0" + hours : hours;
        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;

        if (hours > 0) {
            display.textContent = hours + ":" + minutes + ":" + seconds;
        }
        else {
            display.textContent = minutes + ":" + seconds;
        }


        if ((seconds.toString().substring(1, 2) == '0') || (seconds.toString().substring(1, 2) == '5')) {
            fetchBidSummaryVendorScrapDutch();
            fetchBidTime()
            if (sessionStorage.getItem("UserType") == 'E') {
                fetchUserChats($('#hddnVendorId').val(), 'S');
            } else {
                fetchUserChats(sessionStorage.getItem('UserID'), 'S');
            }
        }
        
        console.log(timer)
       // setTimeout(function () {
            if (--timer <= 0) {
                closeBidAir();
                return;
            }
      //  }, 3000);

    }, 1000);
}
$(document).on("keyup", "#tblParticipantsVender .form-control", function () {
    var txt = this.id
    $('#' + txt).next(':first').addClass('hide');

});
//function InsUpdQuoteScrap() {

//    var vendorID = 0;
//    if (sessionStorage.getItem('ContactEmailID') == 'null' || sessionStorage.getItem('ContactEmailID') == '') {
//        vendorID = sessionStorage.getItem('UserID');
//    }
//    else {
//        vendorID = sessionStorage.getItem('BidUserID');
//    }

//    var insertquery = '';
//    var value = 0;
//    var v = 0;

//    for (var i = 0; i < count; i++) {

//        var Amount = $('#minimuminc' + i).text()
//        if ($('#incon' + i).text() == "A") {
//            if (jQuery("#lastQuote" + i).text() == '') {
//                value = parseFloat($('#txtquote' + i).val())

//            }
//            else {
//                value =parseFloat($('#txtquote' + i).val() -  parseFloat(jQuery("#lastQuote" + i).text()) )
//            }

//        }
//        else {
//            if (jQuery("#lastQuote" + i).text() == '') {
//                value = (parseFloat(Amount) / 100) * (parseFloat(jQuery("#txtquote" + i).val()));
//                v = parseFloat($('#txtquote' + i).val())
//            }
//            else {
//                value = (parseFloat(Amount) / 100) * (parseFloat(jQuery("#lastQuote" + i).text()));
//                v = parseFloat(jQuery("#lastQuote" + i).text()) - parseFloat($('#txtquote' + i).val());
//            }
//        }

//        

//        if (($('#txtquote' + i).val() == 0) || (!/^[0-9]+(\.[0-9]{1,2})?$/.test($('#txtquote' + i).val()))) {
//            $('#spanamount' + i).removeClass('hide')
//            $('#spanamount' + i).text('Amount is required in number only')
//            return false
//        }

//        else if (parseFloat($('#txtquote' + i).val()) < parseFloat($('#ceilingprice' + i).text())) {
//            $('#spanamount' + i).removeClass('hide')
//            $('#spanamount' + i).text('Amount should not be less than Bid start price')
//            return false
//        }
//        else if (value < parseFloat(Amount) && $('#incon' + i).text() == "A" && value != 0) {
//        
//            $('#spanamount' + i).removeClass('hide')
//            // $('#spanamount' + i).text('Amount should be less than last Quote or Minimum decrement is ' + Amount)
//            $('#spanamount' + i).text('Amount should be more than minimum increment value ')
//            return false
//        }

//        else if (v < value && $('#incon' + i).text() == "P") {
//            $('#spanamount' + i).removeClass('hide')
//            // $('#spanamount' + i).text('Amount should be less than last Quote or Minimum decrement is ' + Amount + ' %')
//            $('#spanamount' + i).text('Amount should be more than minimum increment value is' + Amount + ' %')
//            return false
//        }
//        else {

//            if (i == 0) {

//                insertquery = insertquery + 'insert into VendorScrapParticipationDetails(BidID,VendorID,QuotedPrice,PSID,SubmissionTime)'
//                insertquery = insertquery + " select " + sessionStorage.getItem("BidID") +",dbo.Decrypt('" + vendorID + "')," + $('#txtquote' + i).val() + "," + $('#psid' + i).html() + ",getdate() union";

//            }
//            else {
//                insertquery = insertquery + " select " + sessionStorage.getItem("BidID") + ",dbo.Decrypt('" + vendorID + "')," + $('#txtquote' + i).val() + "," + $('#psid' + i).html() + ",getdate() union";

//            }

//        }
//    }

//    insertquery = insertquery.substring(0, insertquery.length - 6);
//    var vendorID = 0;
//    if (sessionStorage.getItem('ContactEmailID') == 'null' || sessionStorage.getItem('ContactEmailID') == '') {
//        vendorID = sessionStorage.getItem('UserID');
//    }
//    else {
//        vendorID = sessionStorage.getItem('BidUserID');
//    }

//    if ($('#hdnval').val() >= 60) {
//        
//        var QuoteProduct = {
//            "VendorID": vendorID,
//            "BidID": sessionStorage.getItem("BidID"),
//            "insertQuery": insertquery,
//            "EnteredBy": vendorID

//        }
//       //alert(JSON.stringify(QuoteProduct))
//        jQuery.ajax({
//        url: sessionStorage.getItem("APIPath") + "VendorParticipation/ParticipationScrapSale/",
//            type: "POST",
//            data: JSON.stringify(QuoteProduct),
//            contentType: "application/json; charset=utf-8",
//            success: function(data, status, jqXHR) {
//                //resetSessions(count);
//                fetchVendorDetails();

//            },
//            error: function(xhr) {
//                jQuery("#error").text(xhr.d);
//            }
//        });
//    }
//    else {
//     
//        var QuoteProduct = {
//            "VendorID": vendorID,
//            "BidID": sessionStorage.getItem("BidID"),
//            "insertQuery": insertquery,
//            "EnteredBy": vendorID

//        }
//        //alert(JSON.stringify(QuoteProduct))
//        jQuery.ajax({
//        url: sessionStorage.getItem("APIPath") + "VendorParticipation/ParticipationScrapSale/",
//            type: "POST",
//            data: JSON.stringify(QuoteProduct),
//            contentType: "application/json; charset=utf-8",
//            success: function (data, status, jqXHR) {
//                //resetSessions(count);
//            fetchVendorDetails();
//            refreshColumnsStaus();

//            },
//            error: function (xhr) {
//                jQuery("#error").text(xhr.d);
//            }
//        });
//        var data = {
//            "BidID": sessionStorage.getItem("BidID")

//        }
//        //alert(JSON.stringify(data))
//        jQuery.ajax({
//            url: sessionStorage.getItem("APIPath") + "VendorParticipation/ExtendDuration/",
//            type: "POST",
//            data: JSON.stringify(data),
//            contentType: "application/json; charset=utf-8",
//            success: function(data, status, jqXHR) {
//                // display = document.querySelector('#lblTimeLeft');
//                // startTimer((parseInt(data[0].TimeLeft)), display);
//                //fetchVendorDetails()
//                return true
//            },
//            error: function(xhr) {
//                jQuery("#error").text(xhr.d);
//            }
//        });
//    }
//


//}


//function Starts

function InsUpdQuoteScrap(rowID) {

    var vendorID = 0;
    var i = rowID;
   // if (sessionStorage.getItem('ContactEmailID') == 'null' || sessionStorage.getItem('ContactEmailID') == '') {
    //vendorID = sessionStorage.getItem('UserID'); 
    vendorID = sessionStorage.getItem('VendorId'); 
    //}
    //else {
    //    vendorID = sessionStorage.getItem('BidUserID');
    //}

    //var insertquery = '';
    var value = 0;
    var v = 0;



    var Amount = $('#minimuminc' + i).text()
    if ($('#incon' + i).text() == "A") {
        if (jQuery("#lastQuote" + i).text() == '') {
            value = parseFloat(removeThousandSeperator($('#txtquote' + i).val()))

        }
        else {
            value = parseFloat(removeThousandSeperator($('#txtquote' + i).val()) - parseFloat(removeThousandSeperator(jQuery("#lastQuote" + i).text())))
        }

    }
    else {
        if (jQuery("#lastQuote" + i).text() == '') {
            value = (parseFloat(Amount) / 100) * (parseFloat(removeThousandSeperator(jQuery("#txtquote" + i).val())));
            v = parseFloat(removeThousandSeperator($('#txtquote' + i).val()))
        }
        else {
            value = (parseFloat(Amount) / 100) * (parseFloat(removeThousandSeperator(jQuery("#lastQuote" + i).text())));
            // v = parseFloat(removeThousandSeperator(jQuery("#lastQuote" + i).text())) - parseFloat(removeThousandSeperator($('#txtquote' + i).val()));
            v = parseFloat(removeThousandSeperator(jQuery("#lastQuote" + i).text()))+value
           
        }
        //alert(value)
        //alert(v+value)
       
    }



    if ((removeThousandSeperator($('#txtquote' + i).val()) == 0) || (!/^[0-9]+(\.[0-9]{1,2})?$/.test(removeThousandSeperator($('#txtquote' + i).val())))) {
        $('#spanamount' + i).removeClass('hide')
        $('#spanamount' + i).text('Amount is required in number only')
        return false
    }

    else if (parseFloat(removeThousandSeperator($('#txtquote' + i).val())) < parseFloat(($('#ceilingprice' + i).text()))) {
        $('#spanamount' + i).removeClass('hide')
        $('#spanamount' + i).text('Amount should not be less than Bid start price')
        return false
    }
    else if (value < parseFloat(Amount) && $('#incon' + i).text() == "A" && value != 0) {
       // alert('false')
        $('#spanamount' + i).removeClass('hide')

        $('#spanamount' + i).text('Amount should be more than minimum increment value ')
        return false
    }

    else if ((parseFloat(removeThousandSeperator(jQuery("#txtquote" + i).val())) < (v)) && $('#incon' + i).text() == "P") {
        $('#spanamount' + i).removeClass('hide')

        $('#spanamount' + i).text('Amount should be more than minimum increment value of ' + Amount + ' %')
        return false
    }
    else {

        var vendorID = 0;
      //  if (sessionStorage.getItem('ContactEmailID') == 'null' || sessionStorage.getItem('ContactEmailID') == '') {
       // vendorID = sessionStorage.getItem('UserID');
        vendorID = sessionStorage.getItem('VendorId'); 
        //}
       // else {
           // vendorID = sessionStorage.getItem('UserID'); 
           // vendorID = sessionStorage.getItem('BidUserID'); 
        //}


        if ($('#hdnval').val() >= 60) {
            //alert($('#hdnval').val())
           // alert('should  insert');
            var QuoteProduct = {
                "VendorID": vendorID,
                "BidID": sessionStorage.getItem("BidID"),
                "QuotedPrice": removeThousandSeperator($('#txtquote' + i).val()),
                "PSID": $('#psid' + i).html(),
                "EnteredBy": vendorID

            }
            //alert(JSON.stringify(QuoteProduct))
            jQuery.ajax({
                url: sessionStorage.getItem("APIPath") + "VendorParticipation/ParticipationScrapSaleSingleItem/",
                beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
                type: "POST",
                data: JSON.stringify(QuoteProduct),
                contentType: "application/json; charset=utf-8",
                success: function(data, status, jqXHR) {

                    if (data[0].insertQuery == "1") {
                        $('#txtquote' + i).val('')
                        fetchVendorDetails();
                    }
                    else if (data[0].insertQuery == "-1") {
                        $('#spanamount' + i).removeClass("hide");
                        $('#spanamount' + i).text("Someone already quoted this price. Please Quote another price.")
                    }

                },
                
                error: function (xhr, status, error) {
                    jQuery("#error").text(xhr.d +" you're offline check your connection and try again");
                var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }
                jQuery.unblockUI();

            }
            });
        }
        else {
           
           // if ($('#hdnval').val() <= 5 && $('#hdnval').val() > 1) {
           
           // }
          
            var QuoteProduct = {
                "VendorID": vendorID,
                "BidID": sessionStorage.getItem("BidID"),
                "QuotedPrice": removeThousandSeperator($('#txtquote' + i).val()),
                "PSID": $('#psid' + i).html(),
                "EnteredBy": vendorID

            }
            //alert(JSON.stringify(QuoteProduct))
            jQuery.ajax({
                url: sessionStorage.getItem("APIPath") + "VendorParticipation/ParticipationScrapSaleSingleItem/",
                beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
                type: "POST",
                data: JSON.stringify(QuoteProduct),
                contentType: "application/json; charset=utf-8",
                success: function(data, status, jqXHR) {

                    if (data[0].insertQuery == "1") {
                        var data = {
                            "BidID": sessionStorage.getItem("BidID")

                        }

                        jQuery.ajax({
                            url: sessionStorage.getItem("APIPath") + "VendorParticipation/ExtendDuration/",
                            type: "POST",
                            data: JSON.stringify(data),
                            contentType: "application/json; charset=utf-8",
                            success: function (data, status, jqXHR) {
                                $('#txtquote' + i).val('')
                                refreshColumnsStaus();

                                return true
                            },
                           
                            error: function (xhr, status, error) {
                            jQuery("#error").text(xhr.d);
                            var err = eval("(" + xhr.responseText + ")");
                            if (xhr.status === 401) {
                                error401Messagebox(err.Message);
                            }
                            jQuery.unblockUI();

                        }
                        });
                        fetchVendorDetails();
                        //refreshColumnsStaus();
                    }
                    else if (data[0].insertQuery == "-1") {
                        $('#spanamount' + i).removeClass("hide");
                        $('#spanamount' + i).text("Someone already quoted this price. Please Quote another price.")
                    }

                },
                error: function (xhr, status, error) {
                   
                    jQuery("#error").text(xhr.d+ " you're offline check your connection and try again");
                   
                      
                        var err = eval("(" + xhr.responseText + ")");
                        if (xhr.status === 401) {
                            error401Messagebox(err.Message);
                        }
                        jQuery.unblockUI();

                    
                }
            });
            //var data = {
            //    "BidID": sessionStorage.getItem("BidID")

            //}
            //alert(JSON.stringify(data))
            //jQuery.ajax({
            //    url: sessionStorage.getItem("APIPath") + "VendorParticipation/ExtendDuration/",
            //    type: "POST",
            //    data: JSON.stringify(data),
            //    contentType: "application/json; charset=utf-8",
            //    success: function(data, status, jqXHR) {
            //        fetchVendorDetails();
            //        refreshColumnsStaus();
            //        return true
            //    },
            //    error: function(xhr) {
            //        jQuery("#error").text(xhr.d);
            //    }
            //});
        }


    }


} // function ends here

function InsUpdQuoteScrapDutch(rowID) {
       
    var i = rowID;
    var vendorID = 0;
        
   // if (sessionStorage.getItem('ContactEmailID') == 'null' || sessionStorage.getItem('ContactEmailID') == '') {
           // vendorID = sessionStorage.getItem('UserID');
        vendorID = sessionStorage.getItem('VendorId'); 
       // }
       // else {
       // vendorID = sessionStorage.getItem('UserID');
       // vendorID = sessionStorage.getItem('BidUserID');
        //}

            var QuoteProduct = {
                "VendorID": vendorID,
                "BidID": sessionStorage.getItem("BidID"),
                "QuotedPrice": $('#offeredprice' + i).html(),
                "PSID": $('#psid' + i).html(),
                "EnteredBy": vendorID,
                "Flag" : 'Y'

            }
    //alert(JSON.stringify(QuoteProduct))
            //debugger;
            jQuery.ajax({
                url: sessionStorage.getItem("APIPath") + "VendorParticipation/ParticipationScrapSaleSingleItemDutch/",
                beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
                type: "POST",
                data: JSON.stringify(QuoteProduct),
                contentType: "application/json; charset=utf-8",
                success: function (data, status, jqXHR) {

                    if (data[0].insertQuery == "1") {
                        fetchVendorDetails();
                    }
                    else if (data[0].insertQuery == "-1") {
                        $('#spanamount' + i).removeClass("hide");
                        $('#spanamount' + i).text("Someone already accepted this price.")
                    }

                },
                error: function (xhr, status, error) {

                    jQuery("#error").text(xhr.d + " you're offline check your connection and try again");


                    var err = eval("(" + xhr.responseText + ")");
                    if (xhr.status === 401) {
                        error401Messagebox(err.Message);
                    }
                    jQuery.unblockUI();


                }
            });  


} // Dutch PArticipation function ends here

function closeBidAir() {
    clearInterval(mytime)
    jQuery.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "VendorParticipation/CloseBid/?BidID=" + sessionStorage.getItem("BidID"),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
            if (BidForID == 82) {
                InsUpdQuoteScrapDutch('0')
            }
            bootbox.alert("Bid time has been over. Thanks for Participation.", function () {
                //window.location = sessionStorage.getItem('MainUrl');
                if (sessionStorage.getItem("ISFromSurrogate") == "Y") {
                    window.location = sessionStorage.getItem('HomePage');
                    sessionStorage.clear();
                }
                else {
                    window.location = 'VendorHome.html';
                }
                return false;
            });
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            jQuery.unblockUI();


        }
    });
}

function fetchBidHeaderDetails(_bidId) {

    var tncAttachment = '';
    var anyotherAttachment = '';
    var url = '';
    //if (sessionStorage.getItem("ContactEmailID") == 'null' || sessionStorage.getItem("ContactEmailID") == '') {
    url = sessionStorage.getItem("APIPath") + "BidVendorSummary/FetchBidDetails_Vendor/?BidID=" + _bidId + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("VendorId"))
    //} else {
    //    url = sessionStorage.getItem("APIPath") + "BidVendorSummary/FetchBidDetails/?BidID=" + _bidId + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("BidUserID"))
    //}
    //alert(sessionStorage.getItem("APIPath") + "VendorParticipation/FetchBidDetails/?BidID=" + sessionStorage.getItem("BidID") + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("UserID")))
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: url,
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
            //alert(JSON.stringify(data));
            if (data.length == 1) {
                $('#tblParticipantsVender').show();
                tncAttachment = data[0].TermsConditions.replace(/\s/g, "%20");
                anyotherAttachment = data[0].Attachment.replace(/\s/g, "%20");

                jQuery("label#lblitem1").text(data[0].BidFor);
                jQuery("#lblbidsubject").text(data[0].BidSubject);
                jQuery("#lblbidDetails").text(data[0].BidDetails);
                jQuery("#lblbiddate").text(data[0].BidDate);
                jQuery("#lblbidtime").text(data[0].BidTime);
                jQuery("#lblbidtype").text(data[0].BidTypeName);
                jQuery("#lblbidfor").text(data[0].BidFor);

                jQuery("a#lnkTermsAttachment").text(data[0].TermsConditions);
                jQuery("a#lnkTermsAttachment").attr("href", "PortalDocs/Bid/" + sessionStorage.getItem("BidID") + "/" + tncAttachment)

                jQuery("a#lnkAnyOtherAttachment").text(data[0].Attachment);
                jQuery("a#lnkAnyOtherAttachment").attr("href", "PortalDocs/Bid/" + sessionStorage.getItem("BidID") + "/" + anyotherAttachment)


                jQuery("#lblbidduration").text(data[0].BidDuration);
                jQuery("#lblcurrency").text(data[0].CurrencyName);
                jQuery("#lblConvRate").text(data[0].ConversionRate);
                jQuery("#lblstatus").text(data[0].ConversionRate);
                jQuery("#lblConvRate").text(data[0].ConversionRate);


                BidTypeID = data[0].BidTypeID;
                BidForID = data[0].BidForID;
                var display = document.querySelector('#lblTimeLeft');
                startTimerBeforeBidStart(data[0].TimeLeft, display)
                //debugger;
                if (BidForID == 81) {
                    fetchBidSummaryVendorScrap();
                    $(".lbltimetextdutch").hide();
                    $("#captionAuctionType").html('').html('<i class="fa fa-reorder"></i> H1 indicates you have entered best buying price');
                }  // for English Type auction
                else {
                    $(".lbltimetextdutch").show();
                    $("#captionAuctionType").html('').html('<i class="fa fa-reorder"></i> Bid Items & Offered price');
                    fetchBidSummaryVendorScrapDutch();
                } // For Dutch Type Auction
                
            }

        },
       
        error: function (xhr, status, error) {
                   
            jQuery("#error").text(xhr.d);
            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            jQuery.unblockUI();

                    
        }
    });
}

function startTimerBeforeBidStart(duration, display) {
    clearInterval(mytime)
    // var timer = 0, hours = 0, minutes = 0, seconds = 0;
    //timer = duration;

    var timer = duration, hours, minutes, seconds;
    mytime = setInterval(function () {
        hours = parseInt(timer / 3600, 10)
        minutes = parseInt(timer / 60, 10) - (hours * 60)
        seconds = parseInt(timer % 60, 10);

        hours = hours < 10 ? "0" + hours : hours;
        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;

        if (hours > 0) {
            display.textContent = hours + ":" + minutes + ":" + seconds;
        }
        else {
            display.textContent = minutes + ":" + seconds;
        }
        //if ((seconds.toString().substring(1, 2) == '0') || (seconds.toString().substring(1, 2) == '5')) {

        //    refreshColumnsStaus()

        //}
        duration--;
        startTimerBeforeBidStart(duration, display)
        if (--timer < 0) {
            //timer = 0;
            //closeBidAir();
            fetchVendorDetails();
        }
        //$('#hdnval').val(timer)

    }, 1000);

}