﻿var param = getUrlVars()["param"]
var decryptedstring = fndecrypt(param)
var BIDID = getUrlVarsURL(decryptedstring)["BidID"];
//var BIDID = getUrlVars()["BidID"];

var BIDTypeID = '';
var BidClosingType='';
sessionStorage.setItem("APIPath", 'http://www.support2educate.com/procurengine/API/api/');
//sessionStorage.setItem("APIPath", 'https://www.procurengine.com/API/api/');
var UrLToken = 'http://www.support2educate.com/procurengine/API/token';
//var UrLToken = 'https://www.procurengine.org/API/token';

function fetchBidHeaderDetails() {
    var tncAttachment = '';
    var anyotherAttachment = '';
    var url = '';
  
    url = sessionStorage.getItem("APIPath") + "BidVendorSummary/FetchBidDetailsForSurrogate/?BidID=" + BIDID;
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: url,
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
            console.log("dataa > ", data)
            if (data.length == 1) {
             
                var datearray = data[0].BidDate.split("/");
                var time = addMinutes(convertTo24Hour(data[0].BidTime.toLowerCase()), data[0].BidDuration);
              //  alert(time)
                var newdate = datearray[1] + '/' + datearray[0] + '/' + datearray[2];
                var BiDatetime = new Date(newdate + ' ' + time);
                var currentTime = new Date();
                //alert(BiDatetime)
                //alert(currentTime)
                if (BiDatetime > currentTime) {
                    $('#btnpassword').removeAttr('disabled');
                    $('#txtpassword').removeAttr('disabled');
                    jQuery('#lblEventID').html(BIDID);
                    jQuery('#bid_EventID').html("Event ID : " + BIDID);
                    tncAttachment = data[0].TermsConditions.replace(/\s/g, "%20");
                    anyotherAttachment = data[0].Attachment.replace(/\s/g, "%20");
                    jQuery("#lblbidsubject").text(data[0].BidSubject);
                    jQuery("#lblbidDetails").text(data[0].BidDetails);
                    jQuery("#lblbiddate").text(data[0].BidDate);
                    jQuery("#lblbidtime").text(data[0].BidTime);
                    jQuery("#lblbidtype").text(data[0].BidTypeName);
                    jQuery("#lblbidfor").text(data[0].BidFor);
                    jQuery("#lblbidsubjectTT").text(data[0].BidSubject);
                    jQuery("#lblbidDetailsTT").text(data[0].BidDetails);
                    jQuery("#lblbiddateTT").text(data[0].BidDate);
                    jQuery("#lblbidtimeTT").text(data[0].BidTime);
                    jQuery("#lblbidtypeTT").text(data[0].BidTypeName);
                    jQuery("#lblbidforTT").text(data[0].BidFor);
                    BIDTypeID = data[0].BidTypeID;
                    BidClosingType = data[0].BidClosingType;
                    jQuery("a#lnkTermsAttachment").text(data[0].TermsConditions);
                    jQuery("a#lnkTermsAttachment").attr("href", "PortalDocs/Bid/" + BIDID + "/" + tncAttachment)

                    jQuery("a#lnkAnyOtherAttachment").text(data[0].Attachment);
                    jQuery("a#lnkAnyOtherAttachment").attr("href", "PortalDocs/Bid/" + BIDID + "/" + anyotherAttachment)

                    jQuery("#lblwarehousearea").text(data[0].WareHouseArea);

                    jQuery("#lblbidduration").text(data[0].BidDuration);
                    jQuery("#lblcurrency").text(data[0].CurrencyName);
                    jQuery("#lblbiddurationTT").text(data[0].BidDuration);
                    jQuery("#lblcurrencyTT").text(data[0].CurrencyName);
                    jQuery("#lblConvRate").text(data[0].ConversionRate);
                    jQuery("#lblstatus").text(data[0].ConversionRate);
                    jQuery("#lblConvRate").text(data[0].ConversionRate);

                }
                else {
                    bootbox.alert("This bid has already expired !!!", function () {
                        //   $('.page-container').hide();
                        $('#btnpassword').attr('disabled', 'disabled')
                        $('#txtpassword').attr('disabled', 'disabled')
                        //setTimeout(function () {
                        //    closewindow();
                        //}, 1500);
                                 
                    });
                   //window.close();
                }

            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
           
            return false;
            jQuery.unblockUI();
        }
    });

}
function closewindow() {
 
   // window.location.href = "ValidateAcceptSurrogateBid.html";
   //// open('ValidateAcceptSurrogateBid.html?BidID=0', '_parent').close()
   // window.close();
}
var erroropenbid = $('#errorOpenbid');
var successopenbid = $('#successopenbid');
function validatepassword() {
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    sessionStorage.setItem("APIPath", 'http://www.support2educate.com/procurengine/API/api/');
    if (jQuery("#txtpassword").val() == "" ) {

        erroropenbid.show();
        $('#erropenbid').html('Please Enter given Password');
        erroropenbid.fadeOut(3000);
        App.scrollTo(erroropenbid, -200);

    }
    else {
        // Get Token For Password Validation
        $.ajax({
            url: UrLToken,
            type: 'POST',
            async: true,
            contentType: "application/json; charset=utf-8",
            crossDomain: true,
            "headers": {
                "accept": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            data: {
                grant_type: "password",
                username: '',
                password: jQuery("#txtpassword").val().trim(),
                linkurl: '',
                machineip: '',
                APICallType: ('SurrogateBid').toLowerCase(),
                EventID: BIDID
                // expires_in: 0,

            },
            success: function (response) {
                
                sessionStorage.setItem("Token", response.access_token)
                fnGtrTokenValidatePassword()
                
            },
            error: function (xhr, status, error) {
                sessionStorage.setItem("Token", '')
                jQuery("#txtpassword").val('')
                var myObj = JSON.parse(xhr.responseText);
                jQuery.unblockUI();
                bootbox.alert(myObj.error + ' <br>' + myObj.error_description, function () {
                });
                sessionStorage.clear();
            }
        });
       
    }
}

function fnGtrTokenValidatePassword() {
     var Data = {
            "BidID": BIDID,
            "Password": jQuery("#txtpassword").val()
        }
        //alert(JSON.stringify(Data))
        jQuery.ajax({
            url: sessionStorage.getItem("APIPath") + "RegisterParticipants/BidSurrogateValidateData",
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            type: "POST",
            data: JSON.stringify(Data),
            contentType: "application/json; charset=utf-8",
            success: function (data, status, jqXHR) {

                if (data[0].FlagStatus == "1") {
                    fetchBidHeaderDetails();
                    sessionStorage.setItem("VendorId", data[0].vendorID)
                    sessionStorage.setItem("UserType", "V")
                    sessionStorage.setItem("UserID", data[0].UserID)
                    sessionStorage.setItem("UserName", data[0].VendorName)
                    sessionStorage.setItem("BidID", BIDID)
                    sessionStorage.setItem("ISFromSurrogate", "Y")
                    sessionStorage.setItem("HomePage", "http://www.support2educate.com/procurengine/")
                    //sessionStorage.setItem("HomePage", "https://www.procurengine.com/")
                  //  sessionStorage.setItem("HomePage", "https://www.procurengine.org/")
                  //  alert(data[0].IsTermsConditionsAccepted)
                    if (data[0].IsTermsConditionsAccepted == "N" || data[0].IsTermsConditionsAccepted == "NO") {
                        setTimeout(function () {
                            $('#termscondition').modal('show');
                        }, 500);
                    }
                    else {
                        setTimeout(function () {
                            if (BIDTypeID == "7" && BidClosingType=='A') {
                            window.location = "ParticipateBidSeaExport.html";
                            }
                       else if (BIDTypeID == "7" && BidClosingType=='S') {
                           window.location = "ParticipateBidStagger.html";
                            }
                        else {
                            window.location = "ParticipateBidForwardAuction.html";
                        }
                        }, 1000);
                    }
                   
                  
                }
                else {
                    successopenbid.hide();
                    erroropenbid.show();
                    $('#erropenbid').html('Invalid password . Please Check your Password and try again.');
                    erroropenbid.fadeOut(3000);
                    App.scrollTo(erroropenbid, -200);
                    jQuery("#txtpassword").val('');
                    jQuery.unblockUI();
                }

                jQuery.unblockUI();
            },
            error: function (xhr, status, error) {

                var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }
                else{
                    successopenbid.hide();
                    erroropenbid.show();
                    $('#erropenbid').html('You have error.Please try agian.');
                    erroropenbid.fadeOut(3000);
                    App.scrollTo(erroropenbid, -200);
                }
                return false;
                jQuery.unblockUI();
            }
            
        })
    }

jQuery('#chkIsAccepted').click(function () {
    if (jQuery('#chkIsAccepted').is(':checked') == true) {
        $('#btnContinue').attr("disabled", false);
    }
    else {
        $('#btnContinue').attr("disabled", true);
    }
});
function formvalidate() {
    $('#AccprtGNc').validate({
        errorElement: 'span', //default input error message container
        errorClass: 'help-block', // default input error message class
        focusInvalid: false, // do not focus the last invalid input
        rules: {
        },

        messages: {

        },

        invalidHandler: function (event, validator) { //display error alert on form submit   
            //$('.alert-danger', $('.login-form')).show();
            //$('#alertmessage').html('User name/ Password cannot be blank.')
        },

        highlight: function (element) { // hightlight error inputs
            $(element)
                    .closest('.form-group').addClass('has-error'); // set error class to the control group
        },

        success: function (label) {
            label.closest('.form-group').removeClass('has-error');
            label.remove();
        },

        errorPlacement: function (error, element) {
            error.insertAfter(element.closest('.input-icon'));
        },

        submitHandler: function (form) {

            //form.submit(); // form validation success, call ajax form submit
            //  acceptterms();
            acceptBidTermsAuction()

        }
    });



}
function acceptBidTermsAuction() {
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    var vendorID = 0;
    vendorID = sessionStorage.getItem('VendorId');
    var acceptTerms = {
        "BidID": BIDID,
        "VendorID": vendorID
    };
    // alert(JSON.stringify(acceptTerms))
    jQuery.ajax({
        url: sessionStorage.getItem("APIPath") + "BidTermsConditions/AcceptBidTermsForSurrogate/",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "POST",
        data: JSON.stringify(acceptTerms),
        contentType: "application/json; charset=utf-8",
        success: function (data, status, jqXHR) {

            if (data[0].IsSuccess == 'Y') {
                window.location = data[0].URL
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else{
                alert('error')
                jQuery("#error").text(xhr.d);
            }
            return false;
            jQuery.unblockUI();
        }
        
    });
}