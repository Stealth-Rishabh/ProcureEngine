﻿var Changepassworderror = $('#errordivChangePassword');
var Changepasswordsuccess = $('#successdivChangePassword');
Changepassworderror.hide();
Changepasswordsuccess.hide();

function handleChangePasword() {
   
    $('#ChangePasswordfrm').validate({
        errorElement: 'span', //default input error message container
        errorClass: 'help-block', // default input error message class
        focusInvalid: false,
        rules: {

            oPassword: {
                required: true
            },
            nPassword: {
                required: true
            },
            reEnterPass: {
                required: true
            }


        },
        messages: {

            oPassword: {
                required: "Old Password Type is required."
            },
            nPassword: {
                required: "New Password is required."
            },
            reEnterPass: {
                required: "Re-Enter  is required."
            }


        },
        invalidHandler: function (event, validator) { //display error alert on form submit   
            Changepasswordsuccess.hide();
            jQuery("#errorpassword").text("You have some form errors. Please check below.");
            Changepassworderror.show();
            Changepassworderror.fadeOut(5000);
        },

        highlight: function (element) { // hightlight error inputs
            $(element)
                        .closest('.form-group').addClass('has-error'); // set error class to the control group
        },

        success: function (label) {
            label.closest('.form-group').removeClass('has-error');
            label.remove();
        },

        errorPlacement: function (error, element) {
            error.insertAfter(element.closest('.xyz'));
        },

        submitHandler: function (form) {
            Changepassworderror.hide();
            ChangePassword();

        }
    });

}
function ChangePassword() {
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    if ($("#nPassword").val() != $("#reEnterPass").val()) {
        jQuery("#errorpassword").text("Password not matched..");
        Changepassworderror.show();
        Changepassworderror.fadeOut(5000);
        jQuery.unblockUI();
        return;
    }
    else {
        var data = {
            "EmailID": sessionStorage.getItem("EmailID"),
            "OldPassword": $("#oPassword").val(),
            "NewPassword": $("#nPassword").val(),
            "BidID": sessionStorage.getItem("BidID"),
            "UserType": sessionStorage.getItem("UserType")
        }

       // alert(JSON.stringify(data));
       
        jQuery.ajax({
            url: sessionStorage.getItem("APIPath") + "ChangeForgotPassword/ChangePassword",
            type: "POST",
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            data: JSON.stringify(data),
            contentType: "application/json; charset=utf-8",
            success: function (data, status, jqXHR) {
                if (data[0].FlagStatus == "1") {
                   
                    jQuery("#sucessPassword").html("Your Password has been Changed successfully..");
                    Changepasswordsuccess.show();
                    Changepasswordsuccess.fadeOut(5000);
                    clearResetForm();
                    jQuery.unblockUI();
                }
                else {
                    jQuery("#errorpassword").html("Please try again with correct current password..");
                    Changepassworderror.show();
                    Changepassworderror.fadeOut(5000);
                    jQuery.unblockUI();
                }
            },
            error: function (xhr, status, error) {
              
                    var err = eval("(" + xhr.responseText + ")");
                    if (xhr.status === 401) {
                        error401Messagebox(err.Message);
                    }
                    jQuery.unblockUI();
                }

            

        });
    }

}

function clearResetForm() {
        $('#nPassword').val('');
        $('#reEnterPass').val('');
        $('#oPassword').val('');
    }
function fnOpenLink(linkurl,isobserver) {
    sessionStorage.setItem('IsObserver', isobserver);
    window.location = linkurl;
}
function fnConfirmArchive(RFQID) {
    bootbox.dialog({
        message: "Are you sure you want to Archive this activity ? ",
        buttons: {
            confirm: {
                label: "Yes",
                className: "btn-success",
                callback: function () {
                    fnArchive(RFQID)
                }
            },
            cancel: {
                label: "No",
                className: "btn-default",
                callback: function () {

                }
            }
        }
    });

}
function fnArchive(RFQID) {
    var Data = {
        "RFQID": RFQID,
        "UserID": sessionStorage.getItem('UserID'),
        "CustomerID": sessionStorage.getItem('CustomerID')
       
    }
    // alert(JSON.stringify(Data))
    jQuery.ajax({
        url: sessionStorage.getItem("APIPath") + "Activities/ArchiveObserverRFQ/",
         beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + Token); },
        type: "POST",
        data: JSON.stringify(Data),
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (data[0].OutPut == "1") {
                fetchDashboardData();
            }
           
        },
       
            error: function (xhr, status, error) {
               var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }
            
            jQuery.unblockUI();
        }
    })
}
function fetchDashboardData() {
 
    jQuery.ajax({
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "Activities/fetchDashboardData/?UserID=" + encodeURIComponent(sessionStorage.getItem('UserID')) + "&AuthenticationToken=" + sessionStorage.getItem('AuthenticationToken') + "&CustomerID=" + sessionStorage.getItem('CustomerID'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "GET",
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (BidData) {
           
            jQuery('#lblTodayBidCount').text(BidData[0].TodayBid[0].NoofBid)
            jQuery('#lblNotForwardedBidCount').text(BidData[0].NotForwarded[0].NoofBid)
            jQuery('#lblForwardedBidCount').text(BidData[0].Forwarded[0].NoofBid)
            jQuery('#lblAwardedBidCount').text(BidData[0].Awarded[0].NoofBid)

            jQuery('#lblopenRFQCount').text(BidData[0].TodayBidRFx[0].NoofBid)
            jQuery('#lblNotFwRFQCount').text(BidData[0].NotForwardedRFx[0].NoofBid)
            jQuery('#lblFwRFQCount').text(BidData[0].ForwardedRFx[0].NoofBid)
            jQuery('#lblAwRFQCount').text(BidData[0].ApprovedRFx[0].NoofBid)

            jQuery("#UlPendingActivity").empty();
            $('#pendingact').text("Pending Activities (" + BidData[0].PendingActivity.length + ")")
            if (BidData[0].PendingActivity.length > 0) {
               
                for (var i = 0; i < BidData[0].PendingActivity.length; i++) {
                    //fnEnryptURL(BidData[0].PendingActivity[i].LinkURL)
                   
                    //                    str = "<li><a href='BidSummarySea.html?BidID=" + BidData[i].BidID + "&BidTypeID=" + BidData[i].BidTypeID + "&BidForID=" + BidData[i].BidForID + "&CActive=Y'>";
                    str = "<li><a style='text-decoration:none;' href='javascript:;' onclick=fnOpenLink(\'" + BidData[0].PendingActivity[i].LinkURL + "'\,\'" + BidData[0].PendingActivity[i].isPPCObserver + "'\)>";
                    str += "<div class='col1'><div class='cont'>";
                    str += "<div class='cont-col1'><div class='label label-sm label-success'><i id=icon" + i + "></i></div></div>";
                    str += "<div class='cont-col2'><div class='desc'>" + BidData[0].PendingActivity[i].ActivityDescription + "</a>";
                    if (BidData[0].PendingActivity[i].isPPCObserver == "Y") {
                        str += "&nbsp;&nbsp;|<span class='label label-sm label-danger'  style='cursor:pointer' onclick=fnConfirmArchive(\'" + BidData[0].PendingActivity[i].BidID + "'\)>Archive&nbsp;<i class='fa fa-arrow-right'></i></span>";
                    }
                    str += "</div></div></div></div>";
                    //if (BidData[0].PendingActivity[i].BidTypeName == 'Product/ Services') {
                    str += "<div class='col2' style='width: 80px !important; margin-left:-80px !important;'>";
                    //}
                    //else {
                    //    str += "<div class='col2'>";
                   // }
                    str += "<div class='date'><span class='label label-sm label-info'>" + BidData[0].PendingActivity[i].ReceiptDt + "</span></div></div>";
                    str += "</li>";
                    jQuery('#UlPendingActivity').append(str);

			if (BidData[0].PendingActivity[i].BidTypeName == 'Air (Import)') {
                        $('#icon' + i).addClass('fa fa-plane');
                    } else if (BidData[0].PendingActivity[i].BidTypeName == 'Sea (Import)') {
                        $('#icon' + i).addClass('fa fa-anchor');
                    } else if (BidData[0].PendingActivity[i].BidTypeName == 'Warehouse') {
                            $('#icon' + i).addClass('fa fa-truck');
                    } else if (BidData[0].PendingActivity[i].BidTypeName == 'VQ') {
                        jQuery('#icon' + i).addClass('fa fa-question-circle');
                    } else if (BidData[0].PendingActivity[i].BidTypeName == 'RFI') {
                        jQuery('#icon' + i).addClass('fa fa-envelope-o');
                    }
                    else if (BidData[0].PendingActivity[i].BidTypeName == 'RFQ') {
                        $('#icon' + i).addClass('fa fa-envelope-o');
                    }
                    else if (BidData[0].PendingActivity[i].BidTypeName == 'eRFQ') {
                        $('#icon' + i).addClass('fa fa-envelope-o');
                    } else if (BidData[0].PendingActivity[i].BidTypeName == 'Product/ Services') {
                        $('#icon' + i).addClass('fa fa-cogs');
                    } else if (BidData[0].PendingActivity[i].BidTypeName == 'Domestic') {
                        $('#icon' + i).addClass('fa fa-home');
                    } else if (BidData[0].PendingActivity[i].BidTypeName == 'Forward Auction') {
                        $('#icon' + i).addClass('fa fa-forward');
                    }
                    else if (BidData[0].PendingActivity[i].BidTypeName == 'Reverse Auction') {
                        $('#icon' + i).addClass('fa fa-gavel');
                    } else if (BidData[0].PendingActivity[i].BidTypeName == 'Forward Auction') {
                        $('#icon' + i).addClass('fa fa-forward');
                    }
                }
            }
            else {
                jQuery('#UlPendingActivity').append("<tr><td colspan='8' style='text-align: center; color:red;'>You have no pending activity.</td></tr>");
            }


            if (BidData[0].TodayBidStatus.length >= 7) {
                jQuery('#see_all_bids_btn').show()
//                jQuery('#seeAllPortlet').addClass('portlet box purple-plum')
//                jQuery('#head-icon').addClass('fa fa-pencil-square-o')
//                $('#portlet-head').text("All Pending Confirmation");
                jQuery('#all_pending_bids_list').empty();
                for (var i = 0; i < BidData[0].TodayBidStatus.length; i++) {
                    str = "<li><a href=" + BidData[0].TodayBidStatus[i].LinkURL + ">";
                    str += "<div class='col1'><div class='cont'>";
                    str += "<div class='cont-col1'><div class='label label-sm label-success'><i id=iconbid_all" + i + "></i></div></div>";
                    str += "<div class='cont-col2'><div class='desc'>" + BidData[0].TodayBidStatus[i].ActivityDescription + "&nbsp;&nbsp;";
                    str += "<span class='label label-sm label-info'>" + BidData[0].TodayBidStatus[i].BidTypeName + "</span>";
                    str += "</div></div></div></div>";
                    str += "<div class='col2'>";
                    str += "<div class='date'>" + BidData[0].TodayBidStatus[i].BidStatus + "</div></div>";
                    str += "</a></li>";
                    jQuery('#all_pending_bids_list').append(str);
                    
                    if (BidData[0].TodayBidStatus[i].BidTypeName == 'Air (Import)') {
                        $('#iconbid_all' + i).addClass('fa fa-plane');
                    } else if (BidData[0].TodayBidStatus[i].BidTypeName == 'Sea (Import)') {
                    $('#iconbid_all' + i).addClass('fa fa-anchor');
                    } else if (BidData[0].TodayBidStatus[i].BidTypeName == 'Warehouse') {

                    $('#iconbid_all' + i).addClass('fa fa-truck');
                    } else if (BidData[0].TodayBidStatus[i].BidTypeName == 'VQ') {
                    jQuery('#iconbid_all' + i).addClass('fa fa-question-circle');
                    }
                    else if (BidData[0].TodayBidStatus[i].BidTypeName == 'RFQ') {
                    $('#iconbid_all' + i).addClass('fa fa-envelope-o');
                    }
                    else if (BidData[0].TodayBidStatus[i].BidTypeName == 'eRFQ') {
                        $('#iconbid_all' + i).addClass('fa fa-envelope-o');
                    }
                    else if (BidData[0].TodayBidStatus[i].BidTypeName == 'RFI') {
                        $('#iconbid_all' + i).addClass('fa fa-envelope-o');
                    } else if (BidData[0].TodayBidStatus[i].BidTypeName == 'Product/ Services') {
                    $('#iconbid_all' + i).addClass('fa fa-cogs');
                    } else if (BidData[0].TodayBidStatus[i].BidTypeName == 'Domestic') {
                    $('#iconbid_all' + i).addClass('fa fa-home');
                    } else if (BidData[0].TodayBidStatus[i].BidTypeName == 'Forward Auction') {
                        $('#iconbid_all' + i).addClass('fa fa-forward');
                    }
                    else if (BidData[0].TodayBidStatus[i].BidTypeName == 'Reverse Auction') {
                        $('#iconbid_all' + i).addClass('fa fa-gavel');
                    } else if (BidData[0].TodayBidStatus[i].BidTypeName == 'Forward Auction') {
                        $('#icon' + i).addClass('fa fa-forward');
                    }

                }
            }
            else {
                jQuery('#see_all_bids_btn').css('visibility', 'hidden')
            }

            jQuery("#ulList").empty();
            $('#spanPanelCaptioncount').text("(" + BidData[0].TodayBidStatus.length + ")")
            if (BidData[0].TodayBidStatus.length > 0) {
                
                for (var i = 0; i < BidData[0].TodayBidStatus.length; i++) {
                    //str = "<li><a href=" + BidData[0].TodayBidStatus[i].LinkURL + ">";
//                    if (sessionStorage.getItem('CustomerID')== '20' && BidData[0].TodayBidStatus[i].BidStatus == 'Running') {
//                        //str = "<li><a href=" + BidData[0].TodayBidStatus[i].LinkURL + ">";
//                        str = "<li><a href='javascript:;' onclick='showErrorMsg()'>";
//                    } else {
                    str = "<li><a href=" + BidData[0].TodayBidStatus[i].LinkURL + ">";
                    //}
                    str += "<div class='col1'><div class='cont'>";
                    str += "<div class='cont-col1'><div class='label label-sm label-success'><i id=iconbid" + i + "></i></div></div>";
                    str += "<div class='cont-col2'><div class='desc'>" + BidData[0].TodayBidStatus[i].ActivityDescription + "&nbsp;&nbsp;";
                    str += "<span class='label label-sm label-info'>" + BidData[0].TodayBidStatus[i].BidTypeName + "</span>";
                    str += "</div></div></div></div>";
                    str += "<div class='col2' style='width: 105px !important; margin-left:-105px !important;'>";
                    str += "<div class='date'>" + BidData[0].TodayBidStatus[i].BidStatus + "</div></div>";
                    str += "</a></li>";
                    jQuery('#ulList').append(str);
                    
		   if (BidData[0].TodayBidStatus[i].BidTypeName == 'Air (Import)') {
                        $('#iconbid' + i).addClass('fa fa-plane');
                    } else if (BidData[0].TodayBidStatus[i].BidTypeName == 'Sea (Import)') {
                        $('#iconbid' + i).addClass('fa fa-anchor');
                    } else if (BidData[0].TodayBidStatus[i].BidTypeName == 'Warehouse') {
                       
                        $('#iconbid' + i).addClass('fa fa-truck');
                    } else if (BidData[0].TodayBidStatus[i].BidTypeName == 'VQ') {
                        jQuery('#iconbid' + i).addClass('fa fa-question-circle');
                    } else if (BidData[0].TodayBidStatus[i].BidTypeName == 'RFI') {
                        jQuery('#iconbid' + i).addClass('fa fa-envelope-o');
                    }
                    else if (BidData[0].TodayBidStatus[i].BidTypeName == 'RFQ') {
                    $('#iconbid' + i).addClass('fa fa-envelope-o');
                    }
                    else if (BidData[0].TodayBidStatus[i].BidTypeName == 'eRFQ') {
                        $('#iconbid' + i).addClass('fa fa-envelope-o');
                    }
                    else if (BidData[0].TodayBidStatus[i].BidTypeName == 'Product/ Services') {
                        $('#iconbid' + i).addClass('fa fa-cogs');
                    } else if (BidData[0].TodayBidStatus[i].BidTypeName == 'Domestic') {
                        $('#iconbid' + i).addClass('fa fa-home');
                    } else if (BidData[0].TodayBidStatus[i].BidTypeName == 'Forward Auction') {
                    $('#iconbid' + i).addClass('fa fa-forward');
                    }
                    else if (BidData[0].TodayBidStatus[i].BidTypeName == 'Reverse Auction') {

                        $('#iconbid' + i).addClass('fa fa-gavel');
                    }
		
                }
            }
            else {
                jQuery('#ulList').append("<tr><td colspan='8' style='text-align: center; color:red;'>No bid is configured for today.</td></tr>");
            }

            if (BidData[0].TodayBidStatusCount.length > 0) {
                for (var i = 0; i < BidData[0].TodayBidStatusCount.length; i++) {
                    if (BidData[0].TodayBidStatusCount[i].BidStatus == "Open") {
                        //jQuery('#spanOpen').html(BidData[0].TodayBidStatusCount[i].BidCount)
                    }
                    else if (BidData[0].TodayBidStatusCount[i].BidStatus == "Not Forwarded") {
                       // jQuery('#spanNotForwarded').html(BidData[0].TodayBidStatusCount[i].BidCount)
                    }
                    else if (BidData[0].TodayBidStatusCount[i].BidStatus == "Forwarded") {
                        ////jQuery('#spanForwarded').html(BidData[0].TodayBidStatusCount[i].BidCount)
                    }
                    else if (BidData[0].TodayBidStatusCount[i].BidStatus == "Awarded") {
                       //jQuery('#spanAwarded').html(BidData[0].TodayBidStatusCount[i].BidCount)
                    }
                }
            }
            
        },
        error: function (xhr, status, error) {

            
            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            jQuery.unblockUI();
        }
    });
}


function fetchBidDataDashboard(requesttype) {
   
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    if (requesttype == 'Today') {
        //jQuery('#spanPanelCaption').html("Today's Open Bids");
        jQuery('#spanPanelCaption').html("Open Bids");
    } else if (requesttype == 'Not Forwarded') {
        jQuery('#spanPanelCaption').html("Not Forwarded Bids");
    } else if (requesttype == 'Forwarded') {
        jQuery('#spanPanelCaption').html("Bids Under Approval");
    } else if (requesttype == 'Awarded') {
        jQuery('#spanPanelCaption').html("Approved Bids");
    }
    else if (requesttype == 'TodayRFQ') {
        jQuery('#spanPanelCaption').html("Opne RFx");
    }
    else if (requesttype == 'Not ForwardedRFQ') {
        jQuery('#spanPanelCaption').html("Not Forwarded RFx");
    }
    else if (requesttype == 'ForwardedRFQ') {
        jQuery('#spanPanelCaption').html("RFx Under Approval");
    }
    else if (requesttype == 'AwardedRFQ') {
        jQuery('#spanPanelCaption').html("Approved RFx");
    }
    jQuery.ajax({
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "Activities/fetchDashboardBidDetails/?UserID=" + encodeURIComponent(sessionStorage.getItem('UserID')) + "&RequestType=" + requesttype + "&CustomerID=" + sessionStorage.getItem('CustomerID'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "GET",
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (BidData) {
           
            jQuery("#ulList").empty();
            $('#spanPanelCaptioncount').text("(" + BidData.length + ")")
            if (BidData.length > 0) {
                if (requesttype == 'Today') {
                    for (var i = 0; i < BidData.length; i++) {
                        //if (sessionStorage.getItem('CustomerID')== '20' && BidData[i].BidStatus == 'Running') {
                            //str = "<li><a href=" + BidData[i].LinkURL + ">";
                         //   str = "<li><a href='javascript:;' onclick='showErrorMsg()'>";
                        //} else {
                        str = "<li><a href=" + BidData[i].LinkURL + ">";
                        // }
                        
                        str += "<div class='col1'><div class='cont'>";
                        str += "<div class='cont-col1'><div class='label label-sm label-success'><i id=iconbidd" + i + "></i></div></div>";
                        str += "<div class='cont-col2'><div class='desc'>" + BidData[i].ActivityDescription + "&nbsp;&nbsp;";
                        str += "<span class='label label-sm label-info'>" + BidData[i].BidTypeName + "</span>";
                        str += "</div></div></div></div>";
                        //if (BidData[i].BidTypeName == 'Product/ Services') {
                        //    str += "<div class='col2' style='margin-left: -99px !important'>";
                        //} else {
                        //    str += "<div class='col2'>";
                        //}
                        str += "<div class='col2'>";
                        str += "<div class='date'>" + BidData[i].BidStatus + "</div></div>";
                        str += "</a></li>";
                        jQuery('#ulList').append(str);

                        if (BidData[i].BidTypeName == 'Air (Import)') {
                            $('#iconbidd' + i).addClass('fa fa-plane');
                        } else if (BidData[i].BidTypeName == 'Sea (Import)') {
                            $('#iconbidd' + i).addClass('fa fa-anchor');
                        } else if (BidData[i].BidTypeName == 'Warehouse') {

                            $('#iconbidd' + i).addClass('fa fa-truck');
                        } else if (BidData[i].BidTypeName == 'VQ') {
                            jQuery('#iconbidd' + i).addClass('fa fa-question-circle');
                        } else if (BidData[i].BidTypeName == 'RFI') {
                            jQuery('#iconbidd' + i).addClass('fa fa-envelope-o');
                        } else if (BidData[i].BidTypeName == 'RFQ') {
                            $('#iconbidd' + i).addClass('icon-envelope');
                        } else if (BidData[i].BidTypeName == 'Product/ Services') {
                            $('#iconbidd' + i).addClass('fa fa-cogs');
                        } else if (BidData[i].BidTypeName == 'Domestic') {
                            $('#iconbidd' + i).addClass('fa fa-home');
                        } else if (BidData[i].BidTypeName == 'Forward Auction') {

                            $('#iconbidd' + i).addClass('fa fa-forward');
                        }
                        else if (BidData[i].BidTypeName == 'Reverse Auction') {

                            $('#iconbidd' + i).addClass('fa fa-gavel');
                        }
                    }
                }
                else {
                    for (var i = 0; i < BidData.length; i++) {

                        str = "<li><a href=" + BidData[i].LinkURL + ">";
                        str += "<div class='col1'><div class='cont'>";
                        str += "<div class='cont-col1'><div class='label label-sm label-success'><i id=iconbidd" + i + "></i></div></div>";
                        str += "<div class='cont-col2'><div class='desc'>" + BidData[i].ActivityDescription;
                        str += "</div></div></div></div>";
                        if (BidData[i].BidTypeName == 'Product/ Services') {
                            str += "<div class='col2' style='margin-left: -99px !important'>";
                        } else {
                            str += "<div class='col2'>";
                        }

                        str += "<div class='date'><span class='label label-sm label-warning'>" + BidData[i].BidTypeName + "</span></div></div>";
                        str += "</a></li>";
                        jQuery('#ulList').append(str);

                        if (BidData[i].BidTypeName == 'Air (Import)') {
                            $('#iconbidd' + i).addClass('fa fa-plane');
                        } else if (BidData[i].BidTypeName == 'Sea (Import)') {
                            $('#iconbidd' + i).addClass('fa fa-anchor');
                        } else if (BidData[i].BidTypeName == 'Warehouse') {
                            $('#iconbidd' + i).addClass('fa fa-truck');
                        } else if (BidData[i].BidTypeName == 'VQ') {
                            jQuery('#iconbidd' + i).addClass('fa fa-question-circle');
                        } else if (BidData[i].BidTypeName == 'RFI') {
                            jQuery('#iconbidd' + i).addClass('fa fa-envelope-o');
                        }
                        else if (BidData[i].BidTypeName == 'RFQ') {
                            $('#iconbidd' + i).addClass('icon-envelope');
                        }
                        else if (BidData[i].BidTypeName == 'eRFQ') {
                            $('#iconbidd' + i).addClass('icon-envelope');
                        }
                        else if (BidData[i].BidTypeName == 'Product/ Services') {
                            $('#iconbidd' + i).addClass('fa fa-cogs');
                        } else if (BidData[i].BidTypeName == 'Domestic') {
                            $('#iconbidd' + i).addClass('fa fa-home');
                        } else if (BidData[i].BidTypeName == 'Forward Auction') {
                            $('#iconbidd' + i).addClass('fa fa-forward');
                        }
                        else if (BidData[i].BidTypeName == 'Reverse Auction') {

                            $('#iconbidd' + i).addClass('fa fa-gavel');
                        }
                    }
                }


            }
            else {
                jQuery('#ulList').append("<tr><td colspan='8' style='text-align: center; color:red;'>No record found</td></tr>");
            }
        },
        error: function (xhr, status, error) {

           
            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            jQuery.unblockUI();
        }
    });
    jQuery.unblockUI();
}



function showErrorMsg() { 
    bootbox.alert("You can not proceed further while current bid is running.");
}


jQuery("#searchPendingActivities").keyup(function () {

    //jQuery('#searchhostelbtn').live('click', function (e) {
    jQuery("#UlPendingActivity li:has(div)").hide(); // Hide all the rows.

    var iCounter = 0;
    var sSearchTerm = jQuery('#searchPendingActivities').val(); //Get the search box value

    if (sSearchTerm.length == 0) //if nothing is entered then show all the rows.
    {
        jQuery("#UlPendingActivity li:has(div)").show();
        return false;
    }

    //Iterate through all the td.
    jQuery("#UlPendingActivity li:has(div)").children().each(function () {

        var cellText = jQuery(this).text().toLowerCase();
        if (cellText.indexOf(sSearchTerm.toLowerCase()) >= 0) //Check if data matches
        {

            jQuery(this).parent().show();
            iCounter++;

            return true;
        }

    });
});


jQuery("#searchPendingBids").keyup(function () {

    //jQuery('#searchhostelbtn').live('click', function (e) {
    jQuery("#ulList li:has(div)").hide(); // Hide all the rows.

    var iCounter = 0;
    var sSearchTerm = jQuery('#searchPendingBids').val(); //Get the search box value

    if (sSearchTerm.length == 0) //if nothing is entered then show all the rows.
    {
        jQuery("#ulList li:has(div)").show();
        return false;
    }

    //Iterate through all the td.
    jQuery("#ulList li:has(div)").children().each(function () {

        var cellText = jQuery(this).text().toLowerCase();
        if (cellText.indexOf(sSearchTerm.toLowerCase()) >= 0) //Check if data matches
        {

            jQuery(this).parent().show();
            iCounter++;

            return true;
        }

    });
});