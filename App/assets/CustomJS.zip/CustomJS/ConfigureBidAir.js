﻿
jQuery('#btnpush').click(function (e) {
    jQuery('#approverList > option:selected').appendTo('#mapedapprover');
});
jQuery('#btnpull').click(function (e) {
    jQuery('#mapedapprover > option:selected').appendTo('#approverList');
});


function fetchVendorparticipanType() {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "BidType/fetchBidType/?CustomerID=" + sessionStorage.getItem("CustomerID") + "&BidTypeID=0&excludeStatus=N&UserID=" + encodeURIComponent(sessionStorage.getItem('UserID')) + "&AuthenticationToken=" + sessionStorage.getItem('AuthenticationToken'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (bidTypedata) {
            var strbidtypes = "<div id=\"divrblist\" class=\"checkbox-list\">";
            for (i = 0; i < bidTypedata.length; i++) {
                //strbidtypes += "<label><div class=\"radio\" style=\"cursor:pointer\" ><span id=\"spanrb\"><input type=\"radio\" grou name=\"rbradio\"  onchange=\"Validate(this)\" value=" + bidTypedata[i].BidTypeID + "></span></div>" + bidTypedata[i].BidTypeName + " </label>";
                strbidtypes += "<div class=\"col-md-3\">";
                strbidtypes += "<div class=\"checker\" id=\"uniform-chkbidTypes\"><span  id=\"spanchecked\"><input type=\"checkbox\" id=\"chkBidType\" style=\"cursor:pointer\"  onchange=\"Validate(this)\" name=\"chkBidType\"/></span></div>";
                strbidtypes += "<label class=\"control-label\" id=\"BidTypeID\">&nbsp;&nbsp;" + bidTypedata[i].BidTypeName + "</label><input type=\"hidden\" id=\"hdnBidTypeID\" value=" + bidTypedata[i].BidTypeID + " /></div>";

            }
            strbidtypes += "</div>";
            jQuery("div#divbidtypelist").append(strbidtypes);
        }
    });
}

function FetchContinent(ContinentID) {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ConfigureBid/FetchContinent/?ContinentID=" + ContinentID + "&excludeStatus=N",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        dataType: "json",
        success: function (data) {
            jQuery("#ddlSector").empty();
            jQuery("#ddlSector").append(jQuery("<option ></option>").val("").html("Select"));
            for (var i = 0; i < data.length; i++) {
                jQuery("#ddlSector").append(jQuery("<option></option>").val(data[i].ContinentId).html(data[i].ContinentNm));
            }
        }
    });
    jQuery("#ddlCountry").append(jQuery("<option ></option>").val("").html("Select"));
}
jQuery("#ddlSector").change(function () {
    var continentID = $("#ddlSector option:selected").val();
    var countryID = "0";
    fetchCountry(continentID, countryID)
});
function fetchCountry(continentID,countryID) {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ConfigureBid/fetchCountry/?ContinentId=" + continentID + "&CountryID=0&excludeStatus=N",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        dataType: "json",
        success: function (data) {
            jQuery("#ddlCountry").empty();
            jQuery("#ddlCountry").append(jQuery("<option ></option>").val("").html("Select"));
            for (var i = 0; i < data.length; i++) {
                jQuery("#ddlCountry").append(jQuery("<option ></option>").val(data[i].CountryId).html(data[i].CountryNm));
            }
            if (countryID != '0') {
                jQuery('#ddlCountry').val(countryID);
               
            }
        }
    });
}
function fetchBidTypeMapping() {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ConfigureBid/fetchBidTypeMapping/?CustomerID=" + sessionStorage.getItem("CustomerID") + "&BidTypeID=0",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        dataType: "json",
        success: function (data) {
            jQuery("#ddlBidForId").empty();
            jQuery("#ddlBidForId").append(jQuery("<option ></option>").val("").html("Select"));
            for (var i = 0; i < data.length; i++) {
                jQuery("#ddlBidForId").append(jQuery("<option ></option>").val(data[i].BidTypeID).html(data[i].BidTypeName));
            }
            jQuery("#ddlBidForId").val('2').attr("selected", "selected");
        }
    });
    fetchBidFor("2");
    jQuery("#ddlBidForId").prop("disabled", true);
   
}

function fetchBidFor(BidTypeID) {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ConfigureBid/fetchBidFor/?BidTypeID=" + BidTypeID,
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        dataType: "json",
        success: function (data) {
            jQuery("#ddlBidFor").empty();
            jQuery("#ddlBidFor").append(jQuery("<option ></option>").val("").html("Select"));
            for (var i = 0; i < data.length; i++) {
                jQuery("#ddlBidFor").append(jQuery("<option></option>").val(data[i].BidForID).html(data[i].BidFor));
            }
        }
    });
}

function FetchCurrency(CurrencyID) {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ConfigureBid/FetchCurrency/?CurrencyID=" + CurrencyID + "&excludeStatus=N",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        dataType: "json",
        success: function (data) {
            jQuery("#dropCurrency").empty();
            jQuery("#dropCurrency").append(jQuery("<option ></option>").val("").html("Select"));
            for (var i = 0; i < data.length; i++) {
                jQuery("#dropCurrency").append(jQuery("<option></option>").val(data[i].CurrencyId).html(data[i].CurrencyNm));
            }
        }
    });
}

function fetchRegisterUser(bidtypeid) {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "RegisterUser/fetchRegisterUser/?CustomerID=" + sessionStorage.getItem("CustomerID") + "&UserID=0&BidTypeID=" + bidtypeid + "&LoginUserID=" + encodeURIComponent(sessionStorage.getItem('UserID')) + "&AuthenticationToken=" + sessionStorage.getItem('AuthenticationToken'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        //url: sessionStorage.getItem("APIPath") + "RegisterUser/fetchRegisterUser/?CustomerID=" + sessionStorage.getItem("CustomerID") + "&UserID=0&BidID=" + bidid + "&AuthenticationToken=" + sessionStorage.getItem('AuthenticationToken'),
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data) {
            jQuery("#approverList").empty();
            for (var i = 0; i < data.length; i++) {
                jQuery("#approverList").append(jQuery("<option></option>").val(data[i].UserID).html(data[i].UserName));
            }
        }
    });

}
function FetchVender(ByBidTypeID) {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ConfigureBid/FetchVendor/?ByBidTypeID=" + ByBidTypeID + "&CustomerID=" + sessionStorage.getItem('CustomerID'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        dataType: "json",
        success: function (data) {
        jQuery("#tblvendorlist > tbody").empty();
        var vName = '';
        for (var i = 0; i < data.length; i++) {
            vName = data[i].VendorName;
            var str = "<tr><td><div class=\"checker\" id=\"uniform-chkbidTypes\"><span  id=\"spanchecked\"><input type=\"checkbox\" Onclick=\"Check(this,\'" + vName + "'\,\'" + data[i].VendorID + "'\)\"; id=\"chkvender" + i + "\" value=" + data[i].VendorID + " style=\"cursor:pointer\" name=\"chkvender\"/></span></div></td><td> " + data[i].VendorName + " </td></tr>";
                jQuery('#tblvendorlist > tbody').append(str);
            }
        }
    });
}


$("#chkAll").click(function() {

    if ($("#chkAll").is(':checked') == true) {
        $('#divvendorlist').find('span#spandynamic').hide();
        $('table#tblvendorlist').closest('.inputgroup').removeClass('has-error');
        jQuery('#selectedvendorlists> tbody').empty()
        jQuery('#selectedvendorlistsPrev> tbody').empty()
        vCount = 0;
        $("#tblvendorlist> tbody > tr").each(function(index) {
            $(this).find("span#spanchecked").addClass("checked");
            $('#chkvender' + vCount).prop("disabled", true);
            var vendorid = $('#chkvender' + vCount).val()
            var v = vCount;
            vCount = vCount + 1;
            var vname = $.trim($(this).find('td:eq(1)').html())
            jQuery('#selectedvendorlists').append('<tr id=SelecetedVendor' + vendorid + '><td class=hide>' + vendorid + '</td><td>' + vname + '</td><td><a href="javascript:;" class="btn btn-xs btn-danger" onclick="removevendor(SelecetedVendor' + vendorid + ',' + 'chkvender' + v + ',SelecetedVendorPrev' + vendorid + ')"><i class="glyphicon glyphicon-remove-circle"></i></a></td></tr>')
            jQuery('#selectedvendorlistsPrev').append('<tr id=SelecetedVendorPrev' + vendorid + '><td class=hide>' + vendorid + '</td><td>' + vname + '</td></tr>')

        });
    }
    else {
        $("#tblvendorlist> tbody > tr").each(function(index) {
            $(this).find("span#spanchecked").removeClass("checked");
            vCount = 0;
            $('input[name="chkvender"]').prop('disabled', false);
            jQuery('#selectedvendorlists> tbody').empty()
            jQuery('#selectedvendorlistsPrev> tbody').empty()
        });

    }
    if (vCount > 0) {
        jQuery('#selectedvendorlists').show()
        jQuery('#selectedvendorlistsPrev').show()
    }
    else {
        jQuery('#selectedvendorlists').hide()
        jQuery('#selectedvendorlistsPrev').hide()
    }
});

var vCount = 0;
function Check(event, vname, vendorID) {
    if ($(event).closest("span#spanchecked").attr('class') == 'checked') {
        $(event).closest("span#spanchecked").removeClass("checked")
    }
    else {
        vCount = vCount + 1;
        var EvID = event.id;
        $(event).prop("disabled", true);
        $(event).closest("span#spanchecked").addClass("checked")
        jQuery('#selectedvendorlists').append('<tr id=SelecetedVendor' + vendorID + '><td class=hide>' + vendorID + '</td><td>' + vname + '</td><td><a href="javascript:;" class="btn btn-xs btn-danger" onclick="removevendor(SelecetedVendor' + vendorID + ',' + EvID + ',SelecetedVendorPrev' + vendorID + ')"><i class="glyphicon glyphicon-remove-circle"></i></a></td></tr>')
        jQuery('#selectedvendorlistsPrev').append('<tr id=SelecetedVendorPrev' + vendorID + '><td class=hide>' + vendorID + '</td><td>' + vname + '</td></tr>')
        $('#divvendorlist').find('span#spandynamic').hide();
        $('table#tblvendorlist').closest('.inputgroup').removeClass('has-error');
    }
    if (vCount > 0) {
        jQuery('#selectedvendorlists').show()
        jQuery('#selectedvendorlistsPrev').show()
    }
    else {
        jQuery('#selectedvendorlists').hide()
        jQuery('#selectedvendorlistsPrev').hide()
    }
}


function removevendor(trid, chkid, Prevtrid) {
    vCount = vCount - 1;

    $('#' + trid.id).remove()
    $('#' + Prevtrid.id).remove()
    $(chkid).closest("span#spanchecked").removeClass("checked")
    $(chkid).prop("disabled", false);
    if (vCount > 0) {
        jQuery('#selectedvendorlists').show()
        jQuery('#selectedvendorlistsPrev').show()
    }
    else {

        $('#chkAll').closest("span").removeClass("checked")
        $('#chkAll').prop("checked", false);
        jQuery('#selectedvendorlists').hide()
        jQuery('#selectedvendorlistsPrev').hide()
        
    }
    
    
}



    ////  validation parts ///////


var FormWizard = function() {
    return {
        init: function() {
            if (!jQuery().bootstrapWizard) {
                return;
            }
            function format(state) {
                if (!state.id) return state.text; // optgroup
                return "<img class='flag' src='assets/global/img/flags/" + state.id.toLowerCase() + ".png'/>&nbsp;&nbsp;" + state.text;
            }
            var form = $('#submit_form');
            var error = $('.alert-danger', form);
            var success = $('.alert-success', form);

            form.validate({
                doNotHideMessage: true, //this option enables to show the error/success messages on tab switch.
                errorElement: 'span', //default input error message container
                errorClass: 'help-block help-block-error', // default input error message class
                focusInvalid: false, // do not focus the last invalid input
                rules: {
                    ddlSector: {
                        required: true
                    },
                    ddlCountry: {
                        required: true
                    },
                    ddlBidFor: {
                        required: true
                    },
                    txtBidDuration: {
                        required: true,
                        number: true,
                        minlength: 1,
                        maxlength: 3
                    },
                    txtBidSubject: {
                        required: true
                    },
                    txtbiddescription: {
                        required: true
                    },
                    dropCurrency: {
                        required: true
                    },
                    txtConversionRate: {
                        required: true,
                        number: true,
                        minlength: 1,
                        maxlength: 3
                    },
                    txtbidDate: {
                        required: true
                    },
                    txtfreight45: {
                        number: true,
                        minlength: 1,
                        maxlength: 5
                    },
                    txtexwork45: {
                        number: true,
                        minlength: 1,
                        maxlength: 5
                    },
                    txtfreight100: {
                        number: true,
                        minlength: 1,
                        maxlength: 5
                    },
                    txtexwork100: {
                        number: true,
                        minlength: 1,
                        maxlength: 5
                    },
                    txtfreight300: {
                        number: true,
                        minlength: 1,
                        maxlength: 5
                    },
                    txtexwork300: {
                        number: true,
                        minlength: 1,
                        maxlength: 5
                    },
                    txtfreight500: {
                        number: true,
                        minlength: 1,
                        maxlength: 5
                    },
                    txtexwork500: {
                        number: true,
                        minlength: 1,
                        maxlength: 5
                    },
                    txtfreigh1000: {
                        number: true,
                        minlength: 1,
                        maxlength: 5
                    },
                    txtexwork1000: {
                        number: true,
                        minlength: 1,
                        maxlength: 5
                    },
                    txtbidTime: {
                        required: true
                    },
                    file1: {
                        required: true
                    },
                    mapedapprover: {
                        required: true
                    }
                },
                messages: {
                    'payment[]': {
                        required: "Please select at least one option",
                        minlength: jQuery.validator.format("Please select at least one option")
                    }
                },
                errorPlacement: function(error, element) {
                    if (element.attr("name") == "gender") {
                        error.insertAfter("#form_gender_error");
                    } else if (element.attr("name") == "payment[]") {
                        error.insertAfter("#form_payment_error");
                    } else {
                        error.insertAfter(element);
                    }

                    if ($("#txtbidDate").closest('.inputgroup').attr('class') == 'inputgroup has-error') {
                        $("#btncal").css("margin-top", "-22px");
                    }
                },
                invalidHandler: function(event, validator) {

                    Metronic.scrollTo(error, -200);
                },
                highlight: function(element) {
                    $(element)
                        .closest('.inputgroup').removeClass('has-success').addClass('has-error');
                },
                unhighlight: function(element) {
                    $(element)
                        .closest('.inputgroup').removeClass('has-error');
                },
                success: function(label) {
                    if (label.attr("for") == "gender" || label.attr("for") == "payment[]") {
                        label
                            .closest('.inputgroup').removeClass('has-error').addClass('has-success');
                        label.remove();
                    } else {
                        label
                            .addClass('valid') // mark the current input as valid and display OK icon
                        .closest('.inputgroup').removeClass('has-error').addClass('has-success'); // set success class to the control group
                    }
                    if ($("#txtbidDate").closest('.inputgroup').attr('class') == 'inputgroup has-error') {
                        $("#txtbidDate").closest('.inputgroup').find("#btncal").css("margin-top", "-22px");
                    }
                },

                submitHandler: function(form) {
                    success.show();
                    error.hide();
                }

            });

            var displayConfirm = function() {
                $('#tab4 .form-control-static', form).each(function() {
                    var input = $('[name="' + $(this).attr("data-display") + '"]', form);
                    if (input.is(":radio")) {
                        input = $('[name="' + $(this).attr("data-display") + '"]:checked', form);
                    }
                    if (input.is(":text") || input.is("textarea")) {
                        $(this).html(input.val());
                    } else if (input.is("select")) {
                        $(this).html(input.find('option:selected').text());
                    } else if (input.is(":radio") && input.is(":checked")) {
                        $(this).html(input.attr("data-title"));
                    } else if ($(this).attr("data-display") == 'payment') {
                        var payment = [];
                        $('[name="payment[]"]:checked').each(function() {
                            payment.push($(this).attr('data-title'));
                        });
                        $(this).html(payment.join("<br>"));
                    }
                });
            }

            var handleTitle = function(tab, navigation, index) {
                var total = navigation.find('li').length;
                var current = index + 1;
                // set wizard title
                $('.step-title', $('#form_wizard_1')).text('Step ' + (index + 1) + ' of ' + total);
                // set done steps
                jQuery('li', $('#form_wizard_1')).removeClass("done");
                var li_list = navigation.find('li');
                for (var i = 0; i < index; i++) {
                    jQuery(li_list[i]).addClass("done");
                }

                if (current == 1) {
                    $('#form_wizard_1').find('.button-previous').hide();
                } else {
                    $('#form_wizard_1').find('.button-previous').show();
                }

                if (current >= total) {
                    $('#form_wizard_1').find('.button-next').hide();
                    $('#form_wizard_1').find('.button-submit').show();
                    displayConfirm();
                } else {
                    $('#form_wizard_1').find('.button-next').show();
                    $('#form_wizard_1').find('.button-submit').hide();
                }
                Metronic.scrollTo($('.page-title'));
            }

            // default form wizard
            $('#form_wizard_1').bootstrapWizard({
                'nextSelector': '.button-next',
                'previousSelector': '.button-previous',
                onTabClick: function(tab, navigation, index, clickedIndex) {
                    return false;
                },
                onNext: function(tab, navigation, index) {
                    success.hide();
                    error.hide();
                    if (index == 1) {
                        if (form.valid() == false) {
                            form.validate();
                            return false;
                        }
                        else {
                            Dateandtimevalidate('index1')

                        }
                    }
                    if (parseInt(index) == 2) {
                        if (ValidateModelClass() == 'false') {
                            return false;
                        }
                        else if (form.valid() == false) {
                            form.validate();
                            return false;
                        }
                        else {
                            ConfigureBidForAirTab2();
                            getBidParametersForPreview();
                        }
                    }
                    handleTitle(tab, navigation, index);
                },
                onPrevious: function(tab, navigation, index) {
                    success.hide();
                    error.hide();
                    handleTitle(tab, navigation, index);
                },
                onTabShow: function(tab, navigation, index) {
                    var total = navigation.find('li').length;
                    var current = index + 1;
                    var $percent = (current / total) * 100;
                    $('#form_wizard_1').find('.progress-bar').css({
                        width: $percent + '%'
                    });
                }
            });
            $('#form_wizard_1').find('.button-previous').hide();
            $('#form_wizard_1 .button-submit').click(function() {
                if (ValidateVendor() == 'false') {
                    return false;
                }
                else {
                    Dateandtimevalidate('index3');
                    return true;
                }

            }).hide();

            //unblock code
        }
    };
} ();
    function ValidateVendor() {
        var status = "false";

        var i = 0;
        $('#divvendorlist').find('span#spandynamic').hide();

        $("#tblvendorlist> tbody > tr").each(function (index) {

            if ($(this).find("span#spanchecked").attr('class') == 'checked') {
                i = i + 1;
                if (i >= 2) {

                    status = "True";
                }
                else {
                    status == "false";
                }

            }

        });

        if (status == "false") {

            $('.alert-danger').show();
            $('#spandanger').html('Please select atleast two vendors');
            Metronic.scrollTo($('.alert-danger'), -200);
            $('.alert-danger').fadeOut(5000);
            $('table#tblvendorlist').closest('.inputgroup').addClass('has-error');

            status = "false";

        }

        return status;
        
    }
    $('input[type=radio]').click(function () {
        $("div#tab2 > div").each(function (index) {
            if ($(this).find('div.radio-list').find('input[type=radio]').is(':checked') == true) {
                status = "True";
                $('div#divmodelclassvalidation').find('span#spandynamic').hide();
            }
        });
    });

    function ValidateModelClass() {
        var status = "false";
        var evement = "";
        $('div#divmodelclassvalidation').find('span#spandynamic').hide();
        $("div#tab2 > div").each(function (index) {
            if ($(this).find('div.radio-list').find('input[type=radio]').is(':checked') == true) {
                status = "True";
            }
        });
        if (status == "false") {
            evement = "<div style=\"clear:both\"></div><span id=\"spandynamic\" style=\"color:#b94a48; margin-left: 20px;\">Please select Model Class<span>";
            $('div#divmodelclassvalidation').append(evement);
            status = "false";
        }
        return status;
    }
    jQuery('#txtweightagetfreight').blur(function () {
        var weightagefreight = ($('#txtweightagetfreight').val() == '') ? '0' : $('#txtweightagetfreight').val();
        var weightageExworks = '0';
        //debugger;
        //if ($('#txtweightagetexwork').is(":disabled") == true && parseInt(weightagefreight) != 100) {
        if (parseInt($('#ddlBidFor').val()) == 2 && parseInt(weightagefreight) != 100) {
            $('#txtweightagetfreight').val('100');
            $('#txtweightagetexwork').val('0')
        }
        else {
            
            weightageExworks = 100 - weightagefreight
            $('#txtweightagetexwork').val(weightageExworks)
        }
        

    });
    

function fetchAirBidDetails() {
        var replaced1 = '';
        var replaced2 = '';
        jQuery.ajax({
            contentType: "application/json; charset=utf-8",
            url: sessionStorage.getItem("APIPath") + "ConfigureBidAir/fetchAirConfigurationData/?UserID=" + encodeURIComponent(sessionStorage.getItem('UserID')) + "&BidID=" + $('#hddn_bidID_Air').val() + "&AuthenticationToken=" + sessionStorage.getItem('AuthenticationToken'),
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            type: "GET",
            cache: false,
            crossDomain: true,
            dataType: "json",
            success: function (BidData) {
                
                jQuery('#txtBidSubject').val(BidData[0].BidDetails[0].BidSubject)
                jQuery('#txtBidDuration').val(BidData[0].BidDetails[0].BidDuration)
                jQuery('#txtbiddescription').val(BidData[0].BidDetails[0].BidDetails)
                jQuery('#txtbidDate').val(BidData[0].BidDetails[0].BidDate)
                jQuery('#txtbidTime').val(BidData[0].BidDetails[0].BidTime)
                
               
                setTimeout(function () {
                    $('#ddlSector').val(BidData[0].BidDetails[0].ContinentId)
                    jQuery("#dropCurrency").val(BidData[0].BidDetails[0].CurrencyID).attr("selected", "selected");
                    jQuery('#ddlBidFor').val(BidData[0].BidDetails[0].BidForID)
                    fetchCountry(BidData[0].BidDetails[0].ContinentId, BidData[0].BidDetails[0].CountryID);
                }, 1000)
                jQuery('#txtConversionRate').val(BidData[0].BidDetails[0].ConversionRate)
                if (BidData[0].BidApproverDetails.length > 0) {
                    for (var i = 0; i < BidData[0].BidApproverDetails.length; i++) {

                        jQuery('#mapedapprover').append(jQuery('<option selected></option>').val(BidData[0].BidApproverDetails[i].UserID).html(BidData[0].BidApproverDetails[i].ApproverName))
                    }
                }
                if (BidData[0].BidDetails[0].TermsConditions != 'xyz') {

                    $('#file1').attr('disabled', true);
                    $('#closebtn').removeClass('display-none');
                    replaced1 = BidData[0].BidDetails[0].TermsConditions.replace(/\s/g, "%20")
                    replaced2 = BidData[0].BidDetails[0].Attachment.replace(/\s/g, "%20")
                    $('#filepthterms').attr('href', 'PortalDocs/Bid/' + $('#hddn_bidID_Air').val() + '/' + replaced1).html(BidData[0].BidDetails[0].TermsConditions);
                    $('#filepthattach').attr('href', 'PortalDocs/Bid/' + $('#hddn_bidID_Air').val() + '/' + replaced2).html(BidData[0].BidDetails[0].Attachment);
                }
                
                
                if (BidData[0].BidDetails[0].ModelClass == 1) {
                    $('#Radio1').attr('checked', 'checked');
                    $('#Radio1').closest('span').addClass("checked")
                }
                if (BidData[0].BidDetails[0].ModelClass == 2) {
                    $('#rb45').attr('checked', 'checked');
                    $('#rb45').closest('span').addClass("checked")
                }
                if (BidData[0].BidDetails[0].ModelClass == 3) {
                    $('#rb100').attr('checked', 'checked');
                    $('#rb100').closest('span').addClass("checked")

                }
                if (BidData[0].BidDetails[0].ModelClass == 4) {
                    $('#rb300').attr('checked', 'checked');
                    $('#rb300').closest('span').addClass("checked")
                }
                if (BidData[0].BidDetails[0].ModelClass == 5) {
                    $('#rb500').attr('checked', 'checked');
                    $('#rb500').closest('span').addClass("checked")
                }
                if (BidData[0].BidDetails[0].ModelClass == 6) {
                    $('#rb1000').attr('checked', 'checked');
                    $('#rb1000').closest('span').addClass("checked")
                }
              
                
                //alert(BidData[0].BidDetails[0].TargetFreightMin)
                if (BidData[0].BidDetails[0].TargetFreightMin != 0) {
                    $('#txtfreightMin').val(BidData[0].BidDetails[0].TargetFreightMin);
                } 
                if (BidData[0].BidDetails[0].TargetExWorksMin != 0) {
                    $('#txtexworkMin').val(BidData[0].BidDetails[0].TargetExWorksMin);
                } 
                if (BidData[0].BidDetails[0].TargetFreightPlus45 != 0) {
                    $('#txtfreight45').val(BidData[0].BidDetails[0].TargetFreightPlus45);
                } 
                if (BidData[0].BidDetails[0].TargetExWorksPlus45 != 0) {
                    $('#txtexwork45').val(BidData[0].BidDetails[0].TargetExWorksPlus45);
                } 
                if (BidData[0].BidDetails[0].TargetFreightPlus100 != 0) {
                    $('#txtfreight100').val(BidData[0].BidDetails[0].TargetFreightPlus100);
                } 
                if (BidData[0].BidDetails[0].TargetExWorksPlus100 != 0) {
                    $('#txtexwork100').val(BidData[0].BidDetails[0].TargetExWorksPlus100);

                } 
                if (BidData[0].BidDetails[0].TargetFreightPlus300 != 0) {
                    $('#txtfreight300').val(BidData[0].BidDetails[0].TargetFreightPlus300);
                } 
                if (BidData[0].BidDetails[0].TargetExWorksPlus300 != 0) {
                    $('#txtexwork300').val(BidData[0].BidDetails[0].TargetExWorksPlus300);
                } 
                if (BidData[0].BidDetails[0].TargetExWorksPlus300 != 0) {
                    $('#txtfreight500').val(BidData[0].BidDetails[0].TargetExWorksPlus300);
                } 
                if (BidData[0].BidDetails[0].TargetExWorksPlus500 != 0) {
                    $('#txtexwork500').val(BidData[0].BidDetails[0].TargetExWorksPlus500);
                } 
                if (BidData[0].BidDetails[0].TargetFreightPlus1000 != 0) {
                    $('#txtfreight1000').val(BidData[0].BidDetails[0].TargetFreightPlus1000);
                } 
                if (BidData[0].BidDetails[0].TargetExWorksPlus1000 != 0) {
                    $('#txtexwork1000').val(BidData[0].BidDetails[0].TargetExWorksPlus1000);
                } 
                
                
                
                
                
                //$('#').val();
                
            }
        });

    }


function ConfigureBidForAirTab1() {
    
    var DataTab1 = {
        "BidID": $('#hddn_bidID_Air').val(),
        "BidTypeID": '2',
        "ContinentId": $("#ddlSector").val(),
        "CountryID": $("#ddlCountry option:selected").val(),
        "BidForID": $("#ddlBidFor option:selected").val(),
        "BidDuration": $("#txtBidDuration").val(),
        "BidSubject": $("#txtBidSubject").val(),
        "BidDescription": $("#txtbiddescription").val(),
        "BidDate": $("#txtbidDate").val(),
        "BidTime": $("#txtbidTime").val(),
        "CurrencyID": $("#dropCurrency option:selected").val(),
        "ConversionRate": jQuery("#txtConversionRate").val(),
        "UserId": sessionStorage.getItem('UserID'),
        "CustomerID": sessionStorage.getItem('CustomerID')
        
    }
    //alert(JSON.stringify(DataTab1))
    jQuery.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ConfigureBidAir/ConfigureBidInsAir/",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        crossDomain: true,
        data: JSON.stringify(DataTab1),
        dataType: "json",
        success: function (data) {
            
            if (window.location.search) {

                $('#hddn_bidID_Air').val(getUrlVars()["BidID"])
            }
            else {
                $('#hddn_bidID_Air').val(data[0].BidID);
            }          
            
        }
    });


}

function ConfigureBidForAirTab2() {

    var TermsConditionFileName = '';
    var AttachementFileName = '';

    if ($('#filepthterms').html() != '') {
        TermsConditionFileName = jQuery('#filepthterms').html();
    } else {
        TermsConditionFileName = jQuery('#file1').val().substring(jQuery('#file1').val().lastIndexOf('\\') + 1);
    }


    if (($('#filepthattach').html() != '') && (jQuery('#file2').val() =='')) {
        AttachementFileName = jQuery('#filepthattach').html();
    } else {
        AttachementFileName = jQuery('#file2').val().substring(jQuery('#file2').val().lastIndexOf('\\') + 1);
    }

    var DataTab2 = {
        "BidID": $('#hddn_bidID_Air').val(),
        "TargetFreightMin": jQuery("#txtfreight45").val(),
        "TargetExWorksMin": jQuery("#txtexwork45").val(),
        "TargetFreightPlus45": jQuery("#txtfreight45").val(),
        "TargetExWorksPlus45": jQuery("#txtexwork45").val(),
        "TargetFreightPlus100": jQuery("#txtfreight100").val(),
        "TargetExWorksPlus100": jQuery("#txtexwork100").val(),
        "TargetFreightPlus300": jQuery("#txtfreight300").val(),
        "TargetExWorksPlus300": jQuery("#txtexwork300").val(),
        "TargetFreightPlus500": jQuery("#txtfreight500").val(),
        "TargetExWorksPlus500": jQuery("#txtexwork500").val(),
        "TargetFreightPlus1000": jQuery("#txtfreight1000").val(),
        "TargetExWorksPlus1000": jQuery("#txtexwork1000").val(),

        "ModelClass": jQuery("div.radio-list").find("span.checked").find($('input[type=radio]')).val(),
        "WeightageFreight": jQuery("#txtweightagetfreight").val(),
        "WeightageExworks": jQuery("#txtweightagetexwork").val(),


        "TermsConditions": TermsConditionFileName,
        "Attachment": AttachementFileName,
        "UserId": sessionStorage.getItem('UserID'),
        "BidApprovers": BidApprovers()
    }
    //alert(JSON.stringify(DataTab2))
    jQuery.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ConfigureBidAir/ConfigureBidInsAirTab2/",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        crossDomain: true,
        data: JSON.stringify(DataTab2),
        dataType: "json",
        success: function (data) {
            fileUploader($('#hddn_bidID_Air').val())
            if (data[0].BidID > 0) {

                return true;
            }
            else {
                return false;

            }           

        }
    });


}

function ConfigureBidForAirTab3() {
        
        jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
        var InsertQuery = '';
        $("#selectedvendorlistsPrev> tbody > tr").each(function(index) {
        //if ($(this).find("span#spanchecked").attr('class') == 'checked') {
        
       InsertQuery = InsertQuery + "select " + $('#hddn_bidID_Air').val() + "," + $.trim($(this).find('td:eq(0)').html()) + " union all ";
            //}
           // else {
               // InsertQuery = InsertQuery;
           // }

        });

        if (InsertQuery != '') {

            InsertQuery = "Insert into BidVendorDetails(BidId,VendorId)" + InsertQuery;
            InsertQuery = InsertQuery.substring(0, InsertQuery.length - 10);

        }
        else {
            InsertQuery = "Print 1";
        }
        var DataTab3 = {
            "BidVendors": InsertQuery,
            "BidID": $('#hddn_bidID_Air').val(),
            "UserId": sessionStorage.getItem('UserID'),
            "BidSubject": jQuery("#txtBidSubject").val(),
            "BidDescription": jQuery("#txtbiddescription").val(),
            "BidDate": jQuery("#txtbidDate").val(),
            "BidTime": jQuery("#txtbidTime").val(),
            "BidDuration": jQuery("#txtBidDuration").val(),
            "BidTypeID": '2'
            //,"ContinentId": jQuery("#ddlSector").val(),
            //"CountryID": jQuery("#ddlCountry option:selected").val(),
            //"BidForID": jQuery("#ddlBidFor option:selected").val(),
            
            };
    //alert(JSON.stringify(DataTab3));
        jQuery.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: sessionStorage.getItem("APIPath") + "ConfigureBidAir/ConfigureBidInsAirTab3/",
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            crossDomain: true,
            data: JSON.stringify(DataTab3),
            dataType: "json",
            success: function (data) {
                
                if (parseInt(data[0].BidID) > 0) {
                    
                    jQuery.unblockUI();
                    bootbox.alert("Bid Configured Successfully.", function () {
                       
                        window.location = sessionStorage.getItem("HomePage")
                        return false;
                    });
                    
                }
                else {

                    jQuery.unblockUI();
                    bootbox.alert("Configuration error.", function () {
                        
                        window.location = sessionStorage.getItem("HomePage")
                        return false;
                    });

                }
            }
        });
        
    }

    function fileUploader(bidID) {
        //debugger;
        var fileTerms = $('#file1');
        
        if ($('#file1').is('[disabled=disabled]')) {

            var fileDataTerms = $('#file2').prop("files")[0];

        }
        else {
            var fileDataTerms = fileTerms.prop("files")[0];
        }
        

        var fileAnyOther = $('#file2');
        var fileDataAnyOther = fileAnyOther.prop("files")[0];

        var formData = new window.FormData();
        formData.append("fileTerms", fileDataTerms);
        formData.append("fileAnyOther", fileDataAnyOther);
        formData.append("AttachmentFor", 'Bid');
        formData.append("BidID", bidID);
        formData.append("VendorID", '');
        
        $.ajax({
            url: 'ConfigureFileAttachment.ashx',
            data: formData,
            processData: false,
            contentType: false,
            asyc: false,
            type: 'POST',
            dataType: 'json',
            success: function (e, data) {
		jQuery.unblockUI();
                //bootbox.alert("Bid Configured Successfully.", function () {
                //    window.location = sessionStorage.getItem("HomePage")
                //    return false;
                //});
            },
            error: function (e, data) {
		jQuery.unblockUI();
                //bootbox.alert("Bid Configured Successfully but attachment could not be uploaded.", function () {
                //    window.location = sessionStorage.getItem("HomePage")
                //    return false;
                //});
            }
        });
	
        
    }
    //function uploadfile(BidID) { 
    //    var msg = "";
    //    var data = new FormData($('form')[0]);
    //    $.ajax({
    //        type: "POST",
    //        url: sessionStorage.getItem("APIPath") + "FileUploader/UploadFiles/?BidID=" + BidID + "&BidType=Air",
    //        enctype: 'multipart/form-data',
    //        async: false,
    //        contentType: false,
    //        processData: false,
    //        cache: false,
    //        data: data,
    //        success: function (data, textStatus, xhr) {
    //            msg = data.toString();
    //        },
    //        error: function (XMLHttpRequest, textStatus, errorThrown) {
    //            msg = '' + textStatus + ': ' + errorThrown;
    //        }
    //    });
    //    if (msg == 'FilesUploadedSuccessfully') {
    //        bootbox.alert("Bid Configured Successfully.", function () {
    //            window.location = sessionStorage.getItem("HomePage")
    //            return false;
    //        });
    //    }
    //    else {
    //        bootbox.alert("Bid Configured Successfully but attachment could not be saved. Please ask Portal Admin to facilitate.", function () {
    //            window.location = sessionStorage.getItem("HomePage")
    //            return false;
    //        });
    //    }
    //}



 function BidApprovers() {
    var bidApprovers = {};
    var bidapprover = []
    bidApprovers.bidapprover = bidapprover;
     $.each($("select#mapedapprover option"), function(index){
         bidApprovers.bidapprover.push({ "AdMinSrNo": index + 1, "UserID": $(this).val() });
     });
     return JSON.stringify(bidApprovers);
 }

 function BidVendors() {
     var bidVendors = {};
     var bidvendor = []
     bidVendors.bidvendor = bidvendor;
     $("#tblvendorlist> tbody > tr").each(function (index) {
         if ($(this).find("span#spanchecked").attr('class') == 'checked') {
             bidVendors.bidvendor.push({ "VendorID": $(this).find("#chkvender").val() });
         }
     });
     return JSON.stringify(bidVendors);
 }

$("#txtbidDate").change(function () {
    if ($("#txtbidDate").val() == '') { }
    else {
        $("#txtbidDate").closest('.inputgroup').removeClass('has-error');
        $("#txtbidDate").closest('.inputgroup').find('span').hide();
        $("#txtbidDate").closest('.inputgroup').find('span.input-group-btn').show();
        $("#txtbidDate").closest('.inputgroup').find("#btncal").css("margin-top", "0px");
    }
});

jQuery("#ddlBidFor").change(function () {
    var BidForID = $("#ddlBidFor option:selected").val();

    if (parseInt(BidForID) == 2) {
        jQuery("input[id^=txtexwork]").prop('disabled', true);
    }
    else {
        jQuery("input[id^=txtexwork]").prop('disabled', false);
    }
    //$('#txtweightagetexwork').prop('disabled',true)
});


jQuery("#txtSearch").keyup(function () {
    _this = this;
    // Show only matching TR, hide rest of them
    jQuery.each($("#tblvendorlist tbody").find("tr"), function () {
        console.log($(this).text());
        if (jQuery(this).text().toLowerCase().indexOf(jQuery(_this).val().toLowerCase()) == -1)
            jQuery(this).hide();
        else
            jQuery(this).show();
    });
});


//function Dateandtimevalidate() {

//    jQuery.ajax({
//        contentType: "application/json; charset=utf-8",
//        url: sessionStorage.getItem("APIPath") + "ConfigureBid/Dateandtimevalidate/?BidDate=" + jQuery("#txtbidDate").val() + "&BidTime=" + jQuery("#txtbidTime").val(),
//        type: "GET",
//        cache: false,
//        crossDomain: true,
//        dataType: "json",
//        success: function (RFQData) {

//            if (RFQData[0].BidId == 1) {
              
//                 ConfigureBidForAir();

//            } else {
//                bootbox.alert("Date and Time should not be less than current date and time.");

//                $('#form_wizard_1').bootstrapWizard('previous');
//                $('#form_wizard_1').bootstrapWizard('previous');
//                return false;


//            }
//        },
//        error: function () {

//            bootbox.alert("you have some error.Please try agian.");

//        }

//    });

//}

function Dateandtimevalidate(indexNo) {

    jQuery.ajax({
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ConfigureBid/Dateandtimevalidate/?BidDate=" + jQuery("#txtbidDate").val() + "&BidTime=" + jQuery("#txtbidTime").val(),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "GET",
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function(RFQData) {

            if (RFQData[0].BidId == 1) {
                if (indexNo == 'index1') {
                    ConfigureBidForAirTab1();
                    fetchARBidDetailsForPreview();
                } else {
                // ConfigureBidForAirTab3();
                    $('#BidPreviewDiv').show();
                    $('#form_wizard_1').hide();
                }

            } else {
                if (indexNo == 'index1') {
                    bootbox.alert("Date and Time should not be less than current date and time.");
                    $('#form_wizard_1').bootstrapWizard('previous');
                    return false;
                } else {
                    bootbox.alert("Date and Time should not be less than current date and time.");
                    $('#form_wizard_1').bootstrapWizard('previous');
                    $('#form_wizard_1').bootstrapWizard('previous');
                    return false;

                }



            }
        },
        error: function() {

            bootbox.alert("you have some error.Please try agian.");

        }

    });

}



function ajaxFileDelete() {
    jQuery(document).ajaxStart(jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" /> Please Wait...</h5>' })).ajaxStop(jQuery.unblockUI);
    var theLinkdiv = document.getElementById('filepthterms')
    var path = theLinkdiv.getAttribute("href");

    var formData = new window.FormData();
    formData.append("Path", path);

    $.ajax({

        url: 'ConfigureFileAttachment.ashx',

        data: formData,

        processData: false,

        contentType: false,

        asyc: false,

        type: 'POST',

        success: function (data) {

            fileDeletefromdb();
        },

        error: function () {

            bootbox.alert("Attachment error.");

        }

    });




    jQuery.unblockUI();

}

function fileDeletefromdb() {

    $('#icon1').remove();
    $('#filepthterms').html('')
    $('#filepthterms').attr('href', 'javascript:;').addClass('display-none');
    $('#file1').attr('disabled', false);
    var BidData = {

        "BidId": $('#hddn_bidID_Air').val(),
        "BidTypeID": '2',
        "UserId": sessionStorage.getItem('UserID'),
        "RFQRFIID": 0,
        "RFIRFQType": ''
    }

    jQuery.ajax({

        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ConfigureBid/FileDeletion/",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        crossDomain: true,
        async: false,
        data: JSON.stringify(BidData),
        dataType: "json",
        success: function (data) {
            if (data[0].IsSuccess == '1') {
                $('#spansuccess1').html('File Deleted Successfully');
                $('.alert-success').show();
                Metronic.scrollTo($('.alert-success'), -200);
                $('.alert-success').fadeOut(5000);
            }
        }

    });
}


// For Bid Preview

function fetchARBidDetailsForPreview() {



    jQuery('#txtBidSubjectPrev').html($('#txtBidSubject').val())
    jQuery('#txtBidDurationPrev').html($('#txtBidDuration').val())
    jQuery('#txtbiddescriptionPrev').html($('#txtbiddescription').val())
    jQuery('#txtbidDatePrev').html($('#txtbidDate').val())
    jQuery('#txtbidTimePrev').html($('#txtbidTime').val())
    jQuery("#dropCurrencyPrev").html($('#dropCurrency option:selected').text())
    jQuery('#txtConversionRatePrev').html($('#txtConversionRate').val())
    jQuery('#ddlBidForPrev').html($('#ddlBidFor option:selected').text())
    jQuery('#ddlCountryPrev').html($('#ddlCountry option:selected').text())
    jQuery('#ddlSectorPrev').html($('#ddlSector option:selected').text())


}

$('#back_prev_btn').click(function() {
    $('#BidPreviewDiv').hide();
    $('#form_wizard_1').show();
});

function getBidParametersForPreview() {
    var TermsConditionFileName = '';
    var AttachementFileName = '';

    var _modal_class = $('input[type="radio"]:checked').val();
    

    jQuery('#mapedapproverPrev').html('');

    if ($('#filepthterms').html() != '' && ($('#file1').val() == '')) {
        $('#filepthtermsPrev').attr('href', 'PortalDocs/Bid/' + $('#hddn_bidID_Air').val() + '/' + $('#filepthterms').html().replace(/\s/g, "%20")).html($('#filepthterms').html());

    } else {
        TermsConditionFileName = jQuery('#file1').val().substring(jQuery('#file1').val().lastIndexOf('\\') + 1);

        $('#filepthtermsPrev').attr('href', 'PortalDocs/Bid/' + $('#hddn_bidID_Air').val() + '/' + TermsConditionFileName.replace(/\s/g, "%20")).html(TermsConditionFileName);
    }
    if (($('#filepthattach').html() != '') && ($('#file2').val() == '')) {
        $('#filepthattachPrev').attr('href', 'PortalDocs/Bid/' + $('#hddn_bidID_Air').val() + '/' + $('#filepthattach').html().replace(/\s/g, "%20")).html($('#filepthattach').html());
    } else {
        AttachementFileName = jQuery('#file2').val().substring(jQuery('#file2').val().lastIndexOf('\\') + 1);

        $('#filepthattachPrev').attr('href', 'PortalDocs/Bid/' + $('#hddn_bidID_Air').val() + '/' + AttachementFileName.replace(/\s/g, "%20")).html(AttachementFileName);
    }
    
    $('#mapedapprover option').each(function() {
        // alert($(this).html())
        jQuery('#mapedapproverPrev').append($(this).html() + '<br/>')
    });

    switch (_modal_class) {
        case '1':
            //$('#Radio1Prev').prop('checked', true)
            $('#Radio1Prev').closest('span').addClass('checked');
            break;
        case '2':
            //$('#rb45Prev').prop('checked', true)
            $('#rb45Prev').closest('span').addClass('checked');
            break;
        case '3':
           // $('#rb100Prev').prop('checked', true)
            $('#rb100Prev').closest('span').addClass('checked');
            break;
        case '4':
            //$('#rb300Prev').prop('checked', true)
            $('#rb300Prev').closest('span').addClass('checked');
            break;
        case '5':
            //$('#rb500Prev').prop('checked', true)
            $('#rb500Prev').closest('span').addClass('checked');
            break;
        case '6':
            //$('#rb1000Prev').prop('checked', true);
            $('#rb1000Prev').closest('span').addClass('checked');
            break;
        default:
            _modal_class = ''
    }

    if ($('#txtfreightMin').val() != '') {
        $('#txtfreightMinPrev').html($('#txtfreightMin').val());
    } else {
        $('#txtfreightMinPrev').html('Not specified.');
    }

    if ($('#txtexworkMin').val() != '') {
        $('#txtexworkMinPrev').html($('#txtexworkMin').val());
    } else {
        $('#txtexworkMinPrev').html('Not specified.');
    }

    if ($('#txtfreight45').val() != '') {
        $('#txtfreight45Prev').html($('#txtfreight45').val());
    } else {
        $('#txtfreight45Prev').html('Not specified.');
    }


    if ($('#txtexwork45').val() != '') {
        $('#txtexwork45Prev').html($('#txtexwork45').val());
    } else {
        $('#txtexwork45Prev').html('Not specified.');
    }

    if ($('#txtfreight100').val() != '') {
        $('#txtfreight100Prev').html($('#txtfreight100').val());
    } else {
        $('#txtfreight100Prev').html('Not specified.');
    }

    if ($('#txtexwork100').val() != '') {
        $('#txtexwork100Prev').html($('#txtexwork100').val());
    } else {
    $('#txtexwork100Prev').html('Not specified.');
    }

    if ($('#txtfreight300').val() != '') {
        $('#txtfreight300Prev').html($('#txtfreight300').val());
    } else {
    $('#txtfreight300Prev').html('Not specified.');
    }

    if ($('#txtexwork300').val() != '') {
        $('#txtexwork300Prev').html($('#txtexwork300').val());
    } else {
    $('#txtexwork300Prev').html('Not specified.');
    }

    if ($('#txtfreight500').val() != '') {
        $('#txtfreight500Prev').html($('#txtfreight500').val());
    } else {
    $('#txtfreight500Prev').html('Not specified.');
    }

    if ($('#txtfreightMin').val() != '') {
        $('#txtfreightMinPrev').html($('#txtfreightMin').val());
    } else {
        $('#txtfreightMinPrev').html('Not specified.');
    }

    if ($('#txtexwork500').val() != '') {
        $('#txtexwork500Prev').html($('#txtexwork500').val());
    } else {
    $('#txtexwork500Prev').html('Not specified.');
    }

    if ($('#txtfreight1000').val() != '') {
        $('#txtfreight1000Prev').html($('#txtfreight1000').val());
    } else {
        $('#txtfreight1000Prev').html('Not specified.');
    }

    if ($('#txtexwork1000').val() != '') {
        $('#txtexwork1000Prev').html($('#txtexwork1000').val());
    } else {
        $('#txtexwork1000Prev').html('Not specified.');
    }

    if (!$('#txtweightagetexwork').attr('disabled', true)) {
        $('#txtweightagetexworkPrev').html($('#txtweightagetexwork').val());
    } else {
        $('#txtweightagetexworkPrev').html('Not specified.');
    }
   
}