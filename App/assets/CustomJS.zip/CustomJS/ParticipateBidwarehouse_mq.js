﻿var BidTypeID = 0;
var BidForID = 0;
var Duration = '0.00';
var form1 = $('#FormparticipateAir');
var error1 = $('.alert-danger', form1);
var success1 = $('.alert-success', form1);

function handlevalidation() {
  
    form1.validate({
        errorElement: 'span', //default input error message container
        errorClass: 'help-block', // default input error message class
        focusInvalid: false, // do not focus the last invalid input
        rules: {
            txtrentalquote: {
                required: true,
                number:true
            },
            txtmanpowerquote: {
                required: true,
                number:true
            },
            txtinfrastructurequote: {
                required: true,
                number: true
            },
            txtutilityquote: {
                required: true,
                number: true
            },
            txtfeequote: {
                required: true,
                number: true
            }
        },

        messages: {
            txtrentalquote: {
                required: "Please enter amount",
                number: "number only"
            },
            txtmanpowerquote: {
                required: "Please enter amount",
                number: "number only"
            },
            txtinfrastructurequote: {
                required: "Please enter amount",
                number: "number only"
            },
            txtutilityquote: {
                required: "Please enter amount",
                number: "number only"
            },
            txtfeequote: {
                required: "Please enter amount",
                number: "number only"
            }
        },

        invalidHandler: function (event, validator) { //display error alert on form submit   
            success1.hide();
            error1.show();
           // App.scrollTo(error1, -300);
            
        },

        highlight: function (element) { // hightlight error inputs
            $(element)
                    .closest('.form-body').addClass('has-error'); // set error class to the control group
        },
        unhighlight: function (element) { // revert the change done by hightlight
            $(element)
                    .closest('.form-body').removeClass('has-error'); // set error class to the control group
        },
        success: function (label) {
            label
                    .closest('.form-body').removeClass('has-error'); // set success class to the control group
        },

        submitHandler: function (form) {

            showreasonmq_modal();
        }
    });
}
function fetchVendorDetails() {

 var tncAttachment = '';
    var anyotherAttachment = '';
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "VendorParticipation/FetchBidDetailsWH_mq/?BidID=" + sessionStorage.getItem("hdnselectedBidSubjID") + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("VendorId")),
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function(data, status, jqXHR) {
            //alert(data.length)
            if (data.length == 1) {
                $('#tblParticipantsVender').show();
                tncAttachment = data[0].TermsConditions.replace(/\s/g, "%20");
                anyotherAttachment = data[0].Attachment.replace(/\s/g, "%20");

                jQuery("label#lblitem1").text(data[0].BidFor);
                jQuery("#lblbidsubject").text(data[0].BidSubject);
                jQuery("#lblbidDetails").text(data[0].BidDetails);
                jQuery("#lblbiddate").text(data[0].BidDate);
                jQuery("#lblbidtime").text(data[0].BidTime);

                jQuery("a#lnkTermsAttachment").text(data[0].TermsConditions);
                jQuery("a#lnkTermsAttachment").attr("href", "PortalDocs/Bid/" + sessionStorage.getItem("BidID") + "/" + tncAttachment)

                jQuery("a#lnkAnyOtherAttachment").text(data[0].Attachment);
                jQuery("a#lnkAnyOtherAttachment").attr("href", "PortalDocs/Bid/" + sessionStorage.getItem("BidID") + "/" + anyotherAttachment)

                jQuery("#lblwarehousearea").text(data[0].WareHouseArea);

                jQuery("#lblbidduration").text(data[0].BidDuration);
                jQuery("#lblcurrency").text(data[0].CurrencyName);
                jQuery("#lblConvRate").text(data[0].ConversionRate);                
                jQuery("#lblConvRate").text(data[0].ConversionRate);


                BidTypeID = data[0].BidTypeID;
                BidForID = data[0].BidForID;
                
                
                fetchBidSummaryVendorWarehouse();
            }
            
        },
        error: function(xhr) {
            jQuery("#error").text(xhr.d);
        }
    });

}

function fetchBidSummaryVendorWarehouse() {
    var url = '';

    url = sessionStorage.getItem("APIPath") + "VendorParticipation/BidSummaryWare/?VendorID=" + encodeURIComponent(sessionStorage.getItem("VendorId")) + "&BidID=" + sessionStorage.getItem("hdnselectedBidSubjID") + "&UserType=MQ&AthenticationToken=''";

   // alert(url)
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: url,
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
         
                if (data.length > 0) {
                    jQuery("#lblrentalinitialquote").text(data[0].IQPerSquareFeetRate == '0' ? '' : data[0].IQPerSquareFeetRate)
                    jQuery("#lblmanpowerinitialquote").text(data[0].IQManPowerCost == '0' ? '' : data[0].IQManPowerCost)
                    jQuery("#lblinfrastructureinitialquote").text(data[0].IQInfrastructureCost == '0' ? '' : data[0].IQInfrastructureCost)
                    jQuery("#lblutilityinitialquote").text(data[0].IQUtilitiesCost == '0' ? '' : data[0].IQUtilitiesCost)
                    jQuery("#lblfeeinitialquote").text(data[0].IQFixedManagementFee == '0' ? '' : data[0].IQFixedManagementFee)

                    jQuery("#lblinfrastructurelastquote").text(data[0].LQInfrastructureCost == '0' ? '' : data[0].LQInfrastructureCost)
                    jQuery("#lblrentallastquote").text(data[0].LQPerSquareFeetRate == '0' ? '' : data[0].LQPerSquareFeetRate)
                    jQuery("#lblmanpowerlastquote").text(data[0].LQManPowerCost == '0' ? '' : data[0].LQManPowerCost)
                    jQuery("#lblutilitylastquote").text(data[0].LQUtilitiesCost == '0' ? '' : data[0].LQUtilitiesCost)
                    jQuery("#lblfeelastquote").text(data[0].LQFixedManagementFee == '0' ? '' : data[0].LQFixedManagementFee)       
                

                    jQuery("#txtrentalquote").val(data[0].LQPerSquareFeetRate);
                    jQuery("#txtmanpowerquote").val(data[0].LQManPowerCost);
                    jQuery("#txtinfrastructurequote").val(data[0].LQInfrastructureCost);
                    jQuery("#txtutilityquote").val(data[0].LQUtilitiesCost);
                    jQuery("#txtfeequote").val(data[0].LQFixedManagementFee);
                }
            }
        })
}


function InsUpdQuotewarehouse() {


    if ($("#txtrentalquote").val() > (parseInt(jQuery("#lblrentallastquote").text()) == '' ? $("#txtrentalquote").val() : parseInt(jQuery("#lblrentallastquote").text()))) {
        $('#spanrental').removeClass('hide')
       
        return false
    }

    else if ($("#txtmanpowerquote").val() > (parseInt(jQuery("#lblmanpowerlastquote").text()) == '' ? $("#txtmanpowerquote").val() : parseInt(jQuery("#lblmanpowerlastquote").text()))) {
        $('#spanmanpower').removeClass('hide')
        return false
    }

    else if ($("#txtinfrastructurequote").val() > (parseInt(jQuery("#lblinfrastructurelastquote").text()) == '' ? $("#txtinfrastructurequote").val() : parseInt(jQuery("#lblinfrastructurelastquote").text()))) {
        $('#spaninfra').removeClass('hide')
        return false
    }

    else if ($("#txtutilityquote").val() > (parseInt(jQuery("#lblutilitylastquote").text()) == '' ? $("#txtutilityquote").val() : parseInt(jQuery("#lblutilitylastquote").text()))) {
        $('#spanutility').removeClass('hide')
        return false
    }

    else if ($("#txtfeequote").val() > (parseInt(jQuery("#lblfeelastquote").text()) == '' ? $("#txtfeequote").val() : parseInt(jQuery("#lblfeelastquote").text()))) {
        $('#spanfee').removeClass('hide')
        return false
    }
    else {
        var vendorID = 0;

        vendorID = sessionStorage.getItem('VendorId');
        
       
      var QuoteWare = {
                "VendorID": vendorID,
                "BidID": sessionStorage.getItem("hdnselectedBidSubjID"),
                "LQPerSquareFeetRate": jQuery("#txtrentalquote").val().trim(),
                "LQManPowerCost": jQuery("#txtmanpowerquote").val().trim(),
                "LQInfrastructureCost": jQuery("#txtinfrastructurequote").val().trim(),
                "LQUtilitiesCost": jQuery("#txtutilityquote").val().trim(),
                "LQFixedManagementFee": jQuery("#txtfeequote").val().trim(),
                "EnteredBy": sessionStorage.getItem("UserID"),
                "Remarks": ''
            }
             
            jQuery.ajax({
                url: sessionStorage.getItem("APIPath") + "VendorParticipation/ParticipationWarehouse/",
                type: "POST",
                data: JSON.stringify(QuoteWare),
                contentType: "application/json; charset=utf-8",
                success: function (data, status, jqXHR) {
                        bootbox.alert("Transaction Successful.", function() {
                            window.location = sessionStorage.getItem("HomePage");
                            return false;
                        });
                },
                error: function (xhr) {
                    jQuery("#error").text(xhr.d);
                }
            });        
        }
}
$("#txtrentalquote").keyup(function () {
        $('#spanrental').addClass('hide')
       return true
   
});
$("#txtmanpowerquote").keyup(function () {
    $('#spanmanpower').addClass('hide')
    return true

});
$("#txtinfrastructurequote").keyup(function () {
    $('#spaninfra').addClass('hide')
    return true

});
$("#txtutilityquote").keyup(function () {
    $('#spanutility').addClass('hide')
    return true

});
$("#txtfeequote").keyup(function () {
    $('#spanfee').addClass('hide')
    return true

});


var form = $('#frm_remarks');
var error = $('.alert-success');
var success = $('.alert-danger');

function FormValidate() {
    form.validate({

        doNotHideMessage: true, //this option enables to show the error/success messages on tab switch.

        errorElement: 'span', //default input error message container

        errorClass: 'help-block help-block-error', // default input error message class

        focusInvalid: false, // do not focus the last invalid input

        rules: {

            txtremarks_mq: {

                required: true,
                maxlength: 100

            },
            file1: {

                required: true

            }


        },

        messages: {

    },



    invalidHandler: function(event, validator) {

    },

    highlight: function(element) {

        $(element).closest('.form-group').removeClass('has-success').addClass('has-error');

    },

    unhighlight: function(element) {

        $(element).closest('.form-group').removeClass('has-error');
    },

    success: function(label) {
    },
    submitHandler: function(form) {

        InsManualQuotesHisotry();
    }



});

}

function showreasonmq_modal() {
    $('#reasonmq_modal').modal('show');
}

function cancelmanualQuote() {
    window.location = sessionStorage.getItem('HomePage')
}


function InsManualQuotesHisotry() {

    var attachment = jQuery('#file1').val().substring(jQuery('#file1').val().lastIndexOf('\\') + 1);

    var mquotes = {

        "BidID": sessionStorage.getItem("hdnselectedBidSubjID"),
        "BidSubject": $.trim($('#lblbidsubject').html()),
        "CustomerID": sessionStorage.getItem('CustomerID'),
        "Remarks": $('#txtremarks_mq').val(),
        "Attachment": attachment,
        "BidtypeID": $.trim(BidTypeID),
        "ForVendorID": sessionStorage.getItem("VendorId"),
        "EnteredBy": sessionStorage.getItem("UserName")

    }

    //alert(JSON.stringify(mquotes))

    jQuery.ajax({
        type: "POST",

        contentType: "application/json; charset=utf-8",

        url: sessionStorage.getItem("APIPath") + "VendorParticipation/InsManualQuotesHisotry/",

        crossDomain: true,

        async: false,

        data: JSON.stringify(mquotes),


        success: function(data, status, jqXHR) {
            //alert(data[0].Success)
            if (data[0].Success == '1') {

                fileUploader(sessionStorage.getItem("hdnselectedBidSubjID"))

            } else {
                bootbox.alert("Error Connecting server. Please try later.");
            }


        },
        error: function(xhr) {
            jQuery("#error").text(xhr.d);
        }
    });


}


function fileUploader(bidID) {

    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });

    var fileTerms = $('#file1');

    var fileDataTerms = fileTerms.prop("files")[0];

    var formData = new window.FormData();

    formData.append("fileTerms", fileDataTerms);

    formData.append("fileAnyOther", '');

    formData.append("AttachmentFor", 'ManualBids');

    formData.append("BidID", bidID);
    formData.append("VendorID", '');



    $.ajax({

        url: 'ConfigureFileAttachment.ashx',

        data: formData,

        processData: false,

        contentType: false,

        asyc: false,

        type: 'POST',

        success: function(data) {
            $('#reasonmq_modal').modal('hide');
            jQuery.unblockUI();
            InsUpdQuotewarehouse()

        },

        error: function() {

            bootbox.alert("Attachment error.");
            jQuery.unblockUI();
        }

    });

}