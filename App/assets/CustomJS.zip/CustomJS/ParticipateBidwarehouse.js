﻿var BidTypeID = 0;
var BidForID = 0;
var Duration = '0.00';
var form1 = $('#FormparticipateAir');
var error1 = $('.alert-danger', form1);
var success1 = $('.alert-success', form1);

function handlevalidation() {
  
    form1.validate({
        errorElement: 'span', //default input error message container
        errorClass: 'help-block', // default input error message class
        focusInvalid: false, // do not focus the last invalid input
        rules: {
            txtrentalquote: {
                required: true,
                number:true
            },
            txtmanpowerquote: {
                required: true,
                number:true
            },
            txtinfrastructurequote: {
                required: true,
                number: true
            },
            txtutilityquote: {
                required: true,
                number: true
            },
            txtfeequote: {
                required: true,
                number: true
            }
        },

        messages: {
            txtrentalquote: {
                required: "Please enter amount",
                number: "number only"
            },
            txtmanpowerquote: {
                required: "Please enter amount",
                number: "number only"
            },
            txtinfrastructurequote: {
                required: "Please enter amount",
                number: "number only"
            },
            txtutilityquote: {
                required: "Please enter amount",
                number: "number only"
            },
            txtfeequote: {
                required: "Please enter amount",
                number: "number only"
            }
        },

        invalidHandler: function (event, validator) { //display error alert on form submit   
            success1.hide();
            error1.show();
           // App.scrollTo(error1, -300);
            
        },

        highlight: function (element) { // hightlight error inputs
            $(element)
                    .closest('.form-body').addClass('has-error'); // set error class to the control group
        },
        unhighlight: function (element) { // revert the change done by hightlight
            $(element)
                    .closest('.form-body').removeClass('has-error'); // set error class to the control group
        },
        success: function (label) {
            label
                    .closest('.form-body').removeClass('has-error'); // set success class to the control group
        },

        submitHandler: function (form) {
           
            InsUpdQuotewarehouse();
        }
    });
}
function fetchVendorDetails() {
 var tncAttachment = '';
    var anyotherAttachment = '';
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "VendorParticipation/FetchBidDetails/?BidID=" + sessionStorage.getItem("BidID") + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("UserID")),
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function(data, status, jqXHR) {
            //alert(data.length)
            if (data.length == 1) {
                $('#tblParticipantsVender').show();
                tncAttachment = data[0].TermsConditions.replace(/\s/g, "%20");
                anyotherAttachment = data[0].Attachment.replace(/\s/g, "%20");

                jQuery("label#lblitem1").text(data[0].BidFor);
                jQuery("#lblbidsubject").text(data[0].BidSubject);
                jQuery("#lblbidDetails").text(data[0].BidDetails);
                jQuery("#lblbiddate").text(data[0].BidDate);
                jQuery("#lblbidtime").text(data[0].BidTime);

                jQuery("a#lnkTermsAttachment").text(data[0].TermsConditions);
                jQuery("a#lnkTermsAttachment").attr("href", "PortalDocs/Bid/" + sessionStorage.getItem("BidID") + "/" + tncAttachment)

                jQuery("a#lnkAnyOtherAttachment").text(data[0].Attachment);
                jQuery("a#lnkAnyOtherAttachment").attr("href", "PortalDocs/Bid/" + sessionStorage.getItem("BidID") + "/" + anyotherAttachment)

                jQuery("#lblwarehousearea").text(data[0].WareHouseArea);

                jQuery("#lblbidduration").text(data[0].BidDuration);
                jQuery("#lblcurrency").text(data[0].CurrencyName);
                jQuery("#lblConvRate").text(data[0].ConversionRate);
                jQuery("#lblstatus").text(data[0].ConversionRate);
                jQuery("#lblConvRate").text(data[0].ConversionRate);


                BidTypeID = data[0].BidTypeID;
                BidForID = data[0].BidForID;
                display = document.querySelector('#lblTimeLeft');

                startTimer((parseInt(data[0].TimeLeft)), display);
                fetchBidSummaryVendorWarehouse();
            }
            else if (data.length > 1 || data.length == 0) {
                // bootbox.alert("Bid has been not started yet.", function () {
                // //  window.location = sessionStorage.getItem('MainUrl');
                // return true;
                // });
                $('#lblTimeLeft').html('Bid has been not started yet.').css('color', 'red');
                $('#tblParticipantsVender').hide();
                fetchDetailsonly();
            }
        },
        error: function(xhr) {
            jQuery("#error").text(xhr.d);
        }
    });

}
function fetchDetailsonly() {
    var url = sessionStorage.getItem("APIPath") + "VendorParticipation/FetchBidDetailsForVendorMain/?BidID=" + sessionStorage.getItem("BidID") + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("BidUserID"));
   

	var tncAttachment = '';
	var anyotherAttachment = '';
   
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: url,
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
           
            if (data.length > 0) {
		tncAttachment = data[0].TermsConditions.replace(/%20/g, " ");
                 anyotherAttachment = data[0].Attachment.replace(/%20/g, " ");
		
                jQuery("#lblbidsubject").text(data[0].BidSubject);
                jQuery("#lblbidDetails").text(data[0].BidDetails);
                jQuery("#lblbiddate").text(data[0].BidDate);
                jQuery("#lblbidtime").text(data[0].BidTime);
				jQuery("#lblwarehousearea").text(data[0].WareHouseArea);

                jQuery("a#lnkTermsAttachment").text(data[0].TermsConditions);
                jQuery("a#lnkTermsAttachment").attr("href", "PortalDocs/Bid/" + sessionStorage.getItem("BidID") + "/" + tncAttachment)
                jQuery("a#lnkAnyOtherAttachment").text(data[0].Attachment);
                jQuery("a#lnkAnyOtherAttachment").attr("href", "PortalDocs/Bid/" + sessionStorage.getItem("BidID") + "/" + anyotherAttachment)
                
                jQuery("#lblbidduration").text(data[0].BidDuration);
                jQuery("#lblcurrency").text(data[0].CurrencyName);
                jQuery("#lblConvRate").text(data[0].ConversionRate);
                

            }
            
        },
        error: function (xhr) {
            jQuery("#error").text(xhr.d);
        }
    });
}

function fetchBidSummaryVendorWarehouse() {
    var url = '';
    if (sessionStorage.getItem("ContactEmailID") == 'null' || sessionStorage.getItem("ContactEmailID") == '') {

        url = sessionStorage.getItem("APIPath") + "VendorParticipation/BidSummaryWare/?VendorID=" + encodeURIComponent(sessionStorage.getItem("UserID")) + "&BidID=" + sessionStorage.getItem("BidID") + "&UserType=" + sessionStorage.getItem("UserType") + "&AthenticationToken=''";

    } else {
        
        url = sessionStorage.getItem("APIPath") + "VendorParticipation/BidSummaryWare/?VendorID=" + encodeURIComponent(sessionStorage.getItem("BidUserID")) + "&BidID=" + sessionStorage.getItem("BidID") + "&UserType=" + sessionStorage.getItem("UserType") + "&AthenticationToken=''";
    }
   // alert(url)
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: url,
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
         
                if (data.length > 0) {
                    jQuery("#lblrentalinitialquote").text(data[0].IQPerSquareFeetRate == '0' ? '' : data[0].IQPerSquareFeetRate)
                    jQuery("#lblmanpowerinitialquote").text(data[0].IQManPowerCost == '0' ? '' : data[0].IQManPowerCost)
                    jQuery("#lblinfrastructureinitialquote").text(data[0].IQInfrastructureCost == '0' ? '' : data[0].IQInfrastructureCost)
                    jQuery("#lblutilityinitialquote").text(data[0].IQUtilitiesCost == '0' ? '' : data[0].IQUtilitiesCost)
                    jQuery("#lblfeeinitialquote").text(data[0].IQFixedManagementFee == '0' ? '' : data[0].IQFixedManagementFee)

                    jQuery("#lblinfrastructurelastquote").text(data[0].LQInfrastructureCost == '0' ? '' : data[0].LQInfrastructureCost)
                    jQuery("#lblrentallastquote").text(data[0].LQPerSquareFeetRate == '0' ? '' : data[0].LQPerSquareFeetRate)
                    jQuery("#lblmanpowerlastquote").text(data[0].LQManPowerCost == '0' ? '' : data[0].LQManPowerCost)
                    jQuery("#lblutilitylastquote").text(data[0].LQUtilitiesCost == '0' ? '' : data[0].LQUtilitiesCost)
                    jQuery("#lblfeelastquote").text(data[0].LQFixedManagementFee == '0' ? '' : data[0].LQFixedManagementFee)
                   
                   
                    jQuery("#lblrentalstatus").html(data[0].LOPerSquareFeetRate)
                    jQuery("#lblinfrastructurestatus").html(data[0].LOInfrastructureCost)
                    jQuery("#lblutilitystatus").html(data[0].LOUtilitiesCost)
                    jQuery("#lblfeestatus").html(data[0].LOFixedManagementFee)
                    jQuery("#lblmanpowerstatus").html(data[0].LOManPowerCost)
                    
                    if (data[0].LOPerSquareFeetRate == 'L1') {
                        jQuery('#lblrentalstatus').css('color', 'Blue');
                    }
                    else {
                        jQuery('#lblrentalstatus').css('color', 'Red');
                    }
                    if (data[0].LOManPowerCost == 'L1') {
                        jQuery('#lblmanpowerstatus').css('color', 'Blue');
                    }
                    else {
                        jQuery('#lblmanpowerstatus').css('color', 'Red');
                    }
                    if (data[0].LOInfrastructureCost == 'L1') {
                        jQuery('#lblinfrastructurestatus').css('color', 'Blue');
                    }
                    else {
                        jQuery('#lblinfrastructurestatus').css('color', 'Red');
                    }
                    if (data[0].LOUtilitiesCost == 'L1') {
                        jQuery('#lblutilitystatus').css('color', 'Blue');
                    }
                    else {
                        jQuery('#lblutilitystatus').css('color', 'Red');
                    }
                    if (data[0].LOFixedManagementFee == 'L1') {
                        jQuery('#lblfeestatus').css('color', 'Blue');
                    }
                    else {
                        jQuery('#lblfeestatus').css('color', 'Red');
                    }

                    jQuery("#txtrentalquote").val(data[0].LQPerSquareFeetRate);
                    jQuery("#txtmanpowerquote").val(data[0].LQManPowerCost);
                    jQuery("#txtinfrastructurequote").val(data[0].LQInfrastructureCost);
                    jQuery("#txtutilityquote").val(data[0].LQUtilitiesCost);
                    jQuery("#txtfeequote").val(data[0].LQFixedManagementFee);
                }
            }
        })
}
function refreshColumnsStaus() {
    var url = '';
    if (sessionStorage.getItem("ContactEmailID") == 'null' || sessionStorage.getItem("ContactEmailID") == '') {

        url = sessionStorage.getItem("APIPath") + "VendorParticipation/BidSummaryWare/?VendorID=" + encodeURIComponent(sessionStorage.getItem("UserID")) + "&BidID=" + sessionStorage.getItem("BidID") + "&UserType=" + sessionStorage.getItem("UserType") + "&AthenticationToken=''";

    } else {

        url = sessionStorage.getItem("APIPath") + "VendorParticipation/BidSummaryWare/?VendorID=" + encodeURIComponent(sessionStorage.getItem("BidUserID")) + "&BidID=" + sessionStorage.getItem("BidID") + "&UserType=" + sessionStorage.getItem("UserType") + "&AthenticationToken=''";
            
    }
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: url,
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
        
            if (data.length > 0) {
                jQuery("#lblinfrastructurelastquote").text(data[0].LQInfrastructureCost == '0' ? '' : data[0].LQInfrastructureCost)
                jQuery("#lblrentallastquote").text(data[0].LQPerSquareFeetRate == '0' ? '' : data[0].LQPerSquareFeetRate)
                jQuery("#lblmanpowerlastquote").text(data[0].LQManPowerCost == '0' ? '' : data[0].LQManPowerCost)
                jQuery("#lblutilitylastquote").text(data[0].LQUtilitiesCost == '0' ? '' : data[0].LQUtilitiesCost)
                jQuery("#lblfeelastquote").text(data[0].LQFixedManagementFee == '0' ? '' : data[0].LQFixedManagementFee)


                jQuery("#lblrentalstatus").html(data[0].LOPerSquareFeetRate)
                jQuery("#lblinfrastructurestatus").html(data[0].LOInfrastructureCost)
                jQuery("#lblutilitystatus").html(data[0].LOUtilitiesCost)
                jQuery("#lblfeestatus").html(data[0].LOFixedManagementFee)
                jQuery("#lblmanpowerstatus").html(data[0].LOManPowerCost)
                if (data[0].LOPerSquareFeetRate == 'L1') {
                    jQuery('#lblrentalstatus').css('color', 'Blue');
                }
                else {
                    jQuery('#lblrentalstatus').css('color', 'Red');
                }
                if (data[0].LOManPowerCost == 'L1') {
                    jQuery('#lblmanpowerstatus').css('color', 'Blue');
                }
                else {
                    jQuery('#lblmanpowerstatus').css('color', 'Red');
                }
                if (data[0].LOInfrastructureCost == 'L1') {
                    jQuery('#lblinfrastructurestatus').css('color', 'Blue');
                }
                else {
                    jQuery('#lblinfrastructurestatus').css('color', 'Red');
                }
                if (data[0].LOUtilitiesCost == 'L1') {
                    jQuery('#lblutilitystatus').css('color', 'Blue');
                }
                else {
                    jQuery('#lblutilitystatus').css('color', 'Red');
                }
                if (data[0].LOFixedManagementFee == 'L1') {
                    jQuery('#lblfeestatus').css('color', 'Blue');
                }
                else {
                    jQuery('#lblfeestatus').css('color', 'Red');
                }
               
               // $('#hdnnoofextension').val(data[0].NoOfExtension)
                display = document.querySelector('#lblTimeLeft');
                startTimer(data[0].TimeLeft, display);
                if (data[0].NoOfExtension >= 1) {
                    jQuery('#lblTimeLeft').css('color', 'red');
					jQuery('#lblTimeLeftTxt').removeClass('display-none');
					jQuery('#lblTimeLeftTxt').html('<b>Bid Time Extended.</b>').css('color', 'red')
                }
                else {
					jQuery('#lblTimeLeftTxt').addClass('display-none');
                    jQuery('#lblTimeLeft').css('color', '');
                }
            }
        }
        });

}
var mytime = 0;
function startTimer(duration, display) {
    clearInterval(mytime)
    var timer = 0, hours = 0, minutes = 0, seconds = 0;
    timer = duration;

    mytime = setInterval(function () {

        hours = parseInt(timer / 3600, 10)
        minutes = parseInt(timer / 60, 10) - (hours * 60)
        seconds = parseInt(timer % 60, 10);

        hours = hours < 10 ? "0" + hours : hours;
        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;

        if (hours > 0) {
            display.textContent = hours + ":" + minutes + ":" + seconds;
        }
        else {
            display.textContent = minutes + ":" + seconds;
        }
        if ((seconds.toString().substring(1, 2) == '0') || (seconds.toString().substring(1, 2) == '5')) {

            refreshColumnsStaus()

        }
        if (--timer < 0) {
            timer = 0;
            closeBidAir();
           
        }
        $('#hdnval').val(timer)

    }, 1000);
    
}
function InsUpdQuotewarehouse() {


    if ($("#txtrentalquote").val() > (parseInt(jQuery("#lblrentallastquote").text()) == '' ? $("#txtrentalquote").val() : parseInt(jQuery("#lblrentallastquote").text()))) {
        $('#spanrental').removeClass('hide')
       
        return false
    }

    else if ($("#txtmanpowerquote").val() > (parseInt(jQuery("#lblmanpowerlastquote").text()) == '' ? $("#txtmanpowerquote").val() : parseInt(jQuery("#lblmanpowerlastquote").text()))) {
        $('#spanmanpower').removeClass('hide')
        return false
    }

    else if ($("#txtinfrastructurequote").val() > (parseInt(jQuery("#lblinfrastructurelastquote").text()) == '' ? $("#txtinfrastructurequote").val() : parseInt(jQuery("#lblinfrastructurelastquote").text()))) {
        $('#spaninfra').removeClass('hide')
        return false
    }

    else if ($("#txtutilityquote").val() > (parseInt(jQuery("#lblutilitylastquote").text()) == '' ? $("#txtutilityquote").val() : parseInt(jQuery("#lblutilitylastquote").text()))) {
        $('#spanutility').removeClass('hide')
        return false
    }

    else if ($("#txtfeequote").val() > (parseInt(jQuery("#lblfeelastquote").text()) == '' ? $("#txtfeequote").val() : parseInt(jQuery("#lblfeelastquote").text()))) {
        $('#spanfee').removeClass('hide')
        return false
    }
    else {
        var vendorID = 0;
        if (sessionStorage.getItem('ContactEmailID') == 'null' || sessionStorage.getItem('ContactEmailID') == '') {
            vendorID = sessionStorage.getItem('UserID');
        }
        else {
            vendorID = sessionStorage.getItem('BidUserID');
        }
       
        if ($('#hdnval').val() >= 60) {

            var QuoteWare = {
                "VendorID": vendorID,
                "BidID": sessionStorage.getItem("BidID"),
                "LQPerSquareFeetRate": jQuery("#txtrentalquote").val().trim(),
                "LQManPowerCost": jQuery("#txtmanpowerquote").val().trim(),
                "LQInfrastructureCost": jQuery("#txtinfrastructurequote").val().trim(),
                "LQUtilitiesCost": jQuery("#txtutilityquote").val().trim(),
                "LQFixedManagementFee": jQuery("#txtfeequote").val().trim(),
                "EnteredBy": vendorID,
                "Remarks": ''
            }
             
            jQuery.ajax({
                url: sessionStorage.getItem("APIPath") + "VendorParticipation/ParticipationWarehouse/",
                type: "POST",
                data: JSON.stringify(QuoteWare),
                contentType: "application/json; charset=utf-8",
                success: function (data, status, jqXHR) {
                    fetchVendorDetails();
                },
                error: function (xhr) {
                    jQuery("#error").text(xhr.d);
                }
            });
        }
        else {
            var QuoteWare = {
                "VendorID": vendorID,
                "BidID": sessionStorage.getItem("BidID"),
                "LQPerSquareFeetRate": jQuery("#txtrentalquote").val(),
                "LQManPowerCost": jQuery("#txtmanpowerquote").val(),
                "LQInfrastructureCost": jQuery("#txtinfrastructurequote").val(),
                "LQUtilitiesCost": jQuery("#txtutilityquote").val(),
                "LQFixedManagementFee": jQuery("#txtfeequote").val(),
                "EnteredBy": vendorID,
                "Remarks": ''
            }
           
            jQuery.ajax({
                url: sessionStorage.getItem("APIPath") + "VendorParticipation/ParticipationWarehouse/",
                type: "POST",
                data: JSON.stringify(QuoteWare),
                contentType: "application/json; charset=utf-8",
                success: function (data, status, jqXHR) {
                fetchVendorDetails();
                refreshColumnsStaus();
                },
                error: function (xhr) {
                    jQuery("#error").text(xhr.d);
                }
            });
           
                var data = {
                    "BidID": sessionStorage.getItem("BidID")

                }
                //alert(JSON.stringify(data))
                jQuery.ajax({
                    url: sessionStorage.getItem("APIPath") + "VendorParticipation/ExtendDuration/",
                    type: "POST",
                    data: JSON.stringify(data),
                    contentType: "application/json; charset=utf-8",
                    success: function (data, status, jqXHR) {
                        //alert(data[0].TimeLeft)
                        display = document.querySelector('#lblTimeLeft');
                        startTimer((parseInt(data[0].TimeLeft)), display);
                        fetchVendorDetails()
                        return true
                    },
                    error: function (xhr) {
                        jQuery("#error").text(xhr.d);
                    }
                });
            }
        }
  


}
$("#txtrentalquote").keyup(function () {
        $('#spanrental').addClass('hide')
       return true
   
});
$("#txtmanpowerquote").keyup(function () {
    $('#spanmanpower').addClass('hide')
    return true

});
$("#txtinfrastructurequote").keyup(function () {
    $('#spaninfra').addClass('hide')
    return true

});
$("#txtutilityquote").keyup(function () {
    $('#spanutility').addClass('hide')
    return true

});
$("#txtfeequote").keyup(function () {
    $('#spanfee').addClass('hide')
    return true

});
function closeBidAir() {
    clearInterval(mytime)
    jQuery.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "VendorParticipation/CloseBid/?BidID=" + sessionStorage.getItem("BidID"),
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
            bootbox.alert("Bid time has been over. Thanks for Participation.", function () {
            window.location = sessionStorage.getItem('MainUrl');
                return false;
            });
        }
    });
}