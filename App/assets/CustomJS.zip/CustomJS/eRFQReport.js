﻿
var max = getUrlVarsURL(decryptedstring)["max"];
function fetchReguestforQuotationDetails() {
    var attachment = '';
    var termattach = '';
    //alert(sessionStorage.getItem("APIPath") + "eRequestForQuotation/eRFQDetails/?RFQID=" + sessionStorage.getItem('hddnRFQID') + "&CustomerID=" + sessionStorage.getItem('CustomerID') + "&UserID=" + sessionStorage.getItem('UserID'))
    jQuery.ajax({
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "eRequestForQuotation/eRFQDetails/?RFQID=" + sessionStorage.getItem('hddnRFQID') + "&CustomerID=" + sessionStorage.getItem('CustomerID') + "&UserID=" + sessionStorage.getItem('UserID'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "GET",
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function(RFQData) {
            $('#tbldetailsExcel > tbody').empty();
            if (RFQData.length > 0) {
               // attachment = RFQData[0].RFQAttachment.replace(/%20/g, " ").replace(/'&amp;'/g, "&");
                termattach = RFQData[0].General[0].RFQTermandCondition.replace(/%20/g, " ").replace(/'&amp;'/g, "&");

            } else {
               // attachment = attachment;
                termattach = termattach;
            }
            //sessionStorage.setItem('CurrentrfiID', RFQData[0].General[0].RFQId)
            jQuery('#RFQSubject').html(RFQData[0].General[0].RFQSubject)
          //  $('#watermark').css({ 'background-image': 'url(' + RFQData[0].General[0].LogoImage + ')' });
            //$('#watermark').css({ 'background-image': 'C:/PEV1SC/SourcingPortal/AgileApt/assets/aalogo.png' });
          
            jQuery('#lbl_ConfiguredBy').html("RFQ Configured By: " + RFQData[0].General[0].RFQConfigureByName)

            $('#Currency').html(RFQData[0].General[0].CurrencyNm)
            jQuery('#RFQDescription').html(RFQData[0].General[0].RFQDescription)
            //jQuery('#RFQStartDate').html(RFQData[0].General[0].RFQStartDate)
            jQuery('#RFQDeadline').html(RFQData[0].General[0].RFQStartDate+ ' / '+RFQData[0].General[0].RFQEndDate)
            jQuery('#ConversionRate').html(RFQData[0].General[0].RFQConversionRate)
            $('#TermCondition').attr('href', 'PortalDocs/eRFQ/' + sessionStorage.getItem('hddnRFQID') + '/' + termattach + '').html(RFQData[0].General[0].RFQTermandCondition)
            //$('#Attachment').attr('href', 'PortalDocs/RFQ/' + sessionStorage.getItem('hdnRfqID') + '/' + attachment + '').html(RFQData[0].RFQAttachment)
            $('#tbldetails').append("<tr><td>" + RFQData[0].General[0].RFQSubject + "</td><td>" + RFQData[0].General[0].RFQDescription + "</td><td id=tdVendorname></td><td>" + RFQData[0].General[0].CurrencyNm + "</td><td >" + RFQData[0].General[0].RFQConversionRate + "</td><td>" + RFQData[0].General[0].RFQEndDate + "</td></tr>")
            $('#tbldetailsExcel > tbody').append("<tr><td>" + RFQData[0].General[0].RFQSubject + "</td><td>" + RFQData[0].General[0].RFQDescription + "</td><td id=tdVendorname></td><td>" + RFQData[0].General[0].CurrencyNm + "</td><td >" + RFQData[0].General[0].RFQConversionRate + "</td><td>" + RFQData[0].General[0].RFQEndDate + "</td></tr>")
           
            jQuery('#refno').html(RFQData[0].General[0].RFQReference)
            // if (RFQData[0].General[0].RFQTermandCondition != '') {
            //    replaced1 = RFQData[0].General[0].RFQTermandCondition.replace(/\s/g, "%20")
            //}

            // $('#TermCondition').attr('href', 'PortalDocs/eFQ/' + $('#hddnRFQID').val() + '/' + replaced1).html(RFQData[0].General[0].RFQTermandCondition)
            //  $('#Attachment').attr('href', 'PortalDocs/RFQ/' + $('#hdnRfqID').val() + '/' + attachment + '').html(RFQData[0].RFQAttachment)
             
            //if (RFQData.length > 0) {
            //    for (var i = 0; i < RFQData.length; i++) {
            //        jQuery('#mapedapprover').append(jQuery('<option selected></option>').val(RFQData[i].UserID).html(RFQData[i].UserName))
            //    }
            //}


        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }

    });

}

function RFQFetchQuotedPriceReport() {
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    var vendorattach = '';
   //alert(sessionStorage.getItem("APIPath") + "RequestForQuotation/RFQFetchQuotedPriceReport/?VendorID=" + sessionStorage.getItem('hddnVendorId') + "&RFQId=" + sessionStorage.getItem('hddnRFQID'))
    jQuery.ajax({
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "eRFQReport/eRFQFetchQuotedPriceReport/?VendorID=" + sessionStorage.getItem('hddnVendorId') + "&RFQId=" + sessionStorage.getItem('hddnRFQID') + "&RFQVersionId=" + sessionStorage.getItem('RFQVersionId'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "GET",
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data) {
            var totalamountsum = 0.0;
           //alert(JSON.stringify(data))
            if (data[0].QuotesDetails.length > 0) {
                var description = "";
                jQuery("#tblServicesProduct").empty();
                jQuery("#tblServicesProductforexcel").empty();
                $('#divdomestic').show();
                $('#btnExport').show();
               // $('#btnprint').show();
                $('#RFQVendorname').html(data[0].QuotesDetails[0].VendorName);
                $('#tdVendorname').html(data[0].QuotesDetails[0].VendorName);
                if (data[0].QuotesDetails[0].VendorRemarks != '') {
                   
                    $('#tblvendorremarks').removeClass('hide')
                    $('#vRemarks').text(data[0].QuotesDetails[0].VendorRemarks.replace(/<br>/g, '\n'))
                   
                } 
                else{
                    $('#tblvendorremarks').addClass('hide')
                }
               
                for (var i = 0; i < data[0].QuotesDetails.length; i++) {

                    var taxHRTextinc = stringDivider("Landed Unit Price (Without GST)", 12, "<br/>\n");
                    var taxHRTextEx = stringDivider("Landed Unit Price (With GST)", 12, "<br/>\n");
                    var HRUnitRate = stringDivider("Amount (Inc. Taxes)", 12, "<br/>\n");
                    var totalamount = 0.0;
                    var bsicpercentageofGST = 0.0;
                    //if (data[i].RFQBoq == 'Y ') {                       
                    description = stringDivider(data[0].QuotesDetails[i].RFQDescription, 45, "<br/>\n");

                    if (i == 0) {
                        jQuery('#tblServicesProduct').append('<thead><tr style="background: grey; color:light black;"><th style="width:40%!important;">Short Name</th><th>Quantity</th><th>UOM</th><th>' + taxHRTextinc + '</th><th>' + taxHRTextEx + '</th><th>' + HRUnitRate + '</th><th>Description</th></tr></thead>');
                        jQuery('#tblServicesProductforexcel').append('<thead><tr style="background: grey; color:light black;"><th style="width:40%!important;">Short Name</th><th>Quantity</th><th>UOM</th><th>' + taxHRTextinc + '</th><th>' + taxHRTextEx + '</th><th>' + HRUnitRate + '</th><th>Description</th></tr></thead>');
                    }
                    if (data[0].QuotesDetails[i].RFQTCID == 0) {
                        if (sessionStorage.getItem('ShowPrice') == "Y" || sessionStorage.getItem('ShowPrice') == "") {
                            totalamount = data[0].QuotesDetails[i].RFQVendorPricewithTax * data[0].QuotesDetails[i].Quantity;
                            jQuery('#tblServicesProduct').append('<thead id=headid' + i + '><tr style="background: #ccc; color:grey;"><td style="width:40%!important;"><b>' + data[0].QuotesDetails[i].RFQShortName + '&nbsp(TC Given Below)</b></td><td class=text-right><b>' + thousands_separators(data[0].QuotesDetails[i].Quantity) + '</b></td><td><b>' + data[0].QuotesDetails[i].UOM + '</b></td><td class=text-right><b>' + thousands_separators(data[0].QuotesDetails[i].RFQVendorPricewithoutGST) + '</b></td><td class=text-right><b>' + thousands_separators(data[0].QuotesDetails[i].RFQVendorPricewithTax) + '</b></td><td class=text-right><b>' + thousands_separators(totalamount) + '</b></td><td><b>' + description + '</b></td></tr></thead>');
                            jQuery('#tblServicesProductforexcel').append('<thead id=headid' + i + '><tr><td style="width:40%!important;"><b>' + data[0].QuotesDetails[i].RFQShortName + '&nbsp(TC Given Below)</b></td><td class=text-right><b>' + thousands_separators(data[0].QuotesDetails[i].Quantity) + '</b></td><td><b>' + data[0].QuotesDetails[i].UOM + '</b></td><td class=text-right><b>' + thousands_separators(data[0].QuotesDetails[i].RFQVendorPricewithoutGST) + '</b></td><td class=text-right><b>' + thousands_separators(data[0].QuotesDetails[i].RFQVendorPricewithTax) + '</b></td><td class=text-right><b>' + thousands_separators(totalamount) + '</b></td><td><b>' + description + '</b></td></tr></thead>');
                            totalamountsum = totalamountsum + totalamount;
                        }
                        else {
                           
                            jQuery('#tblServicesProduct').append('<thead id=headid' + i + '><tr style="background: #ccc; color:grey;"><td style="width:40%!important;"><b>' + data[0].QuotesDetails[i].RFQShortName + '&nbsp(TC Given Below)</b></td><td class=text-right><b>' + thousands_separators(data[0].QuotesDetails[i].Quantity) + '</b></td><td><b>' + data[0].QuotesDetails[i].UOM + '</b></td><td class=text-right><b>Quoted</b></td><td class=text-right><b>Quoted</b></td><td class=text-right><b>Quoted</b></td><td><b>' + description + '</b></td></tr></thead>');
                            jQuery('#tblServicesProductforexcel').append('<thead id=headid' + i + '><tr><td style="width:40%!important;"><b>' + data[0].QuotesDetails[i].RFQShortName + '&nbsp(TC Given Below)</b></td><td class=text-right><b>' + thousands_separators(data[0].QuotesDetails[i].Quantity) + '</b></td><td><b>' + data[0].QuotesDetails[i].UOM + '</b></td><td class=text-right><b>Quoted</b></td><td class=text-right><b>Quoted</b></td><td class=text-right><b>Quoted</b></td><td><b>' + description + '</b></td></tr></thead>');
                           
                        }
                    }

                    for (var j = 0; j < data[0].QuotesDetails.length; j++) {
                        description = stringDivider(data[0].QuotesDetails[j].RFQDescription, 45, "<br/>\n");  // for word wrap
                        // if (data[0].QuotesDetails[i].RFQParameterId == data[0].QuotesDetails[j].RFQParameterId && data[0].QuotesDetails[j].RFQTCID != 0) {
                        if (j == 0) {
                            if (sessionStorage.getItem('ShowPrice') == "Y" || sessionStorage.getItem('ShowPrice') == "") {
                                jQuery("#tblServicesProduct > #headid" + i + "").append('<tr id=trid' + j + '><td>Basic Price</td><td class=text-right>' + '' + '</td><td>' + '' + '</td><td  class=text-right>' + '' + '</td><td class=text-right>' + (data[0].QuotesDetails[i].UnitRate) + '</td><td class=text-right>' + '' + '</td><td>' + '' + '</td></tr>');
                                jQuery("#tblServicesProductforexcel  > #headid" + i + "").append('<tr id=trid' + j + '><td>Basic Price</td><td class=text-right>' + '' + '</td><td>' + '' + '</td><td  class=text-right>' + '' + '</td><td class=text-right>' + (data[0].QuotesDetails[i].UnitRate) + '</td><td class=text-right>' + '' + '</td><td>' + '' + '</td></tr>');
                            }
                            else{
                                jQuery("#tblServicesProduct > #headid" + i + "").append('<tr id=trid' + j + '><td>Basic Price</td><td class=text-right>' + '' + '</td><td>' + '' + '</td><td  class=text-right>' + '' + '</td><td class=text-right>Quoted</td><td class=text-right>' + '' + '</td><td>' + '' + '</td></tr>');
                                jQuery("#tblServicesProductforexcel  > #headid" + i + "").append('<tr id=trid' + j + '><td>Basic Price</td><td class=text-right>' + '' + '</td><td>' + '' + '</td><td  class=text-right>' + '' + '</td><td class=text-right>Quoted</td><td class=text-right>' + '' + '</td><td>' + '' + '</td></tr>');
                            }
                        }
                        if (data[0].QuotesDetails[j].RFQTCID != 0 && data[0].QuotesDetails[i].RFQParameterId == data[0].QuotesDetails[j].RFQParameterId) {
                            bsicpercentageofGST = data[0].QuotesDetails[i].UnitRate * (data[0].QuotesDetails[j].TermRate / 100)
                            if (sessionStorage.getItem('ShowPrice') == "Y" || sessionStorage.getItem('ShowPrice') == "") {
                                jQuery("#tblServicesProduct > #headid" + i + "").append('<tr id=trid' + j + '><td>' + data[0].QuotesDetails[j].TermName + '</td><td class=text-right>' + '' + '</td><td>' + '' + '</td><td  class=text-right>' + (data[0].QuotesDetails[j].TermRate) + '%</td><td class=text-right>' + bsicpercentageofGST + '</td><td class=text-right>' + '' + '</td><td>' + '' + '</td></tr>');
                                jQuery("#tblServicesProductforexcel  > #headid" + i + "").append('<tr id=trid' + j + '><td>' + data[0].QuotesDetails[j].TermName + '</td><td class=text-right>' + '' + '</td><td>' + '' + '</td><td  class=text-right>' + data[0].QuotesDetails[j].TermRate + '%</td><td class=text-right>' + bsicpercentageofGST + '</td><td class=text-right>' + '' + '</td><td>' + '' + '</td></tr>');
                            }
                            else {
                                jQuery("#tblServicesProduct > #headid" + i + "").append('<tr id=trid' + j + '><td>' + data[0].QuotesDetails[j].TermName + '</td><td class=text-right>' + '' + '</td><td>' + '' + '</td><td  class=text-right>Quoted</td><td class=text-right>Quoted</td><td class=text-right>' + '' + '</td><td>' + '' + '</td></tr>');
                                jQuery("#tblServicesProductforexcel  > #headid" + i + "").append('<tr id=trid' + j + '><td>' + data[0].QuotesDetails[j].TermName + '</td><td class=text-right>' + '' + '</td><td>' + '' + '</td><td  class=text-right>Quoted</td><td class=text-right>Quoted</td><td class=text-right>' + '' + '</td><td>' + '' + '</td></tr>');
                            }
                        }
                    }
                }
                jQuery('#tblServicesProduct').append('<thead><tr style="background: #ccc; color:grey;white-space:nowrap!important;"><td colspan=4></td><td class=text-right><b>Total</b></td><td class=text-right><b>' + thousands_separators(totalamountsum) + '</b></td><td>&nbsp;</td></tr></thead>');
                jQuery('#tblServicesProductforexcel').append('<thead><tr><td colspan=4></td><td class=text-right><b>Total</b></td><td class=text-right><b>' + thousands_separators(totalamountsum) + '</b></td><td>&nbsp;</td></tr></thead>');
                  
            }
           
            else
            {
                
                jQuery('#tblServicesProduct').append('<tr><td>No Record Found</td></tr>');
                jQuery('#tblServicesProductforexcel').append('<tr><td>No Record Found</td></tr>');
            }
            if (data[0].CommercialTerms.length > 0) {
                jQuery("#tblcommercialtermsprev").empty();
                jQuery("#tblcommercialterms").empty();
               // jQuery("#tblcommercialtermsprev").removeClass('hide');
                jQuery("#tblcommercialterms").append("<thead><tr style='background: gray; color: #FFF;'><th style='width:30%'>Other Commercial Terms</th><th style='width:30%'>Our Requirement</th><th>Your Offer</th></tr></thead>");
                jQuery("#tblcommercialtermsprev").append("<thead><tr><th style='width:30%'>Other Commercial Terms</th><th style='width:30%'>Our Requirement</th><th>Your Offer</th></tr></thead>");
                for (var i = 0; i < data[0].CommercialTerms.length; i++) {
                    jQuery('<tr id=trid' + i + '><td>' + data[0].CommercialTerms[i].TermName + '</td><td>' + data[0].CommercialTerms[i].Requirement + '</td><td>' + data[0].CommercialTerms[i].Remarks + '</td></tr>').appendTo("#tblcommercialterms");
                    jQuery('<tr id=trid' + i + '><td>' + data[0].CommercialTerms[i].TermName + '</td><td>' + data[0].CommercialTerms[i].Requirement + '</td><td>' + data[0].CommercialTerms[i].Remarks + '</td></tr>').appendTo("#tblcommercialtermsprev");
                }
            }
            else {
                //jQuery("#tblcommercialtermsprev").addClass('hide');
                jQuery('#tblcommercialterms').append('<tr><td>No Record Found</td></tr>');
                jQuery('#tblcommercialtermsprev').append('<tr><td>No Record Found</td></tr>');
            }
            if (data[0].Questions.length > 0) {
                jQuery("#tblquestions").empty();
                jQuery("#tblquestionsprev").empty();
               // jQuery("#tblquestionsprev").removeClass('hide');
                jQuery('#tblquestions').append("<thead><tr  style='background: gray; color: #FFF;'><th class='bold' style='width:30%!important'>Questions</th><th class='bold' style='width:30%!important'>Our Requirement</th><th style='width:40%!important'>Answer</th></tr></thead>");
                jQuery('#tblquestionsprev').append("<thead><tr><th class='bold' style='width:30%!important'>Questions</th><th class='bold' style='width:30%!important'>Our Requirement</th><th style='width:40%!important'>Answer</th></tr></thead>");
                for (var i = 0; i < data[0].Questions.length; i++) {
                    jQuery('<tr id=trid' + i + '><td style="width:30%">' + data[0].Questions[i].Question + '</td><td>' + data[0].Questions[i].Requirement + '</td><td>' + data[0].Questions[i].Answer + '</td></tr>').appendTo("#tblquestions");
                    jQuery('<tr id=trid' + i + '><td style="width:20%">' + data[0].Questions[i].Question + '</td><td>' + data[0].Questions[i].Requirement + '</td><td>' + data[0].Questions[i].Answer + '</td></tr>').appendTo("#tblquestionsprev");
                }
            }
            else {
              //  jQuery("#tblquestionsprev").addClass('hide')
                jQuery('#tblquestions').append('<tr><td>No Record Found</td></tr>');
                jQuery('#tblquestionsprev').append('<tr><td>No Record Found</td></tr>');
            }
            var version = 0;
            if (data[0].Attachments.length > 0) {
                jQuery("#tblAttachments").empty();
                jQuery("#tblAttachmentsprev").empty();
                //jQuery("#tblAttachmentsprev").removeClass('hide');
                jQuery('#tblAttachments').append("<thead><tr  style='background: gray; color: #FFF;'><th class='bold' style='width:30%!important'>Description</th><th class='bold'>Attachment</th></tr></thead>");
                jQuery('#tblAttachmentsprev').append("<thead><tr><th class='bold' style='width:30%!important'>Description</th><th class='bold'>Attachment</th></tr></thead>");
                for (var i = 0; i < data[0].Attachments.length; i++) {

                    if (sessionStorage.getItem('RFQVersionId') == 99) {
                        version = max;
                    }
                    else {
                        version = sessionStorage.getItem('RFQVersionId');
                    }
                    jQuery('<tr id=trid' + i + '><td>' + data[0].Attachments[i].AttachmentDescription + '</td><td><a style="pointer:cursur;text-decoration:none;" target=_blank href=PortalDocs/eRFQ/' + sessionStorage.getItem("hddnRFQID") + '/' + sessionStorage.getItem('hddnVendorId') + '/' + version + '/' + data[0].Attachments[i].Attachment.replace(/\s/g, "%20") + '>' + data[0].Attachments[i].Attachment + '</a></td></tr>').appendTo("#tblAttachments");
                    jQuery('<tr id=trid' + i + '><td>' + data[0].Attachments[i].AttachmentDescription + '</td><td>' + data[0].Attachments[i].Attachment + '</td></tr>').appendTo("#tblAttachmentsprev");
                }
            }
            else {
               // jQuery("#tblAttachmentsprev").addClass('hide');
                jQuery('#tblAttachments').append('<tr><td>No Record Found</td></tr>');
                jQuery('#tblAttachmentsprev').append('<tr><td>No Record Found</td></tr>');
            }
            jQuery.unblockUI();
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }

    });

}
function stringDivider(str, width, spaceReplacer) {
    if (str.length > width) {
        var p = width
        for (; p > 0 && str[p] != ' '; p--) {
        }
        if (p > 0) {
            var left = str.substring(0, p);
            var right = str.substring(p + 1);
            return left + spaceReplacer + stringDivider(right, width, spaceReplacer);
        }
    }
    return str;
}

var tableToExcel = (function () {
    var uri = 'data:application/vnd.ms-excel;base64,'
      , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>'
      , base64 = function (s) { return window.btoa(unescape(encodeURIComponent(s))) }
      , format = function (s, c) { return s.replace(/{(\w+)}/g, function (m, p) { return c[p]; }) }
    return function (table, name, filename) {
        if (!table.nodeType) table = document.getElementById(table)
        var ctx = { worksheet: name || 'Worksheet', table: table.innerHTML }
        document.getElementById("dlink").href = uri + base64(format(template, ctx));
        document.getElementById("dlink").download = filename;
        document.getElementById("dlink").click();
    }
})()

setTimeout(function () {sessionStorage.removeItem('selectedboqtxtboxid') }, 5000);
