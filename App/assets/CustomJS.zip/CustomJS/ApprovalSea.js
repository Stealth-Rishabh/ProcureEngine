﻿var BidID = "";
var ButtonType = '';
var App1 = '';
jQuery(document).ready(function () {
    BidID = getUrlVars()["BidID"];
    FetchVendors(BidID);
    App1 = getUrlVars()['App'];
	fillhelp(App1);
});

function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}
function FetchVendors(BidID) {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ApprovalAir/fetchVendor/?BidID=" + BidID + "&VendorType=YES&AuthenticationToken=" + sessionStorage.getItem('AuthenticationToken'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data) {
            jQuery("#ddlVendors,#ddlVendorsAdmin").empty();
            jQuery("#ddlVendors,#ddlVendorsAdmin").append(jQuery("<option ></option>").val("").html("Select"));
            for (var i = 0; i < data.length; i++) {
                jQuery("#ddlVendors,#ddlVendorsAdmin").append(jQuery("<option ></option>").val(data[i].VendorID).html(data[i].VendorName));
            }
            FetchRecomendedVendor(BidID)
        }
    });
  
   
}






var FormValidation = function () {
    var validateModication = function () {
        var form1 = $('#formModify');
        var error1 = $('.alert-danger', form1);
        var success1 = $('.alert-success', form1);

        form1.validate({
            errorElement: 'span',
            errorClass: 'help-block',
            focusInvalid: false,
            ignore: "",

            rules: {
                txtBAF: {
                    required: true,
                    number: true,
                    minlength: 1,
                    maxlength: 10
                },
                txtCAF: {
                    required: true,
                    number: true,
                    minlength: 1,
                    maxlength: 10
                },
                txtDocharges: {
                    required: true,
                    number: true,
                    minlength: 1,
                    maxlength: 10
                },
                txttargetfreight: {
                    required: true,
                    number: true,
                    minlength: 1,
                    maxlength: 10
                },
                txttargetexwork: {
                    required: true,
                    number: true,
                    minlength: 1,
                    maxlength: 10
                }
            },
            messages: {
                txtBAF: {
                    required: "Please enter BAF"
                },
                txtCAF: {
                    required: "Please enter CAF"
                },
                txtDocharges: {
                    required: "Please enter Docharges"
                },
                txttargetfreight: {
                    required: "Please enter freight"
                },
                txttargetexwork: {
                    required: "Please enter ExWork"
                }
            },

            invalidHandler: function (event, validator) { //display error alert on form submit              
                success1.hide();
                error1.show();
                // App.scrollTo(error1, -300);
            },

            highlight: function (element) { // hightlight error inputs
                $(element)
                        .closest('.Input-group').addClass('has-error'); // set error class to the control group
            },

            unhighlight: function (element) { // revert the change done by hightlight
                $(element)
                        .closest('.Input-group').removeClass('has-error'); // set error class to the control group
            },

            success: function (label) {
                label
                        .closest('.Input-group').removeClass('has-error'); // set success class to the control group
            },

            submitHandler: function (form) {
                InsertBidModificationSea();
                //App.scrollTo(error1, -100);
            }
        });
    }
    var validateformsea = function () {
        var form1 = $('#formsubmitadmin');
        var error1 = $('.alert-danger', form1);
        var success1 = $('.alert-success', form1);
        form1.validate({
            errorElement: 'span',
            errorClass: 'help-block',
            focusInvalid: false,
            ignore: "",

            rules: {
                ddlVendorsAdmin: {
                    required: true,
                },
                txtbidspecification: {
                    required: true,
                }
            },
            messages: {
                ddlVendorsAdmin: {
                    required: "Please select vendor"
                },
                txtbidspecification: {
                    required: "Please enter your comment"
                }
            },

            invalidHandler: function (event, validator) { //display error alert on form submit              
                success1.hide();
                error1.show();
                // App.scrollTo(error1, -300);
            },

            highlight: function (element) { // hightlight error inputs
                $(element)
                        .closest('.Input-group').addClass('has-error'); // set error class to the control group
            },

            unhighlight: function (element) { // revert the change done by hightlight
                $(element)
                        .closest('.Input-group').removeClass('has-error'); // set error class to the control group
            },

            success: function (label) {
                label
                        .closest('.Input-group').removeClass('has-error'); // set success class to the control group
            },

            submitHandler: function (form) {
                if (AppStatus == 'Reverted') {
                   
					//if (ButtonType == 'Cancel') {
                      //  CancelBid(BidID);
                    //} else {
                       
						 ApprovalAdmin();
                    //} 
                }
                else {
					 //if (ButtonType == 'Cancel') {
                       // CancelBid(BidID);
                    //} else {
                        ForwardBid(BidID, BidTypeID, BidForID)
						
                    //}
                    
                }
                //App.scrollTo(error1, -100)
            }
        });
    }
    var validateAppsubmitData = function () {
        var form1 = $('#frmsubmitapp');
        var error1 = $('.alert-danger', form1);
        var success1 = $('.alert-success', form1);
        form1.validate({
            errorElement: 'span',
            errorClass: 'help-block',
            focusInvalid: false,
            ignore: "",

            rules: {
                ddlActionType: {
                    required: true,
                },
                ddlVendors: {
                    required: true,
                },
                txtRemarksApp: {
                    required: true,
                }
            },
            messages: {
                ddlActionType: {
                    required: "Please select Action"
                },
                ddlVendors: {
                    required: "Please select vendor"
                },
                txtRemarksApp: {
                    required: "Please enter your comment"
                }
            },

            invalidHandler: function (event, validator) { //display error alert on form submit              
                success1.hide();
                error1.show();
                //App.scrollTo(error1, -300);
            },

            highlight: function (element) { // hightlight error inputs
                $(element)
                        .closest('.Input-group').addClass('has-error'); // set error class to the control group
            },

            unhighlight: function (element) { // revert the change done by hightlight
                $(element)
                        .closest('.Input-group').removeClass('has-error'); // set error class to the control group
            },

            success: function (label) {
                label
                        .closest('.Input-group').removeClass('has-error'); // set success class to the control group
            },

            submitHandler: function (form) {
                
				//if (ButtonType != 'Cancel') {
                    ApprovalApp();
				//} else {                    
                  // CancelBid(BidID);
                //}  
                //App.scrollTo(error1, -100)
            }
        });
    }
    var validateformAwardedsubmit = function () {
        var form1 = $('#formAwardedsubmit');
        var error1 = $('.alert-danger', form1);
        var success1 = $('.alert-success', form1);
        form1.validate({
            errorElement: 'span',
            errorClass: 'help-block',
            focusInvalid: false,
            ignore: "",

            rules: {
                txtRemarksAward: {
                    required: true
                }
            },
            messages: {
                txtRemarksAward: {
                    required: "Please enter your comment"
                }
            },

            invalidHandler: function (event, validator) { //display error alert on form submit              
                success1.hide();
                error1.show();
                //App.scrollTo(error1, -300);
            },

            highlight: function (element) { // hightlight error inputs
                $(element)
                        .closest('.Input-group').addClass('has-error'); // set error class to the control group
            },

            unhighlight: function (element) { // revert the change done by hightlight
                $(element)
                        .closest('.Input-group').removeClass('has-error'); // set error class to the control group
            },

            success: function (label) {
                label
                        .closest('.Input-group').removeClass('has-error'); // set success class to the control group
            },

            submitHandler: function (form) {
                
				//if (ButtonType != 'Cancel') {
                   AwardBid(BidID)                 
                //} else {                    
                  // CancelBid(BidID);
                //} 
                //App.scrollTo(error1, -100)

            }
        });
    }
    var handleWysihtml5 = function () {
        if (!jQuery().wysihtml5) {
            return;
        }
        if ($('.wysihtml5').size() > 0) {
            $('.wysihtml5').wysihtml5({
                "stylesheets": ["assets/plugins/bootstrap-wysihtml5/wysiwyg-color.css"]
            });
        }
    }
    return {
        init: function () {
            handleWysihtml5();
            validateModication();
            validateformsea();
            validateAppsubmitData();
            validateformAwardedsubmit();
        }
    };
}();

function fillhelp(App1) {

    if (App1 == 'N') {
        $('#Approver').show()
    }

    else {
        $('#awarded').show()
    }

}


jQuery("#btnCancelbidAdmin").click(function () {
    ButtonType = 'Cancel';
    cancelBtnclick();
});

jQuery("#btnCancelbidApp").click(function () {
    ButtonType = 'Cancel';
    cancelBtnclick();
});

jQuery("#btnSubmitApp").click(function () {
    ButtonType = '';
});

jQuery("#btnSubmitAdmin").click(function () {
    ButtonType = '';
});

jQuery("#btnCancelbidAward").click(function () {
    ButtonType = 'Cancel';
    cancelBtnclick();
});

jQuery("#btnSubmitAward").click(function () {
    ButtonType = '';
});

