﻿var Changepassworderror = $('#errordivChangePassword');
var Changepasswordsuccess = $('#successdivChangePassword');
Changepassworderror.hide();
Changepasswordsuccess.hide();
function handleChangePasword() {

    $('#ChangePasswordfrm').validate({
        errorElement: 'span', //default input error message container
        errorClass: 'help-block', // default input error message class
        focusInvalid: false,
        rules: {

            oPassword: {
                required: true
            },
            nPassword: {
                required: true
            },
            reEnterPass: {
                required: true
            }


        },
        messages: {

            oPassword: {
                required: "Old Password Type is required."
            },
            nPassword: {
                required: "New Password is required."
            },
            reEnterPass: {
                required: "Re-Enter  is required."
            }


        },
        invalidHandler: function (event, validator) { //display error alert on form submit   
            Changepasswordsuccess.hide();
            jQuery("#errorpassword").text("You have some form errors. Please check below.");
            Changepassworderror.show();
            Changepassworderror.fadeOut(5000);
        },

        highlight: function (element) { // hightlight error inputs
            $(element)
                        .closest('.form-group').addClass('has-error'); // set error class to the control group
        },

        success: function (label) {
            label.closest('.form-group').removeClass('has-error');
            label.remove();
        },

        errorPlacement: function (error, element) {
            error.insertAfter(element.closest('.xyz'));
        },

        submitHandler: function (form) {
            Changepassworderror.hide();
            ChangePassword();

        }
    });

}
function ChangePassword() {
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    if ($("#nPassword").val() != $("#reEnterPass").val()) {
        jQuery("#errorpassword").text("Password not matched..");
        Changepassworderror.show();
        Changepassworderror.fadeOut(5000);
        jQuery.unblockUI();
        return;
    }
    else {
        var data = {
            "EmailID": sessionStorage.getItem("EmailID"),
            "OldPassword": $("#oPassword").val(),
            "NewPassword": $("#nPassword").val(),
            "BidID": sessionStorage.getItem("BidID"),
            "UserType": sessionStorage.getItem("UserType")
        }

        //alert(JSON.stringify(data));

        jQuery.ajax({
            url: sessionStorage.getItem("APIPath") + "ChangeForgotPassword/ChangePassword",
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            type: "POST",
            data: JSON.stringify(data),
            contentType: "application/json; charset=utf-8",
            EnableViewState:false,
            success: function (data, status, jqXHR) {
                if (data[0].FlagStatus == "1") {

                    jQuery("#sucessPassword").html("Your Password has been Changed successfully..");
                    Changepasswordsuccess.show();
                    Changepasswordsuccess.fadeOut(5000);
                    clearResetForm();
                    jQuery.unblockUI();
                }
                else {
                    jQuery("#errorpassword").html("Please try again with correct current password..");
                    Changepassworderror.show();
                    Changepassworderror.fadeOut(5000);
                    jQuery.unblockUI();
                }
            },
            error: function (xhr, status, error) {
                var err = eval("(" + xhr.responseText + ")");
                jQuery("#error").text(err.Message);
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }

                jQuery.unblockUI();
            }
        });
    }

}

function clearResetForm() {
    $('#nPassword').val('');
    $('#reEnterPass').val('');
    $('#oPassword').val('');
}
function fnischeckSysGeneratedPass() {
   
    if (sessionStorage.getItem("IsSysPassword") == "Y") {
            bootbox.dialog({
                message: "You are using System Generated password. It is recommended to change your password. Please press yes to change your password and no if you want to do it later. ",
                buttons: {
                    confirm: {
                        label: "Yes",
                        className: "btn-success",
                        callback: function () {
                            $('#ChangePassword').modal('show');
                        }
                    },
                    cancel: {
                        label: "No",
                        className: "btn-default",
                        callback: function () {
                            return;
                        }
                    }
                }
            });

       
    }
    //else {

    //}
}
function fetchDashboardData() {
  //  fnischeckSysGeneratedPass();
    handleChangePasword();
    fetchPendingBid()
    formvalidate()
}
sessionStorage.setItem('CustomerID', '0')
function GetDataForCust() {
    sessionStorage.setItem('CustomerID', $('#ULCustomers').val())
    setTimeout(function () {
        fetchPendingBid();
    },400)
}
function fetchPendingBid() {
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    //alert(sessionStorage.getItem("APIPath") + "VendorDashboard/VendorfetchDashboardData/?VendorID=" + encodeURIComponent(sessionStorage.getItem('UserID')) + "&AuthenticationToken=" + sessionStorage.getItem('AuthenticationToken') + "&CustomerID=" + $('#ULCustomers').val())
    if ($('#ULCustomers').val() == null) {
        $('#ULCustomers').val('0')
        sessionStorage.setItem('CustomerID','0')
    }
    jQuery.ajax({
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "VendorDashboard/VendorfetchDashboardData/?VendorID=" + encodeURIComponent(sessionStorage.getItem('VendorId')) + "&AuthenticationToken=" + sessionStorage.getItem('AuthenticationToken') + "&CustomerID=" + sessionStorage.getItem('CustomerID'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "GET",
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data) {
            jQuery("#div_portlet").removeClass();
            jQuery("#iconclass").addClass('fa fa-check');
            jQuery("#spanPanelCaption").text("Open Events");
            jQuery("#div_portlet").addClass('portlet box green-turquoise');

            jQuery('#lblOpenCount').text(data[0].OpenBids[0].NoofBid)
            jQuery('#lblClosedCount').text(data[0].CloseBids[0].NoofBid)
            jQuery('#lblopenRFXCount').text(data[0].OpenRFX[0].NoofBid)
            jQuery('#lblClosedRFXCount').text(data[0].CloseRFX[0].NoofBid)
            jQuery('#lblpendingPO').text(data[0].POPending[0].NoofBid)
            jQuery('#lblAcceptedPO').text(data[0].POAccepted[0].NoofBid)
            $('#totalrecord').text('');
            jQuery("#UlPendingActivity").empty();

            if (data[0].PendingActivity.length > 0) {
                $('#totalrecord').text('(' +data[0].PendingActivity.length+')')
                for (var i = 0; i < data[0].PendingActivity.length; i++) {
                   
                 
                    str = "<li><a href='javascript:;' onclick=fnOpenLink(\'" + data[0].PendingActivity[i].LinkURL + "'\,\'" + data[0].PendingActivity[i].BidID + "'\,\'" + data[0].PendingActivity[i].isTermsConditionsAccepted + "'\,\'" + data[0].PendingActivity[i].BidTypeID + "',\'" + data[0].PendingActivity[i].Version + "'\)>";
                    str += "<div class='col1'><div class='cont'>";
                    str += "<div class='cont-col1'><div class='label label-sm label-success'><i id=icon" + i + "></i></div></div>";
                    str += "<div class='cont-col2'><div class='desc'>" + data[0].PendingActivity[i].ActivityDescription + "&nbsp;&nbsp;";
                   
                   
                    if (data[0].PendingActivity[i].isTermsConditionsAccepted != "Y") {// && data[0].PendingActivity[i].BidTypeName!='PO'
                        str += "<span class='label label-sm label-info'>" + data[0].PendingActivity[i].BidTypeName + " </span>&nbsp;&nbsp;<span class='badge badge-danger'> new </span>";
               
                    }
                    else {
                                str += "<span class='label label-sm label-info'>" + data[0].PendingActivity[i].BidTypeName + "</span>";
                    }
                    str += "</div></div></div></div>";
                    
                    str += "<div class='col2' style='width: 110px !important; margin-left:-110px !important;'>";
                    str += "<div class='date'><span class='label label-sm label-warning'>" + data[0].PendingActivity[i].BidStatus + "</span></div></div>";
                    str += "</a></li>";
                    jQuery('#UlPendingActivity').append(str);
                   
                    if (data[0].PendingActivity[i].BidTypeName == 'Forward Auction') {
                        $('#icon' + i).addClass('fa fa-forward');
                    }
                    else if (data[0].PendingActivity[i].BidTypeName == 'Reverse Auction') {
                        $('#icon' + i).addClass('fa fa-gavel');
                    }
                    else if (data[0].PendingActivity[i].BidTypeName == 'VQ') {
                        jQuery('#icon' + i).addClass('fa fa-question-circle');
                    } else if (data[0].PendingActivity[i].BidTypeName == 'RFI') {
                        jQuery('#icon' + i).addClass('fa fa-envelope-o');
                    } else if (data[0].PendingActivity[i].BidTypeName == 'RFQ') {
                        $('#icon' + i).addClass('fa fa-envelope-o');
                    }
                    else if (data[0].PendingActivity[i].BidTypeName == 'eRFQ') {
                        $('#icon' + i).addClass('fa fa-envelope-o');
                    }
                    else if (data[0].PendingActivity[i].BidTypeName == 'PO') {
                        $('#icon' + i).addClass('fa fa-file');
                    }
                }
            }
            else {
                jQuery('#UlPendingActivity').append("<tr><td colspan='8' style='text-align: center; color:red;'>You have no pending activity.</td></tr>");
            }
            jQuery.unblockUI();
            //jQuery("#ulList").empty();
            //if (BidData[0].TodayBidStatus.length > 0) {
            //    for (var i = 0; i < BidData[0].TodayBidStatus.length; i++) {
            //        str = "<li><a href=" + BidData[0].TodayBidStatus[i].LinkURL + ">";
            //        str += "<div class='col1'><div class='cont'>";
            //        str += "<div class='cont-col1'><div class='label label-sm label-success'><i class='fa fa-check'></i></div></div>";
            //        str += "<div class='cont-col2'><div class='desc'>" + BidData[0].TodayBidStatus[i].ActivityDescription + "&nbsp;&nbsp;";
            //        str += "<span class='label label-sm label-warning'>" + BidData[0].TodayBidStatus[i].BidTypeName + "</span>";
            //        str += "</div></div></div></div>";
            //        str += "<div class='col2'>";
            //        str += "<div class='date'>" + BidData[0].TodayBidStatus[i].BidStatus + "</div></div>";
            //        str += "</a></li>";
            //        jQuery('#ulList').append(str);
            //    }
            //}
            //else {
            //    jQuery('#ulList').append("<tr><td colspan='8' style='text-align: center; color:red;'>No bid is configured for today.</td></tr>");
            //}

            //if (BidData[0].TodayBidStatusCount.length > 0) {
            //    for (var i = 0; i < BidData[0].TodayBidStatusCount.length; i++) {
            //        if (BidData[0].TodayBidStatusCount[i].BidStatus == "Open") {
            //            jQuery('#spanOpen').html(BidData[0].TodayBidStatusCount[i].BidCount)
            //        }
            //        else if (BidData[0].TodayBidStatusCount[i].BidStatus == "Not Forwarded") {
            //            jQuery('#spanNotForwarded').html(BidData[0].TodayBidStatusCount[i].BidCount)
            //        }
            //        else if (BidData[0].TodayBidStatusCount[i].BidStatus == "Forwarded") {
            //            jQuery('#spanForwarded').html(BidData[0].TodayBidStatusCount[i].BidCount)
            //        }
            //        else if (BidData[0].TodayBidStatusCount[i].BidStatus == "Awarded") {
            //            jQuery('#spanAwarded').html(BidData[0].TodayBidStatusCount[i].BidCount)
            //        }
            //    }
            //}

        },
        error: function (xhr, status, error) {
            var err = eval("(" + xhr.responseText + ")");
            jQuery("#error").text(err.Message);
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            jQuery.unblockUI();
        }
    });
}
var _Bidtype = '';
var EventType = '';

function fnOpenLink(linkurl, Bidid, isterms, bidtype,version) {
    
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    
    if (isterms != 'Y') {
        $('#termscondition').modal('show')
    }
    else {
        window.location = linkurl;
    }
   
    _Bidtype = bidtype;
   
    if (bidtype == 'VQ' || bidtype == 'RFQ' || bidtype == 'RFI' || bidtype == 'eRFQ') {
        EventType = 'RFX';
        sessionStorage.setItem('BidID', '0')
        sessionStorage.setItem('hddnRFQRFIID', Bidid)
        sessionStorage.setItem('RFQVersionId', version)
        $('#div_euctions').addClass('hide')
       
        if (bidtype == "eRFQ") {
            $('#div_eRFQ').removeClass('hide')
            $('#div_RFQ').addClass('hide')
            $('#div_bothRFQ').removeClass('hide')
            $('#div_RFX').addClass('hide')
        }
        else if (bidtype == "RFI") {
            $('#div_eRFQ').addClass('hide')
            $('#div_RFQ').addClass('hide')
            $('#div_bothRFQ').addClass('hide')
            $('#div_RFX').removeClass('hide')
        }
        else {
            $('#div_eRFQ').addClass('hide')
            $('#div_RFQ').removeClass('hide')
            $('#div_bothRFQ').removeClass('hide')
            $('#div_RFX').addClass('hide')
        }
        setTimeout(function () {
             if (bidtype == "eRFQ") {
                fetchReguestforQuotationDetailseRFQ();
             }
            else if (bidtype == "RFI") {
                fetchRFIDetails();
             }
            else {
                fetchReguestforQuotationDetails();
            }
            //    window.location = linkurl;
        }, 600);
    }
    else if (bidtype == 'PO') {
        window.location = linkurl;
    }
    else {
        EventType = 'Auction';
        sessionStorage.setItem('BidID', Bidid)
        sessionStorage.setItem('RFQID', '0')
        $('#div_euctions').removeClass('hide')
        $('#div_bothRFQ').addClass('hide')
        setTimeout(function () {
            fetchBidHeaderDetails();
            //    window.location = linkurl;
        }, 600);
    }
    
    
    
    jQuery.unblockUI();
}
function fetchRFIDetails() {
    var attachment = ''//, _selectedCat = new Array(), _txtCategories = [];
    jQuery.ajax({
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "RFIMaster/fetchRFIPendingDetails/?UserID=" + encodeURIComponent(sessionStorage.getItem('UserID')) + "&RFIID=" + sessionStorage.getItem('CurrentRFIID') + "&AuthenticationToken=" + sessionStorage.getItem('AuthenticationToken'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "GET",
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (BidData) {

            attachment = BidData[0].RFIMaster[0].RFIAttachment.replace(/\s/g, "%20")
            //alert(JSON.stringify(BidData))
            jQuery('#RFISubject').val(BidData[0].RFIMaster[0].RFISubject)
            jQuery('#RFIDeadline').val(BidData[0].RFIMaster[0].RFIDeadline)
            jQuery('#RFIDescription').val(BidData[0].RFIMaster[0].RFIDescription)

            //alert(JSON.stringify(BidData))

            //jQuery('#txtattachdescription').val(BidData[0].RFIMaster[0].RFIAttachmentDescription)
            //jQuery('#attach-file').attr('href', "PortalDocs/RFI/" + sessionStorage.getItem("CurrentRFIID") + "/" + attachment).html(BidData[0].RFIMaster[0].RFIAttachment)

        },
        error: function (xhr, status, error) {
            var err = eval("(" + xhr.responseText + ")");
            jQuery("#error").text(err.Message);
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            jQuery.unblockUI();
        }
    });

}

function fetchReguestforQuotationDetails() {
    //alert(sessionStorage.getItem("APIPath") + "RequestForQuotation/fetchReguestforQuotationDetails/?UserID=" + encodeURIComponent(sessionStorage.getItem('VendorId')) + "&RFQID=" + sessionStorage.getItem('hddnRFQRFIID'))
    var attachment = '';
    var termattach = '';
    jQuery.ajax({
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "RequestForQuotation/fetchRFQDetails/?VendorID=" + encodeURIComponent(sessionStorage.getItem('VendorId')) + "&RFQID=" + sessionStorage.getItem('hddnRFQRFIID'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "GET",
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (RFQData) {

            if (RFQData.length > 0) {
                attachment = RFQData[0].RFQAttachment.replace(/\s/g, "%20")
                termattach = RFQData[0].RFQTermandCondition.replace(/\s/g, "%20")
            } else {
                attachment = attachment;
                termattach = termattach;
            }
            sessionStorage.setItem('CurrentrfiID', RFQData[0].RFQId)
            jQuery('#bid_EventID').html("Event ID : " + RFQData[0].RFQId);
            jQuery('#RFQSubject').html(RFQData[0].RFQSubject)

            sessionStorage.setItem('hdnFromUserId', RFQData[0].RFQConfiguredBy)
            $('#Currency').html(RFQData[0].CurrencyNm)
            jQuery('#RFQDescription').html(RFQData[0].RFQDescription)
            jQuery('#RFQDeadline').html(RFQData[0].RFQDeadline)
            jQuery('#ConversionRate').html(RFQData[0].RFQConversionRate)
            //$('#TermCondition').attr('href', 'PortalDocs/RFQ/' + sessionStorage.getItem('hddnRFQID') + '/' + termattach + '').html(RFQData[0].RFQTermandCondition)
            //$('#Attachment').attr('href', 'PortalDocs/RFQ/' + sessionStorage.getItem('hddnRFQID') + '/' + attachment + '').html(RFQData[0].RFQAttachment)



        },
        error: function (xhr, status, error) {
            var err = eval("(" + xhr.responseText + ")");
            jQuery("#error").text(err.Message);
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            jQuery.unblockUI();
        }
    });

}
function fetchReguestforQuotationDetailseRFQ() {
    // jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    var attachment = '';
    var termattach = '';

    jQuery.ajax({
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "eRequestForQuotation/eRFQDetails/?RFQID=" + sessionStorage.getItem('hddnRFQRFIID') + "&CustomerID=" + sessionStorage.getItem('CustomerID') + "&UserID=" + encodeURIComponent(sessionStorage.getItem('UserID')),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "GET",
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (RFQData) {

            sessionStorage.setItem('hddnRFQRFIID', RFQData[0].General[0].RFQId)
            jQuery('#RFQSubject').text(RFQData[0].General[0].RFQSubject)
            //$('#Currency').text(RFQData[0].General[0].RFQCurrencyId)
            $('#Currency').html(RFQData[0].General[0].CurrencyNm)
            jQuery('#RFQDescription').text(RFQData[0].General[0].RFQDescription)
            // jQuery('#txtrfqDuration').val(RFQData[0].General[0].RFQDeadline)
           // jQuery('#txtConversionRate').val(RFQData[0].General[0].RFQConversionRate);
           // jQuery('#txtRFQReference').val(RFQData[0].General[0].RFQReference)
            jQuery('#rfqstartdate').text(RFQData[0].General[0].RFQStartDate)
            jQuery('#rfqenddate').text(RFQData[0].General[0].RFQEndDate)
           // $("#cancelBidBtn").show();
           
        },
        error: function (xhr, status, error) {
            var err = eval("(" + xhr.responseText + ")");
            jQuery("#error").text(err.Message);
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            jQuery.unblockUI();
        }
    });
    jQuery.unblockUI();
}
function acceptBidTermsAuction() {
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    var vendorID = 0;
   // if (sessionStorage.getItem('ContactEmailID') == 'null' || sessionStorage.getItem('ContactEmailID') == '') {
    vendorID = sessionStorage.getItem('VendorId');
    //}
    //else {
    //    vendorID = sessionStorage.getItem('BidUserID');
    //}

    var acceptTerms = {
        "BidID": sessionStorage.getItem('BidID'),
        "VendorID": vendorID
    };
   // alert(JSON.stringify(acceptTerms))
    jQuery.ajax({
        url: sessionStorage.getItem("APIPath") + "BidTermsConditions/AcceptBidTerms/",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "POST",
        data: JSON.stringify(acceptTerms),
        contentType: "application/json; charset=utf-8",
        success: function (data, status, jqXHR) {

            if (data[0].IsSuccess == 'Y') {
                window.location = data[0].URL
            }
        },
        
        error: function (xhr, status, error) {
            var err = eval("(" + xhr.responseText + ")");
            jQuery("#error").text(err.Message);
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            jQuery.unblockUI();
        }
    });
}
function acceptBidTermsRFIRFQ() {
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    var vendorID = 0;
    //if (sessionStorage.getItem('ContactEmailID') == 'null' || sessionStorage.getItem('ContactEmailID') == '') {
    vendorID = sessionStorage.getItem('VendorId');
    //}
    //else {

    //    vendorID = sessionStorage.getItem('VendorId');
    //}

    var acceptTerms = {
        "RFQRFIID": _Bidtype+'-'+sessionStorage.getItem('hddnRFQRFIID'),
        "VID": vendorID
    };
    // alert(JSON.stringify(acceptTerms))
    jQuery.ajax({
        url: sessionStorage.getItem("APIPath") + "BidTermsConditions/AcceptBidTermsRFIRFQ/",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "POST",
        data: JSON.stringify(acceptTerms),
        contentType: "application/json; charset=utf-8",
        success: function (data, status, jqXHR) {

            if (data[0].IsSuccess == 'Y') {
                window.location = data[0].URL
            }
        },
        error: function (xhr, status, error) {
            var err = eval("(" + xhr.responseText + ")");
            jQuery("#error").text(err.Message);
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            jQuery.unblockUI();
        }
    });
}
function eRFQAcceptBidTerms() {
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    var vendorID = 0;
   
    vendorID = sessionStorage.getItem('VendorId');
    
    var acceptTerms = {
        "RFQID":  sessionStorage.getItem('hddnRFQRFIID'),
        "VID": vendorID
    };
    // alert(JSON.stringify(acceptTerms))
    jQuery.ajax({
        url: sessionStorage.getItem("APIPath") + "eRequestForQuotation/eRFQAcceptBidTerms/",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "POST",
        data: JSON.stringify(acceptTerms),
        contentType: "application/json; charset=utf-8",
        success: function (data, status, jqXHR) {

            if (data[0].IsSuccess == 'Y') {
                window.location = data[0].URL
            }
        },
        error: function (xhr, status, error) {
            var err = eval("(" + xhr.responseText + ")");
            jQuery("#error").text(err.Message);
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            jQuery.unblockUI();
        }
    });
}
function fetchBidDataDashboard(requesttype) {
   
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
   
   //alert(sessionStorage.getItem("APIPath") + "VendorDasboard/VendorfetchDashboardBidDetails/?VendorID=" + encodeURIComponent(sessionStorage.getItem('UserID')) + "&RequestType=" + requesttype + "&CustomerID=" + $('#ULCustomers').val())
    jQuery.ajax({
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "VendorDashboard/VendorfetchDashboardBidDetails/?VendorID=" + encodeURIComponent(sessionStorage.getItem('VendorId')) + "&RequestType=" + requesttype + "&CustomerID=" + $('#ULCustomers').val(),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "GET",
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (BidData) {
            $('#totalrecord').text('');
            jQuery("#UlPendingActivity").empty();
            jQuery("#div_portlet").removeClass();
            if (BidData.length > 0) {
                $('#totalrecord').text('(' + BidData.length + ')')
                if (requesttype == 'OpenBids') {
                    for (var i = 0; i < BidData.length; i++) {

                        str = "<li><a href='javascript:;' onclick=fnOpenLink(\'" + BidData[i].LinkURL + "'\,\'" + BidData[i].BidID + "'\,\'" + BidData[i].isTermsConditionsAccepted + "'\,\'" + BidData[i].BidTypeID + "'\)>";

                        str += "<div class='col1'><div class='cont'>";
                        str += "<div class='cont-col1'><div class='label label-sm label-success'><i id=iconbidd" + i + "></i></div></div>";
                        str += "<div class='cont-col2'><div class='desc'>" + BidData[i].ActivityDescription + "&nbsp;&nbsp;";
                        if (BidData[i].isTermsConditionsAccepted != "Y") {
                            
                            str += "<span class='label label-sm label-info'>" + BidData[i].BidTypeName + "</span>&nbsp;&nbsp;<span class='badge badge-danger'> new </span>";
                        }
                        else {
                           str += "<span class='label label-sm label-info'>" + BidData[i].BidTypeName + "</span>";
                        }
                        
                        str += "</div></div></div></div>";

                        str += "<div class='col2' style='width: 110px !important; margin-left:-110px !important;'>";
                        str += "<div class='date'><span class='label label-sm label-warning'>" + BidData[i].BidStatus + "</span></div></div>";
                        str += "</a></li>";
                        jQuery('#UlPendingActivity').append(str);

                        if (BidData[i].BidTypeName == 'VQ') {
                            jQuery('#iconbidd' + i).addClass('fa fa-question-circle');
                        } else if (BidData[i].BidTypeName == 'RFI') {
                            jQuery('#iconbidd' + i).addClass('fa fa-envelope-o');
                        } else if (BidData[i].BidTypeName == 'RFQ') {
                            $('#iconbidd' + i).addClass('icon-envelope');
                        } else if (BidData[i].BidTypeName == 'Forward Auction') {

                            $('#iconbidd' + i).addClass('fa fa-forward');
                        }
                        else if (BidData[i].BidTypeName == 'Reverse Auction') {

                            $('#iconbidd' + i).addClass('fa fa-gavel');
                        }
                        else if (BidData[i].BidTypeName == 'eRFQ') {
                            $('#iconbidd' + i).addClass('fa fa-envelope-o');
                        }
                        else if (BidData[i].BidTypeName == 'PO') {
                            $('#iconbidd' + i).addClass('fa fa-file');
                        }
                    }

                }
                else if (requesttype == 'CloseBids') {
                    for (var i = 0; i < BidData.length; i++) {

                        str = "<li><a href=" + BidData[i].LinkURL + ">";
                        str += "<div class='col1'><div class='cont'>";
                        str += "<div class='cont-col1'><div class='label label-sm label-success'><i id=iconbidd" + i + "></i></div></div>";
                        str += "<div class='cont-col2'><div class='desc'>" + BidData[i].ActivityDescription + "&nbsp;&nbsp;";
                        str += "<span class='label label-sm label-info'>" + BidData[i].BidTypeName + "</span>";
                        str += "</div></div></div></div>";
                        str += "<div class='col2' style='width: 110px !important; margin-left:-110px !important;'>";

                        str += "<div class='date'><span class='label label-sm label-warning'>" + BidData[i].BidStatus + "</span></div></div>";
                        str += "</a></li>";
                        jQuery('#UlPendingActivity').append(str);

                        if (BidData[i].BidTypeName == 'VQ') {
                            jQuery('#iconbidd' + i).addClass('fa fa-question-circle');
                        } else if (BidData[i].BidTypeName == 'RFI') {
                            jQuery('#iconbidd' + i).addClass('fa fa-envelope-o');
                        } else if (BidData[i].BidTypeName == 'RFQ') {
                            $('#iconbidd' + i).addClass('icon-envelope');
                        }
                        else if (BidData[i].BidTypeName == 'Forward Auction') {
                            $('#iconbidd' + i).addClass('fa fa-forward');
                        }
                        else if (BidData[i].BidTypeName == 'Reverse Auction') {

                            $('#iconbidd' + i).addClass('fa fa-gavel');
                        }
                        else if (BidData[i].BidTypeName == 'PO') {
                            $('#iconbidd' + i).addClass('fa fa-file');
                        }

                    }
                }
                else if (requesttype == 'PendingPO' || requesttype == 'AcceptedPO') {
                    for (var i = 0; i < BidData.length; i++) {

                        str = "<li><a href=" + BidData[i].LinkURL + ">";
                        str += "<div class='col1'><div class='cont'>";
                        str += "<div class='cont-col1'><div class='label label-sm label-success'><i id=iconbidd" + i + "></i></div></div>";
                        str += "<div class='cont-col2'><div class='desc'>" + BidData[i].ActivityDescription + "&nbsp;&nbsp;";
                        if (requesttype == 'PendingPO') {
                            str += "<span class='label label-sm label-info'>" + BidData[i].BidTypeName + "</span>&nbsp;&nbsp;<span class='badge badge-danger'> new </span>";
                        } else {
                            str += "<span class='label label-sm label-info'>" + BidData[i].BidTypeName + "</span>";
                        }
                        str += "</div></div></div></div>";
                        str += "<div class='col2' style='width: 110px !important; margin-left:-110px !important;'>";

                        str += "<div class='date'><span class='label label-sm label-warning'>" + BidData[i].BidStatus + "</span></div></div>";
                       
                        str += "</a></li>";
                        jQuery('#UlPendingActivity').append(str);

                        if (BidData[i].BidTypeName == 'VQ') {
                            jQuery('#iconbidd' + i).addClass('fa fa-question-circle');
                        } else if (BidData[i].BidTypeName == 'RFI') {
                            jQuery('#iconbidd' + i).addClass('fa fa-envelope-o');
                        } else if (BidData[i].BidTypeName == 'RFQ') {
                            $('#iconbidd' + i).addClass('icon-envelope');
                        }
                        else if (BidData[i].BidTypeName == 'Forward Auction') {
                            $('#iconbidd' + i).addClass('fa fa-forward');
                        }
                        else if (BidData[i].BidTypeName == 'Reverse Auction') {

                            $('#iconbidd' + i).addClass('fa fa-gavel');
                        }
                        else if (BidData[i].BidTypeName == 'PO') {
                            $('#iconbidd' + i).addClass('fa fa-file');
                        }

                    }
                }
                else if (requesttype == 'CloseRFX') {
                    for (var i = 0; i < BidData.length; i++) {

                        str = "<li><a  href=" + BidData[i].LinkURL + ">";
                        str += "<div class='col1'><div class='cont'>";
                        str += "<div class='cont-col1'><div class='label label-sm label-success'><i id=iconbidd" + i + "></i></div></div>";
                        str += "<div class='cont-col2'><div class='desc'>" + BidData[i].ActivityDescription + "&nbsp;&nbsp;";
                        str += "<span class='label label-sm label-info'>" + BidData[i].BidTypeName + "</span>";
                        str += "</div></div></div></div>";
                        str += "<div class='col2' style='width: 110px !important; margin-left:-110px !important;'>";

                        str += "<div class='date'><span class='label label-sm label-warning'>" + BidData[i].BidStatus + "</span></div></div>";
                        str += "</a></li>";
                        jQuery('#UlPendingActivity').append(str);

                        if (BidData[i].BidTypeName == 'VQ') {
                            jQuery('#iconbidd' + i).addClass('fa fa-question-circle');
                        } else if (BidData[i].BidTypeName == 'RFI') {
                            jQuery('#iconbidd' + i).addClass('fa fa-envelope-o');
                        } else if (BidData[i].BidTypeName == 'RFQ') {
                            $('#iconbidd' + i).addClass('icon-envelope');
                        }
                        else if (BidData[i].BidTypeName == 'eRFQ') {
                            $('#iconbidd' + i).addClass('icon-envelope');
                        }
                        else if (BidData[i].BidTypeName == 'Forward Auction') {
                            $('#iconbidd' + i).addClass('fa fa-forward');
                        }
                        else if (BidData[i].BidTypeName == 'Reverse Auction') {

                            $('#iconbidd' + i).addClass('fa fa-gavel');
                        }
                        else if (BidData[i].BidTypeName == 'PO') {
                            $('#iconbidd' + i).addClass('fa fa-file');
                        }
                        //jQuery("#iconclass").addClass('fa fa-unlink');
                        //jQuery("#spanPanelCaption").text('Open RFx');
                        //jQuery("#div_portlet").addClass('portlet box green');
                    }
                }
                else {
                for (var i = 0; i < BidData.length; i++) {
                   
                    str = "<li><a href='javascript:;' onclick=fnOpenLink(\'" + BidData[i].LinkURL + "'\,\'" + BidData[i].BidID + "'\,\'" + BidData[i].isTermsConditionsAccepted + "'\,\'" + BidData[i].BidTypeID + "'\,\'" + BidData[i].Version + "'\)>";
                    str += "<div class='col1'><div class='cont'>";
                    str += "<div class='cont-col1'><div class='label label-sm label-success'><i id=iconbidd" + i + "></i></div></div>";
                    str += "<div class='cont-col2'><div class='desc'>" + BidData[i].ActivityDescription + "&nbsp;&nbsp;";
                    if (BidData[i].isTermsConditionsAccepted != "Y") {
                        str += "<span class='label label-sm label-info'>" + BidData[i].BidTypeName + "</span>&nbsp;&nbsp;<span class='badge badge-danger'> new </span>";
                    }
                    else {
                        str += "<span class='label label-sm label-info'>" + BidData[i].BidTypeName + "</span>";
                    }
                    str += "</div></div></div></div>";
                    str += "<div class='col2' style='width: 110px !important; margin-left:-110px !important;'>";

                    str += "<div class='date'><span class='label label-sm label-warning'>" + BidData[i].BidStatus + "</span></div></div>";
                    str += "</a></li>";
                    jQuery('#UlPendingActivity').append(str);

                    if (BidData[i].BidTypeName == 'VQ') {
                        jQuery('#iconbidd' + i).addClass('fa fa-question-circle');
                    } else if (BidData[i].BidTypeName == 'RFI') {
                        jQuery('#iconbidd' + i).addClass('fa fa-envelope-o');
                    } else if (BidData[i].BidTypeName == 'RFQ') {
                        $('#iconbidd' + i).addClass('icon-envelope');
                    }
                    else if (BidData[i].BidTypeName == 'Forward Auction') {
                        $('#iconbidd' + i).addClass('fa fa-forward');
                    }
                    else if (BidData[i].BidTypeName == 'Reverse Auction') {

                        $('#iconbidd' + i).addClass('fa fa-gavel');
                    }
                    else if (BidData[i].BidTypeName == 'eRFQ') {
                        $('#iconbidd' + i).addClass('icon-envelope');
                    }
                    else if (BidData[i].BidTypeName == 'PO') {
                        $('#iconbidd' + i).addClass('fa fa-file');
                    }
                    //jQuery("#iconclass").addClass('fa fa-unlink');
                    //jQuery("#spanPanelCaption").text('Open RFx');
                    //jQuery("#div_portlet").addClass('portlet box green');
                }
            }
        
     }
            else {
                jQuery('#UlPendingActivity').append("<tr><td colspan='8' style='text-align: center; color:red;'>No record found</td></tr>");
            }
            if (requesttype == 'OpenBids') {
                jQuery("#iconclass").addClass('fa fa-paperclip');
                jQuery("#spanPanelCaption").text('Open eAuctions');
                jQuery("#div_portlet").addClass('portlet box purple-soft');
            }
            else if (requesttype == 'OpenRFX') {
                jQuery("#iconclass").addClass('fa fa-unlink');
                jQuery("#spanPanelCaption").text('Open RFx');
                jQuery("#div_portlet").addClass('portlet box green');

            } else if (requesttype == 'CloseBids') {
                //jQuery("#iconclass").addClass('fa fa-check-square-o');
                //jQuery("#spanPanelCaption").text('Closed eAuctions');
                //jQuery("#div_portlet").addClass('portlet box yellow-casablanca');
                jQuery("#iconclass").addClass('fa fa-paperclip');
                jQuery("#spanPanelCaption").text('Closed eAuctions');
                jQuery("#div_portlet").addClass('portlet box purple-soft');

            } else if (requesttype == 'CloseRFX') {
                //jQuery("#iconclass").addClass('fa fa-trophy');
                //jQuery("#spanPanelCaption").text('Submitted RFx');
                //jQuery("#div_portlet").addClass('portlet box red-pink');
                jQuery("#iconclass").addClass('fa fa-unlink');
                jQuery("#spanPanelCaption").text('Submitted RFx');
                jQuery("#div_portlet").addClass('portlet box green');
            }
            else if (requesttype == 'PendingPO') {
                jQuery("#iconclass").addClass('fa fa-check-square-o');
                jQuery("#spanPanelCaption").text("Pending PO's");
                jQuery("#div_portlet").addClass('portlet box yellow-casablanca');
            }
            else {
                jQuery("#iconclass").addClass('fa fa-check-square-o');
                jQuery("#spanPanelCaption").text("Accepted/Reverted PO's");
                jQuery("#div_portlet").addClass('portlet box yellow-casablanca');
            }

        },
        error: function (xhr, status, error) {
            var err = eval("(" + xhr.responseText + ")");
            jQuery("#error").text(err.Message);
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            jQuery.unblockUI();
        }
    });
    jQuery.unblockUI();
}

function fetchBidHeaderDetails() {
    var tncAttachment = '';
    var anyotherAttachment = '';
    var url = '';
    //if (sessionStorage.getItem("ContactEmailID") == 'null' || sessionStorage.getItem("ContactEmailID") == '') {
    url = sessionStorage.getItem("APIPath") + "BidVendorSummary/FetchBidDetails_Vendor/?BidID=" + sessionStorage.getItem('BidID') + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("VendorId"))
    // } else {
    //  url = sessionStorage.getItem("APIPath") + "BidVendorSummary/FetchBidDetails/?BidID=" + bidId + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("BidUserID"))
    // }
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: url,
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
            console.log("dataa > ", data)
            if (data.length == 1) {
                jQuery('#bid_EventID').html("Event ID : " + sessionStorage.getItem("BidID"));
                //tncAttachment = data[0].TermsConditions.replace(/\s/g, "%20");
               // anyotherAttachment = data[0].Attachment.replace(/\s/g, "%20");
               // $("#hdnAdvFactor").val(data[0].AdvFactor);
                jQuery("label#lblitem1").text(data[0].BidFor);
                jQuery("#lblbidsubject").text(data[0].BidSubject);
                jQuery("#lblbidDetails").text(data[0].BidDetails);
                jQuery("#lblbiddate").text(data[0].BidDate);
                jQuery("#lblbidtime").text(data[0].BidTime);
                jQuery("#lblbidtype").text(data[0].BidTypeName);
                jQuery("#lblbidfor").text(data[0].BidFor);

                jQuery("a#lnkTermsAttachment").text(data[0].TermsConditions);
                jQuery("a#lnkTermsAttachment").attr("href", "PortalDocs/Bid/" + sessionStorage.getItem("BidID") + "/" + tncAttachment)

                jQuery("a#lnkAnyOtherAttachment").text(data[0].Attachment);
                jQuery("a#lnkAnyOtherAttachment").attr("href", "PortalDocs/Bid/" + sessionStorage.getItem("BidID") + "/" + anyotherAttachment)

                jQuery("#lblwarehousearea").text(data[0].WareHouseArea);

                jQuery("#lblbidduration").text(data[0].BidDuration);
                jQuery("#lblcurrency").text(data[0].CurrencyName);
                jQuery("#lblConvRate").text(data[0].ConversionRate);
                jQuery("#lblstatus").text(data[0].ConversionRate);
                jQuery("#lblConvRate").text(data[0].ConversionRate);
                
               
                
            }
        },
        error: function (xhr, status, error) {
            var err = eval("(" + xhr.responseText + ")");
            jQuery("#error").text(err.Message);
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            jQuery.unblockUI();
        }
    });

}
jQuery('#chkIsAccepted').click(function () {
    if (jQuery('#chkIsAccepted').is(':checked') == true) {
        $('#btnContinue').attr("disabled", false);
    }
    else {
        $('#btnContinue').attr("disabled", true);
    }
});

jQuery("#searchPendingActivities").keyup(function () {

    //jQuery('#searchhostelbtn').live('click', function (e) {
    jQuery("#UlPendingActivity li:has(div)").hide(); // Hide all the rows.

    var iCounter = 0;
    var sSearchTerm = jQuery('#searchPendingActivities').val(); //Get the search box value

    if (sSearchTerm.length == 0) //if nothing is entered then show all the rows.
    {
        jQuery("#UlPendingActivity li:has(div)").show();
        return false;
    }

    //Iterate through all the td.
    jQuery("#UlPendingActivity li:has(div)").children().each(function () {

        var cellText = jQuery(this).text().toLowerCase();
        if (cellText.indexOf(sSearchTerm.toLowerCase()) >= 0) //Check if data matches
        {

            jQuery(this).parent().show();
            iCounter++;

            return true;
        }

    });
});
function formvalidate() {
    $('#AccprtGNc').validate({
        errorElement: 'span', //default input error message container
        errorClass: 'help-block', // default input error message class
        focusInvalid: false, // do not focus the last invalid input
        rules: {
         },

        messages: {
           
        },

        invalidHandler: function (event, validator) { //display error alert on form submit   
            //$('.alert-danger', $('.login-form')).show();
            //$('#alertmessage').html('User name/ Password cannot be blank.')
        },

        highlight: function (element) { // hightlight error inputs
            $(element)
                    .closest('.form-group').addClass('has-error'); // set error class to the control group
        },

        success: function (label) {
            label.closest('.form-group').removeClass('has-error');
            label.remove();
        },

        errorPlacement: function (error, element) {
            error.insertAfter(element.closest('.input-icon'));
        },

        submitHandler: function (form) {
           
            //form.submit(); // form validation success, call ajax form submit
            //  acceptterms();
            if (EventType == 'RFX') {
                if (_Bidtype == "eRFQ") {
                    eRFQAcceptBidTerms();

                } else {
                    acceptBidTermsRFIRFQ();
                }
               
            }
            else {
                acceptBidTermsAuction()

            }
        }
    });

    

}
function validateBid(bidid) {
   
    $('#validatebidmodal').modal('show')
}
function getvalidateBidvendor() {
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "User/validateUser/?LoginID=" + sessionStorage.getItem('ContactEmailID') + "&Password=" + $('#bidpassword').val(),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data) {
            sessionStorage.setItem('BidID', data[0].BidID)
            sessionStorage.setItem('BidTypeID', data[0].BidTypeID)
            sessionStorage.setItem('BidUserID', data[0].UserID)
            jQuery.each(data, function (key, value) {
                if (value.isValidUser == 'Y') {
                   
                    IsAcceptedBidTerms(value.UserID);
                }
                else {
                    jQuery.unblockUI();
                    $('#bidpassword').val('')
                    $('.alert-danger').show();
                    $('#alertmessage').html('Enter a valid password for this Bid.')
                    
                    return
                }
            });
        },
        error: function (xhr, status, error) {
            var err = eval("(" + xhr.responseText + ")");
            jQuery("#error").text(err.Message);
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            jQuery.unblockUI();
        }
    });
}
function IsAcceptedBidTerms(vendorid) {
    
    jQuery.ajax({
        url: sessionStorage.getItem("APIPath") + "BidTermsConditions/IsAcceptedBidTerms/?bidid=" + sessionStorage.getItem('BidID') + "&Userid=" + encodeURIComponent(vendorid),
        type: "GET",
        async: false,
        contentType: "application/json; charset=utf-8",
        success: function (data, status, jqXHR) {
           
           
            window.location = data[0].URL;
            sessionStorage.setItem("HomePage", data[0].HomePage);
        },
        
        error: function (xhr, status, error) {
            $('.page-container').show();
        var err = eval("(" + xhr.responseText + ")");
        jQuery("#error").text(err.Message);
        if (xhr.status === 401) {
            error401Messagebox(err.Message);
        }

        jQuery.unblockUI();
    }
    });
}



function fetchPendingRFQ() {
    var str = '';
    
    jQuery.ajax({
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "Activities/fetchPendingRFIRFQForvendor/?UserID=" + encodeURIComponent(sessionStorage.getItem('UserID')),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "GET",
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data) {
            $('#totalrecord').text('');
            jQuery("#ulPendingRFIRFQ").empty();
            //alert(JSON.stringify(data))
            if (data.length > 0) {
                $('#totalrecord').text('(' + data.length + ')')
				//sessionStorage.setItem('hdnFromUserId', data[0].FromUserId)
                sessionStorage.setItem('VendorId', data[0].VendorId)
                for (var i = 0; i < data.length; i++) {
                    if (data[0].RFQId != 0) {
                        str = "<li><a href=" + data[i].LinkURL + ">";
                        str += "<div class='col1'><div class='cont'>";
                        str += "<div class='cont-col1'><div class='label label-sm label-success'>RFQ</div></div>";
                        str += "<div class='cont-col2'><div class='desc'>" + data[i].ActivityDescription;
                        str += "</div></div></div></div>";
                        str += "<div class='col2'>";
                        str += "<div class='date'><span class='label label-sm label-danger'>" + data[i].RFQClosureDate + "</span></div></div>";
                        str += "</a></li>";
                        jQuery('#ulPendingRFIRFQ').append(str);
                    } else {
                        str = "<li><a href=" + data[i].LinkURL + ">";
                        str += "<div class='col1'><div class='cont'>";
                        str += "<div class='cont-col1'><div class='label label-sm label-success'>RFI</i></div></div>";
                        str += "<div class='cont-col2'><div class='desc'>" + data[i].ActivityDescription;
                        str += "</div></div></div></div>";
                        str += "<div class='col2'>";
                        str += "<div class='date'><span class='label label-sm label-danger'>" + data[i].RFIClosureDate + "</span></div></div>";
                        str += "</a></li>";
                        jQuery('#ulPendingRFIRFQ').append(str);
                    }
                    
                }
            }
            else {
                jQuery('#ulPendingRFIRFQ').append("<tr><td colspan='8' style='text-align: center; color:red;'>You have no pending activity.</td></tr>");
            }


        },
        error: function (xhr, status, error) {
            $('.page-container').show();
            var err = eval("(" + xhr.responseText + ")");
            jQuery("#error").text(err.Message);
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            jQuery.unblockUI();
        }
    });
}

function fetchMappedCustomers() {
   
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    //alert(sessionStorage.getItem("APIPath") + "CustomerRegistration/FetchCustomersForUser/?UserID=" + encodeURIComponent(sessionStorage.getItem("UserID")))
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "CustomerRegistration/FetchCustomersForUser/?UserID=" + encodeURIComponent(sessionStorage.getItem("UserID")),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        dataType: "json",
        success: function (data) {
            jQuery("#ULCustomers").empty();
          
            if (data.length > 0) {
                jQuery("#ULCustomers").append(jQuery("<option></option>").val("0").html("ALL"));
                for (var i = 0; i < data.length; i++) {
                    jQuery("#ULCustomers").append(jQuery("<option></option>").val(data[i].CustomerID).html(data[i].CustomerName));
                    
                 }
            }
            else {
                
            }
        },
        error: function (xhr, status, error) {
            $('.page-container').show();
            var err = eval("(" + xhr.responseText + ")");
            jQuery("#error").text(err.Message);
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            jQuery.unblockUI();
        }

    });
    jQuery.unblockUI();
}