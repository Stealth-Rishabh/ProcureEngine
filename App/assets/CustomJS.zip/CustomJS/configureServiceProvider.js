﻿var serviceproviderForm = $('.form-horizontal');
var serviceproviderError = $('.alert-danger', serviceproviderForm);
var serviceproviderSucccess = $('.alert-success', serviceproviderForm);

var ServiceProvider = function () {
    var handleServiceProvider = function () {
        serviceproviderForm.validate({
            errorElement: 'span', //default input error message container
            errorClass: 'help-block', // default input error message class
            focusInvalid: false, // do not focus the last invalid input
            rules: {
                txtServiceProviderName: {
                    required: true
                },
                txtMobileNo: {
                    required: true
                },
                txtEmailID: {
                    required: true,
                    txtLoginID: true
                }
            },

            invalidHandler: function (event, validator) { //display error alert on form submit   
                serviceproviderSucccess.hide();
                jQuery("#error").text("You have some form errors. Please check below.");
                serviceproviderError.show();
                App.scrollTo(serviceproviderError, -200);
                serviceproviderError.fadeOut(5000);
            },

            highlight: function (element) { // hightlight error inputs
                $(element)
                    .closest('.form-group').addClass('has-error'); // set error class to the control group
            },

            success: function (label) {
                label.closest('.form-group').removeClass('has-error');
                label.remove();
            },

            errorPlacement: function (error, element) {
                error.insertAfter(element.closest('.input-icon'));
            },

            submitHandler: function (form) {
                //form.submit(); // form validation success, call ajax form submit
                //saveServiceProvider();
                saveData();
            }
        });

    }


    return {
        //main function to initiate the module
        init: function () {

            handleServiceProvider();
            fetchServiceProvidertoTable('0', 'T');
        }

    };

}();

function saveData() {

    //alert("Save button clicked")
}

function saveServiceProvider() {
    var ActiveStatus;
    if (jQuery("#chkIsActive").is(':checked')) {
        ActiveStatus = "Y";
    }
    else {
        ActiveStatus = "N";

    }
    var insUpdServiceProvider = "{'SocietyID':'" + sessionStorage.getItem("SocietyID") + "','ServiceProviderID':'" + jQuery('#hdnServiceProviderID').val() + "','ServiceProviderName':'" + jQuery('#txtServiceProviderName').val() + "','MobileNo':'" + jQuery('#txtMobileNo').val() + "','LandLineNo':'" + jQuery('#txtLandLineNo').val() + "','EmailID':'" + jQuery('#txtEmailID').val() + "','LoginID':'" + jQuery('#txtLoginID').val() + "','isActive':'" + ActiveStatus + "','MemberID':'" + sessionStorage.getItem("MemberID") + "'}";

    jQuery.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ServiceProvider/configureServiceProvider/",
        data: insUpdServiceProvider,
        cache: false,
        dataType: "json",
        success: function (data) {
            //clearfieldsBlock();
            //fetchBlocktoTable('0', 'T');
            showTablePanel();
            serviceproviderError.hide();
            jQuery("#success").text("Transaction Successfull.");
            serviceproviderSucccess.show();
            App.scrollTo(serviceproviderSucccess, -200);
            serviceproviderSucccess.fadeOut(5000);
        },
        error: function (result) {
            jQuery("#error").text(result.d);
            serviceproviderError.show();
            serviceproviderError.fadeOut(5000);
        }
    });

}
function fetchServiceProvidertoTable(loginid, serviceproviderid, excludestatus) {
    
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "Resident/fetchServiceProviderDetails/?SocietyID=" + sessionStorage.getItem("SocietyID") + "&LoginID=" + loginid + "&ServiceProviderID=" + serviceproviderid + "&ExcludeStatus=" + excludestatus,
        cache: false,
        dataType: "json",
        success: function (data) {
            jQuery("#tblServiceProvider").empty();
            jQuery("#tblServiceProvider").append("<thead><tr style='font-weight:bold'><td>Service Provider Name</td><td>Block</td><td>Login ID</td><td>Mobile No.</td><td>Email ID</td><td>Land Line No.</td><td>is Active</td><td>Modify</td></tr><thead><tbody>");
            //jQuery.each(data, function (key, value) {
            //    jQuery("#tblServiceProvider").append('<tr><td>' + value.MemberName + '</td><td>' + value.BlockName + '</td><td>' + value.FlatTypeName + '</td><td>' + value.FloorName + '</td><td>' + value.FlatNo + '</td><td>' + value.EmailID + '</td><td>' + value.MobileNo + '</td><td>' + value.ResidentType + '</td><td>' + value.Residing + '</td><td>' + value.isActive + '</td><td> <a href="#" class="btn btn-xs red" onclick="modifyServiceProvider(\'' + value.MemberID + '\')">Modify <i class="fa fa-edit"></i></a></td></tr>');
            //});
            jQuery("#tblServiceProvider").append('</tbody>');
        },
        error: function ajaxError(response) {
            alert(response.status + ' ' + response.statusText);
        }

    });
}

function modifyServiceProvider(memberid) {
    showPanel();
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "Resident/fetchServiceProviderAllDetails/?SocietyID=" + sessionStorage.getItem("SocietyID") + "&MemberID=" + memberid + "&ExcludeStatus=T",
        cache: false,
        dataType: "json",
        success: function (data) {
            jQuery.each(data, function (key, value) {
                jQuery('#txtFIrstName').val(value.FirstName);
                jQuery('#txtMiddleName').val(value.MiddleName);
                jQuery('#txtLastName').val(value.LastName);
                jQuery('#dropGender').val(value.GenderID);
                jQuery('#txtMobileNo').val(value.MobileNo);
                jQuery('#txtEmailID').val(value.EmailID);
                jQuery('#txtBirthDate').val(value.BirthDate);
                jQuery('#dropMaritalStatus').val(value.MaritalStatusID);

                jQuery('#dropBlock').val(value.BlockID);
                jQuery('#dropFlatType').val(value.FlatTypeID);
                jQuery('#dropFloor').val(value.FloorID);
                populateFlatDropDown(value.BlockID, value.FlatTypeID, value.FloorID, value.FlatID, 'T')
                jQuery('#dropFlat').val(value.FlatID);
                jQuery('#dropResidentType').val(value.ResidentType);
                jQuery('#dropResiding').val(value.Residing);

            });
        },
        error: function ajaxError(response) {
            alert(response.status + ' ' + response.statusText);
        }

    });
}