﻿//$(document).ready(function () {
//    $("#add_new").click(function () {
//        var finyear = $('#ddlcompanyfinyear option:selected').text();
//        var Amount = $('#txtCompanyAmount').val();
//        var Currency = $('#ddlcurrency option:selected').text();
//        AddRegistervendor(finyear, Amount, Currency);
//    });
//    $("#btnaddvindata").click(function () {
//        var compfinyear = $('#ddlcompfinyear option:selected').text();
//        var salesamount = $('#txtsalesturnover').val();
//        var salescurrency = $('#ddlcompcurrency option:selected').text();

//        var networthamount = $('#txtnetWorthcredit').val();
//        var networthcurrency = $('#ddlnetworthcurrency option:selected').text();
//        AddtblCompanyCreditLimit(compfinyear, salesamount, salescurrency, networthamount, networthcurrency);
//    });
//});

//function AddRegistervendor(A, B, C) {
//    var str = "<tr><td>" + A + "</td><td>" + B + "</td><td>" + C + "</td></td></tr>";
//    jQuery('#tblRegisterVendor > tbody').append(str);
//    validateTabledata();
//}
//function AddtblCompanyCreditLimit(A, B, C, D, E) {
//    var str = "<tr><td>" + A + "</td><td>" + B + "</td><td>" + C + "</td><td>" + D + "</td><td>" + E + "</td></td></tr>";
//    jQuery('#tblcompanycreditlimit > tbody').append(str);
//    validateCompanylimit();
//}


//function validateTabledata() {
//    if ($('#tblRegisterVendor').find('tr').length > 1) {
//        $('#divtable').show();
//    }
//    else {
//        $('#divtable').hide();
//    }
//}
//function validateCompanylimit() {
//    if ($('#tblcompanycreditlimit').find('tr').length > 1) {
//        $('#divcompanycreditlimit').show();
//    }
//    else {
//        $('#divcompanycreditlimit').hide();
//    }
//}




////  validation parts ///////


var FormWizard = function () {
    return {
        init: function () {
            if (!jQuery().bootstrapWizard) {
                return;
            }
            function format(state) {
                if (!state.id) return state.text; // optgroup
                return "<img class='flag' src='assets/global/img/flags/" + state.id.toLowerCase() + ".png'/>&nbsp;&nbsp;" + state.text;
            }
            var form = $('#submit_form');
            var error = $('.alert-danger', form);
            var success = $('.alert-success', form);

            form.validate({
                doNotHideMessage: true, //this option enables to show the error/success messages on tab switch.
                errorElement: 'span', //default input error message container
                errorClass: 'help-block help-block-error', // default input error message class
                focusInvalid: false, // do not focus the last invalid input
                rules: {
                    txtname: {
                        required: true
                    }
                },
                messages: {
                    txtname: {
                        required: "field is required"
                    }
                },
                errorPlacement: function (error, element) {
                    if (element.attr("name") == "gender") {
                        error.insertAfter("#form_gender_error");
                    } else if (element.attr("name") == "payment[]") {
                        error.insertAfter("#form_payment_error");
                    } else {
                        error.insertAfter(element);
                    }

                    if ($("#txtbidDate").closest('.inputgroup').attr('class') == 'inputgroup has-error') {
                        $("#btncal").css("margin-top", "-22px");
                    }
                },
                invalidHandler: function (event, validator) {
                    success.hide();
                    error.show();
                    Metronic.scrollTo(error, -200);
                },
                highlight: function (element) {
                    $(element)
                        .closest('.inputgroup').removeClass('has-success').addClass('has-error');
                },
                unhighlight: function (element) {
                    $(element)
                        .closest('.inputgroup').removeClass('has-error');
                },
                success: function (label) {
                    if (label.attr("for") == "gender" || label.attr("for") == "payment[]") {
                        label
                            .closest('.inputgroup').removeClass('has-error').addClass('has-success');
                        label.remove();
                    } else {
                        label
                            .addClass('valid') // mark the current input as valid and display OK icon
                        .closest('.inputgroup').removeClass('has-error').addClass('has-success'); // set success class to the control group
                    }
                    if ($("#txtbidDate").closest('.inputgroup').attr('class') == 'inputgroup has-error') {
                        $("#btncal").css("margin-top", "-22px");
                    }
                    else {
                        $("#btncal").css("margin-top", "0px");
                    }
                },

                submitHandler: function (form) {
                    success.show();
                    error.hide();
                }

            });

            var displayConfirm = function () {
                $('#tab4 .form-control-static', form).each(function () {
                    var input = $('[name="' + $(this).attr("data-display") + '"]', form);
                    if (input.is(":radio")) {
                        input = $('[name="' + $(this).attr("data-display") + '"]:checked', form);
                    }
                    if (input.is(":text") || input.is("textarea")) {
                        $(this).html(input.val());
                    } else if (input.is("select")) {
                        $(this).html(input.find('option:selected').text());
                    } else if (input.is(":radio") && input.is(":checked")) {
                        $(this).html(input.attr("data-title"));
                    } else if ($(this).attr("data-display") == 'payment') {
                        var payment = [];
                        $('[name="payment[]"]:checked').each(function () {
                            payment.push($(this).attr('data-title'));
                        });
                        $(this).html(payment.join("<br>"));
                    }
                });
            }

            var handleTitle = function (tab, navigation, index) {
                var total = navigation.find('li').length;
                var current = index + 1;
                // set wizard title
                $('.step-title', $('#form_wizard_1')).text('Step ' + (index + 1) + ' of ' + total);
                // set done steps
                jQuery('li', $('#form_wizard_1')).removeClass("done");
                var li_list = navigation.find('li');
                for (var i = 0; i < index; i++) {
                    jQuery(li_list[i]).addClass("done");
                }

                if (current == 1) {
                    $('#form_wizard_1').find('.button-previous').hide();
                } else {
                    $('#form_wizard_1').find('.button-previous').show();
                }

                if (current >= total) {
                    $('#form_wizard_1').find('.button-next').hide();
                    $('#form_wizard_1').find('.button-submit').show();
                    displayConfirm();
                } else {
                    $('#form_wizard_1').find('.button-next').show();
                    $('#form_wizard_1').find('.button-submit').hide();
                }
                Metronic.scrollTo($('.page-title'));
            }

            // default form wizard
            $('#form_wizard_1').bootstrapWizard({
                'nextSelector': '.button-next',
                'previousSelector': '.button-previous',
                onTabClick: function (tab, navigation, index, clickedIndex) {
                    return false;
                },
                onNext: function (tab, navigation, index) {
                    success.hide();
                    error.hide();
                    if (form.valid() == false) {
                        return false;
                    }

                    handleTitle(tab, navigation, index);
                },
                onPrevious: function (tab, navigation, index) {
                    success.hide();
                    error.hide();
                    handleTitle(tab, navigation, index);
                },
                onTabShow: function (tab, navigation, index) {
                    var total = navigation.find('li').length;
                    var current = index + 1;
                    var $percent = (current / total) * 100;
                    $('#form_wizard_1').find('.progress-bar').css({
                        width: $percent + '%'
                    });
                }
            });
            $('#form_wizard_1').find('.button-previous').hide();
            $('#form_wizard_1 .button-submit').click(function () {
                //if (ValidateVendor() == 'false') {
                //    return false;
                //}
                //else {
                //    ConfigureBidForSea();
                //    return true;
                //}
            }).hide();
        }
    };
} ();

   