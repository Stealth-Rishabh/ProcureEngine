﻿var BidTypeID = 0;
var BidForID = 0;
var Duration = '0.00';
var _isBidStarted = true;


var error1 = $('.alert-danger');
var success1 = $('.alert-success');
var displayForS = "";

function fetchVendorDetails() {

    var url = '';
   
    url = sessionStorage.getItem("APIPath") + "VendorParticipation/FetchBidDetails/?BidID=" + sessionStorage.getItem("BidID") + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("VendorId"));
   
    var tncAttachment = '';
    var anyotherAttachment = '';

    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: url,
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {

            if (data.length == 1) {

                $('#tblParticipantsService').show();
                jQuery("#tblParticipantsServiceBeforeStartBid").hide();
                tncAttachment = data[0].TermsConditions.replace(/\s/g, "%20");
                anyotherAttachment = data[0].Attachment.replace(/\s/g, "%20");
                $("#hdnAdvFactor").val(data[0].AdvFactor);
                jQuery("label#lblitem1").text(data[0].BidFor);
                jQuery("#lblbidsubject").text(data[0].BidSubject);
                jQuery("#lblbidDetails").text(data[0].BidDetails);
                jQuery("#lblbiddate").text(data[0].BidDate);
                jQuery("#lblbidtime").text(data[0].BidTime);
                jQuery("#lblbidtype").text(data[0].BidTypeName);
                jQuery("#lblbidfor").text('Price (' + data[0].BidFor + ')');
               
                jQuery('#bid_EventID').html("Event ID : " + sessionStorage.getItem("BidID"));

                jQuery("a#lnkTermsAttachment").text(data[0].TermsConditions);
                jQuery("a#lnkTermsAttachment").attr("href", "PortalDocs/Bid/" + sessionStorage.getItem("BidID") + "/" + tncAttachment)

                jQuery("a#lnkAnyOtherAttachment").text(data[0].Attachment);
                jQuery("a#lnkAnyOtherAttachment").attr("href", "PortalDocs/Bid/" + sessionStorage.getItem("BidID") + "/" + anyotherAttachment)

                jQuery("#lblwarehousearea").text(data[0].WareHouseArea);

                jQuery("#lblbidduration").text(data[0].BidDuration);
                jQuery("#lblcurrency").text(data[0].CurrencyName);
                jQuery("#lblConvRate").text(data[0].ConversionRate);
                jQuery("#lblstatus").text(data[0].ConversionRate);
                jQuery("#lblConvRate").text(data[0].ConversionRate);

                _isBidStarted = true;
                $('#lblTimeLeftBeforeBid').html('').hide('');
                BidTypeID = data[0].BidTypeID;
                BidForID = data[0].BidForID;
                //alert(BidForID)
                fetchBidSummaryVendorproduct()

                display = document.querySelector('#lblTimeLeft');
                startTimer((parseInt(data[0].TimeLeft)), display);

                $('#btnsubmit').show()

            }
            else if (data.length > 1 || data.length == 0) {

                $('#lblTimeLeftBeforeBid').html('Bid is not  started.').css('color', 'red');
              
                $('#tblParticipantsService').hide();
                jQuery("#tblParticipantsServiceBeforeStartBid").show();
                _isBidStarted = false;
                $('#btnsubmit').hide()
                fetchBidHeaderDetails(sessionStorage.getItem("BidID"))
            }
        },
        
        error: function (xhr, status, error) {
            jQuery("#error").text(xhr.d);      
        var err = eval("(" + xhr.responseText + ")");
        if (xhr.status === 401) {
            error401Messagebox(err.Message);
        }
        jQuery.unblockUI();
    }
    });

}
var count;

function fninsupdQuotesS(index) {
    //jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
   
    var vendorID = '';
    var insertquery = '';
    var v = 0;
    var vjap = 0;
    var value = 0;
    var valuejap = 0;
   
    vendorID = sessionStorage.getItem('VendorId');
    
    var Amount = $('#minimumdec' + index).text()
    if ($('#decon' + index).text() == "A") {
        if (jQuery("#lastQuote" + index).text() == '') {
            value = parseFloat(removeThousandSeperator($('#txtquote' + index).val()))
            valuejap = parseFloat(removeThousandSeperator($('#txtquote' + index).val()))

        }
        else {
            value = parseFloat(removeThousandSeperator(jQuery("#lastQuote" + index).text())) - parseFloat(removeThousandSeperator($('#txtquote' + index).val()))
            valuejap = parseFloat(removeThousandSeperator(jQuery("#L1Price" + index).text())) - parseFloat(removeThousandSeperator($('#txtquote' + index).val()))
        }

    }
    else {
        if (jQuery("#lastQuote" + index).text() == '') {
            value = (parseFloat(Amount) / 100) * (parseFloat(removeThousandSeperator(jQuery("#txtquote" + index).val())));
            v = parseFloat(removeThousandSeperator($('#txtquote' + index).val()))

            valuejap = (parseFloat(Amount) / 100) * (parseFloat(removeThousandSeperator(jQuery("#txtquote" + index).val())));
            vjap = parseFloat(removeThousandSeperator($('#txtquote' + index).val()))
        }
        else {
            value = (parseFloat(Amount) / 100) * (parseFloat(removeThousandSeperator(jQuery("#lastQuote" + index).text())));
            v = parseFloat(removeThousandSeperator(jQuery("#lastQuote" + index).text())) - parseFloat(removeThousandSeperator($('#txtquote' + index).val()));

            valuejap = (parseFloat(Amount) / 100) * (parseFloat(removeThousandSeperator(jQuery("#L1Price" + index).text())));
            vjap = parseFloat(removeThousandSeperator(jQuery("#L1Price" + index).text())) - parseFloat(removeThousandSeperator($('#txtquote' + index).val()));
        }
    }

    if ((removeThousandSeperator($('#txtquote' + index).val()) == 0) || (!/^[0-9]+(\.[0-9]{1,2})?$/.test(removeThousandSeperator($('#txtquote' + index).val())))) {
        $('#spanamount' + index).removeClass('hide')
        $('#spanamount' + index).text('Amount is required in number only')
        jQuery.unblockUI();
        return false
    }

    else if (parseFloat(removeThousandSeperator($('#ceilingprice' + index).text())) < parseFloat(removeThousandSeperator($('#txtquote' + index).val()))) {
        $('#spanamount' + index).removeClass('hide')
        $('#spanamount' + index).text('Amount should be less than Bid start price')
        jQuery.unblockUI();
        return false
    }
    else if (value < parseFloat(Amount) && $('#decon' + index).text() == "A" && value != 0 && BidForID == "81") {

        $('#spanamount' + index).removeClass('hide')
        $('#spanamount' + index).text('Maximum Bid  = Your last quote minus minimum Decrement Value of ' + Amount + " " + $("#lblcurrency").text())
        jQuery.unblockUI();
        return false
    }
    else if (valuejap < parseFloat(Amount) && $('#decon' + index).text() == "A" && value != 0 && BidForID == "83") {

        $('#spanamount' + index).removeClass('hide')
        $('#spanamount' + index).text('Maximum bid amount = current L1 price less the minimum Decrement Value of ' + Amount + " " + $("#lblcurrency").text())
        jQuery.unblockUI();
        return false
    }
    else if (v < value && $('#decon' + index).text() == "P" && BidForID == "81") {
        $('#spanamount' + index).removeClass('hide')
        $('#spanamount' + index).text('Maximum Bid  = Your last quote minus minimum Decrement Value of ' + Amount + '%')
        jQuery.unblockUI();
        return false
    }
    else if (vjap < valuejap && $('#decon' + index).text() == "P" && BidForID == "83") {
        $('#spanamount' + index).removeClass('hide')
        $('#spanamount' + index).text('Maximum bid amount = current L1 price less the minimum Decrement Value of ' + Amount + '%')
        jQuery.unblockUI();
        return false
    }
    else {

        insertquery = insertquery + 'insert into VendorSeaExportParticipationDetails(SEHeaderID,SEID,BidID,VendorID,QuotedPrice,SubmissionTime)'
        insertquery = insertquery + " select  0," + $('#seid' + index).html() + "," + sessionStorage.getItem('BidID') + ",'##VendorID##'," + removeThousandSeperator($('#txtquote' + index).val()) + ",getdate() union";
        insertquery = insertquery.substring(0, insertquery.length - 6);


        var QuoteProduct = {
            "VendorID": vendorID,
            "BidID": sessionStorage.getItem("BidID"),
            "insertQuery": insertquery,
            "EnteredBy": vendorID,
            "Quote": removeThousandSeperator($('#txtquote' + index).val()),
            "SEID": $('#seid' + index).html(),
            "AdvFactor": $("#hdnAdvFactor").val(),
            "ForRFQ": "N"

        }
        // alert(JSON.stringify(QuoteProduct))
        jQuery.ajax({
            url: sessionStorage.getItem("APIPath") + "VendorParticipation/ParticipationSeaExport/",
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            type: "POST",
            data: JSON.stringify(QuoteProduct),
            contentType: "application/json; charset=utf-8",
            success: function (data, status, jqXHR) {

                if (data[0].BidID == -1) {
                    $('#spanmsz' + index).removeClass('hide')
                    $('#spanmsz' + index).text('already Quoted by someone.')
                }
                else {
                    extendbidS(index);
                    // setTimeout(function () {
                    //  fetchVendorDetails();
                    // }, 700);
                    //fetchVendorDetails()
                }
               // jQuery.unblockUI();
                return true;
            },
            error: function (xhr, status, error) {
               
                jQuery("#error").text(xhr.d +" you're offline check your connection and try again");
                   
                    var err = eval("(" + xhr.responseText + ")");
                    if (xhr.status === 401) {
                        error401Messagebox(err.Message);
                    }
                    jQuery.unblockUI();
                
            }
        });

    }
}
function extendbidS(index) {

    var SeaQuote = {
        "SEID": jQuery("#seid" + index).text(),
        "BidID": sessionStorage.getItem("BidID")
    }
    //alert(JSON.stringify(SeaQuote))
    jQuery.ajax({
        url: sessionStorage.getItem("APIPath") + "VendorParticipation/UpdateNoOfExtensionForSeaItem/",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "POST",
        data: JSON.stringify(SeaQuote),
        contentType: "application/json; charset=utf-8",
        success: function (data, status, jqXHR) {
            jQuery("#txtquote" + index).val('');
            // refreshColumnsStaus();
            // setTimeout(function () {
            //  fetchVendorDetails()
            // }, 2000);

        },
        
        error: function (xhr, status, error) {
               
            jQuery("#error").text(xhr.d +" error in update");
              
        var err = eval("(" + xhr.responseText + ")");
        if (xhr.status === 401) {
            error401Messagebox(err.Message);
        }
        jQuery.unblockUI();
                
    }
    })
}
function fetchBidSummaryVendorproduct() {
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    var url = '';
    count = 0;

    url = sessionStorage.getItem("APIPath") + "VendorParticipation/fetchBidSummaryVendorSeaExport/?VendorID=" + sessionStorage.getItem("VendorId") + "&BidID=" + sessionStorage.getItem("BidID") + "&UserType=" + sessionStorage.getItem("UserType") + "&AthenticationToken=''&_isBidStarted=" + _isBidStarted + "";

    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: url,
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {


            if (data.length > 0) {
                if (_isBidStarted == false) {

                    jQuery("#tblParticipantsServiceBeforeStartBid").empty()
                    jQuery("#tblParticipantsServiceBeforeStartBid").append("<thead><tr style='background: gray; color: #FFF'><th>Item/Product/Service</th><th>Quantity</th><th>UOM</th><th class=hide id='bidStartPrice'>Bid start price</th><th class=hide>Target Price</th><th class=hide>Minimum Decrement</th><th class=hide>Initial Quote</th><th class=hide>Last Quote</th><th class=hide> Status </th><th class=hide>Enter your Bid*</th><th class=hide>Action</th><th>Remarks</th></thead>");

                    for (var i = 0; i < data.length; i++) {
                        jQuery("#tblParticipantsServiceBeforeStartBid").append("<tr><td class=hide id=minimumdec" + i + ">" + data[i].MinimumDecreament + "</td><td class=hide id=decon" + i + ">" + data[i].DecreamentOn + "</td><td class=hide id=seid" + i + ">" + data[i].SEID + "</td><td class='hide'>" + data[i].UOM + "</td><td>" + data[i].DestinationPort + "</td><td>" + thousands_separators(data[i].Quantity) + "</td><td>" + data[i].UOM + "</td><td class=hide id=ceilingprice" + i + ">" + thousands_separators(data[i].CeilingPrice) + " " + jQuery("#lblcurrency").text() + "</td><td class=hide id=targetprice" + i + ">" + thousands_separators(data[i].TargetPrice) + " " + jQuery("#lblcurrency").text() + "</td><td class=hide>" + data[i].MinimumDecreament + " " + decreamentOn + "</td><td class=hide id=initialquote" + i + ">" + IQuote + "</td><td class=hide id=lastQuote" + i + ">" + LqQuote + "</td><td class=hide id=lblstatus" + i + ">" + data[i].LOQuotedPrice + "</td><td class=hide > <input type=text class=form-control autocomplete=off  id=txtquote" + i + " name=txtquote" + i + " /> <span id=spanamount" + i + "   style=color:#a94442></span></td><td class=hide ><button type='button' id=AllItembtn" + i + " class='btn btn-warning' onclick=InsUpdQuoteSeaExport(" + i + ")>Submit</button><br/><span id=spanmszA" + i + " style=color:#a94442></span></td><td class=hide id=chkMaskVendor" + i + ">" + data[i].MaskVendor + "</td><td>" + data[i].Remarks + "</td></tr>");
                    }
                }
                else {
                    jQuery("#tblParticipantsService").empty()
                   

                    jQuery("#tblParticipantsService").append("<thead><tr style='background: gray; color: #FFF'><th>Item/Product/Service</th><th>Quantity</th><th>UOM</th><th id=bidStartPrice>Bid start price</th><th>Target Price</th><th>Minimum Decrement</th><th>Initial Quote</th><th>Last Quote</th><th>L1 Price</th><th> Status </th><th>Closing Time</th><th>Time Left</th><th>Quote*</th><th>Action</th></thead>");

                    for (var i = 0; i < data.length; i++) {

                        var IQuote = data[i].IQQuotedPrice == '0' ? '' : data[i].IQQuotedPrice;
                        var LqQuote = data[i].LQQuotedPrice == '0' ? '' : data[i].LQQuotedPrice;
                        var decreamentOn = data[i].DecreamentOn == "A" ? jQuery("#lblcurrency").text() : '%';
                        jQuery("#tblParticipantsService").append("<tr class=text-center><td class=hide id=minimumdec" + i + ">" + data[i].MinimumDecreament + "</td><td class=hide id=decon" + i + ">" + data[i].DecreamentOn + "</td><td class=hide id=seid" + i + ">" + data[i].SEID + "</td><td class='hide'>" + data[i].UOM + "</td><td>" + data[i].DestinationPort + "</td><td>" + thousands_separators(data[i].Quantity) + "</td><td>" + data[i].UOM + "</td><td id=ceilingprice" + i + ">" + thousands_separators(data[i].CeilingPrice) + " " + jQuery("#lblcurrency").text() + "</td><td id=targetprice" + i + ">" + thousands_separators(data[i].TargetPrice) + " " + jQuery("#lblcurrency").text() + "</td><td>" + thousands_separators(data[i].MinimumDecreament) + " " + decreamentOn + "</td><td id=initialquote" + i + ">" + thousands_separators(IQuote) + "</td><td id=lastQuote" + i + ">" + thousands_separators(LqQuote) + "</td><td id=L1Price" + i + ">" + thousands_separators(data[i].L1Quote) + "</td><td id=lblstatus" + i + ">" + data[i].LOQuotedPrice + "</td><td id=itemleft" + i + "></td><td id=itemleftTime" + i + " class=bold></td><td> <input type=text class='form-control txtquote' autocomplete=off  id=txtquote" + i + " name=txtquote" + i + " onkeyup='thousands_separators_input(this)' /> <span id=spanamount" + i + "   style=color:#a94442></span></td><td><button type='button' id=itembtn" + i + " class='btn btn-warning clsdisable' onclick=fninsupdQuotesS(" + i + ")>Submit</button><br/><span class='help-block ' style=color:#a94442 id=spanclosedmsz" + i + ">Bid Item Closed.</span><br/><span id=spanmsz" + i + "   style=color:#a94442></span></td><td class=hide>" + data[i].MaskVendor + "</td></tr>");

                        if (data[i].ItemStatus == "Close" || data[i].ItemStatus == "Inactive") {
                            $("#itemleft" + i).html('')
                            $("#itemleftTime" + i).html('')
                            jQuery("#txtquote" + i).attr("disabled", true)
                            jQuery("#itembtn" + i).attr("disabled", true)
                            jQuery("#spanclosedmsz" + i).removeClass("hide")
                            jQuery("#spanclosedmsz" + i).css("color", "")
                        }
                        else {
                            $("#itemleft" + i).html(data[i].ItemTimeLeft)
                            //$("#itemleftTime" + i).html(data[i].ItemLeft)
                            jQuery("#txtquote" + i).attr("disabled", false)
                            jQuery("#itembtn" + i).attr("disabled", false)
                            jQuery("#spanclosedmsz" + i).addClass("hide")
                            displayForS = document.querySelector('#itemleftTime' + i);
                            startTimerForStaggerItem((parseInt(data[i].ItemLeft)), displayForS);
                        }

                        if (data[i].MaskVendor == 'Y') {
                            $("#targetprice" + i).html('Not Disclosed')
                        }
                        if (data[i].MaskL1Price == 'N') {
                            $("#L1Price" + i).html('Not Disclosed');
                        }
                        if (data[i].ShowStartPrice == 'N') {
                            $("#ceilingprice" + i).html('Not Disclosed');
                        }

                        $('#spanamount' + i).addClass('hide spanclass');
                        $('#spanmsz' + i).addClass('hide spanclass');
                        $('#spanclosedmsz' + i).addClass('hide spanclass');


                        if (data[i].LOQuotedPrice == 'L1') {
                            jQuery('#lblstatus' + i).css('color', 'Blue');
                        }
                        else {

                            jQuery('#lblstatus' + i).css('color', 'Red');
                        }

                        if (data[i].ItemNoOfExtension > 0) {
                            jQuery('#itemleft' + i).css({
                                'color': 'Red',
                                'font-weight': '500'
                            });
                        }
                        if (data[i].ItemNoOfExtension > 0) {
                            jQuery('#itemleftTime' + i).css({
                                'color': 'Red',
                                'font-weight': '500'
                            });
                        }
                        count = count + 1;

                    }


                }


            }
            else {
                jQuery("#tblParticipantsService").append("<tr><td>Nothing Participation</td></tr>")
            }


        },
        error: function (xhr, status, error) {

            jQuery("#error").text(xhr.d + " error in update");

          
            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            jQuery.unblockUI();

        }
    })
    jQuery.unblockUI();

}
function refreshColumnsStaus() {
    clearInterval(mytime)
    var url = '';
   url = sessionStorage.getItem("APIPath") + "VendorParticipation/fetchBidSummaryVendorSeaExport/?VendorID=" + encodeURIComponent(sessionStorage.getItem("VendorId")) + "&BidID=" + sessionStorage.getItem("BidID") + "&UserType=" + sessionStorage.getItem("UserType") + "&AthenticationToken=''&_isBidStarted=" + _isBidStarted + "";
    
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: url,
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {

            if (data.length > 0) {
                for (var i = 0; i < data.length; i++) {
                    if (data[i].NoOfExtension >= 1) {
                        jQuery('#lblTimeLeft').css('color', 'red');
                        jQuery('#lblTimeLeftTxt').removeClass('display-none');
                        jQuery('#lblTimeLeftTxt').html('<b>Bid Time Extended.</b>').css('color', 'red')
                    }
                    else {
                        jQuery('#lblTimeLeftTxt').addClass('display-none');
                        jQuery('#lblTimeLeft').css('color', '');
                    }
                    
                        if (data[i].ItemStatus == "Close" || data[i].ItemStatus == "Inactive") {
                            $("#itemleft" + i).html('')
                            jQuery("#txtquote" + i).val('');
                            $("#itemleftTime" + i).html('')
                            jQuery("#txtquote" + i).attr("disabled", true)
                            jQuery("#itembtn" + i).attr("disabled", true)

                        }
                        else {
                            if (parseInt(data[i].ItemLeft) <= 1) { //<=1
                                jQuery("#itembtn" + i).attr("disabled", true)
                            }
                            else {
                                jQuery("#itembtn" + i).attr("disabled", false)
                            }
                            jQuery("#lblbidduration").text(data[0].BidDuration);
                            $("#itemleft" + i).html(data[i].ItemTimeLeft)
                            jQuery("#txtquote" + i).attr("disabled", false)

                            //$("#itemleftTime" + i).html(data[i].ItemLeft)

                            displayForS = document.querySelector('#itemleftTime' + i);
                            startTimerForStaggerItem((parseInt(data[i].ItemLeft)), displayForS);
                        }
                    
                    jQuery("#lblbidduration").text(data[0].BidDuration);

                    display = document.querySelector('#lblTimeLeft');
                    startTimer(data[i].TimeLeft, display);

                    $("#initialquote" + i).html(data[i].IQQuotedPrice == '0' ? '' : data[i].IQQuotedPrice)
                    $("#lastQuote" + i).html(data[i].LQQuotedPrice == '0' ? '' : thousands_separators(data[i].LQQuotedPrice))
                    $("#lblstatus" + i).html(thousands_separators(data[i].LOQuotedPrice))
                    $("#L1Price" + i).html(thousands_separators(data[i].L1Quote))
                    if (data[i].MaskL1Price == 'N') {
                        $("#L1Price" + i).html('Not Disclosed');
                    }
                    if (data[i].LOQuotedPrice == 'L1') {
                        jQuery('#lblstatus' + i).css('color', 'Blue');
                    }
                    else {
                        jQuery('#lblstatus' + i).css('color', 'Red');

                    }


                    if (data[i].ItemNoOfExtension > 0) {
                        jQuery('#itemleft' + i).css({
                            'color': 'Red',
                            'font-weight': '500'
                        });
                        jQuery('#itemleftTime' + i).css({
                            'color': 'Red',
                            'font-weight': '500'
                        });
                    }


                }
            }

        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            jQuery.unblockUI();

        }
    });

}


var mytime = 0;
var mytimeforSatus = 0;
function startTimer(duration, display) {
    clearInterval(mytime)
    
    var timer = duration, hours, minutes, seconds;
    mytime = setInterval(function () {
        hours = parseInt(timer / 3600, 10)
        minutes = parseInt(timer / 60, 10) - (hours * 60)
        seconds = parseInt(timer % 60, 10);

        hours = hours < 10 ? "0" + hours : hours;
        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;

        if (hours > 0) {
            display.textContent = hours + ":" + minutes + ":" + seconds;
        }
        else {
            display.textContent = minutes + ":" + seconds;
        }
        if ((seconds.toString().substring(1, 2) == '0') || (seconds.toString().substring(1, 2) == '5')) {
           
            if (sessionStorage.getItem("UserType") == 'E') {
                fetchUserChats($('#hddnVendorId').val(), 'S');
            } else {
                fetchUserChats(sessionStorage.getItem('UserID'), 'S');
            }

        }
        refreshColumnsStaus();
        console.log(timer)

        if (timer <= 0) {
            $('.clsdisable').attr('disabled', 'disabled')
           
        }
       
        setTimeout(function () {
            if (--timer < -3) {
                timer = -3;
                if (timer == -3) {
                    closeBidAir();
                }
            }
        }, 1000);
       

    }, 1000);


}
function startTimerForStaggerItem(duration, displayS) {
    clearInterval(mytimeforSatus)

    var timer = duration, hours, minutes, seconds;
    mytimeforSatus = setInterval(function () {
        hours = parseInt(timer / 3600, 10)
        minutes = parseInt(timer / 60, 10) - (hours * 60)
        seconds = parseInt(timer % 60, 10);

        hours = hours < 10 ? "0" + hours : hours;
        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;

        if (hours > 0) {
            displayS.textContent = hours + ":" + minutes + ":" + seconds;
        }
        else {
            displayS.textContent = minutes + ":" + seconds;
        }

       // refreshColumnsStaus();
        if (--timer <= 1) {//button disabled at 2 sec or <=0 if at 1 sec
            timer = 0;
            if (timer == 0) {
                $('.clsdisable').attr('disabled', 'disabled')
            }
        }

    }, 1000);
}


function closeBidAir() {
    clearInterval(mytime)
    jQuery.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "VendorParticipation/CloseBid/?BidID=" + sessionStorage.getItem("BidID"),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
            bootbox.alert("Bid time has been over. Thanks for Participation.", function () {
                //window.location = sessionStorage.getItem('MainUrl');
                if (sessionStorage.getItem("ISFromSurrogate") == "Y") {
                    window.location = sessionStorage.getItem('HomePage');
                    sessionStorage.clear();
                }
                else {
                    window.location = 'VendorHome.html';

                }

                return false;

            });
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            jQuery.unblockUI();

        }
    });
}



function fetchBidHeaderDetails(bidId) {
    var tncAttachment = '';
    var anyotherAttachment = '';
    var url = '';
    
    url = sessionStorage.getItem("APIPath") + "BidVendorSummary/FetchBidDetails_Vendor/?BidID=" + bidId + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("VendorId"))
   
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: url,
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
            console.log("dataa > ", data)
            if (data.length == 1) {
                $('#tblParticipantsService').show();
                tncAttachment = data[0].TermsConditions.replace(/\s/g, "%20");
                anyotherAttachment = data[0].Attachment.replace(/\s/g, "%20");
                $("#hdnAdvFactor").val(data[0].AdvFactor);
                jQuery("label#lblitem1").text(data[0].BidFor);
                jQuery("#lblbidsubject").text(data[0].BidSubject);
                jQuery("#lblbidDetails").text(data[0].BidDetails);
                jQuery("#lblbiddate").text(data[0].BidDate);
                jQuery("#lblbidtime").text(data[0].BidTime);
                jQuery("#lblbidtype").text(data[0].BidTypeName);

                jQuery("#lblbidfor").text('Price (' + data[0].BidFor + ')');

                jQuery("a#lnkTermsAttachment").text(data[0].TermsConditions);
                jQuery("a#lnkTermsAttachment").attr("href", "PortalDocs/Bid/" + sessionStorage.getItem("BidID") + "/" + tncAttachment)

                jQuery("a#lnkAnyOtherAttachment").text(data[0].Attachment);
                jQuery("a#lnkAnyOtherAttachment").attr("href", "PortalDocs/Bid/" + sessionStorage.getItem("BidID") + "/" + anyotherAttachment)

                jQuery("#lblwarehousearea").text(data[0].WareHouseArea);

                jQuery("#lblbidduration").text(data[0].BidDuration);
                jQuery("#lblcurrency").text(data[0].CurrencyName);
                jQuery("#lblConvRate").text(data[0].ConversionRate);
                jQuery("#lblstatus").text(data[0].ConversionRate);
                jQuery("#lblConvRate").text(data[0].ConversionRate);
                var display = document.querySelector('#lblTimeLeft');
                startTimerBeforeBidStart(data[0].TimeLeft, display)
                fetchBidSummaryVendorproduct()
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            jQuery.unblockUI();

        }
    });

}

function startTimerBeforeBidStart(duration, display) {
    clearInterval(mytime)
    
    var timer = duration, hours, minutes, seconds;
    mytime = setInterval(function () {
        hours = parseInt(timer / 3600, 10)
        minutes = parseInt(timer / 60, 10) - (hours * 60)
        seconds = parseInt(timer % 60, 10);

        hours = hours < 10 ? "0" + hours : hours;
        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;

        if (hours > 0) {
            display.textContent = hours + ":" + minutes + ":" + seconds;
        }
        else {
            display.textContent = minutes + ":" + seconds;
        }
        
        duration--;
        startTimerBeforeBidStart(duration, display)
        if (--timer < 0) {
           
            fetchVendorDetails();
        }
       
    }, 1000);

}
$(document).on("keyup", "#tblParticipantsService .form-control", function () {
    var txt = this.id

    $('#' + txt).next(':first').addClass('hide');
    $('.spanclass').addClass('hide')

});