﻿var BidID = "";
var BidTypeID = "";
var BidForID = "";
var PEfaBidForId = 0;
var IsApp = "";
var FwdTo = "";
var AppStatus = "";
var _bidarray = [];
var _timelft = '';
var graphData = [];
var _bidClosingType;
var page = "";

$('#btnpdf').click(function () {
    var encrypdata = fnencrypt("BidID=" + BidID + "&BidTypeID=" + BidTypeID + "&BidForID=" + BidForID)
    var url = "ViewReport2.html?param=" + encrypdata
    var win = window.open(url, "_blank");
               
            
   // var win = window.open('ViewReport2.html?BidID=' + BidID + '&BidTypeID=' + BidTypeID + '&BidForID=' + BidForID+', _blank');
    win.focus();
    //window.location = "ViewReport2.html?BidID=" + BidID + "&BidTypeID=" + BidTypeID + "&BidForID=" + BidForID
})
var postfix=''
function getCurrenttime() {

    var dt = new Date();
    var day = dt.getDate();
    var month = dt.getMonth() + 1;
    var year = dt.getFullYear();
    var hour = dt.getHours();
    var mins = dt.getMinutes();
     postfix = day + "/" + month + "/" + year;
   
}

$(document).ready(function () {
    //debugger;
    
    var path = window.location.pathname;
     page = path.split("/").pop();
   // alert(page)
    console.log(page);
    //BidID = getUrlVars()["BidID"];
    //IsApp = getUrlVars()["App"];
    //FwdTo = getUrlVars()["FwdTo"];
    //AppStatus = getUrlVars()["AppStatus"];
    if (window.location.search) {
        var param = getUrlVars()["param"]
        var decryptedstring = fndecrypt(param)
        BidID = getUrlVarsURL(decryptedstring)["BidID"]
        IsApp = getUrlVarsURL(decryptedstring)["App"]
        FwdTo = getUrlVarsURL(decryptedstring)["FwdTo"]
        AppStatus = getUrlVarsURL(decryptedstring)["AppStatus"]

        if (IsApp == 'N' && FwdTo != 'Admin') {
            jQuery("#divRemarksForward").show();
        }
        else if (IsApp == 'Y' && FwdTo == 'Admin' && AppStatus == 'Reverted') {
            jQuery("#divRemarksForward").show();
        }
        else if (IsApp == 'Y' && FwdTo == 'Admin' && AppStatus != 'Reverted') {
            jQuery("#divRemarksAwarded").show();
        }
        else {
            jQuery("#divRemarksApp").show();
        }
        fetchBidSummary(BidID);
        fetchApproverStatus();
    }
   
});

//function FetchTargetBidAir(bidid) {
//    //alert('test')
//    jQuery.ajax({
//        type: "GET",
//        contentType: "application/json; charset=utf-8",
//        url: sessionStorage.getItem("APIPath") + "ApprovalAir/FetchTargetBid/?BidID=" + bidid,
//        cache: false,
//        crossDomain: true,
//        dataType: "json",
//        success: function (data, status, jqXHR) {
//            if (data.length > 0) {
//                //debugger;
//                //$('#tdfmin').text(data[0].TargetFreightMin);
//                //$('#tdf45').text(data[0].TargetFreightPlus45)
//                //$('#tdf100').text(data[0].TargetFreightPlus100)
//                //$('#tdf300').text(data[0].TargetFreightPlus300)
//                //$('#tdf500').text(data[0].TargetFreightPlus500)
//                //$('#tdf1000').text(data[0].TargetFreightPlus1000)

//                //$('#tdxmin').text(data[0].TargetExWorksMin)
//                //$('#tdx45').text(data[0].TargetExWorksPlus45)
//                //$('#tdx100').text(data[0].TargetExWorksPlus100)
//                //$('#tdx300').text(data[0].TargetExWorksPlus300)
//                //$('#tdx500').text(data[0].TargetExWorksPlus500)
//                //$('#tdx1000').text(data[0].TargetExWorksPlus1000)
//                jQuery("#tdfmin").text(data[0].TargetFreightMin == null ? '' : data[0].TargetFreightMin)
//                jQuery("#tdf45").text(data[0].TargetFreightPlus45 == null ? '' : data[0].TargetFreightPlus45)
//                jQuery("#tdf100").text(data[0].TargetFreightPlus100 == null ? '' : data[0].TargetFreightPlus100)
//                jQuery("#tdx300").text(data[0].TargetFreightPlus300 == null ? '' : data[0].TargetFreightPlus300)
//                jQuery("#tdx500").text(data[0].TargetFreightPlus500 == null ? '' : data[0].TargetFreightPlus500)
//                jQuery("#tdx1000").text(data[0].TargetFreightPlus1000 == null ? '' : data[0].TargetFreightPlus1000)

//                if (data[0].BidForID == "3") {
//                    jQuery("#tdxmin").text(data[0].TargetExWorksMin == null ? '' : data[0].TargetExWorksMin)
//                    jQuery("#tdx45").text(data[0].TargetExWorksPlus45 == null ? '' : data[0].TargetExWorksPlus45)
//                    jQuery("#tdx100").text(data[0].TargetExWorksPlus100 == null ? '' : data[0].TargetExWorksPlus100)
//                    jQuery("#tdx300").text(data[0].TargetExWorksPlus300 == null ? '' : data[0].TargetExWorksPlus300)
//                    jQuery("#tdx500").text(data[0].TargetExWorksPlus500 == null ? '' : data[0].TargetExWorksPlus500)
//                    jQuery("#tdx1000").text(data[0].TargetExWorksPlus1000 == null ? '' : data[0].TargetExWorksPlus1000)
//                }
//                else {
//                    jQuery('#trtargetexworks').hide();
//                }
//                //jQuery('#lblModelClass').text(data[0].ModelClass)
//            }
//        }
//    });
//}
var strrowfordetails = '';

function fetchBidSummary(BidID) {
    //alert(sessionStorage.getItem("APIPath") + "BidVendorSummary/FetchBidDetails/?BidID=" + BidID + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("UserID")))
	var tncAttachment = '';
    	var anyotherAttachment = '';
    	jQuery.ajax({
    	    type: "GET",
    	    contentType: "application/json; charset=utf-8",
    	    url: sessionStorage.getItem("APIPath") + "BidVendorSummary/FetchBidDetails/?BidID=" + BidID + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("UserID")),
    	    beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
    	    cache: false,
    	    crossDomain: true,
    	    dataType: "json",
    	    success: function(data, status, jqXHR) {

                if (data.length > 0) {
                    jQuery('#bid_ConfiguredBy').html("Bid Configured By: " +data[0].ConfigureByName);
    	            if (BidTypeID != "7") {
    	                if (data[0].FinalStatus != 'Awarded') {
    	                    $('#bid_status').html('Status: ' + data[0].FinalStatus)
    	                }

    	                else {
    	                   // $('#bid_status').html('Status: Approved' + ' to: ' + data[0].AwardedToName)
                            $('#bid_status').html('Status: ' + data[0].FinalStatus)
    	                }
    	            }
    	            else {
    	                if (data[0].FinalStatus != 'Awarded') {
    	                    $('#bid_status').html('Status: ' + data[0].FinalStatus)
    	                } else {
    	                    $('#bid_status').html('Status: Approved')
    	                }
    	              }

    	            if (data[0].FinalStatus == 'Cancel') {
    	                $('#cancl_btn').hide();
    	            } else {
    	                $('#cancl_btn').show();

    	            }
    	            if (data[0].BidClosingType != null) _bidClosingType = data[0].BidClosingType;
                    if (sessionStorage.getItem("UserID") == data[0].DecryptedConfiguredBy) {

                        //$('#cancl_btn,#btnCancelbidAdmin').show();
                        $('#btnCancelbidAdmin,#btnCancelbidAward,#cancl_btn,#btnCancelbidApp,#butCancelbid,#btn_invite_vendors').show();
                        $('#btnCancelbidAdmin,#btnCancelbidAward,#cancl_btn,#btnCancelbidApp,#butCancelbid,#btn_invite_vendors').removeClass('hide');
                      
                        if (_bidClosingType == 'S' || _bidClosingType == '82' ) {
                            $('#btndiv').hide()
                            $('#spinnerBidclosingTab').hide()
                        }
                        else {
                            $('#btndiv').show()
                            $('#spinnerBidclosingTab').show()

                        }
                       
                       // $('#spinnerBidclosingTab').spinner({ value: BidData[0].BidDetails[0].BidDuration, step: 1, min: 0, max: 999 });
                    }
                    else {
                       
                        //$('#cancl_btn,#btnCancelbidAdmin').hide();
                        $('#btnCancelbidAdmin,#btnCancelbidAward,#cancl_btn,#btnCancelbidApp,#butCancelbid,#btn_invite_vendors').hide();
                        $('#btnCancelbidAdmin,#btnCancelbidAward,#cancl_btn,#btnCancelbidApp,#butCancelbid,#btn_invite_vendors').addClass('hide');
                        $('#btndiv').hide()
                        $('#spinnerBidclosingTab').hide()
                        if (data[0].Status == 'Close' || data[0].Status == 'CLOSE') {
                           
                            $('#btn_invite_vendors').hide();
                        } else {
                           
                            $('#btn_invite_vendors').show();
                        }
                    }
                   // alert(data[0].BidClosingType)
                    
                   
    	            if (data[0].Status == 'Close' || data[0].Status == 'CLOSE') {
    	                $('#bid_status').show();
    	               
    	            } else {
    	                $('#bid_status').hide();
    	               
    	            }

    	            // tncAttachment = data[0].TermsConditions.replace(/%20/g, " ").replace(/&amp;/g, "&");
    	            //anyotherAttachment = data[0].Attachment.replace(/%20/g, " ").replace(/&amp;/g, "&");
    	           
    	            tncAttachment = data[0].TermsConditions.replace(/\s/g, "%20");
    	            anyotherAttachment = data[0].Attachment.replace(/\s/g, "%20");
    	            jQuery("#lblbidSubject").html('<b>' + data[0].BidSubject + '</b>'); 
    	            jQuery("#lblbiddetails").text(data[0].BidDetails);
    	            jQuery("#lblbiddate").text(data[0].BidDate);
    	            jQuery("#lblbidtime").text(data[0].BidTime);
    	            jQuery("#lblbidtype").text(data[0].BidTypeName);
    	            jQuery("#lblEventID").text(BidID);
    	            if (data[0].BidForID == 81) {
    	                //$('#btndiv').show()
    	               // $('#spinnerBidclosingTab').show()
    	                jQuery("#lblbidfor").text('Price (English)');
    	                PEfaBidForId = 81;
    	            }
    	            else if (data[0].BidForID == 82) {
    	                //$('#btndiv').hide()
    	                //$('#spinnerBidclosingTab').hide()
    	                jQuery("#lblbidfor").text('Dutch Auction');
    	                PEfaBidForId = 82;
    	            }
    	            else if (data[0].BidForID == 83) {
    	                //$('#btndiv').hide()
    	                //$('#spinnerBidclosingTab').hide()
    	                jQuery("#lblbidfor").text('Price (japanese)');
    	                //PEfaBidForId = 82;
    	            }
    	            else {
    	                jQuery("#lblbidfor").text(data[0].BidFor);
    	            }
    	            
    	            jQuery("#lblbidduration").text(data[0].BidDuration + ' mins');
    	           jQuery('#txtBidDurationPrev').val(data[0].BidDuration)
    	            $('#spinnerBidclosingTab').spinner({ value: data[0].BidDuration, step: 1, min: 0, max: 999 });
    	            jQuery("#lblcurrency").text(data[0].CurrencyName);
    	            jQuery("a#lnkTermsAttachment").html(data[0].TermsConditions);
    	            jQuery("a#lnkTermsAttachment").attr("href", "PortalDocs/Bid/" + BidID + "/" + tncAttachment)
    	            jQuery("a#lnkAnyOtherAttachment").html(data[0].Attachment);
    	            jQuery("a#lnkAnyOtherAttachment").attr("href", "PortalDocs/Bid/" + BidID + "/" + anyotherAttachment)

    	           
    	            BidID = data[0].BidID
    	            BidTypeID = data[0].BidTypeID
    	            BidForID = data[0].BidForID
    	            if (data[0].BidTypeID == "2") {


    	                jQuery("#divModelClass").show();
    	                jQuery('#lblModelClass').text(data[0].ModelClass == "1" ? 'Min' : data[0].ModelClass == "2" ? '45+' : data[0].ModelClass == "3" ? '100+' : data[0].ModelClass == "4" ? '300+' : data[0].ModelClass == "5" ? '500+' : '1000+')

    	                jQuery("#divTargetPrice").show();
    	                jQuery("#tdfmin").text(data[0].TargetFreightMin == null ? '' : data[0].TargetFreightMin)
    	                jQuery("#tdf45").text(data[0].TargetFreightPlus45 == null ? '' : data[0].TargetFreightPlus45)
    	                jQuery("#tdf100").text(data[0].TargetFreightPlus100 == null ? '' : data[0].TargetFreightPlus100)
    	                jQuery("#tdf300").text(data[0].TargetFreightPlus300 == null ? '' : data[0].TargetFreightPlus300)
    	                jQuery("#tdf500").text(data[0].TargetFreightPlus500 == null ? '' : data[0].TargetFreightPlus500)
    	                jQuery("#tdf1000").text(data[0].TargetFreightPlus1000 == null ? '' : data[0].TargetFreightPlus1000)
    	                var Modelclass = data[0].ModelClass == "1" ? 'Min' : data[0].ModelClass == "2" ? '45+' : data[0].ModelClass == "3" ? '100+' : data[0].ModelClass == "4" ? '300+' : data[0].ModelClass == "5" ? '500+' : '1000';
    	                var fmin = data[0].TargetFreightMin == null ? '' : data[0].TargetFreightMin
    	                var f45 = data[0].TargetFreightPlus45 == null ? '' : data[0].TargetFreightPlus45
    	                var f100 = data[0].TargetFreightPlus100 == null ? '' : data[0].TargetFreightPlus100
    	                var f300 = data[0].TargetFreightPlus300 == null ? '' : data[0].TargetFreightPlus300
    	                var f500 = data[0].TargetFreightPlus500 == null ? '' : data[0].TargetFreightPlus500
    	                var f1000 = data[0].TargetFreightPlus1000 == null ? '' : data[0].TargetFreightPlus1000

    	                jQuery('#tbldetails').append("<tr id=low><td>" + data[0].BidSubject + "</td><td>" + data[0].BidDetails + "</td><td>" + data[0].BidTime + "</td><td>" + data[0].BidTypeName + "</td><td>" + data[0].BidFor + "</td><td>" + data[0].BidDuration + " mins</td><td>" + data[0].CurrencyName + "</td><td>" + Modelclass + "+</td><td></td><tr>");
    	                jQuery('#tblprice').append("<tr><td>Freight</td><td>" + fmin + "</td><td>" + f45 + "</td><td>" + f100 + "</td><td>" + f300 + "</td><td>" + f500 + "</td><td>" + f1000 + "</td></tr>");

    	                if (data[0].BidTypeID == "2") {
    	                    jQuery('#divTarget').height(130);
    	                }
    	                if (data[0].BidForID == "3") {
    	                    var xmin = data[0].TargetExWorksMin == null ? '' : data[0].TargetExWorksMin
    	                    var x45 = data[0].TargetExWorksPlus45 == null ? '' : data[0].TargetExWorksPlus45
    	                    var x100 = data[0].TargetExWorksPlus100 == null ? '' : data[0].TargetExWorksPlus100
    	                    var x300 = data[0].TargetExWorksPlus300 == null ? '' : data[0].TargetExWorksPlus300
    	                    var x500 = data[0].TargetExWorksPlus500 == null ? '' : data[0].TargetExWorksPlus500
    	                    var x1000 = data[0].TargetExWorksPlus1000 == null ? '' : data[0].TargetExWorksPlus1000

    	                    jQuery('#tblprice').append("<tr><td>Exworks</td><td>" + xmin + "</td><td>" + x45 + "</td><td>" + x100 + "</td><td>" + x300 + "</td><td>" + x500 + "</td><td>" + x1000 + "</td></tr>")
    	                    jQuery("#tdxmin").text(data[0].TargetExWorksMin == null ? '' : data[0].TargetExWorksMin)
    	                    jQuery("#tdx45").text(data[0].TargetExWorksPlus45 == null ? '' : data[0].TargetExWorksPlus45)
    	                    jQuery("#tdx100").text(data[0].TargetExWorksPlus100 == null ? '' : data[0].TargetExWorksPlus100)
    	                    jQuery("#tdx300").text(data[0].TargetExWorksPlus300 == null ? '' : data[0].TargetExWorksPlus300)
    	                    jQuery("#tdx500").text(data[0].TargetExWorksPlus500 == null ? '' : data[0].TargetExWorksPlus500)
    	                    jQuery("#tdx1000").text(data[0].TargetExWorksPlus1000 == null ? '' : data[0].TargetExWorksPlus1000)


    	                }
    	                else {

    	                    jQuery('#trtargetexworks').hide();

    	                }

    	            }
    	            else {

    	                jQuery('#thmodelclass').addClass('hide')
    	                if (BidTypeID == 3) {

    	                    jQuery('#thtargetprice').removeClass('hide')
    	                    var tp = data[0].Targetfreight == null ? '' : data[0].Targetfreight;
    	                    jQuery('#tbldetails').append("<tr id=low><td>" + data[0].BidSubject + "</td><td>" + data[0].BidDetails + "</td><td>" + data[0].BidTime + "</td><td>" + data[0].BidTypeName + "</td><td>" + data[0].BidFor + "</td><td>" + data[0].BidDuration + " mins</td><td>" + data[0].CurrencyName + "</td><td></td><td>" + tp + "</td></tr>")
    	                }
    	                else {

    	                    jQuery('#tbldetails').append("<tr><td>" + data[0].BidSubject + "</td><td>" + data[0].BidDetails + "</td><td>" + data[0].BidTime + "</td><td>" + data[0].BidTypeName + "</td><td>" + data[0].BidFor + "</td><td>" + data[0].BidDuration + " mins</td><td>" + data[0].CurrencyName + "</td><td></td><td></td></tr>")
    	                }


    	                jQuery("#lblbidprice").show();
    	                jQuery("#lblbidprice").text(data[0].Targetfreight == null ? '' : data[0].Targetfreight)
    	            }

    	            fetchBidSummaryDetails(BidID, BidTypeID, BidForID);
    	        }
    	        else {
    	            //                bootbox.alert("Oops! Bid has been expired.", function () {
    	            //                     window.location = sessionStorage.getItem('MainUrl');
    	            //                    return false;
    	            //                });
    	        }
    	    },
    	   
    	    error: function (xhr, status, error) {

    	    var err = eval("(" + xhr.responseText + ")");
    	    if (xhr.status === 401) {
    	        error401Messagebox(err.Message);
    	    }
    	    else{
    	        jQuery("#error").text(xhr.d);
    	    }
    	    return false;
    	    jQuery.unblockUI();
    	}
    	});

    	if (BidTypeID == 1 || BidTypeID == 6) {
    	    $('#lnktotvalue').show()
    	    $('#btngraphbubble').show()
    	}
    	else {
    	    $('#lnktotvalue').hide()
    	    $('#btngraphbubble').show()
    	}
}
function fnTimeUpdate() {
  
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    var Data = {
        "BidClosingType": _bidClosingType,
        "BidID": BidID,
        "BidDuration": jQuery('#txtBidDurationPrev').val(),
        "SEID": 0

    }
 //  alert(JSON.stringify(Data))
    jQuery.ajax({
        url: sessionStorage.getItem("APIPath") + "ConfigureBid/UpdateBidTime/",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "POST",
        data: JSON.stringify(Data),
        contentType: "application/json; charset=utf-8",
        success: function (data, status, jqXHR) {

            if (data[0].Status == "1") {
                jQuery("#lblbidduration").text(jQuery('#txtBidDurationPrev').val() + ' mins');
                $('#extendedDurationPara').show()
            }

            jQuery.unblockUI();
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            
            return false;
            jQuery.unblockUI();
        }
    })
}

function fetchBidSummaryDetails(BidID, BidTypeID, BidForID) {
    sessionStorage.setItem('hdnbidtypeid', BidTypeID)
    //jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });

   // alert(sessionStorage.getItem("APIPath") + "BidVendorSummary/FetchBidSummary/?BidID=" + BidID + "&BidTypeID=" + BidTypeID + "&BidForID=" + BidForID + "&UserID=" + encodeURIComponent(sessionStorage.getItem("UserID")) + "&AuthenticationTonken=" + sessionStorage.getItem("AuthenticationToken"))
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "BidVendorSummary/FetchBidSummary/?BidID=" + BidID + "&BidTypeID=" + BidTypeID + "&BidForID=" + BidForID + "&UserID=" + encodeURIComponent(sessionStorage.getItem("UserID")) + "&AuthenticationTonken=" + sessionStorage.getItem("AuthenticationToken"),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function(data, status, jqXHR) {


            jQuery("#tblBidSummary > thead").empty();
            jQuery("#tblBidSummary > tbody").empty();
            jQuery("#tblbidsummarypercentagewise > thead").empty();
            jQuery("#tblbidsummarypercentagewise > tbody").empty();
            _bidarray = [];

            if (data.length > 0) {
                
                if (parseInt(BidTypeID) == 1) {
                    $('#lnktotvalue').html('Detailed Report')
                    if ($('#lnktotvalue').html() == "Detailed Report") {
                        jQuery("#tblBidSummary").hide()
                        jQuery("#tblbidsummarypercentagewise").show()
                        $('#divfordetailreport').show()
                        $('#divforBidsummary').hide()
                    }


                    var TotalBidValue = ''; // TotalBidValueCeiling = '', TotalBidValueInvoice = '';

                    var Percentreduction = '', Percentreductionceiling = '', Percentreductioninvoice = '';
                    $('#divTarget').hide();
                    var sname = '';

                    var strHead = "<tr><th>Product</th><th>Target Price</th><th>Last Invoice Price</th><th>Bid start price</th><th>Quantity</th><th>UOM</th><th>Contract Duration</th><th>Delivery Location</th><th>Level</th><th>Vendor</th><th>Initial Quote</th><th>Lowest Quote</th><th>Bid Value</th><th>Percentage Reduction (Target Price)</th><th>Percentage Reduction (Last InvoicePrice)</th><th>Percentage Reduction (Bid start price)</th><th>TAT (Days)</th><th>Validity (Days)</th>";
                    strHead += "<th>Warranty (Days)</th><th>VAT %</th><th>CST %</th><th>Excise %</th></tr>";
                    var strHeadsummary = "<tr><th>Product</th><th>Target Price</th><th>Last InvoicePrice</th><th>Bid start price</th><th>Quantity</th><th>UOM</th><th>Level</th><th>Vendor</th><th>Initial Quote</th><th>Lowest Quote</th><th>Bid Value</th><th>Percentage Reduction (Target Price)</th><th>Percentage Reduction (Last InvoicePrice)</th><th>Percentage Reduction (Bid start price)</th></tr>";

                    //                    strHead += "<th>Shipping Line</th><th>Sailing Days</th><th>Ocean Transit Time</th></tr>";

                    jQuery('#tblBidSummary > thead').append(strHead);
                    jQuery('#tblbidsummarypercentagewise > thead').append(strHeadsummary);
                    for (var i = 0; i < data.length; i++) {

                        TotalBidValue = parseFloat(data[i].Quantity) * parseFloat(data[i].LQuote);

                        if (TotalBidValue != 0) {
                            if (data[i].TargetPrice != 0) {
                                Percentreduction = parseFloat(100 - parseFloat(data[i].LQuote / data[i].TargetPrice) * 100).toFixed(2) + ' %'
                            }
                            else {
                                Percentreduction = 'Not Specified';
                            }
                            if (data[i].LastInvoicePrice != 0) {
                                Percentreductioninvoice = parseFloat(100 - parseFloat(data[i].LQuote / data[i].LastInvoicePrice) * 100).toFixed(2) + ' %'
                            }
                            else {
                                Percentreductioninvoice = 'Not Specified';
                            }


                            Percentreductionceiling = parseFloat(100 - parseFloat(data[i].LQuote / data[i].CeilingPrice) * 100).toFixed(2) + ' %'
                        } else {

                            Percentreduction = 'N/A';
                            Percentreductionceiling = 'N/A';
                            Percentreductioninvoice = 'N/A';
                        }

                        if (sname != data[i].ShortName) {
                            sname = data[i].ShortName
                            var str = "<tr id=low" + i + "><td>" + data[i].ShortName + "</td><td>" + data[i].TargetPrice + "</td><td>" + data[i].LastInvoicePrice + "</td><td>" + data[i].CeilingPrice + "</td><td>" + data[i].Quantity + "</td><td>" + data[i].UOM + "</td><td>" + data[i].ContractDuration + "</td><td>" + data[i].DeliveryLocation + "</td>";
                            var strsumm = "<tr id=low_ps" + i + "><td>" + data[i].ShortName + "</td><td>" + data[i].TargetPrice + "</td><td>" + data[i].LastInvoicePrice + "</td><td>" + data[i].CeilingPrice + "</td><td>" + data[i].Quantity + "</td><td>" + data[i].UOM + "</td>";

                        }
                        else {
                            var str = "<tr id=low" + i + "><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>";
                            var strsumm = "<tr id=low_ps" + i + "><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>";
                        }


                        str += "<td>" + data[i].SrNo + "</td><td>" + data[i].VendorName + "</td><td>" + (data[i].IQuote == '0' ? '' : data[i].IQuote) + "</td>";
                        str += "<td>" + (data[i].LQuote == '0' ? '' : data[i].LQuote) + "</td>";
                        str += "<td>" + TotalBidValue + "</td>";
                        strsumm += "<td>" + data[i].SrNo + "</td><td>" + data[i].VendorName + "</td><td>" + (data[i].IQuote == '0' ? '' : data[i].IQuote) + "</td>";
                        strsumm += "<td>" + (data[i].LQuote == '0' ? '' : data[i].LQuote) + "</td><td>" + TotalBidValue + "</td>";
                        if (data[i].SrNo == 'L1') {
                            str += "<td style='background-color: #d9edf7; color: #31708f;'>" + Percentreduction + "</td>";
                            str += "<td style='background-color: #d9edf7; color: #31708f;'>" + Percentreductioninvoice + "</td>";
                            str += "<td style='background-color: #d9edf7; color: #31708f;'>" + Percentreductionceiling + "</td>";
                            strsumm += "<td style='background-color: #d9edf7; color: #31708f;'>" + Percentreduction + "</td>";
                            strsumm += "<td style='background-color: #d9edf7; color: #31708f;'>" + Percentreductioninvoice + "</td>";
                            strsumm += "<td style='background-color: #d9edf7; color:#31708f;'>" + Percentreductionceiling + "</td>";


                        } else {
                            str += "<td>" + Percentreduction + "</td>";
                            str += "<td>" + Percentreductioninvoice + "</td>";
                            str += "<td>" + Percentreductionceiling + "</td>";
                            strsumm += "<td>" + Percentreduction + "</td>";
                            strsumm += "<td>" + Percentreductioninvoice + "</td>";
                            strsumm += "<td>" + Percentreductionceiling + "</td>";
                        }

                        str += "<td>" + (data[i].TAT == '0' ? '' : data[i].TAT) + "</td>";
                        str += "<td>" + (data[i].Validity == '0' ? '' : data[i].Validity) + "</td>";
                        str += "<td>" + (data[i].Warranty == '0' ? '' : data[i].Warranty) + "</td>";
                        str += "<td>" + (data[i].VAT == '0' ? '' : data[i].VAT) + "</td>";
                        str += "<td>" + (data[i].CST == '0' ? '' : data[i].CST) + "</td>";
                        str += "<td>" + (data[i].Excise == '0' ? '' : data[i].Excise) + "</td>";
                        //    //str += "<td>" + (data[i].ShippingLine == null ? '' : data[i].ShippingLine) + "</td><td>" + (data[i].SailingDays == null ? '' : data[i].SailingDays) + "</td><td>" + (data[i].OceanTransitTime == null ? '' : data[i].OceanTransitTime) + "</td>";
                        str += "</tr>";
                        strsumm += "</tr>";
                        jQuery('#tblBidSummary > tbody').append(str);


                        jQuery('#tblbidsummarypercentagewise > tbody').append(strsumm);

                        if (data[i].SrNo == 'L1') {
                            $('#low_ps' + i).css({
                                'background-color': '#3399ff',//'#dff0d8',//#4da6ff,#66b3ff
                                'font-weight': 'bold',
                                'color': '#1a8cff'// '#3c763d'
                            });
                        }
                    }
                }
                else if (parseInt(BidTypeID) == 6) {
                    
                    $('#lnktotvalue').html('Detailed Report')
                    if ($('#lnktotvalue').html() == "Detailed Report") {
                        jQuery("#tblBidSummary").hide()
                        jQuery("#tblbidsummarypercentagewise").show()
                        $('#divfordetailreport').show()
                        $('#divforBidsummary').hide()
                    }
                    $('#lnktotvalue').hide() // IN FA For DEMO

                    var TotalBidValue = ''; // TotalBidValueCeiling = '', TotalBidValueInvoice = '';

                    var Percentreduction = '', Percentreductionceiling = '', Percentreductioninvoice = '';
                    var _offeredPrice;
                    var minimuminc;
                    $('#divTarget').hide();
                    var sname = '';
                    if (PEfaBidForId == 81) {
                        var strHead = "<tr><th>Item/Product</th><th>Target Price</th><th>Last Invoice Price</th><th>Bid Start Price</th><th>Quantity</th><th>UOM</th><th>Minimum Increament</th><th>Level</th><th>Vendor</th><th>Initial Quote</th><th>Highest Quote</th><th>Bid Value</th><th>Percentage Increment (Target Price)</th><th>Percentage Increment (Last Invoice Price)</th><th>Percentage Increment (Bid start price)</th></tr>"; //<th>Contract Duration</th><th>Dispatch Location</th>
                        var strHeadsummary = "<tr><th>Item/Product</th><th>Target Price</th><th>Last Invoice Price</th><th>Bid Start Price</th><th>Quantity</th><th>UOM</th><th>Minimum Increament</th><th>Level</th><th>Vendor</th><th>Initial Quote</th><th>Highest Quote</th><th>Bid Value</th><th>Percentage Increment (Target Price)</th><th>Percentage Increment (Last Invoice Price)</th><th>Percentage Increment (Bid start price)</th></tr>";
                    }
                    else {
                        var strHead = "<tr><th>Item/Product</th><th>Target Price</th><th>Last Invoice Price</th><th>Bid Start Price</th><th>Ceiling/ Max Price</th><th class='Offeredcls bold'>Current Offered Price</th><th>Quantity</th><th>UOM</th><th>Minimum Increament</th><th>Level</th><th>Vendor</th><th>Accepted Price</th><th>Bid Value</th><th>Percentage Decrement (Target Price)</th><th>Percentage Decrement (Last Invoice Price)</th><th>Percentage Decrement (Ceiling/ Max Price)</th></tr>";
                        var strHeadsummary = "<tr><th>Item/Product</th><th>Target Price</th><th>Last Invoice Price</th><th>Bid Start Price</th><th>Ceiling/ Max Price</th><th class='Offeredcls bold'>Current Offered Price</th><th>Quantity</th><th>UOM</th><th>Minimum Increament</th><th>Level</th><th>Vendor</th><th>Accepted Price</th><th>Bid Value</th><th>Percentage Decrement (Target Price)</th><th>Percentage Decrement (Last Invoice Price)</th><th>Percentage Decrement (Ceiling/ Max Price)</th></tr>";
                    }

                    

                    // strHead += "<th>Shipping Line</th><th>Sailing Days</th><th>Ocean Transit Time</th></tr>";

                    jQuery('#tblBidSummary > thead').append(strHead);
                    jQuery('#tblbidsummarypercentagewise > thead').append(strHeadsummary);
                    for (var i = 0; i < data.length; i++) {
                        _offeredPrice = (data[i].OfferedPrice < 0) ? 'NA' : data[i].OfferedPrice;
                        TotalBidValue = parseFloat(data[i].Quantity) * parseFloat(data[i].LQuote);
                        TotalBidValue = TotalBidValue.toFixed(2);

                        if (TotalBidValue != 0) {
                            if (data[i].TargetPrice != 0) {
                                if (PEfaBidForId == 81) {
                                    Percentreduction = parseFloat(parseFloat(data[i].LQuote / data[i].TargetPrice) * 100 - 100).toFixed(2) + ' %'
                                }
                                else {
                                    Percentreduction = parseFloat(100 - parseFloat(data[i].LQuote / data[i].TargetPrice) * 100).toFixed(2) + ' %'
                                }
                            }
                            else {
                                Percentreduction = 'Not Specified';
                            }
                            if (data[i].LastInvoicePrice != 0) {
                                if (PEfaBidForId == 81) {
                                    Percentreductioninvoice = parseFloat(parseFloat(data[i].LQuote / data[i].LastInvoicePrice) * 100 - 100).toFixed(2) + ' %'
                                }
                                else {
                                    Percentreductioninvoice = parseFloat(100 - parseFloat(data[i].LQuote / data[i].LastInvoicePrice) * 100).toFixed(2) + ' %'
                                }
                                
                            }
                            else {
                                Percentreductioninvoice = 'Not Specified';
                            }

                            if (PEfaBidForId == 81) {
                                Percentreductionceiling = parseFloat(parseFloat(data[i].LQuote / data[i].CeilingPrice) * 100 - 100).toFixed(2) + ' %'
                            }
                            else {
                                Percentreductionceiling = parseFloat(100 - parseFloat(data[i].LQuote / data[i].CeilingPrice) * 100).toFixed(2) + ' %'
                            }
                            
                        }
                        else {

                            Percentreduction = 'N/A';
                            Percentreductionceiling = 'N/A';
                            Percentreductioninvoice = 'N/A';
                        }
                        if (data[i].IncreamentOn == "P") {
                            minimuminc = thousands_separators(data[i].MinimumIncreament) + ' %'
                        }
                        else {
                            minimuminc = thousands_separators(data[i].MinimumIncreament) 
                        }
                        if (sname != data[i].ShortName) {
                            sname = data[i].ShortName
                            
                            if (PEfaBidForId == 81) {
                                var str = '<tr id=lowa' + i + ' class=header onclick="fnClickHeader(this,\'i_expandcollapse' + i + '\',\'forAll\')"><td onclick="fnClickHeader(this,\'i_expandcollapse' + i + '\',\'NotTD\')"><a href="javascript:void(0);" onclick="fetchGraphData(' + data[i].PSID + ')"  style="text-decoration:none;">' + data[i].ShortName + '</a></td><td class="text-right">' + thousands_separators(data[i].TargetPrice) + '</td><td class="text-right">' + thousands_separators(data[i].LastInvoicePrice) + '</td><td class="text-right">' + thousands_separators(data[i].CeilingPrice) + '</td><td class="text-right">' + thousands_separators(data[i].Quantity) + '</td><td>' + data[i].UOM + '</td><td class="text-right">' + (minimuminc) + '</td>';
                                var strsumm = '<tr id=low' + i + ' class=header onclick="fnClickHeader(this,\'i_expandcollapse' + i + '\',\'forAll\')"><td onclick="fnClickHeader(this,\'i_expandcollapse' + i + '\',\'NotTD\')"><a href="javascript:void(0);" onclick="fetchGraphData(' + data[i].PSID + ')" style="text-decoration:none;">' + data[i].ShortName + '</a></td><td class="text-right">' + thousands_separators(data[i].TargetPrice) + '</td><td class="text-right">' + thousands_separators(data[i].LastInvoicePrice) + '</td><td class="text-right">' + thousands_separators(data[i].CeilingPrice) + '</td><td class="text-right">' + thousands_separators(data[i].Quantity) + '</td><td>' + data[i].UOM + '</td><td class="text-right">' + (minimuminc) + '</td>';

                            }
                            else {
                                var str = "<tr id=lowa" + i + " class=header onclick='fnClickHeader(this,\'i_expandcollapse' + i + '\',\'forAll\')'><td onclick='fnClickHeader(this,\'i_expandcollapse' + i + '\',\'NotTD'\')'><a href='javascript:void(0);' onclick='fetchGraphData(" + data[i].PSID + ")' style='text-decoration:none;'>" + data[i].ShortName + "</a></td><td class='text-right'>" + thousands_separators(data[i].TargetPrice) + "</td><td class='text-right'>" + thousands_separators(data[i].LastInvoicePrice) + "</td><td class='text-right'>" + thousands_separators(data[i].StartingPrice) + "</td><td class='text-right'>" + thousands_separators(data[i].CeilingPrice) + "</td><td class='text-right bold  font-red Offeredcls'>" + thousands_separators(_offeredPrice) + "</td><td class='text-right'>" + thousands_separators(data[i].Quantity) + "</td><td>" + data[i].UOM + "</td><td class='text-right'>" + (minimuminc) + "</td>";
                                var strsumm = "<tr id=low" + i + " class=header onclick='fnClickHeader(this,\'i_expandcollapse' + i + '\',\'forAll\')'><td onclick='fnClickHeader(this,\'i_expandcollapse' + i + '\',\'NotTD'\')'><a href='javascript:void(0);' onclick='fetchGraphData(" + data[i].PSID + ")' style='text-decoration:none;'>" + data[i].ShortName + "</a></td><td class='text-right'>" + thousands_separators(data[i].TargetPrice) + "</td><td class='text-right'>" + thousands_separators(data[i].LastInvoicePrice) + "</td><td class='text-right'>" + thousands_separators(data[i].StartingPrice) + "</td><td class='text-right'>" + thousands_separators(data[i].CeilingPrice) + "</td><td class='text-right bold  font-red Offeredcls'>" + thousands_separators(_offeredPrice) + "</td><td class='text-right'>" + thousands_separators(data[i].Quantity) + "</td><td>" + data[i].UOM + "</td><td class='text-right'>" + (minimuminc) + "</td>";
                            }
                            //if (PEfaBidForId == 81) {
                            //str +="<td>" + data[i].ContractDuration + "</td><td>" + data[i].DeliveryLocation + "</td>";
                            //}

                        }
                        else {
                            if (PEfaBidForId == 81) {
                                var str = "<tr id=lowa" + i + "><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>"; //<td>&nbsp;</td><td>&nbsp;</td>
                                var strsumm = "<tr id=low" + i + "><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>";
                            }
                            else{
                                var str = "<tr id=lowa" + i + "><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td class=Offeredcls>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>"; //<td>&nbsp;</td><td>&nbsp;</td>
                                var strsumm = "<tr id=low" + i + "><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td class=Offeredcls>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>";
                            }
                            //if (PEfaBidForId == 81) {
                            //    str += "<td>&nbsp;</td><td>&nbsp;</td>";
                            //}
                        }

                        if (PEfaBidForId == 81) {
                            str += "<td>" + data[i].SrNo + "</td><td>" + data[i].VendorName + "</td><td class=text-right>" + thousands_separators((data[i].IQuote == '0' ? '' : data[i].IQuote)) + "</td>";
                            str += "<td class=text-right>" + thousands_separators((data[i].LQuote == '0' ? '' : data[i].LQuote)) + "</td>";
                            str += "<td class=text-right>" + thousands_separators(TotalBidValue )+ "</td>";
                            strsumm += "<td>" + data[i].SrNo + "</td><td>" + data[i].VendorName + "</td><td class=text-right>" + thousands_separators((data[i].IQuote == '0' ? '' : data[i].IQuote)) + "</td>";
                            strsumm += "<td class=text-right>" + thousands_separators((data[i].LQuote == '0' ? '' : data[i].LQuote)) + "</td><td class=text-right>" + thousands_separators(TotalBidValue) + "</td>";
                        }
                        else {
                           // alert(data[i].SrNo)
                            str += "<td>" + data[i].SrNo + "</td><td>" + data[i].VendorName + "</td>";
                            str += "<td class=text-right>" + thousands_separators((data[i].LQuote == '0' ? '' : data[i].LQuote)) + "</td>";
                            str += "<td class=text-right>" + thousands_separators(TotalBidValue) + "</td>";
                            strsumm += "<td>" + data[i].SrNo + "</td><td>" + data[i].VendorName + "</td>";
                            strsumm += "<td class=text-right>" + thousands_separators((data[i].LQuote == '0' ? '' : data[i].LQuote)) + "</td><td class=text-right>" + thousands_separators(TotalBidValue) + "</td>";

                        }
                        if (data[i].SrNo == 'H1') {
                            str += "<td class=text-right style='background-color: #d9edf7; color: #31708f;'>" + Percentreduction + "</td>";
                            str += "<td class=text-right style='background-color: #d9edf7; color: #31708f;'>" + Percentreductioninvoice + "</td>";
                            str += "<td class=text-right style='background-color: #d9edf7; color: #31708f;'>" + Percentreductionceiling + "</td>";
                            strsumm += "<td class=text-right style='background-color: #d9edf7; color: #31708f;'>" + Percentreduction + "</td>";
                            strsumm += "<td class=text-right style='background-color: #d9edf7; color: #31708f;'>" + Percentreductioninvoice + "</td>";
                            strsumm += "<td class=text-right style='background-color: #d9edf7; color:#31708f;'>" + Percentreductionceiling + "</td>";


                        }
                        else if (data[i].SrNo == 'L1') {
                            str += "<td class=text-right style='background-color: #d9edf7; color: #31708f;'>" + Percentreduction + "</td>";
                            str += "<td class=text-right style='background-color: #d9edf7; color: #31708f;'>" + Percentreductioninvoice + "</td>";
                            str += "<td class=text-right style='background-color: #d9edf7; color: #31708f;'>" + Percentreductionceiling + "</td>";
                            strsumm += "<td class=text-right style='background-color: #d9edf7; color: #31708f;'>" + Percentreduction + "</td>";
                            strsumm += "<td class=text-right style='background-color: #d9edf7; color: #31708f;'>" + Percentreductioninvoice + "</td>";
                            strsumm += "<td class=text-right style='background-color: #d9edf7; color:#31708f;'>" + Percentreductionceiling + "</td>";
                        }
                        else {
                            str += "<td class=text-right>" + Percentreduction + "</td>";
                            str += "<td class=text-right>" + Percentreductioninvoice + "</td>";
                            str += "<td class=text-right>" + Percentreductionceiling + "</td>";
                            strsumm += "<td class=text-right>" + Percentreduction + "</td>";
                            strsumm += "<td class=text-right>" + Percentreductioninvoice + "</td>";
                            strsumm += "<td class=text-right>" + Percentreductionceiling + "</td>";
                        }


                        //    //str += "<td>" + (data[i].ShippingLine == null ? '' : data[i].ShippingLine) + "</td><td>" + (data[i].SailingDays == null ? '' : data[i].SailingDays) + "</td><td>" + (data[i].OceanTransitTime == null ? '' : data[i].OceanTransitTime) + "</td>";
                        str += "</tr>";
                        strsumm += "</tr>";
                        jQuery('#tblBidSummary > tbody').append(str);
                        jQuery('#tblbidsummarypercentagewise > tbody').append(strsumm);
                        if (data[i].SrNo == 'H1') {
                            $('#low' + i).css({
                                'background-color': '#dff0d8',
                                'font-weight': 'bold',
                                'color': '#3c763d'
                            })

                        }
                        if (data[i].SrNo == 'L1') {
                            $('#low' + i).css({
                                'background-color': '#dff0d8',
                                'font-weight': 'bold',
                                'color': '#3c763d'
                            })

                        }
                       // alert(page)
                        if (PEfaBidForId == 82) {
                            if (page == "BidSummary.html" || page == "ApprovalForwardAuction.html") {
                                $('.Offeredcls').addClass('hide');
                            }
                            else {
                                $('.Offeredcls').removeClass('hide');
                            }
                        }
                    }
                }
                else if (parseInt(BidTypeID) == 7) {
                    $('#lnktotvalue').html('Detailed Report')
                    if ($('#lnktotvalue').html() == "Detailed Report") {
                        jQuery("#tblBidSummary").hide()
                        jQuery("#tblbidsummarypercentagewise").show()
                        $('#divfordetailreport').show()
                        $('#divforBidsummary').hide()
                    }
                    $('#lnktotvalue').hide();

                    var TotalBidValue = ''; // TotalBidValueCeiling = '', TotalBidValueInvoice = '';

                    var Percentreduction = '', Percentreductionceiling = '', Percentreductioninvoice = '';
                    $('#divTarget').hide();
                    var sname = '';
                    var minimumdec='';
                   
                    var strHead = "<tr><th>Item/Product/Service</th><th>Target Price</th><th>Last Invoice Price</th><th>Bid start price</th><th>Quantity</th><th>UOM</th><th>Minimum Dec.</th><th>Level</th><th>Vendor</th><th>Loading Factor - &lambda; (in %)</th><th>Initial Quote</th><th>Lowest Quote</th><th>Bid Value</th><th>Percentage Reduction (Target Price)</th><th>Percentage Reduction (Last Invoice Price)</th><th>Percentage Reduction (Bid start price)</th></tr>";
                   // jQuery('#tblBidSummary').append("<thead><tr><th>Item/Product/Service</th><th>Target Price</th><th>Last Invoice Price</th><th>Bid start price</th><th>Quantity</th><th>UOM</th><th>Level</th><th>Vendor</th><th>Loading Factor - &lambda; (in %)</th><th>Initial Quote</th><th>Lowest Quote</th><th>Bid Value</th><th>Percentage Reduction (Target Price)</th><th>Percentage Reduction (Last Invoice Price)</th><th>Percentage Reduction (Bid start price)</th></tr></thead>");

                    var strHeadsummary = ""; //"<tr><th>Item/Product/Service</th><th>Target Price</th><th>Last Invoice Price</th><th>Bid start price</th><th>Quantity</th><th>UOM</th><th style=display:none; id=theadbidclosingType></th><th>Level</th><th>Vendor</th><th>Loading Factor - &lambda; (in %)</th><th>Initial Quote</th><th>Lowest Quote</th><th>Bid Value</th><th>Percentage Reduction (Target Price)</th><th>Percentage Reduction (Last Invoice Price)</th><th>Percentage Reduction (Bid start price)</th></tr>";
                    if (_bidClosingType != 'undefined' && _bidClosingType == 'S') {
                        //$("#theadbidclosingType").text('Item Closing Time');
                        strHeadsummary = "<tr><th>Item/Product/Service</th><th>Target Price</th><th>Last Invoice Price</th><th>Bid start price</th><th>Quantity</th><th>UOM</th><th>Minimum Dec.</th><th>Item Closing Time</th><th>Level</th><th>Vendor</th><th>Loading Factor - &lambda; (in %)</th><th>Initial Quote</th><th>Lowest Quote</th><th>Bid Value</th><th>Percentage Reduction (Target Price)</th><th>Percentage Reduction (Last Invoice Price)</th><th>Percentage Reduction (Bid start price)</th></tr>";
                    }
                    else
                    {
                        strHeadsummary = "<tr><th>Item/Product/Service</th><th>Target Price</th><th>Last Invoice Price</th><th>Bid start price</th><th>Quantity</th><th>UOM</th><th>Minimum Dec.</th><th>Level</th><th>Vendor</th><th>Loading Factor - &lambda; (in %)</th><th>Initial Quote</th><th>Lowest Quote</th><th>Bid Value</th><th>Percentage Reduction (Target Price)</th><th>Percentage Reduction (Last Invoice Price)</th><th>Percentage Reduction (Bid start price)</th></tr>";
                    }
                    //                    strHead += "<th>Shipping Line</th><th>Sailing Days</th><th>Ocean Transit Time</th></tr>";
                    
                    jQuery('#tblBidSummary > thead').append(strHead);
                    jQuery('#tblbidsummarypercentagewise > thead').append(strHeadsummary);

                    for (var i = 0; i < data.length; i++) {

                        //console.log("data[i] ==> ", data[i])
                        TotalBidValue = parseFloat(data[i].Quantity) * parseFloat(data[i].LQuote);
                        TotalBidValue = TotalBidValue.toFixed(2);
                        if (TotalBidValue != 0) {
                            if (data[i].TargetPrice != 0) {
                                Percentreduction = parseFloat(100 - parseFloat(data[i].LQuote / data[i].TargetPrice) * 100).toFixed(2) + ' %'
                            }
                            else {
                                Percentreduction = 'Not Specified';
                            }
                            if (data[i].LastInvoicePrice != 0) {
                                Percentreductioninvoice = parseFloat(100 - parseFloat(data[i].LQuote / data[i].LastInvoicePrice) * 100).toFixed(2) + ' %'
                            }
                            else {
                                Percentreductioninvoice = 'Not Specified';
                            }


                            Percentreductionceiling = parseFloat(100 - parseFloat(data[i].LQuote / data[i].CeilingPrice) * 100).toFixed(2) + ' %'
                        } else {

                            Percentreduction = 'N/A';
                            Percentreductionceiling = 'N/A';
                            Percentreductioninvoice = 'N/A';
                        }
                        if (data[i].DecreamentOn == "P") {
                            minimumdec = data[i].MinimumDecreament + ' %' 
                        }
                        else{
                            minimumdec = data[i].MinimumDecreament + ' ' + data[i].SelectedCurrency
                        }
                        var desitinationport = data[i].DestinationPort.replace(/<br\s*\/?>/gi, ' ');

                        //if (sname != data[i].DestinationPort) {
                        //    sname = data[i].DestinationPort
                        if (sname != desitinationport) {
                            sname = desitinationport
                            var str = '<tr id=low' + i + ' class=header onclick="fnClickHeader(this,\'i_expandcollapse' + i + '\')"><td><a href="javascript:;" onclick="fetchGraphData(' + data[i].SeId + ')" style="text-decoration:none;" >' + desitinationport + '</a></td><td class="text-right">' + thousands_separators(data[i].TargetPrice) + '</td><td  class="text-right">' + thousands_separators(data[i].LastInvoicePrice) + '</td><td  class="text-right">' + thousands_separators(data[i].CeilingPrice) + '</td><td class="text-right">' + thousands_separators(data[i].Quantity) + '</td><td class=text-right>' + data[i].UOM + '</td><td class=text-right>' + minimumdec + '</td>';
                            //var strsumm = "" //"<tr id=low_str" + i + "><td><a href='javascript:void(0);' onclick='fetchGraphData(" + data[i].SeId + ")' style='text-decoration:none;'>" + data[i].DestinationPort + "</a></td><td class='text-right'>" + thousands_separators(data[i].TargetPrice) + "</td><td class='text-right'>" + thousands_separators(data[i].LastInvoicePrice) + "</td><td class='text-right'>" + thousands_separators(data[i].CeilingPrice) + "</td><td class='text-right'>" + thousands_separators(data[i].Quantity) + "</td><td class='text-right'>" + data[i].UOM + "</td>";

                            // if (_bidClosingType != 'undefined' && _bidClosingType == 'S' && _bidClosingType != '81' && _bidClosingType == '82') {
                            if (_bidClosingType != 'undefined' && _bidClosingType == 'S') {
                                //$("#theadbidclosingType").text('Item Closing Time');
                               if (data[i].ItemStatus == "Open") {
                                   var strsumm = '<tr id=low_str' + i + ' style="background-color: #66b3ff; color: #000000;" onclick="fnClickHeader(this,\'i_expandcollapse' + i + '\')" class="header"><td class=hide><a class="btn btn-circle btn-success fa fa-arrow-down" id=i_expandcollapse' + i + ' data-toggle="popover" data-trigger="hover" data-content="Collapse/Expand"   data-placement="left"></a></td><td><a href="javascript:;" onclick="fetchGraphData(' + data[i].SeId + ')" style="text-decoration:none;">' + desitinationport + '</a></td><td class="text-right ">' + thousands_separators(data[i].TargetPrice) + '</td><td class="text-right">' + thousands_separators(data[i].LastInvoicePrice) + '</td><td class="text-right">' + thousands_separators(data[i].CeilingPrice) + '</td><td class="text-right">' + thousands_separators(data[i].Quantity) + '</td><td class="text-right">' + data[i].UOM + '</td><td class="text-right">' + minimumdec + '</td><td>' + data[i].closingTime + '</td>';
                                }
                                else {
                                   var strsumm = '<tr id=low_str' + i + ' class=header onclick="fnClickHeader(this,\'i_expandcollapse' + i + '\')"><td class=hide><a class="btn btn-circle btn-success fa fa-arrow-down" id=i_expandcollapse' + i + '  data-trigger="hover"  data-content="Expand/Collapse"></a></td><td><a  href="javascript:;" onclick="fetchGraphData(' + data[i].SeId + ')" style="text-decoration:none;" >' + desitinationport + '</a></td><td class="text-right">' + thousands_separators(data[i].TargetPrice) + '</td><td class="text-right">' + thousands_separators(data[i].LastInvoicePrice) + '</td><td class="text-right">' + thousands_separators(data[i].CeilingPrice) + '</td><td class="text-right">' + thousands_separators(data[i].Quantity) + '</td><td class="text-right">' + data[i].UOM + '</td><td class="text-right">' + minimumdec + '</td><td>' + data[i].closingTime + '</td>';
                                }
                               
                            }
                            else
                            {
                                var strsumm = '<tr id=low_str' + i + '  class="header" onclick="fnClickHeader(this,\'i_expandcollapse' + i + '\')"><td><a href="javascript:;"  onclick="fetchGraphData(' + data[i].SeId + ')" style="text-decoration:none;">' + desitinationport + '</a></td><td class="text-right">' + thousands_separators(data[i].TargetPrice) + '</td><td class="text-right">' + thousands_separators(data[i].LastInvoicePrice) + '</td><td class=text-right>' + thousands_separators(data[i].CeilingPrice) + '</td><td class=text-right>' + thousands_separators(data[i].Quantity) + '</td><td class="text-right">' + data[i].UOM + '</td><td class="text-right">' + minimumdec + '</td>';// btn - icon - only
                            }
                        }
                        else {
                            var str = "<tr id=low" + i + "><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>";
                            
                            if (_bidClosingType != 'undefined' && _bidClosingType == 'S') {
                                var strsumm = "<tr id=low_str" + i + "><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>";
                            }
                            else {
                                var strsumm = "<tr id=low_str" + i + "><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>";
                            }
                        }


                        str += "<td>" + data[i].SrNo + "</td><td>" + data[i].VendorName + "</td><td class='text-right'>" + data[i].AdvFactor + "</td><td class='text-right'>" + (data[i].IQuote != '-93' ? data[i].IQuote : thousands_separators(data[i].IPrice)) + "</td>";
                        str += "<td class='text-right'>" + (data[i].LQuote == '0' ? '' : thousands_separators(data[i].LQuote)) + "</td>";
                        str += "<td class='text-right'>" + thousands_separators(TotalBidValue) + "</td>";
                        strsumm += "<td>" + data[i].SrNo + "</td><td>" + data[i].VendorName + "</td><td class='text-right'>" + data[i].AdvFactor + "</td><td class='text-right'>" + (data[i].IQuote != '-93' ? data[i].IQuote : thousands_separators(data[i].IPrice)) + "</td>";
                        strsumm += "<td class='text-right'>" + (data[i].LQuote == '0' ? '' : thousands_separators(data[i].LQuote)) + "</td><td>" + thousands_separators(TotalBidValue) + "</td>";
                        if (data[i].SrNo == 'L1') {
                            str += "<td style='background-color: #d9edf7; color: #31708f;'>" + Percentreduction + "</td>";
                            str += "<td style='background-color: #d9edf7; color: #31708f;'>" + Percentreductioninvoice + "</td>";
                            str += "<td style='background-color: #d9edf7; color: #31708f;'>" + Percentreductionceiling + "</td>";
                            strsumm += "<td style='background-color: #d9edf7; color: #31708f;'>" + Percentreduction + "</td>";
                            strsumm += "<td style='background-color: #d9edf7; color: #31708f;'>" + Percentreductioninvoice + "</td>";
                            strsumm += "<td style='background-color: #d9edf7; color:#31708f;'>" + Percentreductionceiling + "</td>";


                        } else {
                            str += "<td>" + Percentreduction + "</td>";
                            str += "<td>" + Percentreductioninvoice + "</td>";
                            str += "<td>" + Percentreductionceiling + "</td>";
                            strsumm += "<td>" + Percentreduction + "</td>";
                            strsumm += "<td>" + Percentreductioninvoice + "</td>";
                            strsumm += "<td>" + Percentreductionceiling + "</td>";
                        }
                        str += "</tr>";
                        strsumm += "</tr>";
                        
                        jQuery('#tblBidSummary').append(str);
                        jQuery('#tblbidsummarypercentagewise').append(strsumm);
                        //alert(strsumm)
                        //$('#low_str' + i).popover("show")
                        if (data[i].SrNo == 'L1') {
                            $('#low_str' + i).css({
                                'background-color': '#dff0d8',
                                'font-weight': 'bold',
                                'color': '#3c763d'
                            })

                        }
                       // var firstColumn = $('#low' + i).getElementsByTagName('TD')[0];
                       // firstColumn.remove();
                    }
                   
                }
                else if (parseInt(BidTypeID) == 2) {
                    if (parseInt(BidForID) == 2) {
                        var strHead = "<tr><th rowspan='2'>Level</th><th rowspan='2'>Vendor Name</th><th rowspan='2'>Carrier</th><th rowspan='2'>Loading Airport</th><th rowspan='2'>Consolidation Days</th>";
                        strHead += "<th colspan='6'>Freight</th><th colspan='6'>Ex-Works</th><th rowspan='2'>FSC</th><th rowspan='2'>SSC</th><th rowspan='2'>DO Charges</th><th colspan='6'>Total (Including surcharges)</th><th rowspan='2'>Total For Model Class</th>";
                        strHead += "</tr>";
                        strHead += "<tr><th>Min</th><th>45+</th><th>100+</th><th>300+</th><th>500+</th><th>1000+</th><th>Min</th><th>45+</th><th>100+</th><th>300+</th><th>500+</th><th>1000+</th><th>Min</th><th>45+</th><th>100+</th><th>300+</th><th>500+</th><th>1000+</th>";
                        strHead += "</tr>";
                        jQuery('#tblBidSummary > thead').append(strHead);
                        for (var i = 0; i < data.length; i++) {
                            var str = "<tr id=low2" + i + "><td>" + data[i].SrNo + "</td><td>" + data[i].VendorName + "</td><td>" + data[i].Carrier + "</td><td>" + data[i].LoadingAirport + "</td>";
                            str += "<td>" + data[i].ConsolidationDays + "</td><td>" + (data[i].FreightMin == null ? '' : data[i].FreightMin) + "</td>";
                            str += "<td>" + (data[i].FreightPlus45 == null ? '' : data[i].FreightPlus45) + "</td><td>" + (data[i].FreightPlus100 == null ? '' : data[i].FreightPlus100) + "</td><td>" + (data[i].FreightPlus300 == null ? '' : data[i].FreightPlus300) + "</td>";
                            str += "<td>" + (data[i].FreightPlus500 == null ? '' : data[i].FreightPlus500) + "</td><td>" + (data[i].FreightPlus1000 == null ? '' : data[i].FreightPlus1000) + "</td><td>" + (data[i].ExWorksMin == null ? '' : data[i].ExWorksMin) + "</td>";
                            str += "<td>" + (data[i].ExWorksPlus45 == null ? '' : data[i].ExWorksPlus45) + "</td><td>" + (data[i].ExWorksPlus100 == null ? '' : data[i].ExWorksPlus100) + "</td><td>" + (data[i].ExWorksPlus300 == null ? '' : data[i].ExWorksPlus300) + "</td>";
                            str += "<td>" + (data[i].ExWorksPlus500 == null ? '' : data[i].ExWorksPlus500) + "</td><td>" + (data[i].ExWorksPlus1000 == null ? '' : data[i].ExWorksPlus1000) + "</td><td>" + (data[i].FSC == '0' ? '' : data[i].FSC) + "</td><td>" + (data[i].SSC == '0' ? '' : data[i].SSC) + "</td><td>" + (data[i].DoCharges == null ? '' : data[i].DoCharges) + "</td>";
                            str += "<td>" + (data[i].TotMin == null ? '' : data[i].TotMin) + "</td><td>" + (data[i].Tot45 == null ? '' : data[i].Tot45) + "</td><td>" + (data[i].Tot100 == null ? '' : data[i].Tot100) + "</td><td>" + (data[i].Tot300 == null ? '' : data[i].Tot300) + "</td>";
                            str += "<td>" + data[i].Tot500 + "</td><td>" + data[i].Tot1000 + "</td><td>" + data[i].MinPrice + "</td>";
                            str += "</tr>";
                            jQuery('#tblBidSummary > tbody').append(str);
                            if (data[i].SrNo == 'L1') {
                                $('#low2' + i).css({
                                    'background-color': '#dff0d8',
                                    'font-weight': 'bold',
                                    'color': '#3c763d'
                                });

                            }
                        }
                    }
                    if (parseInt(BidForID) == 3) {
                        var strHead = "<tr><th rowspan='2'>Level</th><th rowspan='2'>Vendor Name</th><th rowspan='2'>Carrier</th><th rowspan='2'>Loading Airport</th><th rowspan='2'>Consolidation Days</th>";
                        strHead += "<th colspan='6'>Freight</th><th colspan='6'>Ex-Works</th><th rowspan='2'>FSC</th><th rowspan='2'>SSC</th><th rowspan='2'>DO Charges</th><th colspan='6'>Total (Including surcharges)</th><th rowspan='2'>Total For Model Class</th>";
                        strHead += "</tr>";
                        strHead += "<tr><th>Min</th><th>45+</th><th>100+</th><th>300+</th><th>500+</th><th>1000+</th><th>Min</th><th>45+</th><th>100+</th><th>300+</th><th>500+</th><th>1000+</th><th>Min</th><th>45+</th><th>100+</th><th>300+</th><th>500+</th><th>1000+</th>";
                        strHead += "</tr>";
                        jQuery('#tblBidSummary > thead').append(strHead);
                        for (var i = 0; i < data.length; i++) {
                            var str = "<tr id=low3" + i + "><td>" + data[i].SrNo + "</td><td>" + data[i].VendorName + "</td><td>" + data[i].Carrier + "</td><td>" + (data[i].LoadingAirport == null ? '' : data[i].LoadingAirport) + "</td>";
                            str += "<td>" + (data[i].ConsolidationDays == null ? '' : data[i].ConsolidationDays) + "</td><td>" + (data[i].FreightMin == null ? '' : data[i].FreightMin) + "</td>";
                            str += "<td>" + (data[i].FreightPlus45 == null ? '' : data[i].FreightPlus45) + "</td><td>" + (data[i].FreightPlus100 == null ? '' : data[i].FreightPlus100) + "</td><td>" + (data[i].FreightPlus300 == null ? '' : data[i].FreightPlus300) + "</td>";
                            str += "<td>" + (data[i].FreightPlus500 == null ? '' : data[i].FreightPlus500) + "</td><td>" + (data[i].FreightPlus1000 == null ? '' : data[i].FreightPlus1000) + "</td><td>" + (data[i].ExWorksMin == null ? '' : data[i].ExWorksMin) + "</td>";
                            str += "<td>" + (data[i].ExWorksPlus45 == null ? '' : data[i].ExWorksPlus45) + "</td><td>" + (data[i].ExWorksPlus100 == null ? '' : data[i].ExWorksPlus100) + "</td><td>" + (data[i].ExWorksPlus300 == null ? '' : data[i].ExWorksPlus300) + "</td>";
                            str += "<td>" + (data[i].ExWorksPlus500 == null ? '' : data[i].ExWorksPlus500) + "</td><td>" + (data[i].ExWorksPlus1000 == null ? '' : data[i].ExWorksPlus1000) + "</td><td>" + (data[i].FSC == '0' ? '' : data[i].FSC) + "</td><td>" + (data[i].SSC == '0' ? '' : data[i].SSC) + "</td><td>" + (data[i].DoCharges == null ? '' : data[i].DoCharges) + "</td>";
                            str += "<td>" + (data[i].TotMin == null ? '' : data[i].TotMin) + "</td><td>" + (data[i].Tot45 == null ? '' : data[i].Tot45) + "</td><td>" + (data[i].Tot100 == null ? '' : data[i].Tot100) + "</td><td>" + (data[i].Tot300 == null ? '' : data[i].Tot300) + "</td>";
                            str += "<td>" + (data[i].Tot500 == null ? '' : data[i].Tot500) + "</td><td>" + (data[i].Tot1000 == null ? '' : data[i].Tot1000) + "</td><td>" + (data[i].MinPrice == null ? '' : data[i].MinPrice) + "</td>";
                            str += "</tr>";
                            jQuery('#tblBidSummary > tbody').append(str);
                            if (data[i].SrNo == 'L1') {
                                $('#low3' + i).css({
                                    'background-color': '#dff0d8',
                                    'font-weight': 'bold',
                                    'color': '#3c763d'
                                });

                            }
                        }
                    }
                }
                else if (parseInt(BidTypeID) == 3) {

                    if (parseInt(BidForID) == 4) {
                        //Freight
                        var strHead = "<tr><th>Level</th><th>Vendor</th><th>Initial Quote</th><th>Lowest Quote</th>";
                        strHead += "<th>BAF</th><th>CAF</th><th>Total Value</th><th>Forwarder's Do Charges</th>";
                        strHead += "<th>Shipping Line</th><th>Sailing Days</th><th>Ocean Transit Time</th></tr>";
                        jQuery('#tblBidSummary > thead').append(strHead);
                        for (var i = 0; i < data.length; i++) {
                            var str = "<tr id=low4" + i + "><td>" + data[i].SrNo + "</td><td>" + data[i].VendorName + "</td>";
                            str += "<td>" + data[i].IQuote + "</td>";
                            str += "<td>" + (data[i].LQuote == null ? '' : data[i].LQuote) + "</td>";
                            //str += "<td>" + ((data[i].ExWorks == null || data[i].ExWorks == 0) ? '' : data[i].ExWorks) + "</td>";
                            str += "<td>" + ((data[i].BAF == null || data[i].BAF == 0) ? '' : data[i].BAF) + "</td>";
                            str += "<td>" + ((data[i].CAF == null || data[i].CAF == 0) ? '' : data[i].CAF) + "</td>";
                            str += "<td>" + (data[i].TotalValue == null ? '' : data[i].TotalValue) + "</td><td>" + (data[i].ForwardersDO == '0' ? '' : data[i].ForwardersDO) + "</td>";
                            str += "<td>" + (data[i].ShippingLine == null ? '' : data[i].ShippingLine) + "</td><td>" + (data[i].SailingDays == null ? '' : data[i].SailingDays) + "</td><td>" + (data[i].OceanTransitTime == null ? '' : data[i].OceanTransitTime) + "</td>";
                            str += "</tr>";
                            jQuery('#tblBidSummary > tbody').append(str);
                            if (data[i].SrNo == 'L1') {
                                $('#low4' + i).css({
                                    'background-color': '#dff0d8',
                                    'font-weight': 'bold',
                                    'color': '#3c763d'
                                });

                            }
                        }
                    }
                    else if (parseInt(BidForID) == 5) {
                        // Total Value
                        var strHead = "<tr><th>Level</th><th>Vendor</th><th>Initial Quote (INR)</th><th>Lowest Quote (INR)</th><th>Freight</th>";
                        strHead += "<th>BAF</th><th>CAF</th><th>Inland Haulage (INR)</th><th>Shipping Line DO Charges (INR)</th><th>Container Cleaning Charges (INR)</th>";
                        strHead += "<th>Shipping Line Any Other Charges (INR)</th><th>Forwarder's DO Charges (INR)</th><th>Shipping Line</th><th>Sailing Days</th><th>Ocean Transit Time</th></tr>";
                        jQuery('#tblBidSummary > thead').append(strHead);
                        for (var i = 0; i < data.length; i++) {
                            var str = "<tr id=low5" + i + "><td>" + data[i].SrNo + "</td><td>" + data[i].VendorName + "</td><td>" + data[i].IQuote + "</td>";
                            str += "<td>" + (data[i].LQuote == '0' ? '' : data[i].LQuote) + "</td><td>" + (data[i].Freight == '0' ? '' : data[i].Freight) + "</td><td>" + (data[i].BAF == '0' ? '' : data[i].BAF) + "</td><td>" + (data[i].CAF == '0' ? '' : data[i].CAF) + "</td>";
                            str += "<td>" + (data[i].InlandHaulage == '0' ? '' : data[i].InlandHaulage) + "</td><td>" + (data[i].ShippingLineDO == '0' ? '' : data[i].ShippingLineDO) + "</td><td>" + (data[i].ContainerClgChg == '0' ? '' : data[i].ContainerClgChg) + "</td>";
                            str += "<td>" + (data[i].ShippingLineOther == '0' ? '' : data[i].ShippingLineOther) + "</td><td>" + (data[i].ForwardersDO == '0' ? '' : data[i].ForwardersDO) + "</td>";
                            str += "<td>" + data[i].ShippingLine + "</td><td>" + data[i].SailingDays + "</td><td>" + data[i].OceanTransitTime + "</td>";
                            str += "</tr>";
                            jQuery('#tblBidSummary > tbody').append(str);
                            if (data[i].SrNo == 'L1') {
                                $('#low5' + i).css({
                                    'background-color': '#dff0d8',
                                    'font-weight': 'bold',
                                    'color': '#3c763d'
                                });

                            }
                        }
                    }
                    else if (parseInt(BidForID) == 6) {
                        // Freight & Exworks
                        var strHead = "<tr><th>Level</th><th>Vendor</th><th>Initial Quote (INR)</th><th>Lowest Quote (INR)</th><th>Freight</th><th>ExWorks</th>";
                        strHead += "<th>BAF</th><th>CAF</th><th>Inland Haulage (INR)</th><th>Shipping Line's DO Charges (INR)</th><th>Container Cleaning Charges (INR)</th><th>Shipping Line's Any Other Charges (INR)</th><th>Forwarder's Do Charges</th>";
                        strHead += "<th>Shipping Line</th><th>Sailing Days</th><th>Ocean Transit Time</th></tr>";
                        jQuery('#tblBidSummary > thead').append(strHead);
                        for (var i = 0; i < data.length; i++) {
                            var str = "<tr id=low6" + i + "><td>" + data[i].SrNo + "</td><td>" + data[i].VendorName + "</td><td>" + data[i].IQuote + "</td>";
                            str += "<td>" + (data[i].LQuote == '0' ? '' : data[i].LQuote) + "</td><td>" + (data[i].Freight == '0' ? '' : data[i].Freight) + "</td><td>" + (data[i].ExWorks == '0' ? '' : data[i].ExWorks) + "</td><td>" + (data[i].BAF == '0' ? '' : data[i].BAF) + "</td><td>" + (data[i].CAF == '0' ? '' : data[i].CAF) + "</td>";
                            str += "<td>" + (data[i].InlandHaulage == '0' ? '' : data[i].InlandHaulage) + "</td><td>" + (data[i].ShippingLineDO == '0' ? '' : data[i].ShippingLineDO) + "</td><td>" + (data[i].ContainerClgChg == '0' ? '' : data[i].ContainerClgChg) + "</td><td>" + (data[i].ShippingLineOther == '0' ? '' : data[i].ShippingLineOther) + "</td><td>" + (data[i].ForwardersDO == '0' ? '' : data[i].ForwardersDO) + "</td>";
                            str += "<td>" + data[i].ShippingLine + "</td><td>" + data[i].SailingDays + "</td><td>" + data[i].OceanTransitTime + "</td>";
                            str += "</tr>";
                            jQuery('#tblBidSummary > tbody').append(str);
                            if (data[i].SrNo == 'L1') {
                                $('#low6' + i).css({
                                    'background-color': '#dff0d8',
                                    'font-weight': 'bold',
                                    'color': '#3c763d'
                                });

                            }
                        }
                    }
                }

                else if (parseInt(BidTypeID) == 5) { // Warehouse
                    var strHead = "<tr><th>Level</th><th>Vendor</th><th>Initial Quote</th><th>Lowest Quote</th><th>Warehouse Area</th><th>Rent Per Sq. Ft.</th>";
                    strHead += "<th>Manpower Cost</th><th>Infrastructure Cost</th><th>Utilities Cost</th><th>Fixed Management Fee</th></tr>";
                    //                    strHead += "<th>Shipping Line</th><th>Sailing Days</th><th>Ocean Transit Time</th></tr>";
                    jQuery('#tblBidSummary > thead').append(strHead);
                    for (var i = 0; i < data.length; i++) {
                        var str = "<tr id=low7" + i + "><td>" + data[i].SrNo + "</a></td><td>" + data[i].VendorName + "</td>";
                        str += "<td>" + data[i].IQuote + "</td>";
                        str += "<td>" + (data[i].LQuote == '0' ? '' : data[i].LQuote) + "</td><td>" + (data[i].WarehouseArea == '0' ? '' : data[i].WarehouseArea) + "</td>";
                        str += "<td>" + (data[i].PerSquareFeetRate == '0' ? '' : data[i].PerSquareFeetRate) + "</td>";
                        str += "<td>" + (data[i].ManPowerCost == '0' ? '' : data[i].ManPowerCost) + "</td>";
                        str += "<td>" + (data[i].InfrastructureCost == '0' ? '' : data[i].InfrastructureCost) + "</td>";
                        str += "<td>" + (data[i].UtilitiesCost == '0' ? '' : data[i].UtilitiesCost) + "</td><td>" + (data[i].FixedManagementFee == '0' ? '' : data[i].FixedManagementFee) + "</td>";
                        //str += "<td>" + (data[i].ShippingLine == null ? '' : data[i].ShippingLine) + "</td><td>" + (data[i].SailingDays == null ? '' : data[i].SailingDays) + "</td><td>" + (data[i].OceanTransitTime == null ? '' : data[i].OceanTransitTime) + "</td>";
                        str += "</tr>";
                        jQuery('#tblBidSummary > tbody').append(str);
                        if (data[i].SrNo == 'L1') {
                            $('#low7' + i).css({
                                'background-color': '#dff0d8',
                                'font-weight': 'bold',
                                'color': '#3c763d'
                            });

                        }
                    }

                }
                else if (parseInt(BidTypeID) == 4) { // Domestic
                    var Dname = '';
                    var str = '';
                    var strHead = "<tr><th>Vendor</th><th>Vehicle Type</th><th>Origin Name</th><th>Destination Name</th><th>Level</th><th>Initial Quote</th><th>Lowest Quote</th><th>TAT</th><th>DocketCharge</th><th>FOV</th><th>FSC</th><th>CFT</th><th>MinChargeWt</th><th>ODA </th></tr>";

                    jQuery('#tblBidSummary > thead').append(strHead);
                    for (var i = 0; i < data.length; i++) {
                        if (Dname != data[i].VendorName) {
                            Dname = data[i].VendorName
                            str = "<tr id=lowD" + i + "><td>" + data[i].VendorName + "</td><td>" + data[i].VehicleTypeName + "</td>";
                        }
                        else {
                            str = "<tr id=lowD" + i + "><td>&nbsp;</td><td>&nbsp;</td>";
                        }

                        str += "<td>" + data[i].OriginName + "</td>";
                        str += "<td>" + data[i].DestinationName + "</td>";
                        str += "<td>" + data[i].SrNo + "</td>";
                        str += "<td>" + data[i].IQuote + "</td>"
                        str += "<td>" + data[i].LQuote + "</td>";
                        str += "<td>" + data[i].TAT + "</td>";
                        str += "<td>" + data[i].DocketCharge + "</td>";
                        str += "<td>" + data[i].FOV + "</td>";
                        str += "<td>" + data[i].FSC + "</td>";
                        str += "<td>" + data[i].CFT + "</td>";
                        str += "<td>" + data[i].MinChargeWt + "</td>";
                        str += "<td>" + data[i].ODA + "</td>";
                        str += "</tr>";
                        jQuery('#tblBidSummary > tbody').append(str);
                        if (data[i].SrNo == 'L1') {
                            $('#lowD' + i).css({
                                'background-color': '#dff0d8',
                                'font-weight': 'bold',
                                'color': '#3c763d'
                            });

                        }
                    }

                }
                _bidarray.push(['VendorID', 'Price', 'Time', 'VendorName'])


                _timelft = $('#lblTimeLeft').text();

                if (_timelft == null || _timelft == '') {
                    _timelft = 0;
                }
                else {
                    _timelft = _timelft.slice(0, _timelft.indexOf(':'))


                }

                //alert(_timelft)
                for (var prop = 0; prop < data.length; prop++) {
                    //VendorName.slice(0, data[prop].VendorName.indexOf(' '))
                    _bidarray.push([data[prop].ShortName, parseInt(data[prop].LQuote), parseInt(_timelft), data[prop].VendorName]) //]
                }

               



            }
            else {
                
                jQuery('#tblBidSummary > tbody').append("<tr><td colspan='18' style='text-align: center; color:red;'>No record found</td></tr>");
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            
            return false;
            jQuery.unblockUI();
        }
    });
    //jQuery.unblockUI();
}
function fnClickHeader(event, icon,flag) {
    //var $cell = $(event.target).closest('td');
   // alert($cell.index())
    // if ($cell.index() > 0) {
    // alert(event.id)
   
    var F = 'N';
    if (flag == 'NotTD') {
        F = 'Y';
    }
   
    if (F == 'N') {
        $(event).nextUntil('tr.header').slideToggle(200);
    }
    //}
    //if ($('#' + iconid).hasClass('fa fa-arrow-down')) {
    //    jQuery("#" + iconid).removeClass('fa fa-arrow-down btn-success');
    //    jQuery("#" + iconid).addClass('fa fa-arrow-up btn-danger');

    //}
    //else {
    //    jQuery("#" + iconid).removeClass('fa fa-arrow-up btn-danger');
    //    jQuery("#" + iconid).addClass('fa fa-arrow-down btn-success');

    //}
}


$('#lnktotvalue').click(function() {
if ($('#lnktotvalue').html() == "Detailed Report") {
        $('#divfordetailreport').hide()
        $('#divforBidsummary').show()
        $('#tblBidSummary').show();
        $('#lnktotvalue').html('Summary Report')
        

    } else {
        $('#divfordetailreport').show()
        $('#divforBidsummary').hide()
        $('#tblbidsummarypercentagewise').show();
        $('#lnktotvalue').html('Detailed Report')
       
        
    }
});
//function fetchtotalvalueForVendors(BidID, BidTypeID) {
//    

//$('#lnktotvalue').html('Bid Summary')
//jQuery.ajax({
//    type: "GET",
//    contentType: "application/json; charset=utf-8",
//    url: sessionStorage.getItem("APIPath") + "BidVendorSummary/FetchBidTotalValue/?BidID=" + BidID+"&BidTypeID="+BidTypeID,
//    cache: false,
//    cache: false,
//    crossDomain: true,
//    dataType: "json",
//    success: function(data, status, jqXHR) {
//    jQuery("#tblbidsummarytotalvalue").empty();
//  
//   
//        //var t = 1;
//        if (data.length > 0) {

//            $('#divTarget').hide();
//            jQuery("#tblbidsummarytotalvalue").append("<thead><tr style='background: gray; color: #FFF;'><th>Vendor Name</th><th>TotalBid Value</th><th>TotalTarget Value</th><th>TotalSaving PR(%)</th><th>Status</th></tr></thead>");

//            for (var i = 0; i < data.length; i++) {
//                //alert(TotalSavingPR)
//                //alert(data[i].TotalSavingPR)
//                //if (TotalSavingPR > data[i].TotalSavingPR) {
//                    
//                    TotalSavingPR = data[i].TotalSavingPR;
//                    jQuery("#tblbidsummarytotalvalue").append("<tr id=low" + i + "><td>" + data[i].VendorName + "</td><td>" + data[i].TotalBidValue + "</td><td>" + data[i].TotalTargetPrice + "</td><td>" + data[i].TotalSavingPR + "</td><td>L" + (i+1) + "</td></tr>");
//                //}

////               else {
////                    t = t + 1;
////                }
//            }


//        }
//    }
//});
//     }


jQuery('#ddlVendorsAdmin').change(function () {
    if (jQuery('#ddlVendorsAdmin option:selected').val() != "0") {
        jQuery('a#ModifyLink').show();
        var vendorid = jQuery('#ddlVendorsAdmin option:selected').val()
        fetchBidModificationAir(vendorid);
        fetchBidModificationSea(vendorid);
        fetchBidModificationWarehouse(vendorid);
    }
    else
        jQuery('a#ModifyLink').hide();

});


function fetchBidModificationAir(vendorid) {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ApprovalAir/fetchBidModificationAir/?BidID=" + BidID + "&VendorID=" + vendorid + "&AthenticationToken=''&UserType=V",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
            if (data.length > 0) {

                jQuery("#txtfreightFSC").val(data[0].FSC);
                jQuery("#txtfreightSSC").val(data[0].SSC);
                jQuery("#txtdocharges").val(data[0].DOCharges);

                jQuery("#txtfreightMin").val(data[0].LQFMin);
                jQuery("#txtfreight45").val(data[0].LQF45);
                jQuery("#txtfreight100").val(data[0].LQF100);
                jQuery("#txtfreight300").val(data[0].LQF300);
                jQuery("#txtfreight500").val(data[0].LQF500);
                jQuery("#txtfreight1000").val(data[0].LQF1000);

                jQuery("#txtexworksMin").val(data[0].LQEMin);
                jQuery("#txtexworks45").val(data[0].LQE45);
                jQuery("#txtexworks100").val(data[0].LQE100);
                jQuery("#txtexworks300").val(data[0].LQE100);
                jQuery("#txtexworks500").val(data[0].LQE500);
                jQuery("#txtexworks1000").val(data[0].LQE1000);
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
           
            return false;
            jQuery.unblockUI();
        }
    });
}


function fetchBidModificationSea(vendorid) {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "BidVendorSummary/FetchBidSummary/?BidID=" + BidID + "&BidTypeID=" + BidTypeID + "&BidForID=" + BidForID + "&UserID=" + vendorid + "&AuthenticationTonken=" + sessionStorage.getItem("AuthenticationToken"),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
            if (data.length > 0) {
                for (var i = 0; i < data.length; i++) {
                    if (parseInt(data[i].VendorId) == parseInt(vendorid) && parseInt(data[i].bidid) == parseInt(BidID)) {
                        jQuery("#txtBAF").val(data[i].BAF);
                        jQuery("#txtCAF").val(data[i].CAFPer);
                        jQuery("#txtDocharges").val(data[i].ForwardersDO);
                        jQuery("#txttargetfreight").val(data[i].Freight);
                        jQuery("#txttargetexwork").val(data[i].ExWorks);
                    }
                }
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            
            return false;
            jQuery.unblockUI();
        }
    });
}

function fetchBidModificationWarehouse(vendorid) {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "BidVendorSummary/FetchBidSummary/?BidID=" + BidID + "&BidTypeID=" + BidTypeID + "&BidForID=" + BidForID + "&UserID=" + vendorid + "&AuthenticationTonken=" + sessionStorage.getItem("AuthenticationToken"),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
            if (data.length > 0) {
                for (var i = 0; i < data.length; i++) {
                    if (parseInt(data[i].VendorId) == parseInt(vendorid) && parseInt(data[i].bidid) == parseInt(BidID)) {
                        jQuery("#txtPerSqFtRate").val(data[i].PerSquareFeetRate);
                        jQuery("#txtManPowerCost").val(data[i].ManPowerCost);
                        jQuery("#txtInfrastructureCost").val(data[i].InfrastructureCost);
                        jQuery("#txtUtilitiesCost").val(data[i].UtilitiesCost);
                        jQuery("#txtFixedManagementFee").val(data[i].FixedManagementFee);
                    }
                }
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
    });
}

//jQuery('#btnsubmitmodify').click(function () {
//    InsertVendorAirModification();
//});

//jQuery('#btnsubmitmodifySea').click(function () {
   
//    jQuery('#responsiveSea').removeClass('in').removeClass('animated').removeClass(this.options.attentionAnimation).removeClass('modal-overflow').attr('aria-hidden', true);
//});
function InsertBidModificationAir() {
    fileUploader(BidID);
    var Vendorid = jQuery('#ddlVendorsAdmin option:selected').val();
    //var modifyVendorBid = {
    //    "BidID": BidID,
    //    "VendorID": Vendorid,
    //    "LoginUserID": sessionStorage.getItem("UserID"),
    //    "FSC": jQuery("#txtfreightFSC").val(),
    //    "SSC": jQuery("#txtfreightSSC").val(),
    //    "DOCharges": jQuery("#txtdocharges").val(),
    //    "LQFMin": jQuery("#txtfreightMin").val(),
    //    "LQF45": jQuery("#txtexworksMin").val(),
    //    "LQF100": jQuery("#txtfreight100").val(),
    //    "LQF300": jQuery("#txtfreight300").val(),
    //    "LQF500": jQuery("#txtfreight500").val(),
    //    "LQF1000": jQuery("#txtfreight1000").val(),

    //    "LQEMin": jQuery("#txtexworksMin").val(),
    //    "LQE45": jQuery("#txtexworks45").val(),
    //    "LQE100": jQuery("#txtexworks100").val(),
    //    "LQE300": jQuery("#txtexworks300").val(),
    //    "LQE500": jQuery("#txtexworks500").val(),
    //    "LQE1000": jQuery("#txtexworks1000").val(),
    //    "Attachement":jQuery('#fileupload').val().substring(jQuery('#fileupload').val().lastIndexOf('\\') + 1)
    //};
    //jQuery.ajax({
    //    type: "POST",
    //    contentType: "application/json; charset=utf-8",
    //    url: sessionStorage.getItem("APIPath") + "ApprovalAir/InsertBidModificationAir",
    //    cache: false,
    //    data: JSON.stringify(modifyVendorBid),
    //    crossDomain: true,
    //    dataType: "json",
    //    success: function (data, status, jqXHR) {
    //        fileUploader(BidID);
    //        fetchBidSummaryDetails(BidID, BidTypeID, BidForID);
    //        $('#responsiveAir').modal('hide');
    //    }
    //});
}
function InsertBidModificationSea() {
    var Vendorid = jQuery('#ddlVendorsAdmin option:selected').val();
    var modifyVendorBidSea = {
        "bidid": BidID,
        "VendorId": Vendorid,
        "LoginUserID": sessionStorage.getItem("UserID"),
        "BAF": jQuery("#txtBAF").val(),
        "CAF": jQuery("#txtCAF").val(),
        "ForwardersDO": jQuery("#txtDocharges").val(),
        "Freight": jQuery("#txttargetfreight").val(),
        "ExWorks": jQuery("#txttargetexwork").val(),
        "Attachement": jQuery('#fileupload').val().substring(jQuery('#fileupload').val().lastIndexOf('\\') + 1)
    };
    jQuery.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ApprovalSea/InsertBidModificationSea",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        data: JSON.stringify(modifyVendorBidSea),
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
            fileUploader(BidID);
            fetchBidSummaryDetails(BidID, BidTypeID, BidForID);
            $('#responsiveSea').modal('hide');
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
    });
}

function InsertBidModificationWarehouse() {
    var Vendorid = jQuery('#ddlVendorsAdmin option:selected').val();
    var modifyVendorBidWarehouse = {
        "bidid": BidID,
        "VendorId": Vendorid,
        "LoginUserID": sessionStorage.getItem("UserID"),
        "PerSquareFeetRate": jQuery("#txtPerSqFtRate").val(),
        "ManPowerCost": jQuery("#txtManPowerCost").val(),
        "InfrastructureCost": jQuery("#txtInfrastructureCost").val(),
        "UtilitiesCost": jQuery("#txtUtilitiesCost").val(),
        "FixedManagementFee": jQuery("#txtFixedManagementFee").val(),
        "Attachement": jQuery('#fileupload').val().substring(jQuery('#fileupload').val().lastIndexOf('\\') + 1)
    };
    jQuery.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ApprovalWarehouse/InsertBidModificationWarehouse",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        data: JSON.stringify(modifyVendorBidWarehouse),
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
            fileUploader(BidID);
            fetchBidSummaryDetails(BidID, BidTypeID, BidForID);
            $('#responsiveSea').modal('hide');
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
    });
}

jQuery("#btnbackAward").click(function () {
    parent.history.back();
});
jQuery("#btnbackApp").click(function () {
    parent.history.back();
});
jQuery("#btnbackAdmin").click(function () {
    parent.history.back();
});
//jQuery("#btnSubmitAdmin").click(function () {
//if (AppStatus == 'Reverted') {
//    ApprovalAdmin();
//}
//else {
//    ForwardBid(BidID, BidTypeID, BidForID)
//}
//});
//jQuery("#btnSubmitAward").click(function () {
//    AwardBid(BidID)
//});
//jQuery("#btnSubmitApp").click(function () {
//       ApprovalApp();
//});
jQuery("#butCancelbid").click(function () {
    CancelBid(BidID);
});



function AwardBid(bidid) {
    var AwardBid = {
        "BidID": bidid,
        "VendorID": jQuery("#hdnvendor").val(),
        "LoginUserID": sessionStorage.getItem("UserID"),
        "Remarks": jQuery("#txtRemarksAward").val()
    };
    jQuery.ajax({
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "Activities/AwardBid",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "POST",
        cache: false,
        data: JSON.stringify(AwardBid),
        crossDomain: true,
        dataType: "json",
        success: function () {
             bootbox.alert("Transaction Successful..", function () {
                 window.location = "index.html";
                 return false;
             });
            // $('.bootbox').children().removeAttr('class');
			// $('#successdiv2').show();
			// setTimeout(function(){
				 // window.location = "index.html";
			 // }, 2000);
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
    });
}
function FetchRecomendedVendor(bidid) {
   // alert(sessionStorage.getItem("APIPath") + "ApprovalAir/FetchRecommendedVendor/?BidID=" + bidid + "&UserID=" + encodeURIComponent(sessionStorage.getItem("UserID")) + "&AuthenticationTonken=" + sessionStorage.getItem("AuthenticationToken"))
    jQuery.ajax({
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ApprovalAir/FetchRecomendedVendor/?BidID=" + bidid + "&UserID=" + encodeURIComponent(sessionStorage.getItem("UserID")) + "&AuthenticationTonken=" + sessionStorage.getItem("AuthenticationToken"),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "GET",
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function(data) {
            $('#tblremarksforward').empty()
            $('#tblremarksapprover').empty()
            $('#tblremarksawared').empty()
            $('#tblapprovalprocess').empty()
            if (data.length > 0) {
                $('#divforapprovalprocess').show()

                $('#tblremarksforward').append('<tr><th>Action Taken By</th><th>Remarks</th><th>Action Type</th><th class=hide id=thforward>Recommended Vendor</th><th>Completion DT</th></tr>')
                $('#tblremarksapprover').append('<tr><th>Action Taken By</th><th>Remarks</th><th>Action Type</th><th class=hide id=thapprover>Recommended Vendor</th><th>Completion DT</th></tr>')
                $('#tblremarksawared').append('<tr><th>Action Taken By</th><th>Remarks</th><th>Action Type</th><th class=hide id=thaward>Recommended Vendor</th><th>Completion DT</th></tr>')
                $('#tblapprovalprocess').append('<tr><th>Action Taken By</th><th>Remarks</th><th>Action Type</th><th style="display: none;" id="thapprovalprocess">Recommended Vendor</th><th>Completion DT</th></tr>')


                jQuery("#lblvendor").text(data[0].VendorName);
                jQuery("#hdnvendor").val(data[0].VendorID);
                jQuery("#ddlVendors,#ddlVendorsAdmin").val(data[0].VendorID).attr("selected", "selected");
                if (AppStatus == 'Reverted') {
                    jQuery("#lblrevertedComment").text(data[0].Remarks);
                    jQuery("#RevertComment").show();
                    $('#frmdivremarksforward').removeClass('col-md-12');
                    $('#frmdivremarksforward').addClass('col-md-6');
                    $('#frmdivforward').show();
                    for (var i = 0; i < data.length; i++) {
                        if (data[i].VendorName != "") {
                            $('#tblremarksforward').append('<tr><td>' + data[i].ActionTakenBy + '</td><td>' + data[i].Remarks + '</td><td>' + data[i].FinalStatus + '</td><td>' + data[i].VendorName + '</td><td>' + data[i].ReceiptDt + '</td></tr>')
                            $('#thforward').removeClass('hide')
                        }
                        else {
                            $('#tblremarksforward').append('<tr><td>' + data[i].ActionTakenBy + '</td><td>' + data[i].Remarks + '</td><td>' + data[i].FinalStatus + '</td><td>' + data[i].ReceiptDt + '</td></tr>')
                            $('#thforward').addClass('hide')
                        }


                    }
                }
                $('#frmdivremarksapprover').removeClass('col-md-12');
                $('#frmdivremarksapprover').addClass('col-md-6');
                for (var i = 0; i < data.length; i++) {
                    if (data[i].VendorName != "") {
                        $('#tblremarksapprover').append('<tr><td>' + data[i].ActionTakenBy + '</td><td>' + data[i].Remarks + '</td><td>' + data[i].FinalStatus + '</td><td>' + data[i].VendorName + '</td><td>' + data[i].ReceiptDt + '</td></tr>')
                        $('#thapprover').removeClass('hide')
                    }
                    else {
                        $('#tblremarksapprover').append('<tr><td>' + data[i].ActionTakenBy + '</td><td>' + data[i].Remarks + '</td><td>' + data[i].FinalStatus + '</td><td>' + data[i].ReceiptDt + '</td></tr>')
                        $('#thapprover').addClass('hide')
                    }
                }
                $('#frmdivapprove').show()
                $('#frmdivremarksawarded').removeClass('col-md-12');
                $('#frmdivremarksawarded').addClass('col-md-6');
                for (var i = 0; i < data.length; i++) {
                    if (data[i].VendorName != "") {
                        $('#tblremarksawared').append('<tr><td>' + data[i].ActionTakenBy + '</td><td>' + data[i].Remarks + '</td><td>' + data[i].FinalStatus + '</td><td>' + data[i].VendorName + '</td><td>' + data[i].ReceiptDt + '</td></tr>')
                        $('#thaward').removeClass('hide')
                    }
                    else {
                        $('#tblremarksawared').append('<tr><td>' + data[i].ActionTakenBy + '</td><td>' + data[i].Remarks + '</td><td>' + data[i].FinalStatus + '</td><td>' + data[i].ReceiptDt + '</td></tr>')
                        $('#thaward').addClass('hide')
                    }
                }
                $('#frmdivawarded').show()
                jQuery("#lblLastcomments,#LblLastcomments,#lbllastcommentSeaAward").text(data[0].Remarks);

                for (var i = 0; i < data.length; i++) {
                    if (data[i].VendorName != "") {
                        $('#tblapprovalprocess').append('<tr><td>' + data[i].ActionTakenBy + '</td><td>' + data[i].Remarks + '</td><td>' + data[i].FinalStatus + '</td><td>' + data[i].VendorName + '</td><td>' + data[i].ReceiptDt + '</td></tr>')
                        $('#thapprovalprocess').show();
                    }
                    else {
                        $('#tblapprovalprocess').append('<tr><td>' + data[i].ActionTakenBy + '</td><td>' + data[i].Remarks + '</td><td>' + data[i].FinalStatus + '</td><td>' + data[i].ReceiptDt + '</td></tr>')
                        $('#thapprovalprocess').hide()
                    }
                }
            }
            else {
                $('#tblapprovalprocess').append('<tr><td colspan="15" style="text-align: center; color: Red">No record found</td></tr>')
            }

        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
    });
    
}
function ForwardBid(bidid, bidtypeid, bidforid) {
    var vendorid = 0;
    if (jQuery("#ddlVendorsAdmin option:selected").val() != undefined) {
        vendorid = jQuery("#ddlVendorsAdmin option:selected").val()
    }
    
    var ForwardBid = {
        "BidID": bidid,
        "BidTypeID": bidtypeid,
        "VendorID": vendorid,
        "BidDescription": jQuery("#lblbidSubject").text(),
        "LoginUserID": sessionStorage.getItem("UserID"),
        "Remarks": jQuery("#txtbidspecification").val(),
        "CustomerID" : sessionStorage.getItem('CustomerID')
    };
   // alert(JSON.stringify(ForwardBid))
    jQuery.ajax({
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "Activities/forwardBidToApprover",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "POST",
        cache: false,
        data: JSON.stringify(ForwardBid),
        crossDomain: true,
        dataType: "json",
        success: function () {
             bootbox.alert("Transaction Successful..", function () {
                 window.location = "index.html";
                 return false;
             });
            // $('.bootbox').children().removeAttr('class');
			
			 // $('#successdiv1').show();
			 // setTimeout(function(){
				 // window.location = "index.html";
			 // }, 2000);
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
    });
}
function ApprovalApp() {
    var vendorid = 0;
    if (jQuery("#ddlVendors option:selected").val() != undefined) {
        vendorid = jQuery("#ddlVendors option:selected").val();
    }
    var  approvalbyapp= {
        "BidID": BidID,
        "FromUserId": sessionStorage.getItem("UserID"),
        "ActivityDescription": jQuery("#lblbidSubject").text(),
        "Remarks": jQuery("#txtRemarksApp").val(),
        "BidTypeID" : BidTypeID,
        "Action":jQuery("#ddlActionType option:selected").val(),
        "ForwardedBy": "Approver",
        "VendorId": vendorid,
        "Carrier": '',
        "CustomerID": sessionStorage.getItem("CustomerID")
    };
	
	//alert(JSON.stringify(approvalbyapp))
     jQuery.ajax({
     contentType: "application/json; charset=utf-8",
     url: sessionStorage.getItem("APIPath") + "ApprovalAir/ApprovalApp",
     beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
         type: "POST",
         cache: false,
         data: JSON.stringify(approvalbyapp),
         crossDomain: true,
         dataType: "json",
         success: function () {
             bootbox.alert("Transaction Successful..", function () {
                  window.location = "index.html";
                  return false;
              });
			 //$('.bootbox').children().removeAttr('class');
			 
			 // $('#successdiv').show();
			 // setTimeout(function(){
				 // window.location = "index.html";
			 // }, 2000);
            
         },
         error: function (xhr, status, error) {

             var err = eval("(" + xhr.responseText + ")");
             if (xhr.status === 401) {
                 error401Messagebox(err.Message);
             }

             return false;
             jQuery.unblockUI();
         }
    });
}
function ApprovalAdmin() {
    var approvalbyapp = {
        "BidID": BidID,
        "FromUserId": sessionStorage.getItem("UserID"),
        "ActivityDescription": jQuery("#lblbidSubject").text(),
        "Remarks": jQuery("#txtbidspecification").val(),
        "BidTypeID": BidTypeID,
        "Action": "",
        "ForwardedBy": "Administrator",
        "VendorId": jQuery("#ddlVendorsAdmin option:selected").val(),
        "Carrier": '',
        "CustomerID": sessionStorage.getItem('CustomerID')
    };
    jQuery.ajax({
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ApprovalAir/ApprovalApp",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "POST",
        cache: false,
        data: JSON.stringify(approvalbyapp),
        crossDomain: true,
        dataType: "json",
        success: function () {
             bootbox.alert("Transaction Successful..", function () {
                 window.location = "index.html";
                 return false;
             });
            // $('.bootbox').children().removeAttr('class');
			 // $('#successdiv1').show();
			 // setTimeout(function(){
				 // window.location = "index.html";
			 // }, 2000);
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
    });
}

function fetchApproverStatus() {

    //jQuery.blockUI({ message: '<h5><img src="assets_1/layouts/layout/img/loading.gif" />  Please Wait...</h5>' });
    var url = sessionStorage.getItem("APIPath") + "Activities/GetBidApproverStatus/?BidID=" + BidID

    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: url,
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        processData: true,
        dataType: "json",
        success: function (data) {
            var status = '';
            var c = 0;
            sessionStorage.setItem("LastApproverStaffCode", data[data.length - 1].ApproverStaffCode)
            if (data.length > 0) {
                $('#div_statusbar').removeClass('hide');
                jQuery('#divappendstatusbar').empty();
                var counterColor = 0;
                for (var i = 0; i < data.length; i++) {

                    jQuery('#divappendstatusbar').append('<div class="col-md-2 mt-step-col first" id=divstatuscolor' + i + '><div class="mt-step-number bg-white" style="font-size:small;height:38px;width:39px;" id=divlevel' + i + '></div><div class="mt-step-title font-grey-cascade" id=divapprovername' + i + ' style="font-size:smaller"></div><div style="font-size:x-small;" class="mt-step-content font-grey-cascade" id=divstatus' + i + '></div><div style="font-size:x-small;" class="mt-step-content font-grey-cascade" id=divPendingDate' + i + '></div></div></div></div>')
                    jQuery('#divlevel' + i).text(data[i].Level);
                    jQuery('#divapprovername' + i).text(data[i].ApproverStaffName);
                    jQuery('#divPendingDate' + i).text(data[i].PendingSince);

                    if (data[i].StatusCode == 10) {
                        
                        counterColor = counterColor + 1;
                        status = 'Pending'
                        jQuery('#divstatus' + i).text(status);
                        jQuery('#divstatuscolor' + i).addClass('last');

                    }
                    if (data[i].StatusCode == 20) {
                        //counterColor = counterColor + 1;
                        status = 'Approved'
                        jQuery('#divstatus' + i).text(status);
                        jQuery('#divstatuscolor' + i).addClass('last');
                    }
                    if (data[i].StatusCode == 30) {

                        //counterColor = counterColor + 1;
                        status = 'Forwarded'
                        jQuery('#divstatus' + i).text(status);
                        jQuery('#divstatuscolor' + i).addClass('last');
                    }
                    if (data[i].StatusCode == 40) {

                        counterColor = counterColor + 1;
                        status = 'Awarded'
                        jQuery('#divstatus' + i).text(status);
                        jQuery('#divstatuscolor' + i).addClass('last');
                    }
                    if (data[i].StatusCode == 10) {
                        jQuery('#divstatuscolor' + i).addClass('error');
                    }
                    if (data[i].StatusCode == 20 | data[i].StatusCode == 30 || data[i].StatusCode == 40) {
                        jQuery('#divstatuscolor' + i).addClass('done');
                    }
                    //if (data[i].StatusCode == 30) {
                    //    jQuery('#divstatuscolor' + i).addClass('active');
                    //}
                    //if (data[i].StatusCode == 40) {
                    //    jQuery('#divstatuscolor' + i).addClass('last');
                    //}

                    if (counterColor > 1) {
                        if (status == 'Pending') {
                            status = 'N/A'
                            jQuery('#divPendingDate' + i).addClass('hide')
                            c = c + 1;
                            jQuery('#divstatus' + i).text(status);
                            jQuery('#divstatuscolor' + i).removeClass('error')
                            jQuery('#divstatuscolor' + i).addClass('font-yellow')
                            jQuery('#divstatuscolor' + i).addClass('last')
                            jQuery('#divstatus' + i).addClass('font-yellow')
                            jQuery('#divapprovername' + i).addClass('font-yellow')

                            //if (c == 1) {
                            //    if (data[i].EMailID != '') {
                            //        sessionStorage.setItem("NextApproverEmail", data[i].EMail)
                            //        sessionStorage.setItem("NextApproverName", data[i].ApproverStaffName)
                            //        sessionStorage.setItem("NextApproverStaffCode", data[i].ApproverStaffCode)
                            //    }
                            //}
                        }
                    }
                    //if (status == 'Pending') {
                    //    if (data[i].EMail != '') {
                    //        sessionStorage.setItem("LoginApproverEmail", data[i].EMail)
                    //    }
                    //}

                   
                }
            }

            else {
                $('#div_statusbar').addClass('hide');

            }
            jQuery.unblockUI();
        },
        
        error: function (xhr, status, error) {

        var err = eval("(" + xhr.responseText + ")");
        if (xhr.status === 401) {
            error401Messagebox(err.Message);
        }
        else{
            alert(response.status + ' ' + response.statusText);
        }   
        return false;
        jQuery.unblockUI();
    }

    });
}
function cancelBtnclick() {
    bootbox.dialog({
        message: "Are you sure want to cancel this bid?",
        // title: "Custom title",
        buttons: {
            confirm: {
                label: "Yes",
                className: "btn-success",
                callback: function() {
                //CancelBid(BidID)
                bootbox.dialog({
                    message: "Do you want to send cancellation email to participants for this bid?",
                    // title: "Custom title",
                    buttons: {
                        confirm: {
                            label: "Yes",
                            className: "btn-success",
                            callback: function() {
                                CancelBid(BidID, 'SendMail')
                            }
                        },
                        cancel: {
                            label: "No",
                            className: "btn-default",
                            callback: function() {
                                CancelBid(BidID, 'NoMail')
                            }
                        }
                    }
                });
                }
            },
            cancel: {
                label: "No",
                className: "btn-default",
                callback: function() {
                    
                }
            }
        }
    });
}

function CancelBid(bidid,mailparam) {
	
     var Cancelbid = {
         "BidID": bidid,
         "Remarks": jQuery("#txtbidspecification").val(),
         "UserID": sessionStorage.getItem('UserID'),         
         "BidSubj":$('#lblbidSubject').text(),
         "BidDescription":$('#lblbiddetails').html().replace(/'/g, " "),
         "BidDate": $('#lblbiddate').html(),
         "BidTime":$('#lblbidtime').html(),
         "BidDuration": $('#lblbidduration').html(),
         "BidTypeID": BidTypeID,
         "SendMail": mailparam

     };
     //alert(JSON.stringify(Cancelbid))
     jQuery.ajax({
         contentType: "application/json; charset=utf-8",
         url: sessionStorage.getItem("APIPath") + "Activities/CancelBid",
         beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "POST",
        cache: false,
         data: JSON.stringify(Cancelbid),
         crossDomain: true,
        dataType: "json",
         success: function () {
            bootbox.alert("Bid Cancelled successfully.", function () {
                window.location = "index.html";
                return false;
            });
            
         },
         error: function (xhr, status, error) {

             var err = eval("(" + xhr.responseText + ")");
             if (xhr.status === 401) {
                 error401Messagebox(err.Message);
             }
            
             return false;
             jQuery.unblockUI();
         }
     });
}
function fileUploader(BidID) {
    
    var fileInput = $('#fileupload');
    var fileData = fileInput.prop("files")[0]; 
    var formData = new window.FormData();    
    formData.append("file", fileData); 
    formData.append("BidID", BidID);
    $.ajax({
        url: '/FileUploader.ashx',
        data: formData,
        processData: false,
        contentType: false,
        type: 'POST',
        success: function (data) {
        }
    });
}

function backButtonClick() {
  
    window.location = "index.html";
}


$('#graphModal').on('shown.bs.modal', function() {    
        drawSeriesChart()
    
        
});


function drawSeriesChart() {    

var data = new google.visualization.arrayToDataTable(_bidarray,false);

var options = {

    hAxis: { title: 'Price' },
    vAxis: { title: 'Time ( in minutes )' },
    //bubble: {textStyle: {fontSize: 11}},
    sizeAxis: { maxSize: 30, minSize: 8 },
    bubble: {
        textStyle: {
            fontSize: 10,
            fontName: 'Verdana',
            color: 'none'

        }
    },
    legend: {
        textStyle: {
            fontSize: 11,
            fontName: 'Verdana',
            bold: true


        }
}
    };
        var chart = new google.visualization.BubbleChart(document.getElementById('series_chart_div'));
        chart.draw(data, options)
       }


      
        

       //$('#graphModalLine').on('shown.bs.modal', function() {
       //    drawLineChart()


       //});
       function drawChart() {
           var _QuotesArray = [];
           jQuery.ajax({
               type: "GET",
               contentType: "application/json; charset=utf-8",
               url: sessionStorage.getItem("APIPath") + "BidVendorSummary/fetchQuotesForTrendChart/?BidID=" + BidID,
               beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
               cache: false,
               crossDomain: true,
               dataType: "json",
               success: function(data, status, jqXHR) {
                   _QuotesArray = [];
                   var st = '';
                   var temp = [];

                   //debugger


                   if (data[0].VendorNames.length > 0) {

                       _QuotesArray.push(['Time'])
                       for (var i = 0; i < data[0].VendorNames.length; i++) {

                           _QuotesArray[0].push(data[0].VendorNames[i].VendorName)


                       }
                   }
                  
               //    alert(_QuotesArray)
                   //                   if (data[0].QuotesDetails.length > 0) {
                   //                       var index = 1;
                   //                       for (var i = 0; i < data[0].QuotesDetails.length; i++) {
                   //                           
                   //                           //alert(data[0].QuotesDetails[i].SubmissionTime)
                   //                           for (var j = 0; j < data[0].QuotesDetails.length; j++) {
                   //                               _QuotesArray.push([data[0].QuotesDetails[i].SubmissionTime]);

                   //                               if ( data[0].QuotesDetails[i].SubmissionTime == data[0].QuotesDetails[j].SubmissionTime) {
                   //                                  
                   //                                   _QuotesArray[index].push(data[0].QuotesDetails[j].QuotedPrice);
                   //                                   index = index + 1;
                   //                               }
                   //                           }




                   //                       }
                   //                   }

               }
           });
           var data = new google.visualization.arrayToDataTable(_QuotesArray, false);
           

//           data.addRows([
//        [1, 37.8, 80.8, 41.8],
//        [2, 30.9, 69.5, 32.4],
//        [3, 25.4, 57, 25.7],
//        [4, 11.7, 18.8, 10.5],
//        [5, 11.9, 17.6, 10.4],
//        [6, 8.8, 13.6, 7.7],
//        [7, 7.6, 12.3, 9.6],
//        [8, 12.3, 29.2, 10.6],
//        [9, 16.9, 42.9, 14.8],
//        [10, 12.8, 30.9, 11.6],
//        [11, 5.3, 7.9, 4.7],
//        [12, 6.6, 8.4, 5.2],
//        [13, 4.8, 6.3, 3.6],
//        [14, 4.2, 6.2, 3.4]
//      ]);

           var options = {
               chart: {
                   title: 'Box Office Earnings in First Two Weeks of Opening',
                   subtitle: 'in millions of dollars (USD)'
               },
               width: 900,
               height: 500
           };

           var chart = new google.charts.Line(document.getElementById('linechart_material'));

           chart.draw(data, options);
            }

function thousands_separators(num) {
    var num_parts = num.toString().split(".");
    num_parts[0] = num_parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    return num_parts.join(".");
}
function minutes_with_leading_zeros(dtmin) {
    return (dtmin < 10 ? '0' : '') + dtmin;
}


function fetchGraphData(itemId) {
     //alert(itemId)
    var _bidTypeID;
    if (getUrlVarsURL(decryptedstring)["BidTypeID"]) {
        _bidTypeID = getUrlVarsURL(decryptedstring)["BidTypeID"];
    } else {
        _bidTypeID = sessionStorage.getItem('hdnbidtypeid');
    }
    console.log(typeof getUrlVarsURL(decryptedstring)["BidTypeID"]);
    graphData = [];

    var _date;
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "BidVendorSummary/fetchDataForBidSummaryTrendGraph/?SeId=" + itemId + "&BidId=" + getUrlVarsURL(decryptedstring)["BidID"] + "&BidTypeId=" + _bidTypeID + "&CustomerId=" + sessionStorage.getItem('CustomerID') + "&UserId=" + sessionStorage.getItem('UserID') + "&chartFor=sample",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
            //console.log("data Vickrant ==> ", data);
            $("#tblForTrendGraphs").empty();
            if (data) {
                $("#tblForTrendGraphs").append("<tr><th>Submission Time</th><th>Quoted Price</th><th>Vendor</th></tr>");
                for (var i = 0; i < data.length; i++) {
                    _date = new Date(data[i].SubmissionTime);
                  
                    //graphtime.push([new Date(data[i].SubmissionTime).getHours(), minutes_with_leading_zeros(new Date(data[i].SubmissionTime).getMinutes())]);
                    // graphData.push([[new Date(data[i].SubmissionTime).getHours(), new Date(data[i].SubmissionTime).getMinutes()], data[i].QuotedPrice, createCustomHTMLContent(new Date(data[i].SubmissionTime).getHours(), new Date(data[i].SubmissionTime).getMinutes(), data[i].VendorName, data[i].QuotedPrice )]);
                    $("#tblForTrendGraphs").append("<tr><td>" + _date.getDate() + "/" + (_date.getMonth() + 1) + "/" + _date.getFullYear() + " " + minutes_with_leading_zeros(new Date(data[i].SubmissionTime).getHours()) + ":" + minutes_with_leading_zeros(new Date(data[i].SubmissionTime).getMinutes()) + "</td><td>" + data[i].QuotedPrice + "</td><td>" + data[i].VendorName + "</td></tr>");
                }
            }
            // graphtime = graphtime.join(',');
            //alert(graphtime)
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            
            return false;
            jQuery.unblockUI();
        }
    }).done(function () {
        //console.log("graphData ==> ", graphData);
        $("#graphModalLine").modal('show');
        //google.charts.load('current', { packages: ['corechart'] });
        //google.charts.setOnLoadCallback(drawBidTrendGraph);
        linegraphsforItems(itemId)
    });
}
    var Vendorseries = "";
    var graphtime = [];
    var dataQuotes = [];
    var Seriesoption = [];
    var FinalQuotes = [];
    var Quotes = "";
    var minprice;
    var maxprice;
    function linegraphsforItems(itemId) {

        var _bidTypeID;
        var _date;
        if (getUrlVarsURL(decryptedstring)["BidTypeID"]) {
            _bidTypeID = getUrlVarsURL(decryptedstring)["BidTypeID"];
        } else {
            _bidTypeID = sessionStorage.getItem('hdnbidtypeid');
        }
        //alert(sessionStorage.getItem("APIPath") + "BidVendorSummary/fetchDataForBidSummaryGraph/?SeId=" + itemId + "&BidId=" + getUrlVarsURL(decryptedstring)["BidID"] + "&BidTypeId=" + _bidTypeID + "&CustomerId=" + sessionStorage.getItem('CustomerID') + "&UserId=")
        graphtime = [];
        Vendorseries = "";
        dataQuotes = [];
        Seriesoption = [];
        FinalQuotes = [];
        var colorArray = ['#007ED2', '#f15c80', '#90ED7D', '#FF7F50', '#f15c80', '#FF5733', '#96FF33', '#33FFF0', '#F9FF33', '#581845', '#0B0C01', '#0C0109', '#DAF7A6', '#FFC300', '#08010C'];
        jQuery.ajax({
            type: "GET",
            contentType: "application/json; charset=utf-8",
            url: sessionStorage.getItem("APIPath") + "BidVendorSummary/fetchDataForBidSummaryGraph/?SeId=" + itemId + "&BidId=" + getUrlVarsURL(decryptedstring)["BidID"] + "&BidTypeId=" + _bidTypeID + "&CustomerId=" + sessionStorage.getItem('CustomerID') + "&UserId=",
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            cache: false,
            crossDomain: true,
            dataType: "json",
            success: function (data, status, jqXHR) {
                minprice = parseInt(data[0].MinMaxprice[0].MinPrice - 5);
                maxprice = parseInt(data[0].MinMaxprice[0].MaxPrice + 5);
               
                $('#lblbidstarttime').text(data[0].BidStartEndTime[0].BidStartTime);
                $('#lblbidendtime').text(data[0].BidStartEndTime[0].BidEndTime);


                if (data[0].SubmissionTime.length > 0) {

                    for (var x = 0; x < data[0].SubmissionTime.length; x++) {
                        //_date = new Date(data[0].SubmissionTime[x].SubTime).getTime();
                        graphtime.push(data[0].SubmissionTime[x].SubTime);
                    }

                }
                Vendorseries = "";
                var values=0;
                if (data[0].VendorNames.length > 0) {


                    for (var i = 0; i < data[0].VendorNames.length; i++) {
                        //dataQuotes = [];
                        Quotes = "";
                        values = null;;
                        //for (var x = 0; x < data[0].SubmissionTime.length; x++) {
                            for (var j = 0; j < data[0].QuotesDetails.length; j++) {
                                if (data[0].VendorNames[i].VendorID == data[0].QuotesDetails[j].VendorID ) {
                                    Quotes = Quotes + '["' + data[0].QuotesDetails[j].SubTime + '",' + data[0].QuotesDetails[j].QuotedPrice + '],';
                                    //  dataQuotes.push([_date, data[0].QuotesDetails[j].QuotedPrice]);
                                   // dataQuotes.push([data[0].QuotesDetails[j].QuotedPrice]);
                                    values = data[0].QuotesDetails[j].QuotedPrice;
                                }
                                else {
                                    //dataQuotes.push([0]);
                                   
                                    Quotes = Quotes + '["' + data[0].QuotesDetails[j].SubTime + '",' + values + '],';
                                }
                            }

                       // }

                        Quotes = Quotes.slice(0, -1);
                        //alert(Quotes)
                        //FinalQuotes.push(Quotes)
                        Vendorseries = '{ "name" :"' + data[0].VendorNames[i].VendorName + '", "color": "' + colorArray[i] + '","data": [' + Quotes + ']}';
                        //alert(Vendorseries)
                        Seriesoption.push(JSON.parse(Vendorseries));
                       
                    }

                }

            },
            error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
             
            return false;
            jQuery.unblockUI();
        }
        })

        setTimeout(function () {
           // alert(Seriesoption)
           // Highcharts.chart('linechart_material', {
              $('#linechart_material').highcharts({
                title: {
                    text: '',
                    style: {
                        //fontWeight: 'normal',
                        fontSize: '15px',
                        //fontFamily: 'Verdana, sans-serif'
                    },
                   // x: -20 //center
                },

                xAxis: {
                   
                    title: {
                        text: 'Time'
                    },

                    //labels: {
                    //   // rotation: -45,
                    //    style: {
                    //        fontWeight: 'normal',
                    //        fontSize: '9px',
                    //        fontFamily: 'Verdana, sans-serif'
                    //    }
                    //},

                    categories: graphtime//,'12:42','15:14','15:14','15:14','15:57']//graphtime

                 //' categories: ['15:55','15:56','15:57','15:58','16:00','16:02']
                },
                yAxis: {
                    min: minprice,
                    max: maxprice,
                    title: {
                        text: 'Quoted Price'
                    },
                    //plotLines: [{
                    //    value: 0,
                    //    width: 1,
                    //    color: '#808080'
                    //}]
                },
                //tooltip: {

                //},

                //   legend: {
                //       layout: 'horizontal',
                //       //align: 'bottom',
                //       horizontalAlign: 'middle',
                //       verticalAlign: 'bottom',
                //       borderWidth: 0,
                //       itemStyle: {
                //           color: '#000',
                //           fontWeight: 'normal',
                //           fontSize: '10px',
                //           fontFamily: 'Verdana, sans-serif'
                //       }
                //},


                    series: Seriesoption,
                //series: [
                // { name: "SBK ENTERPRISES", color: "#f15c80", data: [['11:51', 34]] },
                // { name: "MOHAMMEDALI & SONS", color: "#007ED2", data: [['11:51', 34],['12:35', 17.5]] },
                //{ name: "Bombay General Suppliers", color: "#FF7F50", data: [['11:51', null],['12:35', null],['12:42', 12]] },
                //{ name: "N.AKBARALLY & CO", color: "#007ED2", data: [['11:51', null], ['12:35', null], ['12:42', null],["15:14", 23], ["15:14", 20], ["15:14", 13]] }
                   
                    //{ name: "Best Supply Agencies", color: "#90ED7D", data: [["15:57", 19]] }
                    
                   
              // ],
                credits: {
                    enabled: false
                }

            });

        }, 1000)



    }


    function drawBidTrendGraph() {
        var data = new google.visualization.DataTable();
        data.addColumn('timeofday', 'submissionTime');
        data.addColumn('number', 'QuotedPrice');
        data.addColumn({ 'type': 'string', 'role': 'tooltip', 'p': { 'html': true } })
        //console.log("graphData ==> ", graphData);
        data.addRows(graphData);

        var options = {
            hAxis: {
                title: 'Time',
                format: 'H:mm'

            },
            vAxis: {
                title: 'Quotes'
            },
            legend: 'none',
            // Use an HTML tooltip.
            tooltip: { isHtml: true }
        };

        var chart = new google.visualization.LineChart(document.getElementById('linechart_material'));

        chart.draw(data, options);

    }


    function createCustomHTMLContent(timeHrs, timeMins, vendorName, quotedPrice) {
        return '<div class="table-responsive" style="padding:5px 5px 5px 5px;width:150px;max-width:100%">' +
            '<table class="tooltip-tbl">' +
            //'<img src="' + flagURL + '" style="width:75px;height:50px"><br/>' +
            '<tr><td><strong>' + timeHrs + ':' + timeMins + "</strong></td></tr>" +
            '<tr><td><strong>' + vendorName + ' : </strong></td>' +
            '<td><strong> ' + quotedPrice + '</strong></td></tr>' +
            '</table>' +
            '</div>';
    }

