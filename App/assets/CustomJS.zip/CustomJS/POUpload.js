﻿$(".thousandseparated").inputmask({
    alias: "decimal",
    rightAlign: false,
    groupSeparator: ",",
    radixPoint: ".",
    autoGroup: true,
    integerDigits: 40,
    digitsOptional: true,
    allowPlus: false,
    allowMinus: false,
    'removeMaskOnSubmit': true

});
$('#txtshortname,#txtItemCode,#txtPono,#txtItemCode,#txtvendorremarks').maxlength({
    limitReachedClass: "label label-danger",
    alwaysShow: true
});
if (window.location.search) {
    var param = getUrlVars()["param"]
    var decryptedstring = fndecrypt(param)
    var AppType = getUrlVarsURL(decryptedstring)["AppType"];

    $('#hdnPOHeader').val(getUrlVarsURL(decryptedstring)["POHID"])

}
if (AppType == "Reverted") {
    $('#txtVendor').attr('disabled', 'disabled')
    $('#txtVendorGroup').attr('disabled', 'disabled')
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    fetchAttachments();
    setTimeout(function () {
        fetchDeliverySpread();
    },800)
   
}
else {
    $('#txtVendor').removeAttr('disabled')
    $('#txtVendorGroup').removeAttr('disabled', 'disabled')
}
var form = $('#frmbidsummaryreport');
function InsUpdProductSevices() {

    if ($('#add_or').text() == "Modify") {

        var st = "true"
        $("#tblServicesProduct tr:gt(0)").each(function() {

            var this_row = $(this);

            if ($.trim(this_row.find('td:eq(2)').html()) == $('#txtshortname').val() && $.trim(this_row.find('td:eq(1)').html()) != $('#txtItemCode').val() && $.trim(this_row.find('td:eq(3)').html()) != $('#txtedelivery').val() && $.trim(this_row.find('td:eq(4)').html()) != $("#txtPoNo").val() && $.trim(this_row.find('td:eq(5)').html()) != $("#txtPODate").val() && $.trim(this_row.find('td:eq(6)').html()) != $('#txtquantitiy').val() && $.trim(this_row.find('td:eq(7)').html()) != $('#dropuom').val()) {

                st = "false"

            }

        });
         if (st == "false") {
            error.show();
            $('#spandanger').html('Data already exists...');
            Metronic.scrollTo(error, -200);
            error.fadeOut(3000);
            return false;

        }
         else if ($('#dropuom').val() == '' || $('#txtUOM').val() == '') {
             $('.alert-danger').show();
             $('#spandanger').html('Please Select UOM Properly');
             Metronic.scrollTo($(".alert-danger"), -200);
             $('.alert-danger').fadeOut(7000);
             return false;
         }
        else {

            var this_row = $('#rowid').val();

            var this_row_Prev = $('#rowidPrev').val();
            $("#" + this_row).find("td:eq(1)").text($('#txtItemCode').val())
            $("#" + this_row).find("td:eq(2)").text($('#txtshortname').val())
            $("#" + this_row).find("td:eq(3)").text($('#txtedelivery').val())
            $("#" + this_row).find("td:eq(4)").text($('#txtPoNo').val())
           
            $("#" + this_row).find("td:eq(5)").text($('#txtPODate').val())

            $("#" + this_row).find("td:eq(6)").text($('#txtquantitiy').val())
            $("#" + this_row).find("td:eq(7)").text($('#dropuom').val())
            
            resetfun();

        }
    }

    else {

         if ($('#tblServicesProduct >tbody >tr').length == 0) {
                     ParametersQuery()
           }
            else {

                var status = "true";
             $("#tblServicesProduct tr:gt(0)").each(function() {

                    var this_row = $(this);

                    if ($.trim(this_row.find('td:eq(2)').html()) == $('#txtshortname').val()) {
                            status = "false"

                    }

                });

               
                if (status == "false") {
                    error.show();
                    $('#spandanger').html('Data already exists...');
                    Metronic.scrollTo(error, -200);
                    error.fadeOut(3000);
                    return false;

                }
                else if ($('#dropuom').val() == '' || $('#txtUOM').val() == '') {
                    $('.alert-danger').show();
                    $('#spandanger').html('Please Select UOM Properly');
                    Metronic.scrollTo($(".alert-danger"), -200);
                    $('.alert-danger').fadeOut(7000);
                    return false;
                }
                else {

                    ParametersQuery()

                }

            }

        }

}

var i = 0;
var z = 0;
var PriceDetails = '';

function ParametersQuery() {

   // z = z + 1
    i = $('#tblServicesProduct >tbody >tr').length;
   if (!jQuery("#tblServicesProduct thead").length) {
       jQuery("#tblServicesProduct").append("<thead><tr style='background: gray; color: #FFF;'><th 'width:20%!important;'></th><th>Item Code</th><th>Item/Service</th><th>Delivery Location</th><th>Po No</th><th>Po Delivery Date</th><th>Quantity</th><th>UOM</th></tr></thead>");
       jQuery("#tblServicesProduct").append('<tr id=trid' + i + '><td><button type="button" class="btn btn-xs btn-success" onclick="editvalues(trid' + i + ')" ><i class="fa fa-pencil"></i></button>&nbsp;<button class="btn  btn-xs btn-danger" onclick="deleterow(trid' + i + ')" ><i class="glyphicon glyphicon-remove-circle"></i></button></td><td  style="width:20%!important;">' + $('#txtItemCode').val() + '</td><td>' + $('#txtshortname').val() + '</td><td>' + $('#txtedelivery').val() + '</td><td>' + $('#txtPoNo').val() + '</td><td>' + $('#txtPODate').val() + '</td><td class=text-right>' + thousands_separators($('#txtquantitiy').val()) + '</td><td>' + $("#dropuom").val() + '</td></tr>');
    }
    else {
       
       jQuery("#tblServicesProduct").append('<tr id=trid' + i + '><td><button type="button" class="btn  btn-xs btn-success" onclick="editvalues(trid' + i + ')" ><i class="fa fa-pencil"></i></button>&nbsp<button class="btn  btn-xs btn-danger" onclick="deleterow(trid' + i + ')" ><i class="glyphicon glyphicon-remove-circle"></i></button></td><td style="width:20%!important;">' + $('#txtItemCode').val() + '</td><td>' + $('#txtshortname').val() + '</td><td>' + $('#txtedelivery').val() + '</td><td>' + $('#txtPoNo').val() + '</td><td>' + $('#txtPODate').val() + '</td><td class=text-right>' + thousands_separators($('#txtquantitiy').val()) + '</td><td>' + $("#dropuom").val() + '</td></tr>');
       
    }
   resetfun()

}

function editvalues(rowid) {

    
    Metronic.scrollTo($("body"), 200);
    $('#rowid').val(rowid.id)
   
    $('#txtItemCode').val($("#" + rowid.id).find("td:eq(1)").text())
    $('#txtshortname').val($("#" + rowid.id).find("td:eq(2)").text())
    $('#txtedelivery').val($("#" + rowid.id).find("td:eq(3)").text())
    //alert($("#" + rowid.id).find("td:eq(4)").text())
    $('#txtPoNo').val($("#" + rowid.id).find("td:eq(4)").text())
   
    $('#txtPODate').val($("#" + rowid.id).find("td:eq(5)").text())
    $('#txtquantitiy').val($("#" + rowid.id).find("td:eq(6)").text())
    $('#dropuom').val($("#" + rowid.id).find("td:eq(7)").text())
    $('#txtUOM').val($("#" + rowid.id).find("td:eq(7)").text())
    
    $('#add_or').text('Modify');

}

function deleterow(rowid) {

    $('#' + rowid.id).remove();
   
}
    function insPoDetails(){
       
        jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />Please Wait...</h5>' });
        if (jQuery('#file1').val() != '') {
            $('.alert-danger').show();
            $('#spandanger').html('Your file is not attached. Please do press "+" button after uploading the file.');
            Metronic.scrollTo($(".alert-danger"), -200);
            $('.alert-danger').fadeOut(7000);
           jQuery.unblockUI();
        }
        else {
            var rowCount = jQuery('#tblServicesProduct tr').length;
            if (rowCount > 0) {
                PriceDetails = '';
                $("#tblServicesProduct tr:gt(0)").each(function () {
                    var this_row = $(this);
                    PriceDetails = PriceDetails + ' insert into PODeliverySpread(POHeaderID,CustomerID,VendorID,ItemCode,ItemServiceName,DeliveryLocation,Quantity,UOM,PONo,PODeliveryDate,CreatedBy,CreatedOn) values('
                    var deliverylocation = $.trim(this_row.find('td:eq(3)').html()).replace(/'/g, "");
                    PriceDetails = PriceDetails +$('#hdnPOHeader').val()+","+ sessionStorage.getItem('CustomerID') + "," + sessionStorage.getItem('hdnVendorID') + ",'" + $.trim(this_row.find('td:eq(1)').html()) + "','" + $.trim(this_row.find('td:eq(2)').html()) + "','" + $.trim(deliverylocation) + "','" + $.trim(this_row.find('td:eq(6)').html()) + "','" + $.trim(this_row.find('td:eq(7)').html()) + "','" + this_row.find('td:eq(4)').html() + "','" + $.trim(this_row.find('td:eq(5)').html()) + "',dbo.decrypt('" + sessionStorage.getItem('UserID') + "'),getdate())";


                })
                //alert(BidDuration)
                //console.log(BidDuration)
                console.log(PriceDetails)
                var Tab2data = {
                    "PriceDetails": PriceDetails,
                    "VendorID": sessionStorage.getItem('hdnVendorID'),
                    "CustomerID": sessionStorage.getItem('CustomerID'),
                    "UserID": sessionStorage.getItem('UserID'),
                    "Flag": 'SendToVendor',
                    "POHeaderID": $('#hdnPOHeader').val(),
                    "UserRemarks": $('#txtvendorremarks').val()
                };

               // alert(JSON.stringify(Tab2data))
                jQuery.ajax({

                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    url: sessionStorage.getItem("APIPath") + "POUpload/InsDeliverySpread/",
                    beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
                    crossDomain: true,
                    async: false,
                    data: JSON.stringify(Tab2data),
                    dataType: "json",
                    success: function (data) {
                        if (data[0].OutPut == '1') {
                            if (AppType != 'Reverted') {
                                $('.alert-success').show();
                                $('#spansuccess1').html('PO sent to vendor successfully');
                                Metronic.scrollTo($(".alert-success"), -200);
                                $('.alert-success').fadeOut(7000);


                                resetfun();
                                resetForm();
                            }
                            else {
                                bootbox.alert("PO is now forwarded again to the vendor for acceptance.", function () {
                                    window.location = "index.html";
                                    return false;
                                });
                            }
                            
                            jQuery.unblockUI();
                        }
                        //else {
                        //    $('.alert-danger').show();
                        //    $('#add_submit').removeClass('hide');
                        //    $('#spandanger').html('Please Select UOM Properly');
                        //    Metronic.scrollTo($(".alert-danger"), -200);
                        //    $('.alert-danger').fadeOut(7000);
                        //    return false;

                        //}

                    },
                    error: function (xhr, status, error) {

                        var err = eval("(" + xhr.responseText + ")");
                        if (xhr.status === 401) {
                            error401Messagebox(err.Message);
                        }
                        else {
                            $('.alert-danger').show();
                            $('#spandanger').html('You have error. Please try again.');
                            Metronic.scrollTo($(".alert-danger"), -200);
                            $('.alert-danger').fadeOut(7000);
                        }

                        return false;
                        jQuery.unblockUI();
                    }
                   

                });
            }
        }
            //else {
            //    $('.alert-danger').show();
            //    $('#spandanger').html('You have error. Please try again.');
            //    Metronic.scrollTo($(".alert-danger"), -200);
            //    $('.alert-danger').fadeOut(7000);
            //    return false;
            //}
    }
    function resetForm() {
        $('#tblServicesProduct').empty();
        $('#tblAttachments').empty();
        //$('#tblAttachments').addClass('hide');
        $('#add_submit').addClass('hide');
        $('#txtVendorGroup').removeAttr('disabled')
        $('#txtVendor').removeAttr('disabled')
        $('#txtVendorGroup').val('');
        $('#txtVendor').val('');
        sessionStorage.setItem('hdnVendorID', '0')
        $('#txtvendorremarks').val('');
        
    }
var vendorsForAutoComplete=''
function fetchVendorGroup(categoryFor, vendorId) {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ProductandServiceCategory/fetchProductCategory/?CustomerID=" + sessionStorage.getItem('CustomerID') + "&For=" + categoryFor + "&MappedBy=" + sessionStorage.getItem('UserID') + "&VendorID=" + vendorId,
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        data: "{}",
        cache: false,
        dataType: "json",
        success: function (data) {
            
            if (data.length > 0) {
                vendorsForAutoComplete = data;
            }
            
            jQuery.unblockUI();
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else {
                $('.alert-danger').show();
                $('#spandanger').html('You have error. Please try again.');
                Metronic.scrollTo($(".alert-danger"), -200);
                $('.alert-danger').fadeOut(7000);
            }

            return false;
            jQuery.unblockUI();
        }
    });
}
jQuery("#txtVendorGroup").typeahead({
    source: function (query, process) {
        var data = vendorsForAutoComplete
        usernames = [];
        map = {};
        var username = "";
        jQuery.each(data, function (i, username) {
            map[username.CategoryName] = username;
            usernames.push(username.CategoryName);
        });

        process(usernames);

    },
    minLength: 2,
    updater: function (item) {
        if (map[item].CategoryID != "0") {
            getCategoryWiseVendors(map[item].CategoryID);
        }
        else {
            gritternotification('Please select Vendor  properly!!!');
        }

        return item;
    }

});
var vendor = "";

function getCategoryWiseVendors(categoryID) {

    jQuery.ajax({

        type: "GET",

        contentType: "application/json; charset=utf-8",

        url: sessionStorage.getItem("APIPath") + "ConfigureBid/FetchVendorCategoryWise_PEV2/?CustomerID=" + sessionStorage.getItem('CustomerID') + "&CategoryID=" + categoryID,
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,

        dataType: "json",

        success: function (data) {
            if (data.length) {
                vendor = data;
            }
            //jQuery("#tblvendorlist > tbody").empty();
            //var vName = '';
            //for (var i = 0; i < data.length; i++) {
            //    vName = data[i].VendorName;
            //    var str = "<tr><td class='hide'>" + data[i].VendorID + "</td><td><div class=\"checker\" id=\"uniform-chkbidTypes\"><span  id=\"spanchecked\"><input type=\"checkbox\" Onclick=\"Check(this,\'" + vName + "'\,\'" + data[i].VendorID + "'\)\"; id=\"chkvender" + data[i].VendorID + "\" value=" + data[i].VendorID + " style=\"cursor:pointer\" name=\"chkvender\"/></span></div></td><td> " + data[i].VendorName + " </td></tr>";

            //    jQuery('#tblvendorlist > tbody').append(str);

            //}
            
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else {
                $('.alert-danger').show();
                $('#spandanger').html('You have error. Please try again.');
                Metronic.scrollTo($(".alert-danger"), -200);
                $('.alert-danger').fadeOut(7000);
            }

            return false;
            jQuery.unblockUI();
        }

    });


}
jQuery("#txtVendor").keyup(function () {
    sessionStorage.setItem('hdnVendorID', '0');

});
sessionStorage.setItem('hdnVendorID', 0);
jQuery("#txtVendor").typeahead({
    source: function (query, process) {
        var data = vendor
        usernames = [];
        map = {};
        var username = "";
        jQuery.each(data, function (i, username) {
            map[username.VendorName] = username;
            usernames.push(username.VendorName);
        });

        process(usernames);

    },
    minLength: 2,
    updater: function (item) {
        if (map[item].VendorID != "0") {
            sessionStorage.setItem('hdnVendorID', map[item].VendorID)
        }
        else {
            gritternotification('Please select Vendor  properly!!!');
        }

        return item;
    }

});
function addAttachments() {
    if (jQuery('#file1').val() == "") {
        $('.alert-danger').show();
        $('#spandanger').html('Please Attach File Properly');
        Metronic.scrollTo($(".alert-danger"), -200);
        $('.alert-danger').fadeOut(7000);
        return false;
    }
    else if (sessionStorage.getItem('hdnVendorID') == "0") {
        $('.alert-danger').show();
        $('#spandanger').html('Please Select Vendor Properly');
        Metronic.scrollTo($(".alert-danger"), -200);
        $('.alert-danger').fadeOut(7000);
        return false;
    }
    else {
        var attchname = jQuery('#file1').val().substring(jQuery('#file1').val().lastIndexOf('\\') + 1)
        attchname = attchname.replace(/[&\/\\#,+$~%'":*?<>{}]/g, '_');
        var Attachments = {
            "CustomerID":sessionStorage.getItem('CustomerID'),
            "VendorID": sessionStorage.getItem('hdnVendorID'),
            "POAttachment": attchname,
            "UserID": sessionStorage.getItem('UserID'),
            "POHeaderID": $('#hdnPOHeader').val()
        }
       // alert(JSON.stringify(Attachments))
        jQuery.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: sessionStorage.getItem("APIPath") + "POUpload/AddPOFile",
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            crossDomain: true,
            async: false,
            data: JSON.stringify(Attachments),
            dataType: "json",
            success: function (data) {
              
                if (data.length > 0) {
                   
                    if (data[0].OutPut == "1") {
                        $('#hdnPOHeader').val(data[0].POHeaderID)
                        $('#txtVendorGroup').attr('disabled', 'disabled')
                        $('#txtVendor').attr('disabled', 'disabled')
                        fileUploader(data[0].POHeaderID)
                        
                        fetchAttachments()
                      
                        jQuery('#file1').val('')
                       // $('.alert-success').show();
                       // $('#spansuccess1').html('Attachment saved successfully!');
                        Metronic.scrollTo($(".alert-success"), -200);
                        $('.alert-success').fadeOut(7000);
                        return false;

                    }
                    else if (data[0].OutPut == "2") {
                        $('.alert-danger').show();
                        $('#spandanger').html('Attachment is already Exists.');
                        Metronic.scrollTo($(".alert-danger"), -200);
                        $('.alert-danger').fadeOut(7000);
                        return false;
                    }
                }

            },
            error: function (xhr, status, error) {

                var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }
                else {
                    $('.alert-danger').show();
                    $('#spandanger').html('You have error. Please try again.');
                    Metronic.scrollTo($(".alert-danger"), -200);
                    $('.alert-danger').fadeOut(7000);
                }

                return false;
                jQuery.unblockUI();
            }

        });
    }
}
function fileUploader(PoHeaderID) {
   
    var fileTerms = $('#file1');
    if ($('#file1').is('[disabled=disabled]')) {

        var fileDataTerms = $('#file1').prop("files")[0];

    }
    else {
        var fileDataTerms = fileTerms.prop("files")[0];
    }

    var formData = new window.FormData();

    formData.append("fileTerms", fileDataTerms);
    formData.append("fileAnyOther", '');
    formData.append("fileRFQAttach", '');
    formData.append("AttachmentFor", 'PO');
    formData.append("BidID", PoHeaderID);
    formData.append("VendorID", '');
    formData.append("Version", '');

    $.ajax({

        url: 'ConfigureFileAttachment.ashx',
        data: formData,
        processData: false,
        contentType: false,
        asyc: false,
        type: 'POST',
        success: function (data) {

        },

        error: function () {

            //jQuery.unblockUI();

        }

    });

}
function fetchAttachments() {
    //alert(sessionStorage.getItem("APIPath") + "POUpload/PODetails/?CustomerID=" + sessionStorage.getItem('CustomerID') + "&VendorID=" + sessionStorage.getItem('hdnVendorID') + "&UserID=" + sessionStorage.getItem('UserID') + "&Flag=Attachment&POHeaderID=" + $('#hdnPOHeader').val())
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "POUpload/PODetails/?CustomerID=" + sessionStorage.getItem('CustomerID') + "&VendorID=" + sessionStorage.getItem('hdnVendorID') + "&UserID=" + sessionStorage.getItem('UserID') + "&Flag=Attachment&POHeaderID=" + $('#hdnPOHeader').val(),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
            var attach = "";
            jQuery("#tblAttachments").empty();
          
            if (data.length > 0) {
               
                sessionStorage.setItem('hdnVendorID', data[0].VendorID);
                $('#txtVendor').val(data[0].VendorName)
                $('#txtvendorremarks').val(data[0].UserRemarks)
                jQuery('#tblAttachments').append("<thead><tr><th class='bold'>Attachment</th><th></th></tr></thead>");
                for (var i = 0; i < data.length; i++) {
                    attach = data[i].POAttachment.replace(/\s/g, "%20");
                    var str = "<tr><td style='width:47%!important'><a style='pointer:cursur;text-decoration:none;' target=_blank href=PortalDocs/eRFQ/" + sessionStorage.getItem("hdnVendorID") + '/' + attach + '>' + data[i].POAttachment + "</a></td>";
                    str += "<td style='width:5%!important'><button type='button' class='btn btn-xs btn-danger' id=Removebtnattach" + i + " onclick=fnRemoveAttachment(\'" + data[i].POID + "'\,\'POAttach'\)><i class='glyphicon glyphicon-remove-circle'></i></button></td></tr>";
                    jQuery('#tblAttachments').append(str);
                }
            }

            else {
                $('#txtVendorGroup').removeAttr('disabled')
                $('#txtVendor').removeAttr('disabled')
                jQuery('#tblAttachments').append("<tr><td>No Attachments!!</td></tr>")
            }

        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else {
                $('.alert-danger').show();
                $('#spandanger').html('You have error. Please try again.');
                Metronic.scrollTo($(".alert-danger"), -200);
                $('.alert-danger').fadeOut(7000);
            }

            return false;
            jQuery.unblockUI();
        }
    })
}
function fnRemoveAttachment(POID, deletionfor) {


    var Attachments = {
        "SrNo": POID,
        "DeletionFor": deletionfor,
        "RFQID": 0

    }
    jQuery.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "eRequestForQuotation/eRFQAttachmentQuesremove",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        crossDomain: true,
        async: false,
        data: JSON.stringify(Attachments),
        dataType: "json",
        success: function (data) {
            if (data.length > 0) {
                if (data[0].OutPut == "1") {
                    fetchAttachments();
                    $('.alert-success').show();
                    $('#spansuccess1').html('Record deleted successfully!');

                    Metronic.scrollTo($(".alert-success"), -200);
                    $('.alert-success').fadeOut(7000);

                    return false;
                }
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else {
                $('.alert-danger').show();
                $('#spandanger').html('You have error. Please try again.');
                Metronic.scrollTo($(".alert-danger"), -200);
                $('.alert-danger').fadeOut(7000);
            }

            return false;
            jQuery.unblockUI();
        }
    })
}
var allUOM = '';
function FetchUOM(CustomerID) {

    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "UOM/fetchUOMCust/?CustomerID=" + CustomerID,//  fetchUOM
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        dataType: "json",
        success: function (data) {
            jQuery("#txtUOM").empty();
            if (data.length > 0) {
                allUOM = data;
            }
            else {
                allUOM = '';
            }
           
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else {
                $('.alert-danger').show();
                $('#spandanger').html('You have error. Please try again.');
                Metronic.scrollTo($(".alert-danger"), -200);
                $('.alert-danger').fadeOut(7000);
            }

            return false;
            jQuery.unblockUI();
        }

    });

}
jQuery("#txtUOM").keyup(function () {
    $('#dropuom').val('')

});
jQuery("#txtUOM").typeahead({
    source: function (query, process) {
        var data = allUOM;
        usernames = [];
        map = {};
        var username = "";
        jQuery.each(data, function (i, username) {
            map[username.UOM] = username;
            usernames.push(username.UOM);
        });

        process(usernames);

    },
    minLength: 2,
    updater: function (item) {
        if (map[item].UOM != "") {
            $('#dropuom').val(map[item].UOM)

        }
        else {
            gritternotification('Please select UOM  properly!!!');
        }

        return item;
    }

});
$('#RAexcel').on("hidden.bs.modal", function () {
    $("#instructionsDivParameter").hide();
    $("#instructionSpanParameter").hide();
    $("#error-excelparameter").hide();
    $("#success-excelparameter").hide();
    $("#file-excelparameter").val('');
    $('#btnyesno').show()
    $('#modalLoaderparameter').addClass('display-none');
})
function fnNoUpload() {
    $("#instructionsDivParameter").hide();
    $("#instructionSpanParameter").hide();
    $("#error-excelparameter").hide();
    $("#success-excelparameter").hide();
    $("#file-excelparameter").val('');
    $('#RAexcel').modal('hide');
    $('#btnyesno').show()
    $('#modalLoaderparameter').addClass('display-none');
}


$("#btninstructionexcelparameter").click(function () {
    var ErrorUOMMsz = '<ul class="col-md-3 text-left">';
    var ErrorUOMMszRight = '<ul class="col-md-5 text-left">'
    var quorem = (allUOM.length / 2) + (allUOM.length % 2);
    for (var i = 0; i < parseInt(quorem) ; i++) {
        ErrorUOMMsz = ErrorUOMMsz + '<li>' + allUOM[i].UOM + '</li>';
        var z = (parseInt(quorem) + i);
        if (z <= allUOM.length - 1) {
            ErrorUOMMszRight = ErrorUOMMszRight + '<li>' + allUOM[z].UOM + '</li>';
        }
    }
    ErrorUOMMsz = ErrorUOMMsz + '</ul>'
    ErrorUOMMszRight = ErrorUOMMszRight + '</ul>'

    // alert(ErrorUOMMsz + ErrorUOMMszRight)
    $("#ULUOM_instructions").html(ErrorUOMMsz + ErrorUOMMszRight);
    if ($('#ddlbidclosetype').val() == "S") {
        $('#libidduraion').show()

    }
    else {
        $('#libidduraion').hide()

    }
    $("#instructionsDivParameter").show();
    $("#instructionSpanParameter").show();
});
function handleFileparameter(e) {

    //Get the files from Upload control
    var files = e.target.files;
    var i, f;
    //Loop through files
    for (i = 0, f = files[i]; i != files.length; ++i) {
        var reader = new FileReader();
        var name = f.name;
        reader.onload = function (e) {
            var data = e.target.result;

            var result;
            var workbook = XLSX.read(data, { type: 'binary' });

            var sheet_name_list = workbook.SheetNames;
            sheet_name_list.forEach(function (y) { /* iterate through sheets */
                //Convert the cell value to Json
                var roa = XLSX.utils.sheet_to_json(workbook.Sheets[y]);
                if (roa.length > 0) {
                    result = roa;
                }
            });
            //Get the first column first cell value
            //alert(JSON.stringify(result))
            printdataSeaBid(result)
        };
        reader.readAsArrayBuffer(f);
    }
}
var Rowcount = 0;
var ShowL1Price = ''
function printdataSeaBid(result) {
    var loopcount = result.length; //getting the data length for loop.

    var i;
    //var numberOnly = /^[0-9]+$/;
    var numberOnly = /^[0-9]\d*(\.\d+)?$/;
    $("#temptableForExcelDataparameter").empty();
    $("#temptableForExcelDataparameter").append("<tr><th style='width:20%!important;'>ItemCode</th><th>ItemService</th><th>DeliveryLocation</th><th  class=hide>Description</th><th>Quantity</th><th>UOM</th><th>PoNo</th><th>PoDeliveryDate</th></tr>");
    // checking validation for each row

    var pono = ''
    var podate = ''

    var itemcode = '', deliverylocation = '', deliverylocation = '', itemservicename = '', description = '';


    for (i = 0; i < loopcount; i++) {
        //alert($.trim(result[i].ItemBidDuration.trim()))
        itemcode = '', podate = '', pono = '', deliverylocation = '', itemservicename = '';

        if ($.trim(result[i].PoDeliveryDate) != '') {
            podate = $.trim(result[i].PoDeliveryDate);
        }
        if ($.trim(result[i].PoNo) != '') {
            pono = $.trim(result[i].PoNo);
        }

        if ($.trim(result[i].ItemCode) != '') {
            itemcode = $.trim(result[i].ItemCode);
        }
        if ($.trim(result[i].ItemService) != '') {
            itemservicename = $.trim(result[i].ItemService);
        }
        if ($.trim(result[i].DeliveryLocation) != '') {
            deliverylocation = $.trim(result[i].DeliveryLocation);
        }
        // alert(Povalue)
         if (sessionStorage.getItem('hdnVendorID') == '0') {
            $("#error-excelparameter").show();
            $("#errspan-excelparameter").html('Please Select Vendor First then Please fill and upload the file again.');
            $("#file-excelparameter").val('');
            return false;
        }
       else if ($.trim(result[i].ItemService) != '' && $.trim(result[i].ItemService).length > 200) {
            $("#error-excelparameter").show();
            $("#errspan-excelparameter").html('Item/Product/Services  length should be 200 characters of Item no ' + (i + 1) + ' . Please fill and upload the file again.');
            $("#file-excelparameter").val('');
            return false;
        }


        else if (!result[i].Quantity.trim().match(numberOnly) || result[i].Quantity.trim() == '') {

            $("#error-excelparameter").show();
            $("#errspan-excelparameter").html('Quantity should be in numbers only of Item no ' + (i + 1) + '.');
            $("#file-excelparameter").val('');
            return false;
        }
        else if ($.trim(result[i].UOM) == '') {
            $("#error-excelparameter").show();
            $("#errspan-excelparameter").html('Quantity UOM can not be blank of Item no ' + (i + 1) + '. Please fill and upload the file again.');
            $("#file-excelparameter").val('');
            return false;
        }
        
        else {

            // if values are correct then creating a temp table
            $("<tr><td>" + replaceQuoutesFromStringFromExcel(itemcode) + "</td><td>" + replaceQuoutesFromStringFromExcel(result[i].ItemService) + "</td><td class=hide>" + replaceQuoutesFromStringFromExcel(description) + "</td><td>" + replaceQuoutesFromStringFromExcel(deliverylocation) + "</td><td>" + result[i].Quantity + "</td><td>" + result[i].UOM + "</td><td>" + replaceQuoutesFromStringFromExcel(pono) + "</td><td>" + podate + "</td></tr>").appendTo("#temptableForExcelDataparameter");

        }


    } // for loop ends
    //  $('#txtBidDuration').val(totalitemdurationstagger);
    var excelCorrect = 'N';
    var excelCorrectUOM = 'N';
    var ErrorUOMMsz = '';
    var ErrorUOMMszRight = '';
    Rowcount = 0;
    // check for UOM
    $("#temptableForExcelDataparameter tr:gt(0)").each(function () {
        var this_row = $(this);
        excelCorrectUOM = 'N';
        Rowcount = Rowcount + 1;
        for (var i = 0; i < allUOM.length; i++) {
            if ($.trim(this_row.find('td:eq(5)').html()).toLowerCase() == allUOM[i].UOM.trim().toLowerCase()) {//allUOM[i].UOMID
                excelCorrectUOM = 'Y';
            }

        }
        var quorem = (allUOM.length / 2) + (allUOM.length % 2);
        if (excelCorrectUOM == "N") {
            $("#error-excelparameter").show();
            ErrorUOMMsz = 'UOM not filled properly at row no ' + Rowcount + '. Please choose UOM from given below: <br><ul class="col-md-5 text-left">';
            ErrorUOMMszRight = '<ul class="col-md-5 text-left">'
            for (var i = 0; i < parseInt(quorem) ; i++) {
                ErrorUOMMsz = ErrorUOMMsz + '<li>' + allUOM[i].UOM + '</li>';
                var z = (parseInt(quorem) + i);
                if (z <= allUOM.length - 1) {
                    ErrorUOMMszRight = ErrorUOMMszRight + '<li>' + allUOM[z].UOM + '</li>';
                }
            }
            ErrorUOMMsz = ErrorUOMMsz + '</ul>'
            ErrorUOMMszRight = ErrorUOMMszRight + '</ul><div class=clearfix></div><br/>and upload the file again.'

            // alert(ErrorUOMMsz + ErrorUOMMszRight)
            $("#errspan-excelparameter").html(ErrorUOMMsz + ErrorUOMMszRight);
            // $("#errspan-excelparameter").html('UOM not filled properly at row no ' + Rowcount + '. Please choose UOM from given below:');//at row no ' + Rowcount + '.
            return false;
        }
        if (excelCorrectUOM == 'Y') {
            $('#btnyesno').show();
            $("#error-excelparameter").hide();
            $("#errspan-excelparameter").html('');
            $("#success-excelparameter").show()
            $("#succspan-excelparameter").html('Excel file is found ok. Do you want to upload? \n This will clean your existing Data.')
            $("#file-excelparameter").val('');

            excelCorrectUOM = '';
        }
    });
}
    
function InsupdProductfromExcel() {
    $("#success-excelparameter").hide();
    $("#error-excelparameter").hide();
    $('#loader-msgparameter').html('Processing. Please Wait...!');
    $('#modalLoaderparameter').removeClass('display-none');
    
    var rowCount = jQuery('#temptableForExcelDataparameter tr').length;
    if (rowCount > 0) {
        PriceDetails = '';
        $("#temptableForExcelDataparameter tr:gt(0)").each(function () {
            var this_row = $(this);
            PriceDetails = PriceDetails + 'insert into PODeliverySpread(POHeaderID,CustomerID,VendorID,ItemCode,ItemServiceName,DeliveryLocation,Quantity,UOM,PONo,PODeliveryDate,CreatedBy,CreatedOn) values('
            var deliverylocation = $.trim(this_row.find('td:eq(3)').html()).replace(/'/g, "");
            PriceDetails = PriceDetails + $('#hdnPOHeader').val() +","+ sessionStorage.getItem('CustomerID') + "," + sessionStorage.getItem('hdnVendorID') + ",'" + $.trim(this_row.find('td:eq(0)').html()) + "','" + $.trim(this_row.find('td:eq(1)').html()) + "','" + $.trim(deliverylocation) + "','" + $.trim(this_row.find('td:eq(4)').html()) + "','" + $.trim(this_row.find('td:eq(5)').html()) + "','" + this_row.find('td:eq(6)').html() + "','" + $.trim(this_row.find('td:eq(7)').html()) + "',dbo.decrypt('" + sessionStorage.getItem('UserID') + "'),getdate())";
            

        })
        //alert(BidDuration)
        //console.log(BidDuration)
        console.log(PriceDetails)
        var Tab2data = {
            "PriceDetails": PriceDetails,
            "VendorID": sessionStorage.getItem('hdnVendorID'),
            "CustomerID": sessionStorage.getItem('CustomerID'),
            "UserID": sessionStorage.getItem('UserID'),
            "Flag": 'Insert',
            "POHeaderID": $('#hdnPOHeader').val(),
            "UserRemarks": $('#txtvendorremarks').val()
        };
       
       // alert(JSON.stringify(Tab2data))
        jQuery.ajax({

            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: sessionStorage.getItem("APIPath") + "POUpload/InsDeliverySpread/",
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            crossDomain: true,
            async: false,
            data: JSON.stringify(Tab2data),
            dataType: "json",
            success: function (data) {
                if (data[0].OutPut == '1') {
                   
                    $('#btnyesno').hide()
                    $("#success-excelparameter").show()
                    $("#succspan-excelparameter").html('Excel file uploaded sucessfully')
                    setTimeout(function () {
                        $('#modalLoaderparameter').addClass('display-none');
                        $('#RAexcel').modal('hide');
                        fetchDeliverySpread();
                    }, 1000)
                    return true;
                }
                else {
                    return false;
                }

            },
            error: function (xhr, status, error) {

                var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }
                else {
                    $('#modalLoaderparameter').addClass('display-none');
                    $("#error-excelparameter").show();
                    $("#errspan-excelparameter").html('You have error. Please try again.');
                }

                return false;
                jQuery.unblockUI();
            }
            
        });
    }
    else {
        $("#error-excelparameter").show();
        $("#errspan-excelparameter").html('No Items Found in Excel');
    }
}
function fetchDeliverySpread() {
   // alert(sessionStorage.getItem("APIPath") + "POUpload/PODetails/?CustomerID=" + sessionStorage.getItem('CustomerID') + "&VendorID=" + sessionStorage.getItem('hdnVendorID') + "&UserID=" + sessionStorage.getItem('UserID') + "&Flag=Details&POHeaderID=" + $('#hdnPOHeader').val())
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "POUpload/PODetails/?CustomerID=" + sessionStorage.getItem('CustomerID') + "&VendorID=" + sessionStorage.getItem('hdnVendorID') + "&UserID=" + sessionStorage.getItem('UserID') + "&Flag=Details&POHeaderID=" + $('#hdnPOHeader').val(),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
            var attach = "";
            jQuery("#tblServicesProduct").empty();
           
            if (data.length > 0) {
                $('#add_submit').removeClass('hide')
                jQuery("#tblServicesProduct").append("<thead><tr style='background: gray; color: #FFF;'><th 'width:20%!important;'></th><th>Item Code</th><th>Item/Service</th><th>Delivery Location</th><th>Po No</th><th>Po Delivery Date</th><th>Quantity</th><th>UOM</th></tr></thead>");
                
               // jQuery('#tblServicesProduct').append("<thead><tr><th class='bold'>Item Code</th><th  class='bold'>Item Name</th><th  class='bold'>Delivery Location</th><th  class='bold'>Quantity</th><th  class='bold'>UOM</th><th  class='bold'>Po No</th><th  class='bold'>PO Delivery Date</th></tr></thead>");
                for (var i = 0; i < data.length; i++) {
                    jQuery("#tblServicesProduct").append('<tr id=trid' + i + '><td><button type="button" class="btn btn-xs btn-success" onclick="editvalues(trid' + i + ')" ><i class="fa fa-pencil"></i></button>&nbsp;<button class="btn  btn-xs btn-danger" onclick="deleterow(trid' + i + ')" ><i class="glyphicon glyphicon-remove-circle"></i></button></td><td  style="width:20%!important;">' + data[i].ItemCode + '</td><td>' + data[i].ItemServiceName + '</td><td>' + data[i].DeliveryLocation + '</td><td>' + data[i].PONo + '</td><td>' + data[i].PODeliveryDate + '</td><td class=text-right>' + thousands_separators(data[i].Quantity) + '</td><td>' + data[i].UOM + '</td></tr>');
                   
                }
            }

            else {
                $('#add_submit').addClass('hide')
                jQuery('#tblAttachments').append("<tr><td>No Attachments!!</td></tr>")
            }
            jQuery.unblockUI();
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            
            return false;
            jQuery.unblockUI();
        }
    })
}
function resetfun() {
    $('#add_or').text('Add');
    
    $('#txtquantitiy').val('')
    $('#txtUOM').val('')
    $('#txtshortname').val('')
    $('#txtItemCode').val('')
    $('#txtedelivery').val('')
    $('#txtPODate').val('')
    $('#txtPoNo').val('')
    
}