﻿
var error = $('.alert-danger');
var success = $('.alert-success');

var form = $('#submit_form');


var Vehicleerror1 = $('#errordiv1');
var Vehiclesuccess1 = $('#successdiv1');
function formValidation() {
   
    $('#mapPrices').validate({
        errorElement: 'span', //default input error message container
        errorClass: 'help-block', // default input error message class
        focusInvalid: false, // do not focus the last invalid input
        rules: {
            txtbasicPrice: {
                required: true
            }
        },
        messages: {
        },
        invalidHandler: function (event, validator) { //display error alert on form submit   

        },

        highlight: function (element) { // hightlight error inputs
            $(element).closest('.col-md-6').addClass('has-error'); // set error class to the control group


        },
        unhighlight: function (element) { // revert the change done by hightlight
            $(element).closest('.col-md-6').removeClass('has-error'); // set error class to the control group

        },
        errorPlacement: function (error, element) {
            error.insertAfter(element);
        },

        success: function (label) {
            label.closest('.col-md-6').removeClass('has-error');
            label.remove();
        },
        submitHandler: function (form) {
            RFQinsertItemsTC('Y');
        }
    });

}


var FormWizard = function () {

    return {

        init: function () {

            if (!jQuery().bootstrapWizard) {

                return;

            }

            function format(state) {

                if (!state.id) return state.text; // optgroup

                return "<img class='flag' src='assets/global/img/flags/" + state.id.toLowerCase() + ".png'/>&nbsp;&nbsp;" + state.text;

            }


            form.validate({

                doNotHideMessage: true, //this option enables to show the error/success messages on tab switch.

                errorElement: 'span', //default input error message container

                errorClass: 'help-block help-block-error', // default input error message class

                focusInvalid: false, // do not focus the last invalid input

                rules: {

                },

                messages: {

                },

                errorPlacement: function (error, element) {

                    if (element.attr("name") == "gender") {

                        error.insertAfter("#form_gender_error");

                    } else if (element.attr("name") == "payment[]") {

                        error.insertAfter("#form_payment_error");

                    } else if (element.attr("name") == "txtPODate") {
                        error.insertAfter("#daterr");
                    }
                    else {

                        error.insertAfter(element);

                    }

                    if ($("#txtPODate").closest('.input-group').attr('class') == 'input-group has-error') {

                        $("#btncal").css("margin-top", "-22px");

                    }

                },

                invalidHandler: function (event, validator) {

                },

                highlight: function (element) {

                    $(element)

                        .closest('.inputgroup').removeClass('has-success').addClass('has-error');

                    $(element)

                         .closest('.col-md-4,.xyz').removeClass('has-success').addClass('has-error');

                },

                unhighlight: function (element) {

                    $(element)

                        .closest('.inputgroup').removeClass('has-error');
                    $(element)

                        .closest('.col-md-4,.xyz').removeClass('has-error');

                },

                success: function (label) {

                    if (label.attr("for") == "gender" || label.attr("for") == "payment[]") {

                        label.closest('.inputgroup').removeClass('has-error').addClass('has-success');
                         label.closest('.col-md-4,.xyz').removeClass('has-error').addClass('has-success');

                       

                        label.remove();

                    } else {

                        label.addClass('valid') // mark the current input as valid and display OK icon

                          

                        .closest('.inputgroup').removeClass('has-error').addClass('has-success'); // set success class to the control group
                        label.closest('.col-md-4,.xyz').removeClass('has-error').addClass('has-success'); // set success class to the control group

                    }



                },

                submitHandler: function (form) {
                    // success.show();
                    error.hide();
                }
            });



            var displayConfirm = function () {
                $('#tab4 .form-control-static', form).each(function () {

                    var input = $('[name="' + $(this).attr("data-display") + '"]', form);

                    if (input.is(":radio")) {

                        input = $('[name="' + $(this).attr("data-display") + '"]:checked', form);

                    }

                    if (input.is(":text") || input.is("textarea")) {

                        $(this).html(input.val());

                    } else if (input.is("select")) {

                        $(this).html(input.find('option:selected').text());

                    } else if (input.is(":radio") && input.is(":checked")) {

                        $(this).html(input.attr("data-title"));

                    } else if ($(this).attr("data-display") == 'payment') {

                        var payment = [];

                        $('[name="payment[]"]:checked').each(function () {

                            payment.push($(this).attr('data-title'));

                        });

                        $(this).html(payment.join("<br>"));

                    }

                });

            }



            var handleTitle = function (tab, navigation, index) {

                var total = navigation.find('li').length;

                var current = index + 1;

                // set wizard title

                $('.step-title', $('#form_wizard_1')).text('Step ' + (index + 1) + ' of ' + total);

                // set done steps

                jQuery('li', $('#form_wizard_1')).removeClass("done");

                var li_list = navigation.find('li');

                for (var i = 0; i < index; i++) {

                    jQuery(li_list[i]).addClass("done");

                }



                if (current == 1) {
                    $('#form_wizard_1').find('.button-previous').hide();

                } else {
                    $('#form_wizard_1').find('.button-previous').show();

                }

                if (current >= total) {
                    $('#form_wizard_1').find('.button-next').hide();
                    $('#form_wizard_1').find('.button-submit').show();

                    displayConfirm();

                } else {

                    $('#form_wizard_1').find('.button-next').show();

                    $('#form_wizard_1').find('.button-submit').hide();

                }

                Metronic.scrollTo($('.page-title'));

            }



            // default form wizard

            $('#form_wizard_1').bootstrapWizard({

                'nextSelector': '.button-next',
                'previousSelector': '.button-previous',

                onTabClick: function (tab, navigation, index, clickedIndex) {
                    return false;
                },

                onNext: function (tab, navigation, index) {
                    
                    if (index == 1) {
                        
                    }
                    else if (index == 2) {
                       
                        var flag = "T";
                        var rowCount = jQuery('#tblRFQLevelTCForQuot tr').length;
                       
                        var count = 1;
                        for (i = 0; i < rowCount-1;i++){
                            if ($("#commremarks" + i).val() == "") {
                                $('#commremarks' + i).removeClass('has-success')
                                $('#commremarks' + i).css("border", "1px solid red")
                                flag = "F";
                                // $('#form_wizard_1').bootstrapWizard('previous');
                                $('.alert-danger').show();
                                $('#spandanger').html('Please fill RFQ Commercial Terms.');
                                 Metronic.scrollTo($(".alert-danger"), -200);
                                $('.alert-danger').fadeOut(7000);
                                count = count + 1;
                            }
                            else {
                                flag="T"
                            }
                        }
                        if (flag == "F" ) {//&& (rowCount-1) == count
                            return false;
                        }
                        //else {

                        //}
                        if (flag == "T") {
                           saveQuotation();
                        }

                    }
                    else if (index == 3) {
                       
                        if (jQuery('#fileToUpload1').val() != "") {
                            $('.alert-danger').show();
                            $('#spandanger').text('Your file is not attached. Please do press "+" button after uploading the file.');
                            Metronic.scrollTo($(".alert-danger"), -200);
                            $('.alert-danger').fadeOut(7000);
                            return false;
                        }
                    }
                    handleTitle(tab, navigation, index);

                },

                onPrevious: function (tab, navigation, index) {
                    success.hide();
                    error.hide();
                    handleTitle(tab, navigation, index);

                },

                onTabShow: function (tab, navigation, index) {

                    var total = navigation.find('li').length;
                    var current = index + 1;
                    var $percent = (current / total) * 100;

                    $('#form_wizard_1').find('.progress-bar').css({
                        width: $percent + '%'
                    });
                }

            });

            $('#form_wizard_1').find('.button-previous').hide();

            $('#form_wizard_1 .button-submit').click(function () {
                var flagQ = "T";
                var rowCountQ = jQuery('#tblquestions tr').length;
                
                var countQ = 1;
                for (i = 0; i < rowCountQ - 1; i++) {
                    if ($("#answers" + i).val() == "") {
                        $('#answers' + i).removeClass('has-success')
                        $('#answers' + i).css("border", "1px solid red")
                        flagQ = "F";
                        // $('#form_wizard_1').bootstrapWizard('previous');
                        $('.alert-danger').show();
                        $('#spandanger').html('Please fill RFQ Answer.');
                        Metronic.scrollTo($(".alert-danger"), -200);
                        $('.alert-danger').fadeOut(7000);
                        countQ = countQ + 1;
                    }
                    else {
                        flagQ = "T"
                    }
                }
                if (flagQ == "F" ) {//&& rowCountQ == countQ
                    return false;
                }
                else if (jQuery('#fileToUpload1').val() != "") {
                    $('.alert-danger').show();
                    $('#spandanger').text('Your file is not attached. Please do press "+" button after uploading the file.');
                    Metronic.scrollTo($(".alert-danger"), -200);
                    $('.alert-danger').fadeOut(7000);
                    return false;
                }
                if (flagQ == "T") {
                    addQuestionAnswer('N');
                    $('#BidPreviewDiv').show();
                    $('#form_wizard_1').hide();
                    return true;
                }
              
               
            }).hide();



            //unblock code
            jQuery.unblockUI();
        }

    };

}();


sessionStorage.setItem('CurrentrfiID', 0)
sessionStorage.setItem('CurrentRFQParameterId', 0)
$(document).on('keyup', '.form-control', function () {
    if ($.trim($('.form-control').val()).length) {
        $(this).addClass('has-success');
    }
});

    function fncheckItemWiseTC(ver, BoqPID) {
    
             jQuery.ajax({
                type: "GET",
                contentType: "application/json; charset=utf-8",
                url: sessionStorage.getItem("APIPath") + "eRFQVendor/efetchRFQParameterlastquotes/?RFQId=" + sessionStorage.getItem('hddnRFQID') + "&VendorID=" + sessionStorage.getItem('VendorId') + "&RFQVersionId=" + ver + "&RFQPID=" + BoqPID + "&Flag=ForTC",
                beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
                data: "{}",
                cache: false,
                dataType: "json",
                success: function (data) {
                    if (data.length > 0) {
                        fetchRFQParameterComponent(ver, BoqPID);
                    }
                    else {
                        fetchRFQParameterComponent(ver - 1, BoqPID);
                    }


                },
                error: function (xhr, status, error) {

                    var err = eval("(" + xhr.responseText + ")");
                    if (xhr.status === 401) {
                        error401Messagebox(err.Message);
                    }
                    else{
                        alert("error");
                    }
                    return false;
                    jQuery.unblockUI();
                }
                
            });
        }
    function fetchAttachments() {
            jQuery.ajax({
                type: "GET",
                contentType: "application/json; charset=utf-8",
                url: sessionStorage.getItem("APIPath") + "eRequestForQuotation/eRFQDetails/?RFQID=" + sessionStorage.getItem('hddnRFQID') + "&CustomerID=" + sessionStorage.getItem('CustomerID') + "&UserID=" + sessionStorage.getItem('UserID'),
                beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
                cache: false,
                crossDomain: true,
                dataType: "json",
                success: function (data, status, jqXHR) {
           
                    jQuery("#tblAttachments").empty();
                    jQuery("#tblotherrfqattachmentprev").empty();
                    if (data[0].Attachments.length > 0) {
                        jQuery("#tblAttachments").append("<thead><tr  style='background: gray; color: #FFF;'><th class='bold' style='width:50%!important'>Description</th><th style='width:50%!important'>Attachment</th></tr></thead>")
                        jQuery("#tblotherrfqattachmentprev").append("<thead><tr  style='background: gray; color: #FFF;'><th class='bold' style='width:50%!important'>Description</th><th style='width:50%!important'>Attachment</th></tr></thead>")
                        $('#div_attachments').removeClass('hide')
                        $('#div_otherrfqattachprev').removeClass('hide')
                        $('#headerotherrfqattach').removeClass('hide')
                        $('#wrap_scrollerPrevAtt').show();
                        for (var i = 0; i < data[0].Attachments.length; i++) {
                            var str = "<tr><td style='width:50%!important'>" + data[0].Attachments[i].RFQAttachmentDescription + "</td>";
                            str += '<td class=style="width:50%!important"><a style="pointer:cursur;text-decoration:none;" target=_blank href=PortalDocs/eRFQ/' + sessionStorage.getItem('hddnRFQID') + '/' + data[0].Attachments[i].RFQAttachment.replace(/\s/g, "%20") + '>' + data[0].Attachments[i].RFQAttachment + '</a></td>';
                            jQuery('#tblAttachments').append(str);
                            jQuery('#tblotherrfqattachmentprev').append(str);
                        }
                    }
                    else {
                        $('#div_attachments').addClass('hide')
                        $('#div_otherrfqattachprev').addClass('hide')
                        $('#headerotherrfqattach').addClass('hide')
                    }

                },
                error: function (xhr, status, error) {

                    var err = eval("(" + xhr.responseText + ")");
                    if (xhr.status === 401) {
                        error401Messagebox(err.Message);
                    }
                    
                    return false;
                    jQuery.unblockUI();
                }
            })
        }

    function fetchRFQParameterComponent(version, BoqPID) {
       // alert(sessionStorage.getItem("APIPath") + "eRequestForQuotation/eRFQfetchTCQuotation/?RFQId=" + sessionStorage.getItem("hddnRFQID") + "&ParameterID=" + BoqPID + "&VendorID=" + sessionStorage.getItem("VendorId") + "&RFQVersionId=" + version)
    
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "eRequestForQuotation/eRFQfetchTCQuotation/?RFQId=" + sessionStorage.getItem("hddnRFQID") + "&ParameterID=" + BoqPID + "&VendorID=" + sessionStorage.getItem("VendorId") + "&RFQVersionId=" + version,
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        data: "{}",
        cache: false,
        dataType: "json",
        success: function (data) {
           
            jQuery('#icon').html('<i class="fa fa-list-ul"></i>');
            jQuery("#tblRFQParameterComponet").empty();
            $('#scrolr').show();
          
            if (data.length > 0) {
              
                jQuery("#tblRFQParameterComponet").append("<thead><tr style='background: gray; color: #FFF;'><th>Commercial Terms</th><th>Applicable Rate (%)</th></tr></thead>");
                for (var i = 0; i < data.length; i++) {
                 
                    // jQuery('<tr id=trid' + i + '><td class=hidden >' + data[i].RFQParameterId + '</td><td class=hidden >' + data[i].RFQID + '</td><td>' + data[i].ConditionType + '</td><td>' + data[i].TCName + '</td><td><input type="text"  id="mks1' + i + '" class="form-control input-circle text-right" value="' + thousands_separators(data[i].RFQVendorPrice) + '"  autocomplete=off onkeyup=thousands_separators_input(this) /></td><td><input type="text"  id="mkswithtax1' + i + '" class="form-control input-circle text-right" value="' + thousands_separators(data[i].RFQVendorPricewithTax) + '"  autocomplete=off onkeyup=thousands_separators_input(this) /></td></tr>').appendTo("#tblRFQParameterComponet");
                  ///  if (data[i].isDefault == "N") {
                        jQuery('<tr id=trid' + i + '><td class=hidden >' + data[i].RFQParameterId + '</td><td class=hidden >' + data[i].RFQID + '</td><td class=hidden >' + data[i].TCID + '</td><td>' + data[i].TCName + '</td><td><input type="text"  id="mkswithtax1' + i + '" class="form-control text-right" value="' + thousands_separators(data[i].RFQVendorPricewithTax) + '"  autocomplete=off   onkeyup="this.value = minmax(this.value, 0, 50)" /></td></tr>').appendTo("#tblRFQParameterComponet");
                       
                   // }
                }
            }
            else {

                jQuery("#tblRFQParameterComponet").append('<tr><td>No Information is there..</td></tr>');
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else{
                alert("error");
            }      
            return false;
            jQuery.unblockUI();
        }
       
    });
    }

    function fetchRFQLevelTC(ver) {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "eRequestForQuotation/eRFQfetchTCQuotation/?RFQId=" + sessionStorage.getItem("hddnRFQID") + "&ParameterID=" + 0 + "&VendorID=" + sessionStorage.getItem("VendorId") + "&RFQVersionId=" + ver,
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        data: "{}",
        cache: false,
        dataType: "json",
        success: function (data) {
            jQuery('#icon').html('<i class="fa fa-list-ul"></i>');
            jQuery("#tblRFQLevelTCForQuot").empty(); 
            jQuery("#tbltermsconditionprev").empty();
            $('#scrolr').show();
            //alert(JSON.stringify(data))
            if (data.length > 0) {
                // jQuery("#tblRFQLevelTCForQuot").append("<thead><tr style='background: gray; color: #FFF;'><th>Condition Type</th><th>Terms</th><th>Quoted Price (Unit Rate - Ex. Taxes)</th><th>Quoted Price(Unit Rate - Incl.Taxes)</th></tr></thead>");
                jQuery("#tblRFQLevelTCForQuot").append("<thead><tr style='background: gray; color: #FFF;'><th>Other Commercial Terms</th><th>Our Requirement</th><th>Your Offer</th></tr></thead>");
                jQuery("#tbltermsconditionprev").append("<thead><tr style='background: gray; color: #FFF;'><th>Other Commercial Terms</th><th>Our Requirement</th><th>Your Offer</th></tr></thead>");
                for (var i = 0; i < data.length; i++) {
                    jQuery('<tr id=trid' + i + '><td class=hidden>' + data[i].TCID + '</td><td class=hidden >' + data[i].RFQID + '</td><td class=hide>' + data[i].ConditionType + '</td><td style="width:20%">' + data[i].TCName + '</td><td>'+ data[i].Requirement +'</td><td><textarea name=comm rows=2 class="form-control"  autocomplete=off id=commremarks' + i + ' >' + data[i].RFQRemark + '</textarea></td></tr>').appendTo("#tblRFQLevelTCForQuot");
                    jQuery('<tr id=trid' + i + '><td class=hidden>' + data[i].TCID + '</td><td class=hidden >' + data[i].RFQID + '</td><td class=hide>' + data[i].ConditionType + '</td><td style="width:20%">' + data[i].TCName + '</td><td>' + data[i].Requirement + '</td><td><label class="control-label" >' + data[i].RFQRemark + '</label></td></tr>').appendTo("#tbltermsconditionprev");
                }
            }
            else {

                jQuery("#tblRFQLevelTCForQuot").append('<thead><td>No Other Specified Commecial Terms..</td></thead>');
                jQuery("#tbltermsconditionprev").append('<thead><td>No Other Specified Commecial Terms..</td></thead>');
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else{
                alert("error");
            }      
            return false;
            jQuery.unblockUI();
        }
       
    });
}
   
    function addmoreattachments() {
        if (jQuery("#AttachDescription1").val() == "") {
            $('.alert-danger').show();
            $('#spandanger').text('Please Enter Attachment Description');
            Metronic.scrollTo($(".alert-danger"), -200);
            $('.alert-danger').fadeOut(7000);
            return false;
        }
        else if (jQuery('#fileToUpload1').val() == "") {
            $('.alert-danger').show();
            $('#spandanger').text('Please Attach File Properly');
            Metronic.scrollTo($(".alert-danger"), -200);
            $('.alert-danger').fadeOut(7000);
            return false;
        }
        else {
            var attchname = jQuery('#fileToUpload1').val().substring(jQuery('#fileToUpload1').val().lastIndexOf('\\') + 1)
            attchname = attchname.replace(/[&\/\\#,+$~%'":*?<>{}]/g, '_');
            var Attachments = {

                "RFQId": sessionStorage.getItem('hddnRFQID'),
                "VendorID": sessionStorage.getItem('VendorId'),
                "Version": sessionStorage.getItem('RFQVersionId'),
                "Attachmentdescription": jQuery("#AttachDescription1").val(),
                "Attachment": attchname

            }
           // alert(JSON.stringify(Attachments))
            jQuery.ajax({
                type: "POST",
                contentType: "application/json; charset=utf-8",
                url: sessionStorage.getItem("APIPath") + "eRFQVendor/eInsRFQVendorAttachments",
                beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
                crossDomain: true,
                async: false,
                data: JSON.stringify(Attachments),
                dataType: "json",
                success: function (data) {

                    if (data.length > 0) {

                        if (data[0].OutPut == "1") {
                            fileUploader(sessionStorage.getItem('hddnRFQID'), sessionStorage.getItem('VendorId'), sessionStorage.getItem('RFQVersionId'))
                            
                            fetchRFQResponse('Attachment', sessionStorage.getItem('RFQVersionId'))
                            jQuery("#AttachDescription1").val('')
                            jQuery('#fileToUpload1').val('')
                            $('.alert-success').show();
                            $('#spansuccess1').html('Attachment saved successfully!');
                            Metronic.scrollTo($(".alert-success"), -200);
                            $('.alert-success').fadeOut(7000);
                            return false;

                        }
                        else if (data[0].OutPut == "2") {
                            $('.alert-danger').show();
                            $('#spandanger').text('File already Exists at this version.');
                            Metronic.scrollTo($(".alert-danger"), -200);
                            $('.alert-danger').fadeOut(7000);
                            return false;
                        }
                    }

                },
                error: function (xhr, status, error) {

                    var err = eval("(" + xhr.responseText + ")");
                    if (xhr.status === 401) {
                        error401Messagebox(err.Message);
                    }
                   
                    return false;
                    jQuery.unblockUI();
                }

            });
        }
    }
    function fetchRFQResponseTocheckVersion(Flag, ver) {
        jQuery.ajax({
            type: "GET",
            contentType: "application/json; charset=utf-8",
            url: sessionStorage.getItem("APIPath") + "eRFQVendor/efetchVendorResponsechkversionAttachQues/?RFQId=" + sessionStorage.getItem('hddnRFQID') + "&VendorID=" + sessionStorage.getItem('VendorId') + "&RFQVersionId=" + ver + "&Flag=" + Flag,
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            data: "{}",
            cache: false,
            dataType: "json",
            success: function (data) {
                if (Flag == 'Question') {
                    if (data.length > 0) {
                        fetchRFQResponse(Flag,ver)
                    }
                    else {
                        fetchRFQResponse(Flag, ver-1)
                    }
                }
                else {
                    if (data.length > 0) {
                        fetchRFQResponse(Flag, ver)
                    }
                    else {
                        fetchRFQResponse(Flag, ver - 1)
                    }
                }
            },
            error: function (xhr, status, error) {

                var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }
                
                return false;
                jQuery.unblockUI();
            }
        });
    }
    function fetchRFQResponse(Flag,version) {
       
        var strprev = "";
       // alert(sessionStorage.getItem("APIPath") + "eRFQVendor/efetchVendorResponse/?RFQId=" + sessionStorage.getItem('hddnRFQID') + "&VendorID=" + sessionStorage.getItem('VendorId') + "&RFQVersionId=" + sessionStorage.getItem('RFQVersionId') + "&Flag=" + Flag)
        jQuery.ajax({
            type: "GET",
            contentType: "application/json; charset=utf-8",
            url: sessionStorage.getItem("APIPath") + "eRFQVendor/efetchVendorResponse/?RFQId=" + sessionStorage.getItem('hddnRFQID') + "&VendorID=" + sessionStorage.getItem('VendorId') + "&RFQVersionId=" + version + "&Flag=" + Flag,
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            data: "{}",
            cache: false,
            dataType: "json",
            success: function (data) {
                if (Flag == 'Question') {
                    jQuery("#tblquestions").empty();
                    jQuery("#tblQuestionsPrev").empty();
                    
                   if (data.length > 0) {
                       $('#headerspecificresponse').removeClass('hide')
                       $('#divspecificresponse').removeClass('hide')
                       jQuery('#tblquestions').append("<thead><tr  style='background: gray; color: #FFF;'><th class='bold' style='width:30%!important'>Questions</th><th class='bold' style='width:30%!important'>Our Requirement</th><th style='width:40%!important'>Answer</th></tr></thead>");
                       jQuery('#tblQuestionsPrev').append("<thead><tr  style='background: gray; color: #FFF;'><th class='bold' style='width:30%!important'>Questions</th><th class='bold' style='width:30%!important'>Our Requirement</th><th style='width:40%!important'>Answer</th></tr></thead>");

                       for (var i = 0; i < data.length; i++) {
                        
                           str = "<tr><td style='width:30%!important'>" + data[i].RFQQuestions + "</td>";
                           strprev = "<tr><td style='width:30%!important'>" + data[i].RFQQuestions + "</td>";
                           str += "<td style='width:30%!important'>" + data[i].RFQQuestionsRequirement + "</td>";
                           strprev += "<td style='width:30%!important'>" + data[i].RFQQuestionsRequirement + "</td>";
                           str += "<td class='hide'>" + data[i].QuestionID + "</td>";
                           str += '<td style="width:40%!important"><textarea type=text class="form-control" autocomplete="off" id=answers' + i + '>' + data[i].Answer + '</textarea></td></tr>';
                           strprev += '<td style="width:40%!important"><label class="control-label" >' + data[i].Answer + '</label></td></tr>';
                           jQuery('#tblquestions').append(str);
                           jQuery('#tblQuestionsPrev').append(strprev);

                       }
                   }
                   else {
                       $('#headerspecificresponse').addClass('hide')
                       $('#divspecificresponse').addClass('hide')
                   }
                 }
                else {
                    
                    jQuery("#tblAttachmentsresponse").empty();
                    jQuery("#tblAttachmentsPrev").empty();
                   if (data.length > 0) {
                       $('#headerresposeatt').removeClass('hide')
                       $('#dicresponseatt').removeClass('hide')
                       jQuery('#tblAttachmentsresponse').append("<thead><tr  style='background: gray; color: #FFF;'><th class='bold' style='width:50%!important'>Description</th><th style='width:50%!important'>Attachment</th><th></th></tr></thead>");
                       jQuery('#tblAttachmentsPrev').append("<thead><tr  style='background: gray; color: #FFF;'><th class='bold' style='width:50%!important'>Description</th><th style='width:50%!important'>Attachment</th></tr></thead>");

                        for (var i = 0; i < data.length; i++) {
                            var str = "<tr><td style='width:47%!important'>" + data[i].Attachmentdescription + "</td>";
                            str += '<td class=style="width:47%!important"><a style="pointer:cursur;text-decoration:none;" target=_blank href=PortalDocs/eRFQ/' + sessionStorage.getItem("hddnRFQID") + '/' + sessionStorage.getItem('VendorId') + '/' + sessionStorage.getItem('RFQVersionId') + '/' + data[i].Attachment.replace(/\s/g, "%20") + '>' + data[i].Attachment + '</a></td>';
                            jQuery('#tblAttachmentsPrev').append(str);
                            str += "<td style='width:5%!important'><button type='button' class='btn btn-xs btn-danger' id=Removebtnattach" + i + " onclick=fnRemoveAttachmentQues(\'" + data[i].ID + "'\,\'VAttachment'\)><i class='glyphicon glyphicon-remove-circle'></i></button></td></tr>";
                           
                            if (parseInt(sessionStorage.getItem('RFQVersionId')) > version) {
                                $('#Removebtnattach' + i).attr('disabled', 'disabled')
                                }
                            else {
                                $('#Removebtnattach' + i).removeAttr('disabled')
                            }
                            jQuery('#tblAttachmentsresponse').append(str);

                        }
                    }
                   else {
                       $('#headerresposeatt').addClass('hide')
                       $('#dicresponseatt').addClass('hide')
                   }

                }
               
            },
            error: function (xhr, status, error) {

                var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }
                
                return false;
                jQuery.unblockUI();
            }
            
        })
    }
    function addQuestionAnswer(ismailsent) {
       
        var QuestionDetails = '';

        $("#tblquestions > tbody > tr").each(function () {
            var this_row = $(this);
            QuestionDetails = QuestionDetails + " select " + sessionStorage.getItem('VendorId') + "," + sessionStorage.getItem('hddnRFQID') + "," + sessionStorage.getItem('RFQVersionId') + " ," + $.trim(this_row.find('td:eq(2)').text()) + ",'" +$.trim(this_row.find('td:eq(3)').find('textarea').val()).replace(/'/g, "''")  + "' union all ";
        });

       
        if (QuestionDetails != '') {
            QuestionDetails = 'Insert into eRFQVendorQuestionAnswer (VendorID,RFQId,Version,QuestionID,Answer) ' + QuestionDetails
            QuestionDetails = QuestionDetails.substring(0, QuestionDetails.length - 11);
        }
            console.log(QuestionDetails)
            var Tab2data = {
                "QuestionDetails": QuestionDetails,
                "RFQID": sessionStorage.getItem('hddnRFQID'),
                "VendorID": sessionStorage.getItem('VendorId'),
                "Version": sessionStorage.getItem('RFQVersionId'),
                "IsMailsent": ismailsent,
                "UserName": sessionStorage.getItem('UserName'),
                "UserEmail": sessionStorage.getItem('EmailID'),
                "CustomerID": sessionStorage.getItem('CustomerID')
            }
            // alert(QuestionDetails)
           //  alert(JSON.stringify(Tab2data))
            jQuery.ajax({

                type: "POST",
                contentType: "application/json; charset=utf-8",
                url: sessionStorage.getItem("APIPath") + "eRFQVendor/eRFQVendorQusetionAnswer/",
                beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
                crossDomain: true,
                async: false,
                data: JSON.stringify(Tab2data),
                dataType: "json",
                success: function (data) {

                    setTimeout(function () {
                        if (data[0].RFQID > 0) {
                            fetchRFQResponse('Question', sessionStorage.getItem('RFQVersionId'))
                            if (ismailsent == "Y") {

                                bootbox.alert("RFQ response submitted and forwarded to company.", function () {
                                    //window.location = sessionStorage.getItem('MainUrl');
                                    if (sessionStorage.getItem("ISFromSurrogateRFQ") == "Y") {
                                        window.location = sessionStorage.getItem('HomePage');
                                        sessionStorage.clear();
                                    }
                                    else {
                                        window.location = 'VendorHome.html';
                                    }
                                    

                                    return false;
                                });
                                return true;
                            }
                        }
                        else {
                            return false;
                        }
                       
                    }, 500)
                    //alert(data[0].RFQID)
                    if (data[0].RFQID == 0) {
                        bootbox.alert("Error connecting server. Please try later.");
                    }
                },
                error: function (xhr, status, error) {

                    var err = eval("(" + xhr.responseText + ")");
                    if (xhr.status === 401) {
                        error401Messagebox(err.Message);
                    }

                    return false;
                    jQuery.unblockUI();
                }
            });
       
    }
    function fnRemoveAttachmentQues(srno, deletionfor) {
        var Attachments = {
            "SrNo": srno,
            "DeletionFor": deletionfor,
            "RFQID": sessionStorage.getItem('hddnRFQID')

        }
        jQuery.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: sessionStorage.getItem("APIPath") + "eRequestForQuotation/eRFQAttachmentQuesremove",
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            crossDomain: true,
            async: false,
            data: JSON.stringify(Attachments),
            dataType: "json",
            success: function (data) {
                if (data.length > 0) {
                   
                    if (data[0].OutPut == "1") {
                        fetchRFQResponse('Attachment', sessionStorage.getItem('RFQVersionId'))
                        $('.alert-success').show();
                        $('#spansuccess1').html('Record deleted successfully!');
                         Metronic.scrollTo($(".alert-success"), -200);
                        $('.alert-success').fadeOut(7000);
                        return false;
                    }
                }
            },
            error: function (xhr, status, error) {

                var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }

                return false;
                jQuery.unblockUI();
            }
        })
    }
    var currentdate = new Date();
    function fetchReguestforQuotationDetails() {
        // jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
        var replaced1 = '';

        jQuery.ajax({
            contentType: "application/json; charset=utf-8",
            url: sessionStorage.getItem("APIPath") + "eRequestForQuotation/eRFQDetails/?RFQID=" + sessionStorage.getItem('hddnRFQID') + "&CustomerID=" + sessionStorage.getItem('CustomerID') + "&UserID=" + sessionStorage.getItem('UserID'),
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            type: "GET",
            cache: false,
            crossDomain: true,
            dataType: "json",
            success: function (RFQData) {

                sessionStorage.setItem('hddnRFQID', RFQData[0].General[0].RFQId)
                jQuery('#RFQSubject').text(RFQData[0].General[0].RFQSubject)

                jQuery('#RFQDescription').html(RFQData[0].General[0].RFQDescription)
                $('#Currency').html(RFQData[0].General[0].CurrencyNm)
                $('#txtcurrency').val(RFQData[0].General[0].CurrencyNm)
                jQuery('#ConversionRate').html(RFQData[0].General[0].RFQConversionRate);
                jQuery('#refno').html(RFQData[0].General[0].RFQReference);
                jQuery('#txtRFQReference').html(RFQData[0].General[0].RFQReference)
                jQuery('#RFQStartDate').html(RFQData[0].General[0].RFQStartDate)
                jQuery('#RFQEndDate').html(RFQData[0].General[0].RFQEndDate)

                if (RFQData[0].General[0].RFQTermandCondition != '') {
                         replaced1 = RFQData[0].General[0].RFQTermandCondition.replace(/\s/g, "%20")
                }
                jQuery('#TermCondition').attr('href', 'PortalDocs/eRFQ/' + sessionStorage.getItem('hddnRFQID') + '/' + replaced1).html(RFQData[0].General[0].RFQTermandCondition)
                $('#filepthtermsPrev').attr('href', 'PortalDocs/eRFQ/' + sessionStorage.getItem('hddnRFQID') + '/' + replaced1).html(RFQData[0].General[0].RFQTermandCondition);

                //Preview Details
                var TermsConditionFileName = '';

                jQuery('#lblRfqsubject').html(RFQData[0].General[0].RFQSubject)
               
                jQuery('#lblrfqstartdate').html(RFQData[0].General[0].RFQStartDate)
                jQuery('#lblrfqenddate').html(RFQData[0].General[0].RFQEndDate)
                jQuery('#lblrfqdescription').html(RFQData[0].General[0].RFQDescription)

                jQuery("#dropCurrencyPrev").html(RFQData[0].General[0].CurrencyNm)
                jQuery('#lblConversionRatePrev').html(RFQData[0].General[0].RFQConversionRate)
               
                jQuery("#txtRFQReferencePrev").html(RFQData[0].General[0].RFQReference);

                var StartDT = new Date(RFQData[0].General[0].RFQStartDate.replace('-', ''));
                if (currentdate < StartDT) {
                    $('#form_wizard_1').find('.button-next').hide();
                    $('#regretrfq').hide();
                    $('#lblRFQMessage').show();
                }
                else {
                    $('#regretrfq').show();
                    $('#form_wizard_1').find('.button-next').show();
                    $('#lblRFQMessage').hide();
                }
            },
            error: function (xhr, status, error) {

                var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }

                return false;
                jQuery.unblockUI();
            }
        });
        jQuery.unblockUI();
    }
    function fnConfirmRegretted() {
        bootbox.dialog({
            message: "Are you sure you want to Regret to Quote? ",
            buttons: {
                confirm: {
                    label: "Yes",
                    className: "btn-success",
                    callback: function () {
                        fnRegreteRFQ()
                    }
                },
                cancel: {
                    label: "No",
                    className: "btn-default",
                    callback: function () {
                       
                    }
                }
            }
        });

    }
    function fnRegreteRFQ() {
        var RegretData = {
            "RFQId": sessionStorage.getItem('hddnRFQID'),
            "VendorID": sessionStorage.getItem('VendorId'),
            "Version": sessionStorage.getItem('RFQVersionId'),
           
        }
       // alert(JSON.stringify(RegretData))
        jQuery.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: sessionStorage.getItem("APIPath") + "eRFQVendor/eRFQRegretAfterReinvite",
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            crossDomain: true,
            async: false,
            data: JSON.stringify(RegretData),
            dataType: "json",
            success: function (data) {
                if (data[0].OutPut == "1") {
                    bootbox.alert("RFQ Regretted Successfully.", function () {
                        //window.location = sessionStorage.getItem('MainUrl');
                        if (sessionStorage.getItem("ISFromSurrogate") == "Y") {
                            window.location = sessionStorage.getItem('HomePage');
                            sessionStorage.clear();
                        }
                        else {
                            window.location = 'VendorHome.html';
                        } 
                        return false;
                    });
                    return true;
                }
            },
            error: function (xhr, status, error) {

                var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }

                return false;
                jQuery.unblockUI();
            }
        })
    }
    
    function fetchRFQParameterlastquotesonload(ver) {

        //alert(sessionStorage.getItem("APIPath") + "RequestForQuotation/fetchRFQParameter/?RFQId=" + sessionStorage.getItem('hddnRFQID') + "&VendorID=" + sessionStorage.getItem('VendorId') + "&RFQVersionId=" + ver+"&Flag=NOTBOQ" + "&BoqParentID="+0)
        jQuery.ajax({
            type: "GET",
            contentType: "application/json; charset=utf-8",
            url: sessionStorage.getItem("APIPath") + "eRFQVendor/efetchRFQParameterlastquotes/?RFQId=" + sessionStorage.getItem('hddnRFQID') + "&VendorID=" + sessionStorage.getItem('VendorId') + "&RFQVersionId=" + ver + "&RFQPID=" + 0 + "&Flag=Item",
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            data: "{}",
            cache: false,
            dataType: "json",
            success: function (data) {

                if (data.length > 0) {
                    fetchRFIParameteronload(ver);
                }
                else {
                    fetchRFIParameteronload(ver - 1);
                }


            },
            error: function (xhr, status, error) {

                var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }
                else{
                    alert("error");
                }
                return false;
                jQuery.unblockUI();
            }
            
        });
    }

    function fetchRFIParameteronload(ver) {
        fetchRFQLevelTC(ver);
        var attachment = '';
        var vendorAttachment = '';
        var replaced = '';
        //  alert(sessionStorage.getItem("APIPath") + "RequestForQuotation/fetchRFQParameter/?RFQId=" + sessionStorage.getItem('hddnRFQID') + "&VendorID=" + sessionStorage.getItem('VendorId') + "&RFQVersionId=" + version)
        jQuery.ajax({
            type: "GET",
            contentType: "application/json; charset=utf-8",
            url: sessionStorage.getItem("APIPath") + "eRFQVendor/efetchRFQParameter/?RFQId=" + sessionStorage.getItem('hddnRFQID') + "&VendorID=" + sessionStorage.getItem('VendorId') + "&RFQVersionId=" + ver,
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            data: "{}",
            cache: false,
            dataType: "json",
            success: function (data) {
                jQuery('#icon').html('<i class="fa fa-list-ul"></i>');
                jQuery("#tblServicesProduct").empty();
                jQuery("#tblRFQPrev").empty();
                
                $('#divdomestic').show();
                var description = "";
                var totalammwithoutGST = 0;
                var totalammwithGST = 0;
                if (data.length > 0) {
                    jQuery("#tblServicesProduct").append("<thead><tr style='background: gray; color: #FFF;'><th>Item/Service</th><th>UOM</th><th>Qty</th><th class=hide>TAT</th><th>Currency</th><th class=hide>Delivery Location</th><th></th><th>Landed Unit Price<br/>(Without GST)</th><th>Landed Unit Price<br/>(With GST)</th><th class='hidden'>Description</th><th>Amount<br/>(Without GST)</th><th>Amount<br/>(With GST)</th></tr></thead>");
                    jQuery("#tblRFQPrev").append("<thead><tr style='background: gray; color: #FFF;'><th>Item/Service</th><th>UOM</th><th>Qty</th><th class=hide>TAT</th><th class=hide>Currency</th><th class=hide>Delivery Location</th><th>Landed Unit Price<br/>(Without GST)</th><th>Landed Unit Price<br/>(With GST)</th><th>Amount<br/>(Without GST)</th><th>Amount<br/>(With GST)</th><th class='hidden'>Description</th></tr></thead>");
                    // alert(data[0].VendorRemarks)
                    $('#txtvendorremarks').val(data[0].VendorRemarks);
                   for (var i = 0; i < data.length; i++)
                    {
                        description = stringDivider(data[i].RFQDescription, 40, "<br/>\n");
                        var detailsdesc = (data[i].RFQDescription).replace(/(\r\n|\n|\r)/gm, "");
                        detailsdesc = detailsdesc.replace(/'/g, '');
                        $('#wrap_scrollerPrev').show();

                        totalammwithoutGST = totalammwithoutGST + (data[i].RFQPriceWithoutGST * data[i].RFQuantity);
                        totalammwithGST = totalammwithGST + (data[i].RFQVendorPricewithTax * data[i].RFQuantity);

                        if (data[i].RFQVendorPricewithTax > 0 && data[i].RFQVendorPrice > 0) {
                            jQuery('<tr id=trid' + i + '><td class=hidden>' + data[i].RFQParameterId + '</td><td class=hidden>' + data[i].RFQID + '</td><td data-toggle="popover" data-content="Click here for detailed description" data-trigger="hover"><a  href="#responsiveDescModal"  data-toggle="modal" onClick="showDetailedDescription(\'' + detailsdesc + '\')" >' + data[i].RFQShortName + '</a></td><td>' + data[i].RFQUomId + '</td><td>' + thousands_separators(data[i].RFQuantity) + '</td><td class="fit hide">' + data[i].TAT + '</td><td class=fit>' + $('#txtcurrency').val() + '</td><td class="hide">' + data[i].RFQDelivery + '</td><td><button type="button" class="btn default btn-xs green-haze-stripe" data-toggle="modal" href="#responsive" onclick="mapQuestion(\'' + data[i].RFQParameterId + '\',\'mkswithoutgst' + i + '\',\'' + data[i].RFQuantity + '\',\'' + ver + '\',\'mkswithgst' + i + '\',\'' + data[i].RFQVendorPrice + '\')">Input Price</button></td><td><input type="text" readonly="true" id="mkswithoutgst' + i + '" class="form-control input-circle pricebox text-right" value="' + thousands_separators(data[i].RFQPriceWithoutGST) + '"  autocomplete=off onkeyup=thousands_separators_input(this)/></td><td><input type="text" readonly="true" id="mkswithgst' + i + '" class="form-control input-circle pricebox text-right" value="' + thousands_separators(data[i].RFQVendorPricewithTax) + '"  autocomplete=off onkeyup=thousands_separators_input(this)/></td><td class="hidden">' + description + '</td><td class="hidden">' + data[i].RFQRemark + '</td><td class="hidden">' + data[i].RFQVendorPrice + '</td><td class="text-right">' + thousands_separators((data[i].RFQPriceWithoutGST * data[i].RFQuantity).round(2)) + '</td><td class="text-right">' + thousands_separators((data[i].RFQVendorPricewithTax * data[i].RFQuantity).round(2)) + '</td></tr>').appendTo("#tblServicesProduct");
                            jQuery('<tr id=trid' + i + '><td class=hidden>' + data[i].RFQParameterId + '</td><td class=hidden>' + data[i].RFQID + '</td><td><a href="#responsiveDescModal" data-toggle="modal" onClick="showDetailedDescription(\'' + detailsdesc + '\')" >' + data[i].RFQShortName + '</a></td><td>' + data[i].RFQUomId + '</td><td>' + thousands_separators(data[i].RFQuantity) + '</td><td class="fit hide">' + data[i].TAT + '</td><td class="fit hide">' + $('#txtcurrency').val() + '</td><td class="fit hide">' + data[i].RFQDelivery + '</td><td class="text-right">' + thousands_separators(data[i].RFQPriceWithoutGST) + '</td><td class="text-right">' + thousands_separators(data[i].RFQVendorPricewithTax) + '</td><td class="hidden">' + description + '</td><td class="hidden">' + data[i].RFQRemark + '</td><td class="text-right">' + thousands_separators((data[i].RFQPriceWithoutGST * data[i].RFQuantity).round(2)) + '</td><td class="text-right">' + thousands_separators((data[i].RFQVendorPricewithTax * data[i].RFQuantity).round(2)) + '</td></tr>').appendTo("#tblRFQPrev");

                        }
                        else {
                            //$('#wrap_scrollerPrev').hide();
                            jQuery('<tr id=trid' + i + '><td class=hidden>' + data[i].RFQParameterId + '</td><td class=hidden>' + data[i].RFQID + '</td><td data-toggle="popover" data-content="Click here for detailed description" data-trigger="hover"><a  href="#responsiveDescModal" data-toggle="modal" onClick="showDetailedDescription(\'' + detailsdesc + '\')" >' + data[i].RFQShortName + '</a></td><td>' + data[i].RFQUomId + '</td><td>' + thousands_separators(data[i].RFQuantity) + '</td><td class="fit hide">' + data[i].TAT + '</td><td class=fit>' + $('#txtcurrency').val() + '</td><td class="hide">' + data[i].RFQDelivery + '</td><td><button type="button"  class="btn default btn-xs red-stripe" data-toggle="modal" href="#responsive" onclick="mapQuestion(\'' + data[i].RFQParameterId + '\',\'mkswithoutgst' + i + '\',\'' + data[i].RFQuantity + '\',\'' + ver + '\',\'mkswithgst' + i + '\',\'' + data[i].RFQVendorPrice + '\')">Input Price</button></td><td><input type="text" readonly="true" id="mkswithoutgst' + i + '" class="form-control input-circle pricebox text-right" value="' + thousands_separators(data[i].RFQPriceWithoutGST) + '"  autocomplete=off /></td><td><input type="text" readonly="true" id="mkswithgst' + i + '" class="form-control input-circle pricebox text-right" value="' + thousands_separators(data[i].RFQVendorPricewithTax) + '"  autocomplete=off /></td><td class="hidden">' + description + '</td><td class="hidden">' + data[i].RFQRemark + '</td><td class="hidden">' + data[i].RFQVendorPrice + '</td><td class="text-right">' + thousands_separators((data[i].RFQPriceWithoutGST * data[i].RFQuantity).round(2)) + '</td><td class="text-right">' + thousands_separators((data[i].RFQVendorPricewithTax * data[i].RFQuantity).round(2)) + '</td></tr>').appendTo("#tblServicesProduct");
                            jQuery('<tr id=trid' + i + '><td class=hidden>' + data[i].RFQParameterId + '</td><td class=hidden>' + data[i].RFQID + '</td><td><a href="#responsiveDescModal" data-toggle="modal" onClick="showDetailedDescription(\'' + detailsdesc + '\')" >' + data[i].RFQShortName + '</a></td><td>' + data[i].RFQUomId + '</td><td>' + thousands_separators(data[i].RFQuantity) + '</td><td class="fit hide">' + data[i].TAT + '</td><td class="fit hide">' + $('#txtcurrency').val() + '</td><td class="fit hide">' + data[i].RFQDelivery + '</td><td class="text-right">' + thousands_separators(data[i].RFQPriceWithoutGST) + '</td><td class="text-right">' + thousands_separators(data[i].RFQVendorPricewithTax) + '</td><td class="hidden">' + description + '</td><td class="hidden">' + data[i].RFQRemark + '</td><td class="text-right">' + thousands_separators((data[i].RFQPriceWithoutGST * data[i].RFQuantity).round(2)) + '</td><td class="text-right">' + thousands_separators((data[i].RFQVendorPricewithTax * data[i].RFQuantity).round(2)) + '</td></tr>').appendTo("#tblRFQPrev");

                        }
                        
                       // $('#td' + i).popover("show")
                   }
                   jQuery('<tr><td colspan=7><b>Total</b></td><td class="text-right">' + thousands_separators(totalammwithoutGST) + '</td><td class="text-right">' + thousands_separators(totalammwithGST) + '</td></tr>').appendTo("#tblServicesProduct");
                   jQuery('<tr><td colspan=5><b>Total</b></td><td class="text-right">' + thousands_separators(totalammwithoutGST) + '</td><td class="text-right">' + thousands_separators(totalammwithGST) + '</td></tr>').appendTo("#tblRFQPrev");
                   //$('[data-toggle="popover"]').popover({})
                }


            },
            error: function (xhr, status, error) {

                var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }
                else{
                    alert("error");
                }
                return false;
                jQuery.unblockUI();
            }
            
        });
    }
    
    function showDetailedDescription(descText) {
        //alert(descText)
        $("#paraItemDescription").html(descText);
    }
    function fileUploader(RFQID, VendorId,version) {

        var fileRFQAttachments = $('#fileToUpload1');
        var fileDataAnyRFQAttachments = fileRFQAttachments.prop("files")[0];


        var formData = new window.FormData();

        formData.append("fileTerms", '');
        formData.append("fileAnyOther", '');
        formData.append("fileRFQAttach", fileDataAnyRFQAttachments);
        formData.append("AttachmentFor", 'eRFQ');
        formData.append("BidID", RFQID);
        formData.append("VendorID", VendorId);
        formData.append("Version", version);


            $.ajax({

                url: 'ConfigureFileAttachment.ashx',

                data: formData,

                processData: false,

                contentType: false,

                asyc: false,

                type: 'POST',

                success: function (data) {

                },

                error: function () {



                }

            });
        }

    


    setTimeout(function () { sessionStorage.removeItem('selectedboqtxtboxid') }, 5000);
    sessionStorage.removeItem('selectedboqtxtboxidTax');

    function ajaxFileDelete(closebtnid, fileid, filepath, itemID) {
        jQuery(document).ajaxStart(jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" /> Please Wait...</h5>' })).ajaxStop(jQuery.unblockUI);
        var theLinkdiv = document.getElementById(filepath)
        var path = theLinkdiv.getAttribute("href").replace(/%20/g, " ");

        var formData = new window.FormData();
        formData.append("Path", path);

        $.ajax({

            url: 'ConfigureFileAttachment.ashx',
            data: formData,
            processData: false,
            contentType: false,
            asyc: false,
            type: 'POST',
            success: function (data) {
                fileDeletefromdbForItem(closebtnid, fileid, filepath, itemID);
            },

            error: function () {
                bootbox.alert("Attachment error.");

            }

        });

        jQuery.unblockUI();

    }

    //File Delete Vendor Response 
    function fileDeletefromdbForItem(closebtnid, fileid, filepath, itemID) {

        $('#' + closebtnid).remove();
        $('#' + filepath).html('')
        $('#' + filepath).attr('href', 'javascript:;').addClass('display-none');
        $('#' + fileid).attr('disabled', false);
        var BidData = {

            "BidId": 0,
            "BidTypeID": 0,
            "UserId": sessionStorage.getItem('VendorId'),
            "RFQRFIID": sessionStorage.getItem('hddnRFQID'),
            "RFIRFQType": 'vendorResponse',
            "RFQParameterID": itemID
        }

        jQuery.ajax({

            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: sessionStorage.getItem("APIPath") + "ConfigureBid/FileDeletionRFQParameter/",
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            crossDomain: true,
            async: false,
            data: JSON.stringify(BidData),
            dataType: "json",
            success: function (data) {
                if (data[0].IsSuccess == '1') {
                    $('#spansuccattachment').html('File Deleted Successfully');
                    $("#divsuccattachment").show();
                    Metronic.scrollTo(success, -200);
                    $("#divsuccattachment").fadeOut(5000);
                }
            },
            error: function (xhr, status, error) {

                var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }
                else {
                    alert("error");
                }
                return false;
                jQuery.unblockUI();
            }

        });
    }

    function mapQuestion(RFQParameterId, mskwithoutgst, quantity, version,withgst,basicprice) {
     
        $('#txtbasicPrice').val(thousands_separators(basicprice))
        $("#hddnBoqParamQuantity").val(quantity);
        //sessionStorage.setItem('selectedboqtxtboxid', mskNo)
        //  sessionStorage.setItem('selectedboqtxtboxidTax', mskNowithTax)
        // $('#texttblid').val(mskNo);
        $('#texttblidwithGST').val(withgst);
        $('#texttblidwithoutGST').val(mskwithoutgst);
        $('#txtRFQParameterId').val(RFQParameterId);
        saveQuotation();
        fncheckItemWiseTC(version, RFQParameterId)

    }
    $('#responsive').on("hidden.bs.modal", function () {
        jQuery('input:checkbox[name=chkreplicateprice]').prop('checked', false);
        jQuery('#chkreplicateprice').parents('span').removeClass('checked');
         Price = 0;
         PricewithoutGST = 0;
         basicprice = 0;
    })
    var Price = 0;
    var PricewithoutGST = 0;
    var basicprice = 0;
    
    function RFQinsertItemsTC(issubmitbuttonclick) {
        
        Price = 0;
        PricewithoutGST = 0;
        basicprice = 0;

        basicprice = removeThousandSeperator($('#txtbasicPrice').val());

            $('#loader-msg').html('Processing. Please Wait...!');
            $('.progress-form').show();
            PriceDetails = '';
           // var rowCount = jQuery('#tblRFQParameterComponet  tr').length;
           
            // if (TermsrowCount > 1) {
            if (jQuery('#tblRFQParameterComponet  tr').length > 0) {
                PriceDetails = PriceDetails + 'Insert into eRFQVendor (VendorID,RFQParameterId,RFQId,RFQTCID,RFQVendorPricewithTax,RFQPriceWithoutGST,FinalStatus,Version) ' + PriceDetails

                $("#tblRFQParameterComponet tr:gt(0)").each(function () {
                    var this_row = $(this);
                    if ($.trim(this_row.find('td:eq(3)').html()) != "GST")
                    {
                        // PricewithoutGST = PricewithoutGST + (removeThousandSeperator(basicprice) * (parseFloat(removeThousandSeperator(this_row.find('td:eq(4) input[type="text"]').val())) / 100));
                        PricewithoutGST = PricewithoutGST + (parseFloat(removeThousandSeperator(this_row.find('td:eq(4) input[type="text"]').val())) / 100);
                    }
                    Price = Price + (parseFloat(removeThousandSeperator(this_row.find('td:eq(4) input[type="text"]').val())) / 100);
                    // Price = Price + parseFloat(removeThousandSeperator(this_row.find('td:eq(4) input[type="text"]').val()))//* removeThousandSeperator($.trim(this_row.find('td:eq(5)').html())));
                    // PriceTax = PriceTax + parseFloat(removeThousandSeperator(this_row.find('td:eq(4) input[type="text"]').val()) * removeThousandSeperator($.trim(this_row.find('td:eq(5)').html())));

                    PriceDetails = PriceDetails + " select " + sessionStorage.getItem('VendorId') + "," + $.trim(this_row.find('td:eq(0)').html()) + "," + $.trim(this_row.find('td:eq(1)').html()) + " ,'" + $.trim(this_row.find('td:eq(2)').html()) + "'," + removeThousandSeperator($.trim(this_row.find('td:eq(4) input[type="text"]').val())) + ","+ removeThousandSeperator($.trim(this_row.find('td:eq(4) input[type="text"]').val())) + ",'N'," + sessionStorage.getItem('RFQVersionId') + " union all ";

                 });
                    PricewithoutGST = (removeThousandSeperator(basicprice) * (PricewithoutGST+1)) ;
                    Price = (removeThousandSeperator(basicprice) * (Price+1));
                    PriceDetails = PriceDetails.substring(0, PriceDetails.length - 11);
                    console.log(PriceDetails)
                var Tab2data = {
                    "PriceDetails": PriceDetails,
                    "RFQparameterID": $('#txtRFQParameterId').val(),
                    "RFQID": sessionStorage.getItem('hddnRFQID'),
                    "VendorId": sessionStorage.getItem('VendorId'),
                    "RFQVersionId": sessionStorage.getItem('RFQVersionId'),
                    "Price": Price,
                    "PricewithoutGST": PricewithoutGST,
                    "PriceBasic":basicprice
                };

               // alert(PriceDetails)
              // alert(JSON.stringify(Tab2data))
                jQuery.ajax({

                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    url: sessionStorage.getItem("APIPath") + "eRFQVendor/eRFQQuotedTCPriceSave/",
                    beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
                    crossDomain: true,
                    async: false,
                    data: JSON.stringify(Tab2data),
                    dataType: "json",
                    success: function (data) {

                        if (data[0].RFQID > 0) {
                            $("#" + $('#texttblidwithGST').val()).val(Price);
                            $("#" + $('#texttblidwithoutGST').val()).val(PricewithoutGST);
                           // saveQuotation()
                            fetchRFIParameteronload(sessionStorage.getItem('RFQVersionId'));
                            Price = 0;
                            if (issubmitbuttonclick == "Y") {
                                $('#responsive').modal('hide');
                            }

                        }


                    },
                    error: function (xhr, status, error) {

                        var err = eval("(" + xhr.responseText + ")");
                        if (xhr.status === 401) {
                            error401Messagebox(err.Message);
                        }
                        
                        return false;
                        jQuery.unblockUI();
                    }
                });
            }
            $('.progress-form').hide()
        
    }
   
    function saveQuotation() {
        var PriceDetails = '';
        var commercialterms = '';
        $("#tblServicesProduct > tbody > tr").not(':last').each(function () {
            var this_row = $(this);
            PriceDetails = PriceDetails + " select " + sessionStorage.getItem('VendorId') + "," + $.trim(this_row.find('td:eq(0)').html()) + "," + $.trim(this_row.find('td:eq(1)').html()) + " ,'" + $.trim(this_row.find('td:eq(2)').text().replace(/'/g, "''")) + "','" + removeThousandSeperator($.trim(this_row.find('td:eq(3)').html())) + "','" + removeThousandSeperator($.trim(this_row.find('td:eq(4)').html())) + "','" + $.trim(this_row.find('td:eq(7)').html()) + "'," + removeThousandSeperator($.trim(this_row.find('td:eq(10) input[type="text"]').val())) + "," + removeThousandSeperator($.trim(this_row.find('td:eq(9) input[type="text"]').val())) +"," + $.trim(this_row.find('td:eq(13)').html()) +" ,"+ 0 + "," + sessionStorage.getItem('RFQVersionId') + ",'N' union all ";

        });
         $("#tblRFQLevelTCForQuot > tbody > tr").each(function () {
             var this_row = $(this);
             commercialterms = commercialterms + " select " + sessionStorage.getItem('VendorId') + "," + $.trim(this_row.find('td:eq(0)').html()) + "," + $.trim(this_row.find('td:eq(1)').html()) + " ,'" + $.trim(this_row.find('td:eq(5)').find('textarea').val()).replace(/'/g, "''") + "'," + sessionStorage.getItem('RFQVersionId') + ",'N' union all ";

         });
         if (commercialterms != '') {
             commercialterms = 'insert into eRFQVendorCommercial(VendorID,RFQTCID,RFQID,Remarks,Version,FinalStatus) ' + commercialterms
             commercialterms = commercialterms.substring(0, commercialterms.length - 11);
         }
        
        
         if (PriceDetails != '') {
             PriceDetails = 'Insert into eRFQVendor (VendorID,RFQParameterId,RFQId,RFQShortName,RFQUomId,RFQuantity,RFQDelivery,RFQVendorPricewithTax,RFQPriceWithoutGST,RFQVendorPrice,RFQTCID,Version,FinalStatus) ' + PriceDetails
             PriceDetails = PriceDetails.substring(0, PriceDetails.length - 11);
             console.log(PriceDetails)
         }
        // alert(PriceDetails)
            var Tab2data = {
                "PriceDetails": PriceDetails,
                "RFQID": sessionStorage.getItem('hddnRFQID'),
                "VendorId": sessionStorage.getItem('VendorId'),
                "RFQVersionId": sessionStorage.getItem('RFQVersionId'),
                "CommercialTerms": commercialterms,
                "VendorRemarks": $('#txtvendorremarks').val()
            };
           // alert(commercialterms)

         //  alert(JSON.stringify(Tab2data))
            jQuery.ajax({

                type: "POST",
                contentType: "application/json; charset=utf-8",
                url: sessionStorage.getItem("APIPath") + "eRFQVendor/eRFQQuotedPriceSave/",
                beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
                crossDomain: true,
                async: false,
                data: JSON.stringify(Tab2data),
                dataType: "json",
                success: function (data) {
                   
                    setTimeout(function () {
                        if (data[0].RFQID != 0) {
                            fetchRFIParameteronload(sessionStorage.getItem('RFQVersionId'));
                            
                        }
                        return true;
                    }, 500)
                    //alert(data[0].RFQID)
                    if (data[0].RFQID == 0) {
                        bootbox.alert("Error connecting server. Please try later.");
                    }
                },
                error: function (xhr, status, error) {

                    var err = eval("(" + xhr.responseText + ")");
                    if (xhr.status === 401) {
                        error401Messagebox(err.Message);
                    }
                    
                    return false;
                    jQuery.unblockUI();
                }
            });
        
        //else {
        //    //$('#spanerrordomestic').html('Please Fill Price For All RFQ Parameter.!')
        //    //$('#divalerterrordomestic').show();
        //    //$('#divalerterrordomestic').fadeOut(5000);
        //    return false
        //}

    }
    jQuery('#chkreplicateprice').click(function () {
        if (jQuery('#chkreplicateprice').is(':checked') == true) {
            shwconfirmationtoreplicate();
        }
        else {
          
        }
    });
  
    function shwconfirmationtoreplicate() {
        bootbox.dialog({
            message: "Are you sure? This will also replace earlier filled rates,  if any ",
            buttons: {
                confirm: {
                    label: "Yes",
                    className: "btn-success",
                    callback: function () {
                        fnReplicateToAllItems()
                    }
                },
                cancel: {
                    label: "No",
                    className: "btn-default",
                    callback: function () {
                        jQuery('input:checkbox[name=chkreplicateprice]').prop('checked', false);
                        jQuery('#chkreplicateprice').parents('span').removeClass('checked');
                    }
                }
            }
        });

    }
    function fnReplicateToAllItems() {
        PricewithoutGST = 0;
        Price = 0;
        basicprice = 0;
      //  basicprice = removeThousandSeperator($('#txtbasicPrice').val());
        $('#loader-msg').html('Processing. Please Wait...!');
        $('.progress-form').show();

        RFQinsertItemsTC('N');
        //$("#tblRFQParameterComponet tr:gt(0)").each(function () {
        //    var this_row = $(this);
        //    if ($.trim(this_row.find('td:eq(3)').html()) != "GST") {
        //        PricewithoutGST = PricewithoutGST + (parseFloat(removeThousandSeperator(this_row.find('td:eq(4) input[type="text"]').val())) / 100);
        //    }
        //    Price = Price + (parseFloat(removeThousandSeperator(this_row.find('td:eq(4) input[type="text"]').val())) / 100);
            
        //});
        //PricewithoutGST = (removeThousandSeperator(basicprice) * (PricewithoutGST + 1));
        //Price = (removeThousandSeperator(basicprice) * (Price + 1));
        var Tab2data = {
            "PriceDetails": '',
            "RFQparameterID": $('#txtRFQParameterId').val(),
            "RFQID": sessionStorage.getItem('hddnRFQID'),
            "VendorId": sessionStorage.getItem('VendorId'),
            "RFQVersionId": sessionStorage.getItem('RFQVersionId'),
            "Price": Price,
            "PricewithoutGST": PricewithoutGST,
            "PriceBasic": basicprice
        };
      //alert(JSON.stringify(Tab2data))
        jQuery.ajax({

           type: "POST",
            contentType: "application/json; charset=utf-8",
            url: sessionStorage.getItem("APIPath") + "eRFQVendor/eRFQQuotedTCPriceSave/",
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            crossDomain: true,
            async: false,
            data: JSON.stringify(Tab2data),
            dataType: "json",
            success: function (data) {
               
                if (data[0].RFQID > 0) {
                    //RFQinsertItemsTC('N')
                    fetchRFIParameteronload(sessionStorage.getItem('RFQVersionId'));
                    $('#responsive').modal('hide');
                }
            },
            error: function (xhr, status, error) {

                var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }

                return false;
                jQuery.unblockUI();
            }
        })
        $('.progress-form').hide()
    }
    $('#back_prev_btn').click(function () {
        $('#BidPreviewDiv').hide();
        $('#form_wizard_1').show();
    });
    function fnRedirectToHome() {
        if (sessionStorage.getItem("ISFromSurrogate") == "Y") {
            window.location = sessionStorage.getItem('HomePage');
            sessionStorage.clear();
        }
        else {
            window.location = "VendorHome.html"
        }
    }