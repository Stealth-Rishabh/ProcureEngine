﻿

param = getUrlVars()["param"]
decryptedstring = fndecrypt(param)
var RFQID = getUrlVarsURL(decryptedstring)["RFQID"]

function FetchInvitedVendorsForeRFQ() {
    //alert(sessionStorage.getItem("APIPath") + "eRFQReport/eRFQFetchInvitedVendors/?RFQID=" + RFQID + "&Userid=" + encodeURIComponent(sessionStorage.getItem('UserID')) + '&CustomerID=' + sessionStorage.getItem('CustomerID'))
    jQuery.ajax({
        url: sessionStorage.getItem("APIPath") + "eRFQReport/eRFQFetchInvitedVendors/?RFQID=" + RFQID + "&Userid=" + encodeURIComponent(sessionStorage.getItem('UserID')) + '&CustomerID=' + sessionStorage.getItem('CustomerID'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "GET",
        async: false,
        contentType: "application/json; charset=utf-8",
        success: function(data, status, jqXHR) {
          //  alert(data.length)
            if (data.length > 0) {
                $('#tblVendorSummary tbody').empty();
                $('#displayTable').show();
                jQuery('#lbl_configuredBy').html("RFQ Configured By: " + data[0].ConfiguredByName);
                
              //  alert(data[0].Deadline)
                $('#rq_subject').html('<b>' + data[0].RQSubject + '</b>');
                $('#rq_deadline').html(data[0].Deadline);
                $('#rq_description').html(data[0].RQDescription);
                $("#deadlineModal").html(data[0].Deadline);
                for (var i = 0; i < data.length; i++) {
                    $('#tblVendorSummary').append(jQuery('<tr><td class="hide">' + data[i].VendorID + '</td><td>' + data[i].VendorName + ' ( ' + data[i].ContactPerson + ' , ' + data[i].VendorEmail + ' , ' + data[i].PhoneNo + ' )</td><td>' + data[i].RQStatus + '</td><td>' + data[i].ResponseDTTime + '</td><td class=hide>' + data[i].VendorEmail + '</td></tr>')); //<td>' + data[i].ResponseDate + ' - ' + data[i].ResponseTime + '</td>
                }
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }

    });
}
var errorremainder = $('#errorsendremainder');
var succesremainder = $('#successremainder');
function sendremainderstoparicipants() {
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    
        var checkedValue = '';
        var temp = new Array();
        $("#tblVendorSummary> tbody > tr").each(function (index) {

            vemail = $(this).find("td").eq(4).html();
            vid = $(this).find("td").eq(0).html();
            if($(this).find("td").eq(2).html().toLowerCase()!='close' &&  $(this).find("td").eq(2).html().toLowerCase()!='regretted'){
                checkedValue = checkedValue + " select  " + RFQID + ",'" + vemail + "','N','" + vid + "'  union";
            }
            // }
        });
        if (checkedValue != '') {
            checkedValue = 'insert into #temp(RFQID,EmailId,MailSent,VendorID) ' + checkedValue
            checkedValue = checkedValue.substring(0, checkedValue.length - 6);
        }

        var data = {
            "QueryString": checkedValue,
            "RFQID": RFQID,
            "UserID": sessionStorage.getItem("UserID")
        }
           // alert(JSON.stringify(data))
        jQuery.ajax({
            url: sessionStorage.getItem("APIPath") + "eRFQReport/SendRemainderToParticipanteRFQ",
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            data: JSON.stringify(data),
            type: "POST",
            contentType: "application/json",
            success: function (data) {
                // alert(data[0].Flag)
                if (data[0].Flag == "1") {
                    errorremainder.hide();
                    succesremainder.show();
                    $('#success').html('Reminder has been sent Successfully..');
                    succesremainder.fadeOut(3000);
                   
                    jQuery.unblockUI();
                }
            },
            error: function (xhr, status, error) {

                var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }
            
                return false;
                jQuery.unblockUI();
            }
           
        });

        return true;
    
}
function CancelRFIRFQ(MailPermit) {
    var Data = {

        "RFQID": RFQID,
        "CustomerID": sessionStorage.getItem('CustomerID'),
        "UserID": sessionStorage.getItem('UserID'),
        "MailParam": MailPermit,
        "RQSubj": $('#rq_subject').html(),
        "RQDescription": $('#rq_description').html().replace(/'/g, " "),
        "RQDeadLin": $('#rq_deadline').html()

    };
   // alert(JSON.stringify(Data))

    jQuery.ajax({

        type: "POST",

        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "eRFQReport/ecancelRFQ/",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },

        crossDomain: true,

        async: false,

        data: JSON.stringify(Data),

        dataType: "json",

        success: function(data) {
        
        bootbox.alert("RFQ cancelled successfully.", function() {
        window.location = sessionStorage.getItem('HomePage');
            return false;
        });
            
            

        },
        error: function(jqXHR, exception) {
            var err = eval("(" + jqXHR.responseText + ")");
            if (jqXHR.status === 401) {
                error401Messagebox(err.Message);
            }
            else{
                var msg = '';
                if (jqXHR.status === 0) {
                    msg = 'Not connect.\n Verify Network.';
                } else if (jqXHR.status == 404) {
                    msg = 'Requested page not found. [404]';
                } else if (jqXHR.status == 500) {
                    msg = 'Internal Server Error [500].';
                } else if (exception === 'parsererror') {
                    msg = 'Error connecting server. Please retry.';
                } else if (exception === 'timeout') {
                    msg = 'Time out error.';
                } else if (exception === 'abort') {
                    msg = 'Ajax request aborted.';
                } else {
                    msg = 'Uncaught Error.\n' + jqXHR.responseText;
                }
                jQuery.unblockUI();
                bootbox.alert(msg);
                return false;
            }
        }
       
            
     
   
    });
    jQuery.unblockUI();

}
function ViewReport() {
    var encrypdata = fnencrypt("RFQID=" + RFQID + "&RFQSubject=" + encodeURIComponent($('#rq_subject').text()))
    if (sessionStorage.getItem('CustomerID') != "32") {
       
        window.open("eRFQAnalysis.html?param=" + encrypdata, "_blank")
    }
    else {
        window.open("AzeRFQAnalysis.html?param=" + encrypdata, "_blank")
        
    }
}
$('#btn_cancl_rfirfq').click(function() {

bootbox.dialog({
message: "Do you want to send email to vendors regarding this cancellation?",
   // title: "Custom title",
    buttons: {
        confirm: {
            label: "Yes",
            className: "btn-success",
            callback: function() {
                CancelRFIRFQ('SendMail')
            }
        },
        cancel: {
            label: "No",
            className: "btn-warning",
            callback: function() {
             CancelRFIRFQ('NoMail')
            }
        }
    }
});

});

$('#ext_btn').click(function() {
    window.location = sessionStorage.getItem('HomePage');
});

// for Extend date

function formValidation() {
    $('#frmExtendDate').validate({
        errorElement: 'span', //default input error message container
        errorClass: 'help-block', // default input error message class
        focusInvalid: false, // do not focus the last invalid input
        rules: {
            txtextendDate: {
                required: true
            }
        },
        messages: {

    },
    invalidHandler: function(event, validator) { //display error alert on form submit   

    },

    highlight: function(element) { // hightlight error inputs
        $(element).closest('.col-md-6').addClass('has-error'); // set error class to the control group


    },
    unhighlight: function(element) { // revert the change done by hightlight
        $(element).closest('.col-md-6').removeClass('has-error'); // set error class to the control group

    },
    errorPlacement: function(error, element) {
         if (element.attr("name") == "txtextendDate") {

            error.insertAfter("#daterr");

        }
        else {

            error.insertAfter(element);
        }
    },

    success: function(label) {
        label.closest('.col-md-6').removeClass('has-error');

        label.remove();
    },


    submitHandler: function(form) {
        ExtendDuration();
    }
});

}
var currentdate = new Date();
function ExtendDuration() {
    var EndDT = new Date($('#txtextendDate').val().replace('-', ''));
    if (EndDT < currentdate) {
        $('#error_deaddate').show();
        $("#txtextendDate").closest('.col-md-6').addClass('has-error');
        $("#txtextendDate").val('');
        $('#error1').text('End Date Time must greater than Current Date Time.');
        Metronic.scrollTo($("#error_deaddate"), -200);
        $('#error_deaddate').fadeOut(7000);
        return false;
    }
    else {
    var RFQData = {
            "RFQID": RFQID,
            "ExtendedDate": $("#txtextendDate").val(),
            "ExtendedBy": sessionStorage.getItem('UserID')
        }
        //alert(JSON.stringify(RFQData));

        jQuery.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: sessionStorage.getItem("APIPath") + "eRFQReport/eRFQExtendDeadline/",
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            crossDomain: true,
            async: false,
            data: JSON.stringify(RFQData),
            dataType: "json",
            success: function (data) {
                if (data[0].IsSuccess == '1') {
                    $("#extendDate").modal("hide");
                    $("#txtextendDate").val('');
                    bootbox.alert("Date extended successfully.", function () {
                        FetchInvitedVendorsForeRFQ();
                    });

                }
            },
            error: function (xhr, status, error) {

                var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }

                return false;
                jQuery.unblockUI();
            }

        });
    }
    
}