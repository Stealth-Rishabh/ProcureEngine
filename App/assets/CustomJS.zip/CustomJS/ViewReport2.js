﻿var BidID = "";
var BidTypeID = "";
var BidForID = "";

var postfix = ''

$('#printed_by').html(sessionStorage.getItem('UserName'));
function getCurrenttime() {

    var dt = new Date();
    var day = dt.getDate();
    var month = dt.getMonth() + 1;
    var year = dt.getFullYear();
    var hour = dt.getHours();
    var mins = dt.getMinutes();
    postfix = day + "/" + month + "/" + year;
    
    $('#printed_on').html(postfix);
}




function saveAspdf() {

    //var doc = new jsPDF('p', 'px', 'a4');
    //doc.setFontSize(10);
    //doc.addHTML(document.body, function () {
    //    doc.save('BidSummary.pdf');

    //});
    //    pagesplit: true,
    //    setTimeout(function () {
    //       window.location = "BidSummary.html?BidID=" + getUrlVars()["BidID"] + "&BidTypeID=" + getUrlVars()["BidTypeID"] + "&BidForID=" + getUrlVars()["BidForID"]
    //    })


    var pdf = new jsPDF('l', 'mm',[300, 475]);
   var options = {
        pagesplit: true
   };
    
    pdf.addHTML(document.body, options, function () {
        pdf.save('BidSummary.pdf');
        encrypdata = fnencrypt("BidID=" + getUrlVarsURL(decryptedstring)["BidID"] + "&BidTypeID=" + getUrlVarsURL(decryptedstring)["BidTypeID"] + "&BidForID=" + getUrlVarsURL(decryptedstring)["BidForID"]);
        window.location = "BidSummary.html?param="+encrypdata
    });

   //// var pdf = new jsPDF('p', 'pt', 'letter');
   
   // //pdf.addHTML(document.body, {
   // //    callback: function (pdf) {
   // //        pdf.save('test.pdf');
   // //    }
   // //});


}


var _bidclosingtype='';
function ReportBind(Bidid, Bidtypeid, Bidforid) {

    var tncAttachment = '';
    var anyotherAttachment = '';
    //alert(sessionStorage.getItem("APIPath") + "BidVendorSummary/FetchBidDetails/?BidID=" + BidID + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("UserID")))
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "BidVendorSummary/FetchBidDetails/?BidID=" + BidID + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("UserID")),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function(data, status, jqXHR) {
            //alert(data.length)
            if (data.length > 0) {
                //$('#watermark').css({
                //    'position': 'absolute',
                //    'left': 0, 'right': 0, 'top': 0, 'bottom': 0
                //})

                $('#watermark').css({ 'background-image': 'url(' + data[0].LogoImage + ')' });
                $('#spnconfiguredby').text(data[0].ConfigureByName);
                $('#logo').attr("src", data[0].LogoImage);

                //$('#watermark').css({
                //    'Background-repeat': 'repeat', 'opacity': 0.1, 'z-index': -999999
                //})
              //  setTimeout(function () {
                    if (Bidtypeid != 7) {
                        if (data[0].FinalStatus != 'Awarded') {
                            $('#bid_status').html('Status: ' + data[0].FinalStatus)
                        }

                        else {
                           // $('#bid_status').html('Status: ' + data[0].FinalStatus + ' to: ' + data[0].AwardedToName)
                            $('#bid_status').html('Status: ' + data[0].FinalStatus)
                        }
                    }
                    else {
                        $('#bid_status').html('Status: ' + data[0].FinalStatus)
                    }

                    if (data[0].FinalStatus == 'Cancel') {
                        $('#cancl_btn').hide();
                    } else {
                        $('#cancl_btn').show();

                    }

                    if (data[0].Status == 'Close' || data[0].Status == 'CLOSE') {
                        $('#bid_status').show();

                    } else {
                        $('#bid_status').hide();
                    }


                    BidID = data[0].BidID
                    BidTypeID = data[0].BidTypeID
                    BidForID = data[0].BidForID
                    _bidclosingtype = data[0].BidClosingType;

                    if (data[0].BidTypeID == "2") {
                        jQuery('#tblprice').css('display', 'block');
                        jQuery('#thmodelclass').css('display', 'block');
                        var Modelclass = data[0].ModelClass == "1" ? 'Min' : data[0].ModelClass == "2" ? '45+' : data[0].ModelClass == "3" ? '100+' : data[0].ModelClass == "4" ? '300+' : data[0].ModelClass == "5" ? '500+' : '1000';
                        var fmin = data[0].TargetFreightMin == null ? '' : data[0].TargetFreightMin
                        var f45 = data[0].TargetFreightPlus45 == null ? '' : data[0].TargetFreightPlus45
                        var f100 = data[0].TargetFreightPlus100 == null ? '' : data[0].TargetFreightPlus100
                        var f300 = data[0].TargetFreightPlus300 == null ? '' : data[0].TargetFreightPlus300
                        var f500 = data[0].TargetFreightPlus500 == null ? '' : data[0].TargetFreightPlus500
                        var f1000 = data[0].TargetFreightPlus1000 == null ? '' : data[0].TargetFreightPlus1000

                        jQuery('#tbldetails').append("<tr id=low><td>Bid Subject: " + data[0].BidSubject + "</td><td>Bid Description: " + data[0].BidDetails + "</td></tr><tr><td><b>Bid Date/Time:</b> " + data[0].BidDate + ' - ' + data[0].BidTime + "</td><td><b>Bid Type:</b> " + data[0].BidTypeName + "</td></tr><tr><td><b>Bid For:</b> " + data[0].BidFor + "</td><td><b>Bid Duration:</b> " + data[0].BidDuration + " mins</td></tr><tr><td id='tdCurrency'><b>Currency:</b> " + data[0].CurrencyName + "</td><td id=tdmodal><b>ModelClass:</b> " + Modelclass + "+</td></tr><tr id='trtargetprice'><td id=tdtargetprive></td></tr>");
                        jQuery('#tblprice').append("<tr><td>Freight</td><td>" + fmin + "</td><td>" + f45 + "</td><td>" + f100 + "</td><td>" + f300 + "</td><td>" + f500 + "</td><td>" + f1000 + "</td></tr>");


                        if (data[0].BidForID == "3") {
                            var xmin = data[0].TargetExWorksMin == null ? '' : data[0].TargetExWorksMin
                            var x45 = data[0].TargetExWorksPlus45 == null ? '' : data[0].TargetExWorksPlus45
                            var x100 = data[0].TargetExWorksPlus100 == null ? '' : data[0].TargetExWorksPlus100
                            var x300 = data[0].TargetExWorksPlus300 == null ? '' : data[0].TargetExWorksPlus300
                            var x500 = data[0].TargetExWorksPlus500 == null ? '' : data[0].TargetExWorksPlus500
                            var x1000 = data[0].TargetExWorksPlus1000 == null ? '' : data[0].TargetExWorksPlus1000

                            jQuery('#tblprice').append("<tr><td>Exworks</td><td>" + xmin + "</td><td>" + x45 + "</td><td>" + x100 + "</td><td>" + x300 + "</td><td>" + x500 + "</td><td>" + x1000 + "</td></tr>")


                        }

                    }
                    else {

                        jQuery('#tdtargetprice').css('display', 'none');



                        jQuery('#tblprice').css('display', 'none');
                        jQuery('#thmodelclass').css('display', 'none');
                        if (BidTypeID == 3) {


                            jQuery('#thtargetprice').css('display', 'block');
                            var tp = data[0].Targetfreight == null ? '' : data[0].Targetfreight;
                            jQuery('#tbldetails').append("<tr id=low><td><b>Bid Subject:</b> " + data[0].BidSubject + "</td><td><b>Bid Description:</b> " + data[0].BidDetails + "</td></tr><tr><td><b>Bid Date/Time:</b> " + data[0].BidDate + ' - ' + data[0].BidTime + "</td><td><b>Bid Type:</b> " + data[0].BidTypeName + "</td></tr><tr><td><b>Bid For:</b> " + data[0].BidFor + "</td><td><b>Bid Duration:</b> " + data[0].BidDuration + " mins</td></tr><tr><td id='tdCurrency'><b>Currency:</b> " + data[0].CurrencyName + "</td><td id=tdmodal></td></tr><tr id='trtargetprice'><td id=tdtargetprive><b>Target Price:</b> " + tp + "</td></tr>")
                        }
                        else {

                            jQuery('#tbldetails').append("<tr><td><b>Bid Subject:</b> " + data[0].BidSubject + "</td><td><b>Bid Description:</b> " + data[0].BidDetails + "</td></tr><tr><td><b>Bid Date/Time:</b> " + data[0].BidDate + ' - ' + data[0].BidTime + "</td><td><b>Bid Type:</b> " + data[0].BidTypeName + "</td></tr><tr><td><b>Bid For:</b> " + data[0].BidFor + "</td><td><b>Bid Duration:</b> " + data[0].BidDuration + " mins</td></tr><tr><td id='tdCurrency'><b>Currency:</b> " + data[0].CurrencyName + "</td><td><b>Event ID:</b> " + BidID + "</td><td id=tdmodal></td></tr><tr id='trtargetprice'><td id=tdtargetprive></td></tr>")
                            jQuery('#trtargetprice').css('display', 'none');
                        }
                        jQuery('#tdmodal').css('display', 'none');
                       // $("#tdCurrency").attr("colspan", 2);


                        jQuery("#lblbidprice").show();
                        jQuery("#lblbidprice").text(data[0].Targetfreight == null ? '' : data[0].Targetfreight)
                    }



               // }, 1000);
            }
            


        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else{
                jQuery("#error").text(xhr.d);
            } 
            return false;
            jQuery.unblockUI();
        }
        
    });

    if (BidTypeID == 1 || BidTypeID == 6) {
        $('#lnktotvalue').show()
        $('#btngraphbubble').show()
    }
    else {
        $('#lnktotvalue').hide()
        $('#btngraphbubble').show()
    }
}

function fetchBidSummaryDetails(BidID, BidTypeID, BidForID) {
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });

    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "BidVendorSummary/FetchBidSummary/?BidID=" + BidID + "&BidTypeID=" + BidTypeID + "&BidForID=" + BidForID + "&UserID=" + encodeURIComponent(sessionStorage.getItem("UserID")) + "&AuthenticationTonken=" + sessionStorage.getItem("AuthenticationToken"),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function(data, status, jqXHR) {
            var counterForItenscount = 0;

            jQuery("#tblBidSummary > thead").empty();
            jQuery("#tblBidSummary > tbody").empty();

            _bidarray = [];

            if (data.length > 0) {
               
                if (parseInt(BidTypeID) == 1) {



                    var TotalBidValue = ''; // TotalBidValueCeiling = '', TotalBidValueInvoice = '';

                    var Percentreduction = '', Percentreductionceiling = '', Percentreductioninvoice = '';
                    $('#divTarget').hide();
                    var sname = '';

                    var strHead = "<tr style='background: #67809f;'><th style='font-size: 19px; text-align: left; color: #FFF;' colspan='22'>Participation Details</th></tr>"
                    //strHead += "<tr><th>Product</th><th>Target Price</th><th>Last Invoice Price</th><th>Bid start price</th><th>Quantity</th><th>UOM</th><th>Contract Duration</th><th>Delivery Location</th></tr>";
                    // strHead += "<tr><th>Level</th><th>Vendor</th><th>Initial Quote</th><th>Lowest Quote</th><th>Bid Value</th><th>Percentage Reduction (Target Price)</th><th>Percentage Reduction (Last InvoicePrice)</th><th>Percentage Reduction (Bid start price)</th><th>TAT (Days)</th><th>Validity (Days)</th><th>Warranty (Days)</th><th>VAT %</th><th>CST %</th><th>Excise %</th></tr>";

                  jQuery('#tblBidSummary > thead').append(strHead);

                    for (var i = 0; i < data.length; i++) {
                        var str = '';
                        TotalBidValue = (parseFloat(data[i].Quantity) * parseFloat(data[i].LQuote)).toFixed(2);

                        if (TotalBidValue != 0) {
                            if (data[i].TargetPrice != 0) {
                                Percentreduction = parseFloat(100 - parseFloat(data[i].LQuote / data[i].TargetPrice) * 100).toFixed(2) + ' %'
                            }
                            else {
                                Percentreduction = 'Not Specified';
                            }
                            if (data[i].LastInvoicePrice != 0) {
                                Percentreductioninvoice = parseFloat(100 - parseFloat(data[i].LQuote / data[i].LastInvoicePrice) * 100).toFixed(2) + ' %'
                            }
                            else {
                                Percentreductioninvoice = 'Not Specified';
                            }


                            Percentreductionceiling = parseFloat(100 - parseFloat(data[i].LQuote / data[i].CeilingPrice) * 100).toFixed(2) + ' %'
                        } else {

                            Percentreduction = 'N/A';
                            Percentreductionceiling = 'N/A';
                            Percentreductioninvoice = 'N/A';
                        }


                        if (data[i].ShortName != sname) {


                            str = "<tr style='background:#E1E1E1;'><td><b>Item Name:</b> " + data[i].ShortName + "</td><td><b>Target Price:</b> " + data[i].TargetPrice + "</td><td><b>Last Invoice Price:</b> " + data[i].LastInvoicePrice + "</td><td><b>Bid start price:</b> " + data[i].CeilingPrice + "</td><td><b>Quantity:</b> " + data[i].Quantity + "</td><td><b>UOM:</b> " + data[i].UOM + "</td><td><b>Contract Duration:</b> " + data[i].ContractDuration + "</td><td><b>Delivery Location:</b> " + data[i].DeliveryLocation + "</td></tr>"; //<td><b>Delivery Location:</b> " + data[i].DeliveryLocation + "</td>
                            sname = data[i].ShortName

                        }


                        str += "<tr  id=low" + i + "><td>" + data[i].VendorName + "</td><td><b>Position:</b><br/>" + data[i].SrNo + "</td>";
                        str += "<td><b>Final Quote:</b><br/>" + (data[i].LQuote == '0' ? '' : data[i].LQuote) + "</td><td><b>Initial Quote:</b><br/>" + (data[i].IQuote == '0' ? '' : data[i].IQuote) + "</td>";
                        str += "<td><b>Total Bid Value:</b><br/>" + TotalBidValue + "</td>";
                        if (data[i].SrNo == 'L1') {

                            str += "<td style='background-color: #d9edf7; color: #31708f;'><b>Reduction from Target Price:</b><br/>" + Percentreduction + "</td>";
                            str += "<td style='background-color: #d9edf7; color: #31708f;'><b>Reduction from Last Invoice Price:</b><br/>" + Percentreductioninvoice + "</td>";
                            str += "<td style='background-color: #d9edf7; color: #31708f;'><b>Reduction from Bid start price:</b><br/>" + Percentreductionceiling + "</td>";

                        } else {

                        str += "<td><b>Reduction from Target Price:</b><br/>" + Percentreduction + "</td>";
                        str += "<td><b>Reduction from Last Invoice Price:</b><br/>" + Percentreductioninvoice + "</td>";
                        str += "<td><b>Reduction from Bid start price:</b><br/>" + Percentreductionceiling + "</td>";


                        }

//                        str += "<td>" + (data[i].TAT == '0' ? '' : data[i].TAT) + "</td>";
//                        str += "<td>" + (data[i].Validity == '0' ? '' : data[i].Validity) + "</td>";
//                        str += "<td>" + (data[i].Warranty == '0' ? '' : data[i].Warranty) + "</td>";
//                        str += "<td>" + (data[i].VAT == '0' ? '' : data[i].VAT) + "</td>";
//                        str += "<td>" + (data[i].CST == '0' ? '' : data[i].CST) + "</td>";
//                        str += "<td>" + (data[i].Excise == '0' ? '' : data[i].Excise) + "</td>";

                        str += "</tr>";



                        jQuery('#tblBidSummary > tbody').append(str);



                        if (data[i].SrNo == 'L1') {
                            $('#low' + i).css({
                                'background-color': '#dff0d8',
                                'font-weight': 'bold',
                                'color': '#3c763d'
                            })

                        }

                    }
                }
                else if (parseInt(BidTypeID) == 6) {
                    $('#lnktotvalue').html('Detailed Report')
                    if ($('#lnktotvalue').html() == "Detailed Report") {
                        jQuery("#tblBidSummary").hide()
                        jQuery("#tblbidsummarypercentagewise").show()
                        $('#divfordetailreport').show()
                        $('#divforBidsummary').hide()
                    }

                    counterForItenscount = 0;
                    var TotalBidValue = ''; // TotalBidValueCeiling = '', TotalBidValueInvoice = '';

                    var Percentreduction = '', Percentreductionceiling = '', Percentreductioninvoice = '';
                    $('#divTarget').hide();
                    var sname = '';
                    if (BidForID == 81) {
                        $('#BidTrendGraph').css('display','block');
                        var strHead = "<tr><th>Item/Product</th><th>Target Price</th><th>Last Invoice Price</th><th>Bid Start Price</th><th>Quantity</th><th>UOM</th><th>Minimum Increament</th><th>Level</th><th>Vendor</th><th>Initial Quote</th><th>Highest Quote</th><th>Bid Value</th><th>Percentage Increment (Target Price)</th><th>Percentage Increment (Last Invoice Price)</th><th>Percentage Increment (Bid start price)</th></tr>"; //<th>Contract Duration</th><th>Dispatch Location</th>
                    }
                    else {
                       
                        $('#BidTrendGraph').css('display', 'none');
                        var strHead = "<tr><th>Item/Product</th><th>Target Price</th><th>Last Invoice Price</th><th>Bid Start Price</th><th>Ceiling/ Max Price</th><th>Quantity</th><th>UOM</th><th>Minimum Increament</th><th>Level</th><th>Vendor</th><th>Accepted Price</th><th>Bid Value</th><th>Percentage Decrement (Target Price)</th><th>Percentage Decrement (Last Invoice Price)</th><th>Percentage Decrement (Ceiling/ Max Price)</th></tr>";
                    }
                   

                    // var strHeadsummary = "<tr><th>Product</th><th>Target Price</th><th>Last Sale Price</th><th>Bid start price</th><th>Quantity</th><th>UOM</th><th>Level</th><th>Vendor</th><th>Initial Quote</th><th>Highest Quote</th><th>Bid Value</th><th>Percentage Reduction (Target Price)</th><th>Percentage Reduction (Last Sale Price)</th><th>Percentage Reduction (Bid start price)</th></tr>";

                    //                    strHead += "<th>Shipping Line</th><th>Sailling Days</th><th>Ocean Transit Time</th></tr>";

                    jQuery('#tblBidSummary > thead').append(strHead);
                    //jQuery('#tblbidsummarypercentagewise > thead').append(strHeadsummary);
                    for (var i = 0; i < data.length; i++) {

                        TotalBidValue = (parseFloat(data[i].Quantity) * parseFloat(data[i].LQuote)).toFixed(2);

                        if (TotalBidValue != 0) {
                            if (data[i].TargetPrice != 0) {
                                if (BidForID == 81) {
                                    Percentreduction = parseFloat(parseFloat(data[i].LQuote / data[i].TargetPrice) * 100 - 100).toFixed(2) + ' %'
                                }
                                else {
                                    Percentreduction = parseFloat(100 - parseFloat(data[i].LQuote / data[i].TargetPrice) * 100).toFixed(2) + ' %'
                                }
                            }
                            else {
                                Percentreduction = 'Not Specified';
                            }
                            if (data[i].LastInvoicePrice != 0) {
                                if (BidForID == 81) {
                                    Percentreductioninvoice = parseFloat(parseFloat(data[i].LQuote / data[i].LastInvoicePrice) * 100 - 100).toFixed(2) + ' %'
                                }
                                else {
                                    Percentreductioninvoice = parseFloat(100 - parseFloat(data[i].LQuote / data[i].LastInvoicePrice) * 100).toFixed(2) + ' %'
                                }

                            }
                            else {
                                Percentreductioninvoice = 'Not Specified';
                            }

                            if (BidForID == 81) {
                                Percentreductionceiling = parseFloat(parseFloat(data[i].LQuote / data[i].CeilingPrice) * 100 - 100).toFixed(2) + ' %'
                            }
                            else {
                                Percentreductionceiling = parseFloat(100 - parseFloat(data[i].LQuote / data[i].CeilingPrice) * 100).toFixed(2) + ' %'
                            }

                        }
                        else {

                            Percentreduction = 'N/A';
                            Percentreductionceiling = 'N/A';
                            Percentreductioninvoice = 'N/A';
                        }
                        if (sname != data[i].ShortName) {
                            sname = data[i].ShortName
                            if (BidForID == 81) {
                                var str = "<tr id=low" + i + "><td>" + data[i].ShortName + "</td><td class='text-right'>" + thousands_separators(data[i].TargetPrice) + "</td><td class='text-right'>" + thousands_separators(data[i].LastInvoicePrice) + "</td><td class='text-right'>" + thousands_separators(data[i].CeilingPrice) + "</td><td class='text-right'>" + thousands_separators(data[i].Quantity) + "</td><td>" + data[i].UOM + "</td><td>" + data[i].MinimumIncreament + "</td>";
                                counterForItenscount = counterForItenscount + 1;
                                if (counterForItenscount <= 6) {
                                    fnPaintGraph(data[i].ShortName, counterForItenscount, data[i].PSID)
                                }

                            } else {
                                var str = "<tr id=low" + i + "><td>" + data[i].ShortName + "</td><td class='text-right'>" + thousands_separators(data[i].TargetPrice) + "</td><td class='text-right'>" + thousands_separators(data[i].LastInvoicePrice) + "</td><td class='text-right'>" + thousands_separators(data[i].StartingPrice) + "</td><td class='text-right'>" + thousands_separators(data[i].CeilingPrice) + "</td><td class='text-right'>" + thousands_separators(thousands_separators(data[i].Quantity)) + "</td><td>" + data[i].UOM + "</td><td>" + data[i].MinimumIncreament + "</td>";
                               
                            }
                            // var strsumm = "<tr id=low" + i + "><td>" + data[i].ShortName + "</td><td>" + data[i].TargetPrice + "</td><td>" + data[i].LastInvoicePrice + "</td><td>" + data[i].CeilingPrice + "</td><td>" + data[i].Quantity + "</td><td>" + data[i].UOM + "</td>";

                        }
                        else {
                            if (BidForID == 81) {
                                var str = "<tr id=low" + i + "><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>";
                            }
                            else {
                                var str = "<tr id=low" + i + "><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>";
                            }
                            
                            // var strsumm = "<tr id=low" + i + "><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>";
                        }


                        if (BidForID == 81) {
                            str += "<td>" + data[i].SrNo + "</td><td>" + data[i].VendorName + "</td><td class=text-right>" + thousands_separators((data[i].IQuote == '0' ? '' : data[i].IQuote)) + "</td>";
                            str += "<td class=text-right>" + thousands_separators((data[i].LQuote == '0' ? '' : data[i].LQuote)) + "</td>";
                            str += "<td class=text-right>" + thousands_separators(TotalBidValue) + "</td>";
                           
                        }
                        else {
                            // alert(data[i].SrNo)
                            str += "<td>" + data[i].SrNo + "</td><td>" + data[i].VendorName + "</td>";
                            str += "<td class=text-right>" + thousands_separators((data[i].LQuote == '0' ? '' : data[i].LQuote)) + "</td>";
                            str += "<td class=text-right>" + thousands_separators(TotalBidValue) + "</td>";
                           
                        }
                        if (data[i].SrNo == 'H1') {
                            str += "<td style='background-color: #d9edf7; color: #31708f;'>" + Percentreduction + "</td>";
                            str += "<td style='background-color: #d9edf7; color: #31708f;'>" + Percentreductioninvoice + "</td>";
                            str += "<td style='background-color: #d9edf7; color: #31708f;'>" + Percentreductionceiling + "</td>";
                        }
                        else if (data[i].SrNo == 'L1') {
                            str += "<td style='background-color: #d9edf7; color: #31708f;'>" + Percentreduction + "</td>";
                            str += "<td style='background-color: #d9edf7; color: #31708f;'>" + Percentreductioninvoice + "</td>";
                            str += "<td style='background-color: #d9edf7; color: #31708f;'>" + Percentreductionceiling + "</td>";
                        }
                            else {
                            str += "<td>" + Percentreduction + "</td>";
                            str += "<td>" + Percentreductioninvoice + "</td>";
                            str += "<td>" + Percentreductionceiling + "</td>";

                        }


                        //    //str += "<td>" + (data[i].ShippingLine == null ? '' : data[i].ShippingLine) + "</td><td>" + (data[i].SailingDays == null ? '' : data[i].SailingDays) + "</td><td>" + (data[i].OceanTransitTime == null ? '' : data[i].OceanTransitTime) + "</td>";
                        str += "</tr>";

                        jQuery('#tblBidSummary > tbody').append(str);



                        if (data[i].SrNo == 'H1') {
                            $('#low' + i).css({
                                'background-color': '#dff0d8',
                                'font-weight': 'bold',
                                'color': '#3c763d'
                            })

                        }
                    }
                }
                else if (parseInt(BidTypeID) == 7) {
                    counterForItenscount = 0;
                    $('#BidTrendGraph').css('display', 'block');
                    var TotalBidValue = ''; // TotalBidValueCeiling = '', TotalBidValueInvoice = '';

                    var Percentreduction = '', Percentreductionceiling = '', Percentreductioninvoice = '';
                    $('#divTarget').hide();
                    var sname = '';
                     var ItemNameHead = stringDivider("Item Product Service", 5, "<br/>\n");
                   
                     if (_bidclosingtype != 'undefined' && _bidclosingtype == 'S') {
                         var strHead = "<tr><th>" + ItemNameHead + "</th><th>Target Price</th><th>Last Invoice Price</th><th>Bid start price</th><th>Quantity</th><th>UOM</th><th>Minimum Dec.</th><th>Item Closing Time</th><th>Level</th><th>Vendor</th><th>Loading Factor - &lambda; (in %)</th><th>Initial Quote</th><th>Lowest Quote</th><th>Bid Value</th><th>Percentage Reduction (Target Price)</th><th>Percentage Reduction (Last Invoice Price)</th><th>Percentage Reduction (Bid start price)</th></tr>";
                     }
                     else {
                         var strHead = "<tr><th>" + ItemNameHead + "</th><th>Target Price</th><th>Last Invoice Price</th><th>Bid start price</th><th>Quantity</th><th>UOM</th><th>Minimum Dec.</th><th>Level</th><th>Vendor</th><th>Loading Factor - &lambda; (in %)</th><th>Initial Quote</th><th>Lowest Quote</th><th>Bid Value</th><th>Percentage Reduction (Target Price)</th><th>Percentage Reduction (Last Invoice Price)</th><th>Percentage Reduction (Bid start price)</th></tr>";
                     }

                    jQuery('#tblBidSummary > thead').append(strHead);
                   

                    for (var i = 0; i < data.length; i++) {

                        TotalBidValue = (parseFloat(data[i].Quantity) * parseFloat(data[i].LQuote)).toFixed(2);

                        if (TotalBidValue != 0) {
                            if (data[i].TargetPrice != 0) {
                                Percentreduction = parseFloat(100 - parseFloat(data[i].LQuote / data[i].TargetPrice) * 100).toFixed(2) + ' %'
                            }
                            else {
                                Percentreduction = 'Not Specified';
                            }
                            if (data[i].LastInvoicePrice != 0) {
                                Percentreductioninvoice = parseFloat(100 - parseFloat(data[i].LQuote / data[i].LastInvoicePrice) * 100).toFixed(2) + ' %'
                            }
                            else {
                                Percentreductioninvoice = 'Not Specified';
                            }


                            Percentreductionceiling = parseFloat(100 - parseFloat(data[i].LQuote / data[i].CeilingPrice) * 100).toFixed(2) + ' %'
                        }
                        else {

                            Percentreduction = 'N/A';
                            Percentreductionceiling = 'N/A';
                            Percentreductioninvoice = 'N/A';
                        }

                        if (sname != data[i].DestinationPort) {
                            sname = data[i].DestinationPort
                            if (_bidclosingtype != 'undefined' && _bidclosingtype == 'S') {
                                var str = "<tr id=low" + i + "><td>" + data[i].DestinationPort + "</td><td class=text-right>" + thousands_separators(data[i].TargetPrice) + "</td><td class=text-right>" + thousands_separators(data[i].LastInvoicePrice) + "</td><td class=text-right>" + thousands_separators(data[i].CeilingPrice) + "</td><td class=text-right>" + thousands_separators(data[i].Quantity) + "</td><td>" + data[i].UOM + "</td><td class='text-right'>" + data[i].MinimumDecreament + "</td><td>" + data[i].closingTime + "</td>";
                            }
                            else {
                                var str = "<tr id=low" + i + "><td>" + data[i].DestinationPort + "</td><td class=text-right>" + thousands_separators(data[i].TargetPrice) + "</td><td class=text-right>" + thousands_separators(data[i].LastInvoicePrice) + "</td><td class=text-right>" + thousands_separators(data[i].CeilingPrice) + "</td><td class=text-right>" + thousands_separators(data[i].Quantity) + "</td><td>" + data[i].UOM + "</td><td class='text-right'>" + data[i].MinimumDecreament + "</td>";
                            }
                            counterForItenscount = counterForItenscount + 1;
                            if (counterForItenscount <= 6) {
                                fnPaintGraph(data[i].DestinationPort, counterForItenscount, data[i].SeId)
                            }

                        }
                        else {
                            if (_bidclosingtype != 'undefined' && _bidclosingtype == 'S') {
                                var str = "<tr id=low" + i + "><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>";
                            }
                            else {
                                var str = "<tr id=low" + i + "><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>";
                            }

                        }

                       
                            str += "<td>" + data[i].SrNo + "</td><td>" + data[i].VendorName + "</td><td class='text-right'>" + thousands_separators(data[i].AdvFactor) + "</td><td>" + (data[i].IQuote != '-93' ? data[i].IQuote : thousands_separators(data[i].IPrice)) + "</td>";
                       
                        str += "<td class='text-right'>" + thousands_separators(data[i].LQuote == '0' ? '' : data[i].LQuote) + "</td>";
                        str += "<td class='text-right'>" + thousands_separators(TotalBidValue) + "</td>";

                        if (data[i].SrNo == 'L1') {
                            str += "<td style='background-color: #d9edf7; color: #31708f;'>" + Percentreduction + "</td>";
                            str += "<td style='background-color: #d9edf7; color: #31708f;'>" + Percentreductioninvoice + "</td>";
                            str += "<td style='background-color: #d9edf7; color: #31708f;'>" + Percentreductionceiling + "</td>";



                        } else {
                            str += "<td>" + Percentreduction + "</td>";
                            str += "<td>" + Percentreductioninvoice + "</td>";
                            str += "<td>" + Percentreductionceiling + "</td>";

                        }
                        str += "</tr>";

                        jQuery('#tblBidSummary > tbody').append(str);

                        if (data[i].SrNo == 'L1') {
                            $('#low' + i).css({
                                'background-color': '#dff0d8',
                                'font-weight': 'bold',
                                'color': '#3c763d'
                            })

                        }
                    }
                   
                }
                else if (parseInt(BidTypeID) == 2) {
                    if (parseInt(BidForID) == 2) {
                        var strHead = "<tr><th rowspan='2'>Level</th><th rowspan='2'>Vendor Name</th><th rowspan='2'>Carrier</th><th rowspan='2'>Loading Airport</th><th rowspan='2'>Consolidation Days</th>";
                        strHead += "<th colspan='6'>Freight</th><th colspan='6'>Ex-Works</th><th rowspan='2'>FSC</th><th rowspan='2'>SSC</th><th rowspan='2'>DO Charges</th><th colspan='6'>Total (Including surcharges)</th><th rowspan='2'>Total For Model Class</th>";
                        strHead += "</tr>";
                        strHead += "<tr><th>Min</th><th>45+</th><th>100+</th><th>300+</th><th>500+</th><th>1000+</th><th>Min</th><th>45+</th><th>100+</th><th>300+</th><th>500+</th><th>1000+</th><th>Min</th><th>45+</th><th>100+</th><th>300+</th><th>500+</th><th>1000+</th>";
                        strHead += "</tr>";
                        jQuery('#tblBidSummary > thead').append(strHead);
                        for (var i = 0; i < data.length; i++) {
                            var str = "<tr id=low2" + i + "><td>" + data[i].SrNo + "</td><td>" + data[i].VendorName + "</td><td>" + data[i].Carrier + "</td><td>" + data[i].LoadingAirport + "</td>";
                            str += "<td>" + data[i].ConsolidationDays + "</td><td>" + (data[i].FreightMin == null ? '' : data[i].FreightMin) + "</td>";
                            str += "<td>" + (data[i].FreightPlus45 == null ? '' : data[i].FreightPlus45) + "</td><td>" + (data[i].FreightPlus100 == null ? '' : data[i].FreightPlus100) + "</td><td>" + (data[i].FreightPlus300 == null ? '' : data[i].FreightPlus300) + "</td>";
                            str += "<td>" + (data[i].FreightPlus500 == null ? '' : data[i].FreightPlus500) + "</td><td>" + (data[i].FreightPlus1000 == null ? '' : data[i].FreightPlus1000) + "</td><td>" + (data[i].ExWorksMin == null ? '' : data[i].ExWorksMin) + "</td>";
                            str += "<td>" + (data[i].ExWorksPlus45 == null ? '' : data[i].ExWorksPlus45) + "</td><td>" + (data[i].ExWorksPlus100 == null ? '' : data[i].ExWorksPlus100) + "</td><td>" + (data[i].ExWorksPlus300 == null ? '' : data[i].ExWorksPlus300) + "</td>";
                            str += "<td>" + (data[i].ExWorksPlus500 == null ? '' : data[i].ExWorksPlus500) + "</td><td>" + (data[i].ExWorksPlus1000 == null ? '' : data[i].ExWorksPlus1000) + "</td><td>" + (data[i].FSC == '0' ? '' : data[i].FSC) + "</td><td>" + (data[i].SSC == '0' ? '' : data[i].SSC) + "</td><td>" + (data[i].DoCharges == null ? '' : data[i].DoCharges) + "</td>";
                            str += "<td>" + (data[i].TotMin == null ? '' : data[i].TotMin) + "</td><td>" + (data[i].Tot45 == null ? '' : data[i].Tot45) + "</td><td>" + (data[i].Tot100 == null ? '' : data[i].Tot100) + "</td><td>" + (data[i].Tot300 == null ? '' : data[i].Tot300) + "</td>";
                            str += "<td>" + data[i].Tot500 + "</td><td>" + data[i].Tot1000 + "</td><td>" + data[i].MinPrice + "</td>";
                            str += "</tr>";
                            jQuery('#tblBidSummary > tbody').append(str);
                            if (data[i].SrNo == 'L1') {
                                $('#low2' + i).css({
                                    'background-color': '#dff0d8',
                                    'font-weight': 'bold',
                                    'color': '#3c763d'
                                });

                            }
                        }
                    }
                    if (parseInt(BidForID) == 3) {
                        var strHead = "<tr><th rowspan='2'>Level</th><th rowspan='2'>Vendor Name</th><th rowspan='2'>Carrier</th><th rowspan='2'>Loading Airport</th><th rowspan='2'>Consolidation Days</th>";
                        strHead += "<th colspan='6'>Freight</th><th colspan='6'>Ex-Works</th><th rowspan='2'>FSC</th><th rowspan='2'>SSC</th><th rowspan='2'>DO Charges</th><th colspan='6'>Total (Including surcharges)</th><th rowspan='2'>Total For Model Class</th>";
                        strHead += "</tr>";
                        strHead += "<tr><th>Min</th><th>45+</th><th>100+</th><th>300+</th><th>500+</th><th>1000+</th><th>Min</th><th>45+</th><th>100+</th><th>300+</th><th>500+</th><th>1000+</th><th>Min</th><th>45+</th><th>100+</th><th>300+</th><th>500+</th><th>1000+</th>";
                        strHead += "</tr>";
                        jQuery('#tblBidSummary > thead').append(strHead);
                        for (var i = 0; i < data.length; i++) {
                            var str = "<tr id=low3" + i + "><td>" + data[i].SrNo + "</td><td>" + data[i].VendorName + "</td><td>" + data[i].Carrier + "</td><td>" + (data[i].LoadingAirport == null ? '' : data[i].LoadingAirport) + "</td>";
                            str += "<td>" + (data[i].ConsolidationDays == null ? '' : data[i].ConsolidationDays) + "</td><td>" + (data[i].FreightMin == null ? '' : data[i].FreightMin) + "</td>";
                            str += "<td>" + (data[i].FreightPlus45 == null ? '' : data[i].FreightPlus45) + "</td><td>" + (data[i].FreightPlus100 == null ? '' : data[i].FreightPlus100) + "</td><td>" + (data[i].FreightPlus300 == null ? '' : data[i].FreightPlus300) + "</td>";
                            str += "<td>" + (data[i].FreightPlus500 == null ? '' : data[i].FreightPlus500) + "</td><td>" + (data[i].FreightPlus1000 == null ? '' : data[i].FreightPlus1000) + "</td><td>" + (data[i].ExWorksMin == null ? '' : data[i].ExWorksMin) + "</td>";
                            str += "<td>" + (data[i].ExWorksPlus45 == null ? '' : data[i].ExWorksPlus45) + "</td><td>" + (data[i].ExWorksPlus100 == null ? '' : data[i].ExWorksPlus100) + "</td><td>" + (data[i].ExWorksPlus300 == null ? '' : data[i].ExWorksPlus300) + "</td>";
                            str += "<td>" + (data[i].ExWorksPlus500 == null ? '' : data[i].ExWorksPlus500) + "</td><td>" + (data[i].ExWorksPlus1000 == null ? '' : data[i].ExWorksPlus1000) + "</td><td>" + (data[i].FSC == '0' ? '' : data[i].FSC) + "</td><td>" + (data[i].SSC == '0' ? '' : data[i].SSC) + "</td><td>" + (data[i].DoCharges == null ? '' : data[i].DoCharges) + "</td>";
                            str += "<td>" + (data[i].TotMin == null ? '' : data[i].TotMin) + "</td><td>" + (data[i].Tot45 == null ? '' : data[i].Tot45) + "</td><td>" + (data[i].Tot100 == null ? '' : data[i].Tot100) + "</td><td>" + (data[i].Tot300 == null ? '' : data[i].Tot300) + "</td>";
                            str += "<td>" + (data[i].Tot500 == null ? '' : data[i].Tot500) + "</td><td>" + (data[i].Tot1000 == null ? '' : data[i].Tot1000) + "</td><td>" + (data[i].MinPrice == null ? '' : data[i].MinPrice) + "</td>";
                            str += "</tr>";
                            jQuery('#tblBidSummary > tbody').append(str);
                            if (data[i].SrNo == 'L1') {
                                $('#low3' + i).css({
                                    'background-color': '#dff0d8',
                                    'font-weight': 'bold',
                                    'color': '#3c763d'
                                });

                            }
                        }
                    }
                }
                else if (parseInt(BidTypeID) == 3) {

                    if (parseInt(BidForID) == 4) {
                        //Freight
                        var strHead = "<tr><th>Level</th><th>Vendor</th><th>Initial Quote</th><th>Lowest Quote</th>";
                        strHead += "<th>BAF</th><th>CAF</th><th>Total Value</th><th>Forwarder's Do Charges</th>";
                        strHead += "<th>Shipping Line</th><th>Sailling Days</th><th>Ocean Transit Time</th></tr>";
                        jQuery('#tblBidSummary > thead').append(strHead);
                        for (var i = 0; i < data.length; i++) {
                            var str = "<tr id=low4" + i + "><td>" + data[i].SrNo + "</td><td>" + data[i].VendorName + "</td>";
                            str += "<td>" + data[i].IQuote + "</td>";
                            str += "<td>" + (data[i].LQuote == null ? '' : data[i].LQuote) + "</td>";
                            //str += "<td>" + ((data[i].ExWorks == null || data[i].ExWorks == 0) ? '' : data[i].ExWorks) + "</td>";
                            str += "<td>" + ((data[i].BAF == null || data[i].BAF == 0) ? '' : data[i].BAF) + "</td>";
                            str += "<td>" + ((data[i].CAF == null || data[i].CAF == 0) ? '' : data[i].CAF) + "</td>";
                            str += "<td>" + (data[i].TotalValue == null ? '' : data[i].TotalValue) + "</td><td>" + (data[i].ForwardersDO == '0' ? '' : data[i].ForwardersDO) + "</td>";
                            str += "<td>" + (data[i].ShippingLine == null ? '' : data[i].ShippingLine) + "</td><td>" + (data[i].SailingDays == null ? '' : data[i].SailingDays) + "</td><td>" + (data[i].OceanTransitTime == null ? '' : data[i].OceanTransitTime) + "</td>";
                            str += "</tr>";
                            jQuery('#tblBidSummary > tbody').append(str);
                            if (data[i].SrNo == 'L1') {
                                $('#low4' + i).css({
                                    'background-color': '#dff0d8',
                                    'font-weight': 'bold',
                                    'color': '#3c763d'
                                });

                            }
                        }
                    }
                    else if (parseInt(BidForID) == 5) {
                        // Total Value
                        var strHead = "<tr><th>Level</th><th>Vendor</th><th>Initial Quote (INR)</th><th>Lowest Quote (INR)</th><th>Freight</th>";
                        strHead += "<th>BAF</th><th>CAF</th><th>Inland Haulage (INR)</th><th>Shipping Line DO Charges (INR)</th><th>Container Cleaning Charges (INR)</th>";
                        strHead += "<th>Shipping Line Any Other Charges (INR)</th><th>Forwarder's DO Charges (INR)</th><th>Shipping Line</th><th>Sailling Days</th><th>Ocean Transit Time</th></tr>";
                        jQuery('#tblBidSummary > thead').append(strHead);
                        for (var i = 0; i < data.length; i++) {
                            var str = "<tr id=low5" + i + "><td>" + data[i].SrNo + "</td><td>" + data[i].VendorName + "</td><td>" + data[i].IQuote + "</td>";
                            str += "<td>" + (data[i].LQuote == '0' ? '' : data[i].LQuote) + "</td><td>" + (data[i].Freight == '0' ? '' : data[i].Freight) + "</td><td>" + (data[i].BAF == '0' ? '' : data[i].BAF) + "</td><td>" + (data[i].CAF == '0' ? '' : data[i].CAF) + "</td>";
                            str += "<td>" + (data[i].InlandHaulage == '0' ? '' : data[i].InlandHaulage) + "</td><td>" + (data[i].ShippingLineDO == '0' ? '' : data[i].ShippingLineDO) + "</td><td>" + (data[i].ContainerClgChg == '0' ? '' : data[i].ContainerClgChg) + "</td>";
                            str += "<td>" + (data[i].ShippingLineOther == '0' ? '' : data[i].ShippingLineOther) + "</td><td>" + (data[i].ForwardersDO == '0' ? '' : data[i].ForwardersDO) + "</td>";
                            str += "<td>" + data[i].ShippingLine + "</td><td>" + data[i].SailingDays + "</td><td>" + data[i].OceanTransitTime + "</td>";
                            str += "</tr>";
                            jQuery('#tblBidSummary > tbody').append(str);
                            if (data[i].SrNo == 'L1') {
                                $('#low5' + i).css({
                                    'background-color': '#dff0d8',
                                    'font-weight': 'bold',
                                    'color': '#3c763d'
                                });

                            }
                        }
                    }
                    else if (parseInt(BidForID) == 6) {
                        // Freight & Exworks
                        var strHead = "<tr><th>Level</th><th>Vendor</th><th>Initial Quote (INR)</th><th>Lowest Quote (INR)</th><th>Freight</th><th>ExWorks</th>";
                        strHead += "<th>BAF</th><th>CAF</th><th>Inland Haulage (INR)</th><th>Shipping Line's DO Charges (INR)</th><th>Container Cleaning Charges (INR)</th><th>Shipping Line's Any Other Charges (INR)</th><th>Forwarder's Do Charges</th>";
                        strHead += "<th>Shipping Line</th><th>Sailling Days</th><th>Ocean Transit Time</th></tr>";
                        jQuery('#tblBidSummary > thead').append(strHead);
                        for (var i = 0; i < data.length; i++) {
                            var str = "<tr id=low6" + i + "><td>" + data[i].SrNo + "</td><td>" + data[i].VendorName + "</td><td>" + data[i].IQuote + "</td>";
                            str += "<td>" + (data[i].LQuote == '0' ? '' : data[i].LQuote) + "</td><td>" + (data[i].Freight == '0' ? '' : data[i].Freight) + "</td><td>" + (data[i].ExWorks == '0' ? '' : data[i].ExWorks) + "</td><td>" + (data[i].BAF == '0' ? '' : data[i].BAF) + "</td><td>" + (data[i].CAF == '0' ? '' : data[i].CAF) + "</td>";
                            str += "<td>" + (data[i].InlandHaulage == '0' ? '' : data[i].InlandHaulage) + "</td><td>" + (data[i].ShippingLineDO == '0' ? '' : data[i].ShippingLineDO) + "</td><td>" + (data[i].ContainerClgChg == '0' ? '' : data[i].ContainerClgChg) + "</td><td>" + (data[i].ShippingLineOther == '0' ? '' : data[i].ShippingLineOther) + "</td><td>" + (data[i].ForwardersDO == '0' ? '' : data[i].ForwardersDO) + "</td>";
                            str += "<td>" + data[i].ShippingLine + "</td><td>" + data[i].SailingDays + "</td><td>" + data[i].OceanTransitTime + "</td>";
                            str += "</tr>";
                            jQuery('#tblBidSummary > tbody').append(str);
                            if (data[i].SrNo == 'L1') {
                                $('#low6' + i).css({
                                    'background-color': '#dff0d8',
                                    'font-weight': 'bold',
                                    'color': '#3c763d'
                                });

                            }
                        }
                    }
                }

                else if (parseInt(BidTypeID) == 5) { // Warehouse
                    var strHead = "<tr><th>Level</th><th>Vendor</th><th>Initial Quote</th><th>Lowest Quote</th><th>Warehouse Area</th><th>Rent Per Sq. Ft.</th>";
                    strHead += "<th>Manpower Cost</th><th>Infrastructure Cost</th><th>Utilities Cost</th><th>Fixed Management Fee</th></tr>";
                    //                    strHead += "<th>Shipping Line</th><th>Sailling Days</th><th>Ocean Transit Time</th></tr>";
                    jQuery('#tblBidSummary > thead').append(strHead);
                    for (var i = 0; i < data.length; i++) {
                        var str = "<tr id=low7" + i + "><td>" + data[i].SrNo + "</a></td><td>" + data[i].VendorName + "</td>";
                        str += "<td>" + data[i].IQuote + "</td>";
                        str += "<td>" + (data[i].LQuote == '0' ? '' : data[i].LQuote) + "</td><td>" + (data[i].WarehouseArea == '0' ? '' : data[i].WarehouseArea) + "</td>";
                        str += "<td>" + (data[i].PerSquareFeetRate == '0' ? '' : data[i].PerSquareFeetRate) + "</td>";
                        str += "<td>" + (data[i].ManPowerCost == '0' ? '' : data[i].ManPowerCost) + "</td>";
                        str += "<td>" + (data[i].InfrastructureCost == '0' ? '' : data[i].InfrastructureCost) + "</td>";
                        str += "<td>" + (data[i].UtilitiesCost == '0' ? '' : data[i].UtilitiesCost) + "</td><td>" + (data[i].FixedManagementFee == '0' ? '' : data[i].FixedManagementFee) + "</td>";
                        //str += "<td>" + (data[i].ShippingLine == null ? '' : data[i].ShippingLine) + "</td><td>" + (data[i].SailingDays == null ? '' : data[i].SailingDays) + "</td><td>" + (data[i].OceanTransitTime == null ? '' : data[i].OceanTransitTime) + "</td>";
                        str += "</tr>";
                        jQuery('#tblBidSummary > tbody').append(str);
                        if (data[i].SrNo == 'L1') {
                            $('#low7' + i).css({
                                'background-color': '#dff0d8',
                                'font-weight': 'bold',
                                'color': '#3c763d'
                            });

                        }
                    }

                } else if (parseInt(BidTypeID) == 4) { // Domestic
                    var Dname = '';
                    var str = '';
                    var strHead = "<tr><th>Vendor</th><th>Vehicle Type</th><th>Origin Name</th><th>Destination Name</th><th>Level</th><th>Initial Quote</th><th>Lowest Quote</th><th>TAT</th><th>DocketCharge</th><th>FOV</th><th>FSC</th><th>CFT</th><th>MinChargeWt</th><th>ODA </th></tr>";

                    jQuery('#tblBidSummary > thead').append(strHead);
                    for (var i = 0; i < data.length; i++) {
                        if (Dname != data[i].VendorName) {
                            Dname = data[i].VendorName
                            str = "<tr id=lowD" + i + "><td>" + data[i].VendorName + "</td><td>" + data[i].VehicleTypeName + "</td>";
                        }
                        else {
                            str = "<tr id=lowD" + i + "><td>&nbsp;</td><td>&nbsp;</td>";
                        }

                        str += "<td>" + data[i].OriginName + "</td>";
                        str += "<td>" + data[i].DestinationName + "</td>";
                        str += "<td>" + data[i].SrNo + "</td>";
                        str += "<td>" + data[i].IQuote + "</td>"
                        str += "<td>" + data[i].LQuote + "</td>";
                        str += "<td>" + data[i].TAT + "</td>";
                        str += "<td>" + data[i].DocketCharge + "</td>";
                        str += "<td>" + data[i].FOV + "</td>";
                        str += "<td>" + data[i].FSC + "</td>";
                        str += "<td>" + data[i].CFT + "</td>";
                        str += "<td>" + data[i].MinChargeWt + "</td>";
                        str += "<td>" + data[i].ODA + "</td>";
                        str += "</tr>";
                        jQuery('#tblBidSummary > tbody').append(str);
                        if (data[i].SrNo == 'L1') {
                            $('#lowD' + i).css({
                                'background-color': '#dff0d8',
                                'font-weight': 'bold',
                                'color': '#3c763d'
                            });

                        }
                    }

                }
                _bidarray.push(['VendorID', 'Price', 'Time', 'VendorName'])


                _timelft = $('#lblTimeLeft').text();

                if (_timelft == null || _timelft == '') {
                    _timelft = 0;
                }
                else {
                    _timelft = _timelft.slice(0, _timelft.indexOf(':'))


                }

                //alert(_timelft)
                for (var prop = 0; prop < data.length; prop++) {
                    //VendorName.slice(0, data[prop].VendorName.indexOf(' '))
                    _bidarray.push([data[prop].ShortName, parseInt(data[prop].LQuote), parseInt(_timelft), data[prop].VendorName]) //]
                }
                setTimeout(function () {
                // saveAspdf()
                    jQuery.unblockUI();
                    setTimeout(function () {
                        window.print();
                        window.close();
                    }, 1000)
             }, 6000)
                //window.onfocus = function () { setTimeout(function () { window.close(); }, 4000); }


            }
            else {
                jQuery('#tblBidSummary > tbody').append("<tr><td colspan='18' style='text-align: center; color:red;'>No record found</td></tr>");
                jQuery.unblockUI();
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else {
                jQuery("#error").text(xhr.d);
            }
            return false;
            jQuery.unblockUI();
        }
    });
}


function FetchRecomendedVendor(bidid) {
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    // alert(sessionStorage.getItem("APIPath") + "ApprovalAir/FetchRecomendedVendor/?BidID=" + bidid + "&UserID=" + encodeURIComponent(sessionStorage.getItem("UserID")) + "&AuthenticationTonken=" + sessionStorage.getItem("AuthenticationToken"))
    jQuery.ajax({
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ApprovalAir/FetchRecomendedVendor/?BidID=" + bidid + "&UserID=" + encodeURIComponent(sessionStorage.getItem("UserID")) + "&AuthenticationTonken=" + sessionStorage.getItem("AuthenticationToken"),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "GET",
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function(data) {

            $('#tblapprovalprocess').empty()
            if (data.length > 0) {
                $('#tblapprovalprocess').show();

                $('#tblapprovalprocess').append('<tr style="background: #44b6ae;"><th colspan="5" style="font-size: 19px; text-align: left;color: #FFF;">Approval Details</th></tr><tr><th width="20%">Action Taken By</th><th width="20%">Remarks</th><th width="20%">Action Type</th><th style="display:none" id=thvendor width="20%">Recomended Vendor</th><th width="20%">Completion DT</th></tr>')

                for (var i = 0; i < data.length; i++) {
                    if (data[i].VendorName != "") {
                        $('#tblapprovalprocess').append('<tr><td width="20%">' + data[i].ActionTakenBy + '</td><td width="20%">' + data[i].Remarks + '</td><td width="20%">' + data[i].FinalStatus + '</td><td width="20%">' + data[i].VendorName + '</td><td width="20%">' + data[i].ReceiptDt + '</td></tr>')
                        $('#thvendor').show();
                    }
                    else {
                        $('#tblapprovalprocess').append('<tr><td width="20%">' + data[i].ActionTakenBy + '</td><td width="20%">' + data[i].Remarks + '</td><td width="20%">' + data[i].FinalStatus + '</td><td width="20%">' + data[i].ReceiptDt + '</td></tr>')
                        $('#thvendor').hide();
                    }
                }
                
               // jQuery.unblockUI();
            }
            else {
                $('#tblapprovalprocess').append('<tr><td colspan="15" style="text-align: center; color: Red">No record found</td></tr>')
                $('#tblapprovalprocess').hide();
                jQuery.unblockUI();
            }

        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
           
            return false;
            jQuery.unblockUI();
        }
    });

}
var graphData = [];
function fnPaintGraph(shortname, counter, itemId) {
    

    $('#Items').append('<table  width="100%"  class=pagebreak border="1" style="border-collapse: collapse;" id="tblBidItem' + counter + '"></table>')
    if (counter == 1) {
        $('#tblBidItem' + counter).append('<tr><td width="100%"><div id="BidTrendGraph" style="width:100%;margin-top:10px;font-size:20px;line-height: 30px;padding-bottom: 8px;font-family:Arial, Helvetica, sans-serif; font-weight: 200;text-align: center;"><div style="clear: both;"></div> <label style="text-align: center;">Bid Graph Trend</label></div></td></tr>')
    }
    $('#tblBidItem' + counter).append('<tr style="background: #44b6ae;"  width="100%" ><th colspan=2 style="font-size: 19px; text-align: left;color: #FFF;">' + shortname + '</th></tr>')
    $('#tblBidItem' + counter).append('<tbody><tr><td><table width="100%"  cellpadding="8" style="border-collapse: collapse;display:block;"  border="1" id="tblForTrendGraphs' + counter + '"></table></td></tr><tr><td><div id="linechart_material' + counter + '" style="text-align:center;min-height:300px;width:900px;margin-left:200px;margin-bottom:40px;"></div></td></tr></tbody>'); //
    fetchGraphData(itemId,counter);
    linegraphsforItems(itemId,counter);
}
function fetchGraphData(itemId, counter) {
    // alert(itemId)
    var _bidTypeID;
    if (getUrlVarsURL(decryptedstring)["BidTypeID"]) {
        _bidTypeID = getUrlVarsURL(decryptedstring)["BidTypeID"];
    }
    //alert(getUrlVarsURL(decryptedstring)["BidID"])
    var _date;
    var _finaldate=''
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "BidVendorSummary/fetchDataForBidSummaryTrendGraph/?SeId=" + itemId + "&BidId=" + getUrlVarsURL(decryptedstring)["BidID"] + "&BidTypeId=" + _bidTypeID + "&CustomerId=" + sessionStorage.getItem('CustomerID') + "&UserId=" + sessionStorage.getItem('UserID') + "&chartFor=sample",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {

            $("#tblForTrendGraphs" + counter).empty();
            if (data) {
                var str = '';
                var quorem = (data.length / 3) + (data.length % 3);
                var quo = (data.length / 3);

                var len = parseInt(quo) + parseInt(quorem);
                //if (len * 2 <= data.length) {

                //    $("#tblForTrendGraphs" + counter).append("<tr><th>Submission Time</th><th>Quoted Price</th><th>Vendor</th><th>&nbsp;</th><th>Submission Time</th><th>Quoted Price</th><th>Vendor</th></tr>");
                //    for (var i = 0; i < parseInt(quorem); i++) {
                //        _date = new Date(data[i].SubmissionTime);
                //        _finaldate = _date.getDate() + "/" + (_date.getMonth() + 1) + "/" + _date.getFullYear() + " " + minutes_with_leading_zeros(new Date(data[i].SubmissionTime).getHours()) + ":" + minutes_with_leading_zeros(new Date(data[i].SubmissionTime).getMinutes());
                //        str = str + '<tr><td>' + _finaldate + '</td><td>' + data[i].QuotedPrice + '</td><td>' + data[i].VendorName + '</td><td>&nbsp;</td>';

                //        var z = (parseInt(quorem) + i);
                //        if (z <= data.length - 1) {
                //            _date = new Date(data[z].SubmissionTime);
                //            _finaldate = _date.getDate() + "/" + (_date.getMonth() + 1) + "/" + _date.getFullYear() + " " + minutes_with_leading_zeros(new Date(data[z].SubmissionTime).getHours()) + ":" + minutes_with_leading_zeros(new Date(data[z].SubmissionTime).getMinutes());
                //            str = str + '<td>' + _finaldate + '</td><td>' + data[z].QuotedPrice + '</td><td>' + data[z].VendorName + '</td><td>&nbsp;</td>';
                //        }

                //        //var o = (parseInt(quorem) * 2) + i;
                //        //if (o <= data.length - 1) {
                //        //    _date = new Date(data[o].SubmissionTime);
                //        //    _finaldate = _date.getDate() + "/" + (_date.getMonth() + 1) + "/" + _date.getFullYear() + " " + minutes_with_leading_zeros(new Date(data[o].SubmissionTime).getHours()) + ":" + minutes_with_leading_zeros(new Date(data[o].SubmissionTime).getMinutes());
                //        //    str = str + '<td>' + _finaldate + '</td><td>' + data[o].QuotedPrice + '</td><td>' + data[o].VendorName + '</td></tr>';
                //        //}

                //    }
                //}
                //else  {
                $("#tblForTrendGraphs" + counter).append('<tr><th width=10%>Submission Time</th><th width=10%>Quoted Price</th><th width=10%>Vendor</th><th style="border:none;">&nbsp;</th><th width=10%>Submission Time</th><th width=10%>Quoted Price</th><th width=10%>Vendor</th><th style="border:none;">&nbsp;</th><th width=10%>Submission Time</th><th width=10%>Quoted Price</th><th width=10%>Vendor</th></tr>');
                    for (var i = 0; i < parseInt(quorem); i++) {
                        _date = new Date(data[i].SubmissionTime);
                        _finaldate = _date.getDate() + "/" + (_date.getMonth() + 1) + "/" + _date.getFullYear() + " " + minutes_with_leading_zeros(new Date(data[i].SubmissionTime).getHours()) + ":" + minutes_with_leading_zeros(new Date(data[i].SubmissionTime).getMinutes());
                        str = str + '<tr><td>' + _finaldate + '</td><td>' + data[i].QuotedPrice + '</td><td>' + data[i].VendorName + '</td><td style="border: none;">&nbsp;</td>';

                        var z = (parseInt(quorem) + i);
                        if (z <= data.length - 1) {
                            _date = new Date(data[z].SubmissionTime);
                            _finaldate = _date.getDate() + "/" + (_date.getMonth() + 1) + "/" + _date.getFullYear() + " " + minutes_with_leading_zeros(new Date(data[z].SubmissionTime).getHours()) + ":" + minutes_with_leading_zeros(new Date(data[z].SubmissionTime).getMinutes());
                            str = str + '<td>' + _finaldate + '</td><td>' + data[z].QuotedPrice + '</td><td>' + data[z].VendorName + '</td><td style="border: none;">&nbsp;</td>';
                        }

                        var o = (parseInt(quorem) * 2) + i;
                        if (o <= data.length - 1) {
                            _date = new Date(data[o].SubmissionTime);
                            _finaldate = _date.getDate() + "/" + (_date.getMonth() + 1) + "/" + _date.getFullYear() + " " + minutes_with_leading_zeros(new Date(data[o].SubmissionTime).getHours()) + ":" + minutes_with_leading_zeros(new Date(data[o].SubmissionTime).getMinutes());
                            str = str + '<td>' + _finaldate + '</td><td>' + data[o].QuotedPrice + '</td><td>' + data[o].VendorName + '</td></tr>';
                        }

                    }
               // }
                $("#tblForTrendGraphs" + counter).append(str);
                //for (var i = 0; i < data.length; i++) {
                //    _date = new Date(data[i].SubmissionTime);
                //    $("#tblForTrendGraphs" + counter).append("<tr><td>" + _date.getDate() + "/" + (_date.getMonth() + 1) + "/" + _date.getFullYear() + " " + minutes_with_leading_zeros(new Date(data[i].SubmissionTime).getHours()) + ":" + minutes_with_leading_zeros(new Date(data[i].SubmissionTime).getMinutes()) + "</td><td>" + data[i].QuotedPrice + "</td><td>" + data[i].VendorName + "</td></tr>");
                //}
            }

        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
           
            return false;
            jQuery.unblockUI();
        }
    })
}
var Vendorseries = "";
var graphtime = [];
var Seriesoption = [];
var FinalQuotes = [];
var Quotes = "";
var minprice;
var maxprice;
var colorArray = ['#007ED2', '#f15c80', '#90ED7D', '#FF7F50', '#f15c80', '#FF5733', '#96FF33', '#33FFF0', '#F9FF33', '#581845', '#0B0C01', '#0C0109', '#DAF7A6', '#FFC300', '#08010C'];
function linegraphsforItems(itemId, counter) {

    var _bidTypeID;
    var _date;
    if (getUrlVarsURL(decryptedstring)["BidTypeID"]) {
        _bidTypeID = getUrlVarsURL(decryptedstring)["BidTypeID"];
    }
    
    // alert(sessionStorage.getItem("APIPath") + "BidVendorSummary/fetchDataForBidSummaryGraph/?SeId=" + itemId + "&BidId=" + getUrlVars()["BidID"] + "&BidTypeId=" + _bidTypeID + "&CustomerId=" + sessionStorage.getItem('CustomerID') + "&UserId=" + sessionStorage.getItem('UserID') )
    graphtime = [];
    Vendorseries = "";

    Seriesoption = [];
   
    // alert(sessionStorage.getItem("APIPath") + "BidVendorSummary/fetchDataForBidSummaryGraph/?SeId=" + itemId + "&BidId=" + getUrlVars()["BidID"] + "&BidTypeId=" + _bidTypeID + "&CustomerId=" + sessionStorage.getItem('CustomerID') + "&UserId=" + sessionStorage.getItem('UserID'))
    setTimeout(function () {
       
        jQuery.ajax({
            type: "GET",
            contentType: "application/json; charset=utf-8",
            url: sessionStorage.getItem("APIPath") + "BidVendorSummary/fetchDataForBidSummaryGraph/?SeId=" + itemId + "&BidId=" + getUrlVarsURL(decryptedstring)["BidID"] + "&BidTypeId=" + _bidTypeID + "&CustomerId=" + sessionStorage.getItem('CustomerID') + "&UserId=",//+ sessionStorage.getItem('UserID'),
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            cache: false,
            crossDomain: true,
            dataType: "json",
            success: function (data, status, jqXHR) {
                minprice = parseInt(data[0].MinMaxprice[0].MinPrice - 5);
                maxprice = parseInt(data[0].MinMaxprice[0].MaxPrice + 5);
                
                $('#lblbidstarttime').text(data[0].BidStartEndTime[0].BidStartTime);
                $('#lblbidendtime').text(data[0].BidStartEndTime[0].BidEndTime);
              
                if (data[0].SubmissionTime.length > 0) {

                    for (var x = 0; x < data[0].SubmissionTime.length; x++) {
                        graphtime.push(data[0].SubmissionTime[x].SubTime);
                    }

                }
                Vendorseries = "";
                Quotes = "";
                var values = 0;
                Seriesoption = [];
                if (data[0].VendorNames.length > 0) {
                    
                    for (var i = 0; i < data[0].VendorNames.length; i++) {

                        Quotes = "";
                        values = null;;

                        for (var j = 0; j < data[0].QuotesDetails.length; j++) {
                            if (data[0].VendorNames[i].VendorID == data[0].QuotesDetails[j].VendorID) {
                                Quotes = Quotes + '["' + data[0].QuotesDetails[j].SubTime + '",' + data[0].QuotesDetails[j].QuotedPrice + '],';
                                values = data[0].QuotesDetails[j].QuotedPrice;
                            }
                            else {

                                Quotes = Quotes + '["' + data[0].QuotesDetails[j].SubTime + '",' + values + '],';
                            }
                        }

                        Quotes = Quotes.slice(0, -1);
                        Vendorseries = '{ "name" :"' + data[0].VendorNames[i].VendorName + '", "color": "' + colorArray[i] + '","data": [' + Quotes + ']}';
                        Seriesoption.push(JSON.parse(Vendorseries));

                    }
                   // alert(Vendorseries)

                }
               // setTimeout(function () {
                //alert(Vendorseries)
                    $('#linechart_material' + counter).highcharts({
                        title: {
                            text: '',
                            style: {

                                fontSize: '15px',

                            },

                        },

                        xAxis: {

                            title: {
                                text: 'Time'
                            },

                            categories: graphtime

                        },
                        yAxis: {
                            min: minprice,
                            max: maxprice,
                            title: {
                                text: 'Quoted Price'
                            },

                        },

                        series: Seriesoption,

                        credits: {
                            enabled: false
                        },
                        exporting: {
                            showTable: false
                        }

                    });

               // }, 200 );

            },
            error: function (xhr, status, error) {

                var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }

                return false;
                jQuery.unblockUI();
            }

          
    }, 500 * counter);

    })

}



function thousands_separators(num) {
    var num_parts = num.toString().split(".");
    num_parts[0] = num_parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    return num_parts.join(".");
}
function minutes_with_leading_zeros(dtmin) {
    return (dtmin < 10 ? '0' : '') + dtmin;
}

function stringDivider(str, width, spaceReplacer) {
   
    if (str.length > width) {
        var p = width
        for (; p > 0 && str[p] != ' '; p--) {
        }
        if (p > 0) {
            var left = str.substring(0, p);
            var right = str.substring(p + 1);
            return left + spaceReplacer + stringDivider(right, width, spaceReplacer);
        }
    }
    return str;
}