﻿$("#cancelBidBtn").hide();

    $("#txtCeilingPrice,#txtquantitiy,#txtlastinvoiceprice,#txtminimumdecreament,#txtStartingPrice,#txttargetprice,#txtPriceReductionAmount").inputmask({
        alias: "decimal",
        rightAlign: false,
        groupSeparator: ",",
        radixPoint: ".",
        autoGroup: true,
        integerDigits: 40,
        digitsOptional: true,
        allowPlus: false,
        allowMinus: false,
        clearMaskOnLostFocus: true,
       'removeMaskOnSubmit': true

    });


$('#txtBidSubject,#txtshortname').maxlength({
    limitReachedClass: "label label-danger",
    alwaysShow: true
});
jQuery("#txtApprover").keyup(function () {
    sessionStorage.setItem('hdnApproverid', '0');

});
sessionStorage.setItem('hdnApproverid', 0);
jQuery("#txtApprover").typeahead({
    source: function (query, process) {
        var data = allUsers;
        usernames = [];
        map = {};
        var username = "";
        jQuery.each(data, function (i, username) {
            map[username.UserName] = username;
            usernames.push(username.UserName);
        });

        process(usernames);

    },
    minLength: 2,
    updater: function (item) {
        if (map[item].UserID != "0") {
            sessionStorage.setItem('hdnApproverid', map[item].UserID);
            addApprovers();
        }
        else {
            gritternotification('Approver not selected. Please press + Button after selecting Approver.');
        }

        return item;
    }

});
function addApprovers() {
    if (sessionStorage.getItem('hdnApproverid') == "0" || $('#txtApprover').val()=="") {
        $('.alert-danger').show();
        $('#spandanger').html('Approver not selected. Please press + Button after selecting Approver');
        Metronic.scrollTo($(".alert-danger"), -200);
        $('.alert-danger').fadeOut(7000);
        return false;
    }
    else {
        var Approvers = {

            "ApproverID": sessionStorage.getItem('hdnApproverid'),
            "BidID": sessionStorage.getItem('CurrentBidID'),
            "UserID": sessionStorage.getItem('UserID'),
            "CustomerID": sessionStorage.getItem('CustomerID')
        }
         //alert(JSON.stringify(Approvers))
        jQuery.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: sessionStorage.getItem("APIPath") + "eReverseAuction/eRAInsApprover",
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            crossDomain: true,
            async: false,
            data: JSON.stringify(Approvers),
            dataType: "json",
            success: function (data) {
                if (data.length > 0) {

                    if (data[0].OutPut == "1") {
                        fnGetApprovers();

                    }
                    else {
                        $('.alert-danger').show();
                        $('#spandanger').html('Approver is already mapped for this PEFA Auction.');
                        Metronic.scrollTo($(".alert-danger"), -200);
                        $('.alert-danger').fadeOut(7000);
                        return false;
                    }
                    //jQuery("#txtApprover").val('')
                    //sessionStorage.setItem('hdnApproverid', '0')

                }

            },
            error: function (xhr, status, error) {

                var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }
                else {
                    alert(xhr.status + ' ' + xhr.statusText);
                    jQuery.unblockUI();
                }

                return false;
                jQuery.unblockUI();
            }

        });
    }
}
function fnGetApprovers() {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "eReverseAuction/eRAfetchApprover/?BidID=" + sessionStorage.getItem('CurrentBidID') + "&CustomerID=" + sessionStorage.getItem('CustomerID') + "&UserID=" + encodeURIComponent(sessionStorage.getItem('UserID')),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data) {
            var str = "";
           // alert(data.length)
            jQuery("#tblapprovers").empty();
            jQuery("#tblapproversPrev").empty();
            if (data.length > 0) {
                var approvertype = "";
                $('#wrap_scrollerPrevApp').show();
                jQuery('#tblapprovers').append("<thead><tr><th class='bold' style='width:30%!important'>Approver</th><th class='bold' style='width:30%!important'>Email</th><th class='bold' style='width:15%!important'>Sequence</th><th style='width:5%!important'></th></tr></thead>");
                jQuery('#tblapproversPrev').append("<thead><tr><th class='bold' style='width:30%!important'>Approver</th><th class='bold' style='width:30%!important'>Email</th><th class='bold' style='width:15%!important'>Sequence</th></tr></thead>");

                for (var i = 0; i < data.length; i++) {

                    str = "<tr><td>" + data[i].ApproverName + "</td>";
                    str += "<td>" + data[i].EmailID + "</td>";

                    str += "<td>" + data[i].AdminSrNo + "</td>";
                    jQuery('#tblapproversPrev').append(str);
                    str += "<td><button type='button' class='btn btn-xs btn-danger' id=Removebtn" + i + " onclick=fnRemoveBidApprover(\'" + data[i].SrNo + "'\)><i class='glyphicon glyphicon-remove-circle'></i></button></td></tr>";
                    jQuery('#tblapprovers').append(str);

                }
            }
            else {
                // jQuery('#tblapprovers').append("<tr><td colspan=4>Map Approvers</td></tr>")
            }

        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else {
                alert(xhr.status + ' ' + xhr.statusText);
                jQuery.unblockUI();
            }

            return false;
            jQuery.unblockUI();
        }
    })
}
function fnRemoveBidApprover(rowsrno) {
    var Approvers = {
        "SrNo": rowsrno,
        "BidID": sessionStorage.getItem('CurrentBidID')
    }
    jQuery.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "eReverseAuction/eBidApproveRemove",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        crossDomain: true,
        async: false,
        data: JSON.stringify(Approvers),
        dataType: "json",
        success: function (data) {
            if (data[0].OutPut == "1") {

                fnGetApprovers();
                $('.alert-success').show();
                $('#spansuccess1').html('Approver removed successfully!');
                Metronic.scrollTo($(".alert-success"), -200);
                $('.alert-success').fadeOut(7000);
                return false;

            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else {
                alert(xhr.status + ' ' + xhr.statusText);
                jQuery.unblockUI();
            }

            return false;
            jQuery.unblockUI();
        }
    })
}
var _BidDuration = 0;

jQuery('#btnpush').click(function (e) {

    jQuery('#approverList > option:selected').appendTo('#mapedapprover');

});

jQuery('#btnpull').click(function (e) {

    jQuery('#mapedapprover > option:selected').appendTo('#approverList');

});

function fetchVendorparticipanType() {

    jQuery.ajax({

        type: "GET",

        contentType: "application/json; charset=utf-8",

        url: sessionStorage.getItem("APIPath") + "BidType/fetchBidType/?CustomerID=" + sessionStorage.getItem("CustomerID") + "&BidTypeID=0&excludeStatus=N&UserID=" + encodeURIComponent(sessionStorage.getItem('UserID')) + "&AuthenticationToken=" + sessionStorage.getItem('AuthenticationToken'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,

        crossDomain: true,

        dataType: "json",

        success: function (bidTypedata) {



            var strbidtypes = "<div id=\"divrblist\" class=\"checkbox-list\">";

            for (i = 0; i < bidTypedata.length; i++) {

                //strbidtypes += "<label><div class=\"radio\" style=\"cursor:pointer\" ><span id=\"spanrb\"><input type=\"radio\" grou name=\"rbradio\"  onchange=\"Validate(this)\" value=" + bidTypedata[i].BidTypeID + "></span></div>" + bidTypedata[i].BidTypeName + " </label>";

                strbidtypes += "<div class=\"col-md-3\">";

                strbidtypes += "<div class=\"checker\" id=\"uniform-chkbidTypes\"><span  id=\"spanchecked\"><input type=\"checkbox\" id=\"chkBidType\" style=\"cursor:pointer\"  onchange=\"Validate(this)\" name=\"chkBidType\"/></span></div>";

                strbidtypes += "<label class=\"control-label\" id=\"BidTypeID\">&nbsp;&nbsp;" + bidTypedata[i].BidTypeName + "</label><input type=\"hidden\" id=\"hdnBidTypeID\" value=" + bidTypedata[i].BidTypeID + " /></div>";

            }

            strbidtypes += "</div>";

            jQuery("div#divbidtypelist").append(strbidtypes);

        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else {
                alert(xhr.status + ' ' + xhr.statusText);
                jQuery.unblockUI();
            }

            return false;
            jQuery.unblockUI();
        }

    });

}

function FetchCurrency(CurrencyID) {

    jQuery.ajax({

        type: "GET",

        contentType: "application/json; charset=utf-8",

        url: sessionStorage.getItem("APIPath") + "ConfigureBid/FetchCurrency/?CurrencyID=" + CurrencyID + "&excludeStatus=N",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,

        dataType: "json",

        success: function (data) {

            jQuery("#dropCurrency").empty();

            jQuery("#dropCurrency").append(jQuery("<option ></option>").val("").html("Select"));

            for (var i = 0; i < data.length; i++) {

                jQuery("#dropCurrency").append(jQuery("<option></option>").val(data[i].CurrencyId).html(data[i].CurrencyNm));

            }

        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else {
                alert(xhr.status + ' ' + xhr.statusText);
                jQuery.unblockUI();
            }

            return false;
            jQuery.unblockUI();
        }

    });

}



function FetchVender(ByBidTypeID) {

    jQuery.ajax({

        type: "GET",

        contentType: "application/json; charset=utf-8",

        url: sessionStorage.getItem("APIPath") + "ConfigureBid/FetchVendor/?ByBidTypeID=" + ByBidTypeID + "&CustomerID=" + sessionStorage.getItem('CustomerID'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,

        dataType: "json",

        success: function (data) {

            jQuery("#tblvendorlist > tbody").empty();
            var vName = '';
            for (var i = 0; i < data.length; i++) {
                vName = data[i].VendorName;
                var str = "<tr><td><div class=\"checker\" id=\"uniform-chkbidTypes\"><span  id=\"spanchecked\"><input type=\"checkbox\" Onclick=\"Check(this,\'" + vName + "'\,\'" + data[i].VendorID + "'\)\"; id=\"chkvender" + i + "\" value=" + data[i].VendorID + " style=\"cursor:pointer\" name=\"chkvender\"/></span></div></td><td> " + data[i].VendorName + " </td></tr>";

                jQuery('#tblvendorlist > tbody').append(str);

            }

        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else {
                alert(xhr.status + ' ' + xhr.statusText);
                jQuery.unblockUI();
            }

            return false;
            jQuery.unblockUI();
        }

    });

}
var vCount = 0;

function Check(event, vname, vendorID) {

    if ($(event).closest("span#spanchecked").attr('class') == 'checked') {

        $(event).closest("span#spanchecked").removeClass("checked")

    }

    else {
        vCount = vCount + 1;
        var EvID = event.id;
        $(event).prop("disabled", true);
        $(event).closest("span#spanchecked").addClass("checked")
        jQuery('#selectedvendorlists').append('<tr id=SelecetedVendor' + vendorID + '><td class=hide>' + vendorID + '</td><td>' + vname + '</td><td><a href="javascript:;" class="btn btn-xs btn-danger" onclick="removevendor(SelecetedVendor' + vendorID + ',' + EvID + ',SelecetedVendorPrev' + vendorID + ')"><i class="glyphicon glyphicon-remove-circle"></i></a></td></tr>')
        jQuery('#selectedvendorlistsPrev').append('<tr id=SelecetedVendorPrev' + vendorID + '><td class=hide>' + vendorID + '</td><td>' + vname + '</td></tr>')
        $('#divvendorlist').find('span#spandynamic').hide();

        $('table#tblvendorlist').closest('.inputgroup').removeClass('has-error');

    }

    if (vCount > 0) {
        jQuery('#selectedvendorlists').show()
        jQuery('#selectedvendorlistsPrev').show()
    }
    else {
        jQuery('#selectedvendorlists').hide()
        jQuery('#selectedvendorlistsPrev').hide()
    }

}

function removevendor(trid, chkid, Prevtrid) {
    vCount = vCount - 1;
  
    $('#' + trid.id).remove()
    $('#' + Prevtrid.id).remove()
    $(chkid).closest("span#spanchecked").removeClass("checked")
    $(chkid).prop("disabled", false);
    if (vCount > 0) {
        jQuery('#selectedvendorlists').show()
        jQuery('#selectedvendorlistsPrev').show()
    }
    else {
        $('#chkAll').closest("span").removeClass("checked")
        $('#chkAll').prop("checked", false);
        jQuery('#selectedvendorlists').hide()
        jQuery('#selectedvendorlistsPrev').hide()
    }
}

var status;

function ValidateVendor() {

    status = "false";

    var i = 0;

    $('#divvendorlist').find('span#spandynamic').hide();
    if ($("#ddlAuctiontype option:selected").val() == 81) {
        $("#tblvendorlist> tbody > tr").each(function (index) {

            if ($(this).find("span#spanchecked").attr('class') == 'checked') {
                i = i + 1;
                if (i >= 2) {

                    status = "True";
                }
                else {
                    status == "false";
                }

            }

        });
    }
    else {
         $("#tblvendorlist> tbody > tr").each(function (index) {
              if ($(this).find("span#spanchecked").attr('class') == 'checked') {
                    i = i + 1;
                    if (i >= 1) {

                        status = "True";
                    }
                    else {
                        status == "false";
                    }

                }

            });
        
    }

    if (status == "false") {

        $('.alert-danger').show();
        if ($("#ddlAuctiontype option:selected").val() == 81) {
            $('#spandanger').html('Please select atleast two vendors');
        }
        else {
            $('#spandanger').html('Please select atleast one vendors');
        }
        Metronic.scrollTo($('.alert-danger'), -200);
        $('.alert-danger').fadeOut(5000);
        $('table#tblvendorlist').closest('.inputgroup').addClass('has-error');

        status = "false";

    }

    return status;

}




$("#chkAll").click(function () {

//    if ($("#chkAll").is(':checked') == true) {

//        $('#divvendorlist').find('span#spandynamic').hide();

//        $('table#tblvendorlist').closest('.inputgroup').removeClass('has-error');

//        $("#tblvendorlist> tbody > tr").each(function (index) {

//            $(this).find("span#spanchecked").addClass("checked");

//        });

//    }

//    else {

//        $("#tblvendorlist> tbody > tr").each(function (index) {

//            $(this).find("span#spanchecked").removeClass("checked");

//        });

//    }

if ($("#chkAll").is(':checked') == true) {
    $('#divvendorlist').find('span#spandynamic').hide();
    $('table#tblvendorlist').closest('.inputgroup').removeClass('has-error');
    jQuery('#selectedvendorlists> tbody').empty()
    jQuery('#selectedvendorlistsPrev> tbody').empty()
    vCount = 0;
    $("#tblvendorlist> tbody > tr").each(function(index) {
        $(this).find("span#spanchecked").addClass("checked");
        $('#chkvender' + vCount).prop("disabled", true);
        var vendorid = $('#chkvender' + vCount).val()
        var v = vCount;
        vCount = vCount + 1;
        var vname = $.trim($(this).find('td:eq(1)').html())
        jQuery('#selectedvendorlists').append('<tr id=SelecetedVendor' + vendorid + '><td class=hide>' + vendorid + '</td><td>' + vname + '</td><td><a href="javascript:;" class="btn btn-xs btn-danger" onclick="removevendor(SelecetedVendor' + vendorid + ',' + 'chkvender' + v + ',SelecetedVendorPrev' + vendorid + ')"><i class="glyphicon glyphicon-remove-circle"></i></a></td></tr>')
        jQuery('#selectedvendorlistsPrev').append('<tr id=SelecetedVendorPrev' + vendorid + '><td class=hide>' + vendorid + '</td><td>' + vname + '</td></tr>')

    });
}
else {
    $("#tblvendorlist> tbody > tr").each(function(index) {
        $(this).find("span#spanchecked").removeClass("checked");
        vCount = 0;
        $('input[name="chkvender"]').prop('disabled', false);
        jQuery('#selectedvendorlists> tbody').empty()
        jQuery('#selectedvendorlistsPrev> tbody').empty()
    });

}
if (vCount > 0) {
    jQuery('#selectedvendorlists').show()
    jQuery('#selectedvendorlistsPrev').show()
}
else {
    jQuery('#selectedvendorlists').hide()
    jQuery('#selectedvendorlistsPrev').hide()
}

});



var allUsers = '';
function fetchRegisterUser(bidtypeid) {

    jQuery.ajax({

        type: "GET",

        contentType: "application/json; charset=utf-8",

        url: sessionStorage.getItem("APIPath") + "RegisterUser/fetchRegisterUser/?CustomerID=" + sessionStorage.getItem("CustomerID") + "&UserID=0&BidTypeID=" + bidtypeid + "&LoginUserID=" + encodeURIComponent(sessionStorage.getItem('UserID')) + "&AuthenticationToken=" + sessionStorage.getItem('AuthenticationToken'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,

        crossDomain: true,

        dataType: "json",

        success: function (data) {
            if (data.length > 0) {
                allUsers = data;
            }
            else {
                allUsers = '';
            }
            //jQuery("#approverList").empty();

            //for (var i = 0; i < data.length; i++) {

            //    jQuery("#approverList").append(jQuery("<option></option>").val(data[i].UserID).html(data[i].UserName));

            //}

        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else {
                alert(xhr.status + ' ' + xhr.statusText);
                jQuery.unblockUI();
            }

            return false;
            jQuery.unblockUI();
        }

    });

}

////  validation parts ///////

var error = $('.alert-danger');

var success = $('.alert-success');

var form = $('#submit_form');

var FormWizard = function () {

    return {

        init: function () {

            if (!jQuery().bootstrapWizard) {

                return;

            }

            function format(state) {

                if (!state.id) return state.text; // optgroup

                return "<img class='flag' src='assets/global/img/flags/" + state.id.toLowerCase() + ".png'/>&nbsp;&nbsp;" + state.text;

            }


            form.validate({

                doNotHideMessage: true, //this option enables to show the error/success messages on tab switch.

                errorElement: 'span', //default input error message container

                errorClass: 'help-block help-block-error', // default input error message class

                focusInvalid: false, // do not focus the last invalid input

                rules: {

                    ddlSector: {
                        required: true
                    },

                    ddlCountry: {
                        required: true
                    },

                    txtBidDuration: {
                        required: true,
                        minlength: 1,
                        maxlength: 3,
                        number: true
                    },

                    txtBidSubject: {
                        required: true
                    },

                    txtbiddescription: {
                        required: true
                    },

                    dropCurrency: {
                        required: true
                    },

                    txtConversionRate: {
                        required: true,
                        number: true,
                        minlength: 1,
                        maxlength: 3
                    },
                    ddlAuctiontype:{
                        required: true
                    },

                    txtbidDate: {
                        required: true
                    },

                    txtbidTime: {
                        required: true
                    },

                    mapedapprover: {
                        required: true
                    },
                    file1: {
                        required: true
                    },

                    //Second Tab
                    txtshortname: {
                        required: true
                    },
                    txtquantitiy: {

                    },
                    dropuom: {

                    },
                    txtbiddescriptionP: {

                    },
                    txtContractDuration: {

                    },
                    txtCeilingPrice: {

                    },
                    txtedelivery: {

                    },
                    txtminimumdecreament: {

                    },
                    drpdecreamenton: {

                    },
                    txttargetprice: {
                        number: true,
                        maxlength: 10
                    },
                    txtlastinvoiceprice: {
                        number: true,
                        maxlength: 10
                    }
                },

                messages: {

                    'payment[]': {

                        required: "Please select at least one option",

                        minlength: jQuery.validator.format("Please select at least one option")

                    }

                },

                errorPlacement: function (error, element) {

                    if (element.attr("name") == "gender") {

                        error.insertAfter("#form_gender_error");

                    } else if (element.attr("name") == "payment[]") {

                        error.insertAfter("#form_payment_error");

                    } else {

                        error.insertAfter(element);

                    }



                    if ($("#txtbidDate").closest('.inputgroup').attr('class') == 'inputgroup has-error') {

                        $("#btncal").css("margin-top", "-22px");

                    }

                },

                invalidHandler: function (event, validator) {
                    success.hide();
                    Metronic.scrollTo(error, -200);

                },

                highlight: function (element) {

                    $(element)
                        .closest('.inputgroup').removeClass('has-success').addClass('has-error');
                    $(element)
                        .closest('.col-md-4').removeClass('has-success').addClass('has-error');

                },

                unhighlight: function (element) {

                    $(element)
                        .closest('.inputgroup').removeClass('has-error');
                    $(element)
                        .closest('.col-md-4').removeClass('has-error');

                },

                success: function (label) {

                    if (label.attr("for") == "gender" || label.attr("for") == "payment[]") {

                        label

                            .closest('.inputgroup').removeClass('has-error').addClass('has-success');

                        label.remove();

                    } else {

                        label

                            .addClass('valid') // mark the current input as valid and display OK icon

                        .closest('.inputgroup').removeClass('has-error').addClass('has-success'); // set success class to the control group

                    }

                    if ($("#txtbidDate").closest('.inputgroup').attr('class') == 'inputgroup has-error') {

                        $("#btncal").css("margin-top", "-22px");

                    }

                    else {

                        $("#btncal").css("margin-top", "0px");

                    }

                },



                submitHandler: function (form) {

                    // success.show();

                    error.hide();

                }



            });



            var displayConfirm = function () {

                $('#tab4 .form-control-static', form).each(function () {

                    var input = $('[name="' + $(this).attr("data-display") + '"]', form);

                    if (input.is(":radio")) {

                        input = $('[name="' + $(this).attr("data-display") + '"]:checked', form);

                    }

                    if (input.is(":text") || input.is("textarea")) {

                        $(this).html(input.val());

                    } else if (input.is("select")) {

                        $(this).html(input.find('option:selected').text());

                    } else if (input.is(":radio") && input.is(":checked")) {

                        $(this).html(input.attr("data-title"));

                    } else if ($(this).attr("data-display") == 'payment') {

                        var payment = [];

                        $('[name="payment[]"]:checked').each(function () {

                            payment.push($(this).attr('data-title'));

                        });

                        $(this).html(payment.join("<br>"));

                    }

                });

            }



            var handleTitle = function (tab, navigation, index) {

                var total = navigation.find('li').length;

                var current = index + 1;

                // set wizard title

                $('.step-title', $('#form_wizard_1')).text('Step ' + (index + 1) + ' of ' + total);

                // set done steps

                jQuery('li', $('#form_wizard_1')).removeClass("done");

                var li_list = navigation.find('li');

                for (var i = 0; i < index; i++) {

                    jQuery(li_list[i]).addClass("done");

                }



                if (current == 1) {

                    $('#form_wizard_1').find('.button-previous').hide();

                } else {

                    $('#form_wizard_1').find('.button-previous').show();

                }



                if (current >= total) {

                    $('#form_wizard_1').find('.button-next').hide();

                    $('#form_wizard_1').find('.button-submit').show();

                    displayConfirm();

                } else {

                    $('#form_wizard_1').find('.button-next').show();

                    $('#form_wizard_1').find('.button-submit').hide();

                }

                Metronic.scrollTo($('.page-title'));

            }



            // default form wizard

            $('#form_wizard_1').bootstrapWizard({

                'nextSelector': '.button-next',

                'previousSelector': '.button-previous',

                onTabClick: function (tab, navigation, index, clickedIndex) {

                    return false;

                },

                onNext: function (tab, navigation, index) {

                    success.hide();

                    error.hide();

                    if (index == 1) {
                        if (form.valid() == false) {

                            form.validate();
                            return false;

                        }
                        else if ($('#tblapprovers >tbody >tr').length == 0) {
                            $('.alert-danger').show();
                            $('#spandanger').html('Please Map Approver.');
                            Metronic.scrollTo($(".alert-danger"), -200);
                            $('.alert-danger').fadeOut(5000);
                            return false;

                        }
                        else {
                            
                            Dateandtimevalidate('index1')
                            $('.currencyparam').html($('#dropCurrency option:selected').text());
                        }

                    } else if (index == 2) {
                        if ($('#tblServicesProduct >tbody >tr').length == 0) {
                            $('#spandanger').html('You have Some error. Please Check Below!')
                            $('.alert-danger').show();
                            Metronic.scrollTo($('.alert-danger'), -200);
                            $('.alert-danger').fadeOut(5000);

                            return false;

                        }
                       else if ($("#txtBidDuration").val() == '0') {
                            $('#form_wizard_1').bootstrapWizard('previous');
                            $(".alert-danger").find("span").html('').html('Bid Duration can not be zero.')
                            Metronic.scrollTo(error, -200);
                            $(".alert-danger").show();
                            $(".alert-danger").fadeOut(5000);
                           
                            return false;
                        }
                        else
                        {
                            ConfigureBidInsPefaTab2()
                        }
                    }
                    handleTitle(tab, navigation, index);

                },

                onPrevious: function (tab, navigation, index) {

                    success.hide();

                    error.hide();

                    handleTitle(tab, navigation, index);

                },

                onTabShow: function (tab, navigation, index) {

                    var total = navigation.find('li').length;

                    var current = index + 1;

                    var $percent = (current / total) * 100;

                    $('#form_wizard_1').find('.progress-bar').css({

                        width: $percent + '%'

                    });

                }

            });

            $('#form_wizard_1').find('.button-previous').hide();

            $('#form_wizard_1 .button-submit').click(function () {

                if ($('#tblServicesProduct >tbody >tr').length == 0) {



                    $('#form_wizard_1').bootstrapWizard('previous');

                    error.show();

                    $('#spandanger').html('please Configure Bid parameters..')

                    error.fadeOut(3000)

                    return false;

                }

                else if (ValidateVendor() == 'false') {

                    return false;

                }

                else {
                    Dateandtimevalidate('index3')

                }

            }).hide();



            //unblock code

        }

    };

}();


//sessionStorage.setItem('CurrentBidID', 0)

function ConfigureBidInsPefaTab1() {
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    var TermsConditionFileName = '';
    var AttachementFileName = '';

    if ($("#ddlAuctiontype option:selected").val() == 81) {
        $(".hdnfielddutch").attr('disabled', false);
        _bidType = $("#ddlAuctiontype option:selected").val();
    } else {
        $(".hdnfielddutch").attr('disabled', true);
        _bidType = $("#ddlAuctiontype option:selected").val();
    }

    if ($('#filepthterms').html() != '' && ($('#file1').val() == '')) {
        TermsConditionFileName = jQuery('#filepthterms').html();
    } else {
        TermsConditionFileName = jQuery('#file1').val().substring(jQuery('#file1').val().lastIndexOf('\\') + 1);
    }


    if (($('#filepthattach').html() != '') && ($('#file2').val() == '')) {
        AttachementFileName = jQuery('#filepthattach').html();
    } else {
        AttachementFileName = jQuery('#file2').val().substring(jQuery('#file2').val().lastIndexOf('\\') + 1);
    }
    var bidDuration = 0;
    TermsConditionFileName = TermsConditionFileName.replace(/[&\/\\#,+$~%'":*?<>{}]/g, '_'); //Replace special Characters
    AttachementFileName = AttachementFileName.replace(/[&\/\\#,+$~%'":*?<>{}]/g, '_'); //Replace special Characters

    
    
    if ($("#ddlAuctiontype option:selected").val() == 81) {
        
        bidDuration = $("#txtBidDuration").val();
    } else {
        bidDuration = $("#txtBidDuration").val();
    }

   

    var Tab1Data = {

        "BidId": sessionStorage.getItem('CurrentBidID'),
        "BidTypeID": '6',
        "ContinentId": jQuery("#ddlSector").val(),
        "CountryID": jQuery("#ddlCountry option:selected").val(),
        "BidForID": $("#ddlAuctiontype option:selected").val(),
        "BidDuration": bidDuration,
        "BidSubject": jQuery("#txtBidSubject").val(),
        "BidDescription": jQuery("#txtbiddescription").val(),
        "BidDate": jQuery("#txtbidDate").val(),
        "BidTime": jQuery("#txtbidTime").val(),
        "CurrencyID": jQuery("#dropCurrency option:selected").val(),
        "ConversionRate": jQuery("#txtConversionRate").val(),
        "TermsConditions": TermsConditionFileName,
        "Attachment": AttachementFileName,
        "UserId": sessionStorage.getItem('UserID'),
        "BidApprovers": '',
        "CustomerID": sessionStorage.getItem('CustomerID'),
        "ShowRankToVendor": $('#drpshowL1L2').val()

    };

    //alert(JSON.stringify(Tab1Data))
    jQuery.ajax({

        type: "POST",

        contentType: "application/json; charset=utf-8",

        url: sessionStorage.getItem("APIPath") + "ConfigureBid/ConfigureBidInsPefaTab1/",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        crossDomain: true,

        async: false,

       data: JSON.stringify(Tab1Data),

        dataType: "json",

        success: function (data) {
            if (window.location.search) {
                var param = getUrlVars()["param"]
                var decryptedstring = fndecrypt(param)
                sessionStorage.setItem('CurrentBidID', getUrlVarsURL(decryptedstring)["BidID"]);
                if ($("#ddlAuctiontype option:selected").val() == '81') {
                    $(".for-englishbid").show();
                    $(".for-dutch-bid").hide();
                    $("#lblCeilingPrice").html('').html('Bid Start Price <span class="required"> *</span>');
                    $('#lblshowprice').text('Show H1 Price')
                    $('#lblshowprice').removeClass('hide');
                    $('#divshowprice').removeClass('hide');
                    $('#lblshowstartprice').removeClass('hide');
                    $('#divshowstartprice').removeClass('hide');
                   // $("#lbllastSalePrice").html('').html('Last Sale Price');
                } else {
                    $(".for-englishbid").hide();
                    $(".for-dutch-bid").show();
                    $("#lblCeilingPrice").html('').html('Ceiling/ Max. Price <span class="required"> *</span>');
                    $('#lblshowprice').text('Show L1 Price')
                    $('#lblshowprice').addClass('hide');
                    $('#divshowprice').addClass('hide');
                    $('#lblshowstartprice').addClass('hide');
                    $('#divshowstartprice').addClass('hide');
                   // $("#lbllastSalePrice").html('').html('Last Purchase Price');
                }
            }
            else {
                sessionStorage.setItem('CurrentBidID', data[0].BidID)
                if ($("#ddlAuctiontype option:selected").val() == '81') {
                    $(".for-englishbid").show();
                    $(".for-dutch-bid").hide();
                    $("#lblCeilingPrice").html('').html('Bid Start Price <span class="required"> *</span>');
                    $('#lblshowprice').text('Show H1 Price')
                    $('#lblshowprice').removeClass('hide');
                    $('#divshowprice').removeClass('hide');
                    $('#lblshowstartprice').removeClass('hide');
                    $('#divshowstartprice').removeClass('hide');

                   // $("#lbllastSalePrice").html('').html('Last Sale Price');
                } else {
                    $(".for-englishbid").hide();
                    $(".for-dutch-bid").show();
                    $("#lblCeilingPrice").html('').html('Ceiling/ Max. Price <sptan class="required"> *</span>');
                    $('#lblshowprice').text('Show L1 Price')
                    $('#lblshowprice').addClass('hide');
                    $('#divshowprice').addClass('hide');
                    $('#lblshowstartprice').addClass('hide');
                    $('#divshowstartprice').addClass('hide');
                   // $("#lbllastSalePrice").html('').html('Last Purchase Price');
                }
            }

            fileUploader(sessionStorage.getItem('CurrentBidID'))
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else {
                alert(xhr.status + ' ' + xhr.statusText);
                jQuery.unblockUI();
            }

            return false;
            jQuery.unblockUI();
        }

    });
    jQuery.unblockUI();
}

function ConfigureBidInsPefaTab2() {
    var targetPrice;
    var lastInvoiceprice=0;
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    PriceDetails = '';
    
    var rowCount = jQuery('#tblServicesProduct tr').length;
    if (rowCount > 1) {
        if ($("#ddlAuctiontype option:selected").val() == 81) {
            
            $("#tblServicesProduct tr:gt(0)").each(function () {
                PriceDetails = PriceDetails + 'insert into BidPefaDetails(BidID,ItemName,Quantity,Targetprice,MeasurementUnit,Description,ContractDuration,DispatchLocation,CeilingPrice,MaskVendor,MinimumIncreament,IncreamentOn,Attachments,LastSalePrice,AttachmentSeqID,StartingPrice,PriceReductionFrequency,PriceReductionAmount,ShowHLPrice,ShowStartPrice) values('
                targetPrice = 0
                var this_row = $(this);
                var t = 'A';
                if ($.trim(this_row.find('td:eq(11)').html()) == "Percentage") {
                    t = 'P'
                }
                if ($.trim(this_row.find('td:eq(2)').html()) != '') {
                    targetPrice = $.trim(this_row.find('td:eq(2)').html());
                }
                if ($.trim(this_row.find('td:eq(11)').html()) != '') {
                    targetPrice = removeThousandSeperator($.trim(this_row.find('td:eq(11)').html()));
                }
                var desc = $.trim(this_row.find('td:eq(5)').html()).replace(/'/g, "");

                PriceDetails = PriceDetails + sessionStorage.getItem('CurrentBidID') + ",'" + $.trim(this_row.find('td:eq(1)').html()) + "'," + removeThousandSeperator($.trim(this_row.find('td:eq(3)').html())) + " ," + removeThousandSeperator(targetPrice) + ",'" + $.trim(this_row.find('td:eq(4)').html()) + "','','',''," + removeThousandSeperator($.trim(this_row.find('td:eq(5)').html())) + ",'" + $.trim(this_row.find('td:eq(6)').html()) + "'," + removeThousandSeperator($.trim(this_row.find('td:eq(7)').html())) + ",'" + $.trim(this_row.find('td:eq(10)').text()) + "','" + $.trim(this_row.find('td:eq(9)').text()) + "'," + lastInvoiceprice + ",'" + $.trim(this_row.find('td:eq(12)').html()) + "',0,0,0,'" + $.trim(this_row.find('td:eq(13)').html()) + "','" + $.trim(this_row.find('td:eq(14)').html()) + "' )";
            });
           // PriceDetails = PriceDetails.substring(0, PriceDetails.length - 6);
        }
        else {

            if ($("#txtBidDuration").val() != '0') {
                _BidDuration = $("#txtBidDuration").val();
            }
            
            $("#tblServicesProduct tr:gt(0)").each(function () {
                PriceDetails = PriceDetails + 'insert into BidPefaDetails(BidID,ItemName,Quantity,Targetprice,MeasurementUnit,Description,ContractDuration,DispatchLocation,CeilingPrice,MaskVendor,MinimumIncreament,IncreamentOn,Attachments,LastSalePrice,AttachmentSeqID,StartingPrice,PriceReductionFrequency,PriceReductionAmount) values('
                targetPrice = 0
                var this_row = $(this);
                var t = 'A';
                if ($.trim(this_row.find('td:eq(11)').html()) == "Percentage") {
                    t = 'P'
                }
                if ($.trim(this_row.find('td:eq(2)').html()) != '') {
                    targetPrice = $.trim(this_row.find('td:eq(2)').html());
                }
                var desc = $.trim(this_row.find('td:eq(5)').html()).replace(/'/g, "");
                PriceDetails = PriceDetails + sessionStorage.getItem('CurrentBidID') + ",'" + $.trim(this_row.find('td:eq(1)').html()) + "'," + removeThousandSeperator($.trim(this_row.find('td:eq(3)').html())) + " ," + removeThousandSeperator(targetPrice) + ",'" + $.trim(this_row.find('td:eq(4)').html()) + "','','',''," + removeThousandSeperator($.trim(this_row.find('td:eq(5)').html())) + ",'" + $.trim(this_row.find('td:eq(6)').html()) + "',0,'','" + $.trim(this_row.find('td:eq(9)').text()) + "'," + removeThousandSeperator($.trim(this_row.find('td:eq(11)').text())) + ",'" + $.trim(this_row.find('td:eq(12)').html()) + "'," + $.trim(removeThousandSeperator(this_row.find('td:eq(13)').html())) + ",'" + $.trim(this_row.find('td:eq(14)').html()) + "','" + $.trim(removeThousandSeperator(this_row.find('td:eq(15)').html())) + "' )";
            });
        }
    }
  
    //alert(PriceDetails)
    var Tab2data = {
        "PriceDetails": PriceDetails,
        "BidID": sessionStorage.getItem('CurrentBidID'),
        "UserID": sessionStorage.getItem('UserID'),
        "BidDuration": _BidDuration == 0 ? 0 : _BidDuration

    };
    console.log(PriceDetails)
    //alert(JSON.stringify(Tab2data))
    jQuery.ajax({

        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ConfigureBid/ConfigureBidInsPefaTab2/",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        crossDomain: true,
        async: false,
        data: JSON.stringify(Tab2data),
        dataType: "json",
        success: function (data) {
            if (data[0].BidID > 0) {

                return true;
            }
            else {
                return false;

            }

        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else {
                alert(xhr.status + ' ' + xhr.statusText);
                jQuery.unblockUI();
            }

            return false;
            jQuery.unblockUI();
        }

    });
    jQuery.unblockUI();
}

function ConfigureBidInsPefaTab3() {
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    var InsertQuery = '';
//    $("#tblvendorlist> tbody > tr").each(function (index) {
    $("#selectedvendorlists > tbody > tr").each(function(index) {
//        if ($(this).find("span#spanchecked").attr('class') == 'checked') {

            //alert($(this).find('input[type="checkbox"]:checked').val())

            //InsertQuery = InsertQuery + "select " + sessionStorage.getItem('CurrentBidID') + "," + $(this).find('input[type="checkbox"]:checked').val() + " union all ";
            InsertQuery = InsertQuery + "select " + sessionStorage.getItem('CurrentBidID') + "," + $.trim($(this).find('td:eq(0)').html()) + " union all "; 
//        }
//        else {
//            InsertQuery = InsertQuery;
//        }

    });

    if (InsertQuery != '') {

        InsertQuery = "Insert into BidVendorDetails(BidId,VendorId)" + InsertQuery;
        InsertQuery = InsertQuery.substring(0, InsertQuery.length - 10);

    }
    else {
        InsertQuery = "Print 1";
    }
    var bidDuration = '0';
    if ($("#ddlAuctiontype option:selected").val() == 81) {

        bidDuration = $("#txtBidDuration").val();
    } else {
        bidDuration = $("#txtBidDuration").val();
    }
    if (bidDuration == '0') {
        //$('#form_wizard_1').bootstrapWizard('previous');
        $(".alert-danger").find("span").html('').html("The Event Duration can not be '0'. Please check your bid again. ")
        Metronic.scrollTo(error, -200);
        $(".alert-danger").show();
        $(".alert-danger").fadeOut(5000);
        jQuery.unblockUI();
        return false;
    }
    else {
        var Tab3data = {
            "BidVendors": InsertQuery,
            "BidID": sessionStorage.getItem('CurrentBidID'),
            "UserID": sessionStorage.getItem('UserID'),
            "BidSubject": jQuery("#txtBidSubject").val(),
            "BidDescription": jQuery("#txtbiddescription").val(),
            "BidDate": jQuery("#txtbidDate").val(),
            "BidTime": jQuery("#txtbidTime").val(),
            "BidDuration": bidDuration,
            "BidTypeID": '6'
        };
        //alert(JSON.stringify(Tab3data))

        jQuery.ajax({

            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: sessionStorage.getItem("APIPath") + "ConfigureBid/ConfigureBidInsPefaTab3/",
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            crossDomain: true,
            async: false,
            data: JSON.stringify(Tab3data),
            dataType: "json",
            success: function (data) {
                if (data[0].BidID > 0) {

                    jQuery.unblockUI();

                    bootbox.alert("Bid Configured Successfully.", function () {
                        sessionStorage.removeItem('CurrentBidID');
                        window.location = sessionStorage.getItem("HomePage")
                        return false;
                    });
                }
                else {

                    jQuery.unblockUI();
                    bootbox.alert("Configuration error.", function () {
                        sessionStorage.removeItem('CurrentBidID');
                        window.location = sessionStorage.getItem("HomePage")
                        return false;
                    });

                }

            },
            error: function (xhr, status, error) {

                var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }
                else {
                    alert(xhr.status + ' ' + xhr.statusText);
                    jQuery.unblockUI();
                }

                return false;
                jQuery.unblockUI();
            }

        });
    }


}

function uploadFileattchmentsForItems(bidID) {
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    var fileTerms = $('#fileattachment');
    var fileDataTerms = $('#fileattachment').prop("files")[0];
    var formData = new window.FormData();

    formData.append("fileTerms", fileDataTerms);
    formData.append("AttachmentFor", 'Bid');

    formData.append("BidID", bidID);
    formData.append("VendorID", FileseqNo);
    $.ajax({

        url: 'ConfigureFileAttachment.ashx',

        data: formData,

        processData: false,

        contentType: false,

        asyc: false,

        type: 'POST',

        success: function (data) {
            jQuery.unblockUI();
        },

        error: function () {

            bootbox.alert("Attachment error.");
            jQuery.unblockUI();
        }

    });

}

function fileUploader(bidID) {
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });

    var fileTerms = $('#file1');
    if ($('#file1').is('[disabled=disabled]')) {

        var fileDataTerms = $('#file2').prop("files")[0];

    }
    else {
        var fileDataTerms = fileTerms.prop("files")[0];
    }


    var fileAnyOther = $('#file2');

    var fileDataAnyOther = fileAnyOther.prop("files")[0];



    var formData = new window.FormData();

    formData.append("fileTerms", fileDataTerms);

    formData.append("fileAnyOther", fileDataAnyOther);

    formData.append("AttachmentFor", 'Bid');

    formData.append("BidID", bidID);
    formData.append("VendorID", '');



    $.ajax({

        url: 'ConfigureFileAttachment.ashx',

        data: formData,

        processData: false,

        contentType: false,

        asyc: false,

        type: 'POST',

        success: function (data) {
            jQuery.unblockUI();
        },

        error: function () {

            bootbox.alert("Attachment error.");
            jQuery.unblockUI();
        }

    });

}



function BidApprovers() {

    var bidApprovers = {};

    var bidapprover = []

    bidApprovers.bidapprover = bidapprover;

    $.each($("select#mapedapprover option"), function (index) {

        bidApprovers.bidapprover.push({ "AdMinSrNo": index + 1, "UserID": $(this).val() });

    });

    return JSON.stringify(bidApprovers);

}



function BidVendors() {

    var bidVendors = {};

    var bidvendor = []

    bidVendors.bidvendor = bidvendor;

    $("#tblvendorlist> tbody > tr").each(function (index) {

        if ($(this).find("span#spanchecked").attr('class') == 'checked') {

            bidVendors.bidvendor.push({ "VendorID": $(this).find("#chkvender").val() });

        }

    });

    return JSON.stringify(bidVendors);

}



$("#txtbidDate").change(function () {

    if ($("#txtbidDate").val() == '') { }

    else {

        $("#txtbidDate").closest('.inputgroup').removeClass('has-error');

        $("#txtbidDate").closest('.inputgroup').find('span').hide();

        $("#txtbidDate").closest('.inputgroup').find('span.input-group-btn').show();

        $("#txtbidDate").closest('.inputgroup').find("#btncal").css("margin-top", "0px");

    }

});

var FileseqNo = 0;
function InsUpdProductSevices() {

    if ($('#add_or').text() == "Modify")
    {

        var st = "true"

        $("#tblServicesProduct tr:gt(0)").each(function () {

            var this_row = $(this);

            if ($.trim(this_row.find('td:eq(1)').html()) == $('#txtshortname').val() && $.trim(this_row.find('td:eq(2)').html()) != $('#txttargetprice').val() && $.trim(this_row.find('td:eq(3)').html()) != $('#txtquantitiy').val() && $.trim(this_row.find('td:eq(4)').html()) != $("#dropuom option:selected").text() && $.trim(this_row.find('td:eq(5)').html()) != $('#txtbiddescriptionP').val() && $.trim(this_row.find('td:eq(6)').html()) != $('#txtContractDuration').val() && $.trim(this_row.find('td:eq(7)').html()) != $('#txtedelivery').val() && $.trim(this_row.find('td:eq(8)').html()) != $('#txtCeilingPrice').val() && $.trim(this_row.find('td:eq(10)').html()) != $('#txtminimumdecreament').val() && $.trim(this_row.find('td:eq(11)').html()) != $("#drpdecreamenton option:selected").text() && $.trim(this_row.find('td:eq(14)').html()) != $("#txtlastinvoiceprice").val()) {

                st = "false"

            }

        });



        if (form.valid() == false) {

            error.show();
            $('#spandanger').html('You have some error.Please Check below...');

            Metronic.scrollTo(error, -200);

            error.fadeOut(3000);

            return false;

        }
        else if (parseInt(removeThousandSeperator($('#txtminimumdecreament').val())) > parseInt(removeThousandSeperator($('#txtCeilingPrice').val()))) {
            error.show();
            $('#spandanger').html('Minimum Increment should be less than Bid start price.');

            Metronic.scrollTo(error, -200);

            error.fadeOut(3000);

            return false;

        }
        else if ($('#txtStartingPrice').is(':visible') && (parseInt(removeThousandSeperator($('#txtStartingPrice').val())) + parseInt(removeThousandSeperator($('#txtPriceReductionAmount').val()))) >= parseInt(removeThousandSeperator($('#txtCeilingPrice').val())) && $("#ddlAuctiontype option:selected").val() == 82) {
            error.show();
            $('#spandanger').html('Ceiling Max Price should not be less than Bid start price + Price Reduction amount.');

            Metronic.scrollTo(error, -200);

            error.fadeOut(3000);

            return false;

        }
        else if ((parseInt($('#txtminimumdecreament').val()) > parseInt(20) && $("#drpdecreamenton option:selected").val() == "P")) {
            error.show();
            $('#spandanger').html('Minimum Increament should be less than 20%.');

            Metronic.scrollTo(error, -200);

            error.fadeOut(3000);

            return false;

        }
        else if (parseInt($('#txtminimumdecreament').val()) > parseFloat(20 * (removeThousandSeperator($('#txtCeilingPrice').val())) / 100) && $("#drpdecreamenton option:selected").val() == "A") {
            error.show();
            $('#spandanger').html('Minimum Increament should be less than 20% of Bid Start Price.');
            Metronic.scrollTo(error, -200);
            error.fadeOut(3000);
            return false;
        }

        else if (st == "false") {

            error.show();
            $('#spandanger').html('Data already exists...');

            Metronic.scrollTo(error, -200);

            error.fadeOut(3000);

            // resetfun()

            return false;

        }

        else {

            PriceDetails = '';

            filetoupload = '';
            filetoupload = jQuery('#fileattachment').val().substring(jQuery('#fileattachment').val().lastIndexOf('\\') + 1);

            PriceDetails = PriceDetails + 'insert into BidProductServicesDetails(BidID,ItemName,Quantity,Targetprice,MeasurementUnit,Description,ContractDuration,DeliveryLocation,CeilingPrice,MaskVendor,MinimumDecreament,DecreamentOn,Attachments,LastInvoicePrice,AttachmentSeqID)'

            var this_row = $('#rowid').val();
            var this_row_Prev = $('#rowidPrev').val();

            $("#" + this_row).find("td:eq(1)").text($('#txtshortname').val())

            $("#" + this_row).find("td:eq(2)").text($('#txttargetprice').val())

            $("#" + this_row).find("td:eq(3)").text($('#txtquantitiy').val())

            $("#" + this_row).find("td:eq(4)").text($('#dropuom').val())

            $("#" + this_row).find("td:eq(5)").text($('#txtCeilingPrice').val())            

            $("#" + this_row).find("td:eq(7)").text($('#txtminimumdecreament').val())
            //debugger;
            if ($('#drpdecreamenton option:selected').val() == 'A') {
                $("#" + this_row).find("td:eq(8)").text('Amount');
                $("#" + this_row_Prev).find("td:eq(7)").text('Amount')

            } else {
                $("#" + this_row).find("td:eq(8)").text('Percentage');
               $("#" + this_row_Prev).find("td:eq(7)").text('Percentage')
            }
            //$("#" + this_row).find("td:eq(8)").text($('#txtCeilingPrice').val())
            //checkmask vendor change
            $("#" + this_row).find("td:eq(6)").text(jQuery("#checkmaskvendor option:selected").val())
            

            $("#" + this_row).find("td:eq(10)").text($("#drpdecreamenton option:selected").val())

            //$("#" + this_row).find("td:eq(12)").text(filetoupload)
            $("#" + this_row).find("td:eq(11)").text($("#txtlastinvoiceprice").val())
            
            $("#" + this_row).find("td:eq(14)").text($("#txtPriceReductionFrequency").val())
            $("#" + this_row).find("td:eq(15)").text($("#txtPriceReductionAmount").val())
            if ($("#ddlAuctiontype option:selected").val() != '81') {
                $("#" + this_row).find("td:eq(16)").text($("#showhlprice").val())
                $("#" + this_row).find("td:eq(17)").text($("#showstartprice").val())
                $("#" + this_row).find("td:eq(13)").text($("#txtStartingPrice").val())
            }
            else {
                $("#" + this_row).find("td:eq(13)").text($("#showhlprice").val())
                $("#" + this_row).find("td:eq(14)").text($("#showstartprice").val())
            }

           
            if (!$('#fileattachment').is('[disabled=disabled]')) {
                $("#" + this_row).find("td:eq(12)").text(FileseqNo)
                $("#" + this_row).find("td:eq(9)").html('<a href=PortalDocs/Bid/' + sessionStorage.getItem('CurrentBidID') + '/' + FileseqNo + '/' + filetoupload.replace(/\s/g, "%20") + '>' + filetoupload + '</a>')
                $("#" + this_row_Prev).find("td:eq(8)").html('<a href=PortalDocs/Bid/' + sessionStorage.getItem('CurrentBidID') + '/' + FileseqNo + '/' + filetoupload.replace(/\s/g, "%20") + '>' + filetoupload + '</a>')
               // uploadFileattchmentsForItems(sessionStorage.getItem('CurrentBidID'))
            }

            //For Preview Table

            $("#" + this_row_Prev).find("td:eq(0)").text($('#txtshortname').val())

            $("#" + this_row_Prev).find("td:eq(1)").text($('#txttargetprice').val())

            $("#" + this_row_Prev).find("td:eq(2)").text($('#txtquantitiy').val())

            $("#" + this_row_Prev).find("td:eq(3)").text($('#dropuom').val())

            $("#" + this_row_Prev).find("td:eq(4)").text($('#txtCeilingPrice').val())

           // $("#" + this_row_Prev).find("td:eq(7)").text($('#txtminimumdecreament').val())    

            $("#" + this_row_Prev).find("td:eq(6)").text($('#txtminimumdecreament').val())

            $("#" + this_row_Prev).find("td:eq(5)").text(jQuery("#checkmaskvendor option:selected").val())

            // $("#" + this_row_Prev).find("td:eq(7)").text($("#drpdecreamenton option:selected").text())
            //$("#" + this_row_Prev).find("td:eq(7)").text($("#drpdecreamenton option:selected").text())
            $("#" + this_row_Prev).find("td:eq(9)").text($("#drpdecreamenton option:selected").val())
            $("#" + this_row_Prev).find("td:eq(10)").text($("#txtlastinvoiceprice").val())
          
            $("#" + this_row_Prev).find("td:eq(13)").text($("#txtPriceReductionFrequency").val())
            $("#" + this_row_Prev).find("td:eq(14)").text($("#txtPriceReductionAmount").val())
            if ($("#ddlAuctiontype option:selected").val() != '81') {
                $("#" + this_row_Prev).find("td:eq(15)").text($("#showhlprice").val())
                $("#" + this_row_Prev).find("td:eq(16)").text($("#showstartprice").val())
                $("#" + this_row_Prev).find("td:eq(12)").text($("#txtStartingPrice").val())
            }
            else {
                $("#" + this_row_Prev).find("td:eq(12)").text($("#showhlprice").val())
                $("#" + this_row_Prev).find("td:eq(13)").text($("#showstartprice").val())
            }
            
            //("#" + this_row).find("td:eq(9)").html('<a href=PortalDocs/Bid/' + sessionStorage.getItem('CurrentBidID') + '/' + FileseqNo + '/' + filetoupload.replace(/\s/g, "%20") + '>' + filetoupload + '</a>')
            $("#tblServicesProduct tr:gt(0)").each(function () {

                var this_row = $(this);

                var t = 'A';

                if ($.trim(this_row.find('td:eq(7)').html()) == "Percentage") {

                    t = 'P'

                }

                PriceDetails = PriceDetails + " select " + sessionStorage.getItem('CurrentBidID') + ",'" + $.trim(this_row.find('td:eq(1)').html()) + "','" + $.trim(this_row.find('td:eq(3)').html()) + "' ,'" + $.trim(this_row.find('td:eq(2)').html()) + "','" + $.trim(this_row.find('td:eq(4)').html()) + "','" + $.trim(this_row.find('td:eq(5)').html()) + "','" + $.trim(this_row.find('td:eq(6)').html()) + "','" + $.trim(this_row.find('td:eq(7)').html()) + "','" + $.trim(this_row.find('td:eq(8)').html()) + "','" + $.trim(this_row.find('td:eq(9)').html()) + "','" + $.trim(this_row.find('td:eq(10)').html()) + "','" + t + "','" + filetoupload + "','" + $.trim(this_row.find('td:eq(14)').html()) + "','" + FileseqNo + "' union";

            });
            //if (jQuery("#tblServicesProduct >tbody >tr").length >= 1) {

            //    $(".alert-danger").find("span").html('').html('You can not add more than one item for Dutch Auction.')
            //    $(".alert-danger").show();
            //    resetfun()
            //    $(".alert-danger").fadeOut(5000);
            //    return false;
            //}
            if ($("#ddlAuctiontype option:selected").val() != '81') {
                _BidDuration = (((removeThousandSeperator($("#txtCeilingPrice").val()) - removeThousandSeperator($("#txtStartingPrice").val())) / removeThousandSeperator($("#txtPriceReductionAmount").val())) * $("#txtPriceReductionFrequency").val()) + parseInt($("#txtPriceReductionFrequency").val());
                $("#txtBidDuration").val(parseInt(_BidDuration));
                $("#txtBidDurationPrev").text(parseInt(_BidDuration))
            }
           
           
            //else {
            //    _BidDuration = $("#txtBidDuration").val();
            //}
            

            resetfun();

        }

    }

    else {

        if ($('#txtshortname').val() == "") {

            error.show();
            $('#spandanger').html('Please Enter Item Name...');

            Metronic.scrollTo(error, -200);

            error.fadeOut(3000);

            return false;

        }

        else if ($('#txtquantitiy').val() == "") {

            error.show();
            $('#spandanger').html('Please Enter Quantity in Number Only...');


            Metronic.scrollTo(error, -200);

            error.fadeOut(3000);

            return false;

        }

        else if ($('#txtUOM').val() == "" || $('#dropuom').val() == "") {

            error.show();
            $('#spandanger').html('Please Enter Measurement Unit...');

            Metronic.scrollTo(error, -200);

            error.fadeOut(3000);

            return false;

        }

        else if ($('#txtbiddescriptionP').val() == "") {

            error.show();
            $('#spandanger').html('Please Enter Description...');

            Metronic.scrollTo(error, -200);

            error.fadeOut(3000);

            return false;

        }

        else if ($('#txtContractDuration').val() == "") {

            error.show();

            $('#spandanger').html('Please enter contract duration...');
            Metronic.scrollTo(error, -200);

            error.fadeOut(3000);

            return false;

        }

        else if ($('#txtedelivery').val() == "") {

            error.show();
            $('#spandanger').html('Please Enter Dispatch Location...');


            Metronic.scrollTo(error, -200);

            error.fadeOut(3000);

            return false;

        }



        else if ($('#txtCeilingPrice').val() == "") {

            error.show();
            $('#spandanger').html('Please Enter Bid start price in Number only...');
            Metronic.scrollTo(error, -200);

            error.fadeOut(3000);

            return false;

        }

        else if ($('#txtminimumdecreament').is(":visible") && $('#txtminimumdecreament').val() == "") {

            error.show();
            $('#spandanger').html('Please Enter Minimum Increment in Number only......');
            Metronic.scrollTo(error, -200);

            error.fadeOut(3000);

            return false;

        }

        else if ($('#drpdecreamenton').is(":visible") && $('#drpdecreamenton').val() == "") {

            error.show();
            $('#spandanger').html('Please Select Increment On...');

            Metronic.scrollTo(error, -200);

            error.fadeOut(3000);

            return false;

        }
        else if ($('#txtStartingPrice').is(":visible") && $('#txtStartingPrice').val() == "") {

            error.show();
            $('#spandanger').html('Please Enter Starting Price...');

            Metronic.scrollTo(error, -200);

            error.fadeOut(3000);

            return false;

        }
        //debugger;
        else if ($('#txtStartingPrice').is(":visible") && parseInt($.trim(removeThousandSeperator($('#txtCeilingPrice').val()))) > parseInt($.trim(removeThousandSeperator($('#txtStartingPrice').val()))) && $("#ddlAuctiontype option:selected").val() != '82') {
        //alert("Bid start price: "+$('#txtCeilingPrice').val() +"\n Starting Price: "+ $('#txtStartingPrice').val())
        
            error.show();
            $('#spandanger').html('Starting price should not be less than Bid start price...');

            Metronic.scrollTo(error, -200);

            error.fadeOut(3000);

            return false;

        }
        else if ($('#txtPriceReductionFrequency').is(":visible") && $('#txtPriceReductionFrequency').val() == 0) {

            error.show();
            $('#spandanger').html('Please Enter Price Reduction Frequency...');

            Metronic.scrollTo(error, -200);

            error.fadeOut(3000);

            return false;

        }
        else if ($('#txtPriceReductionAmount').is(":visible") && $('#txtPriceReductionAmount').val() == "") {

            error.show();
            $('#spandanger').html('Please Enter Price Reduction Amount...');

            Metronic.scrollTo(error, -200);

            error.fadeOut(3000);

            return false;

        }
        else if ($('#txtPriceReductionAmount').is(":visible") && parseInt(removeThousandSeperator($('#txtPriceReductionAmount').val())) > parseInt(removeThousandSeperator($('#txtStartingPrice').val()))) {

                error.show();
                $('#spandanger').html('Price increment amount should be less than starting price.');

                Metronic.scrollTo(error, -200);

                error.fadeOut(3000);

                return false;

        }

        else if ($('#txtPriceReductionAmount').is(":visible") && parseInt(removeThousandSeperator($('#txtPriceReductionAmount').val())) >= parseInt((removeThousandSeperator($('#txtStartingPrice').val()) - removeThousandSeperator($('#txtCeilingPrice').val())) / removeThousandSeperator($('#txtPriceReductionFrequency').val())) && $("#ddlAuctiontype option:selected").val() == 81) {

            error.show();
            $('#spandanger').html('Please enter valid Price Reduction amount.');

            Metronic.scrollTo(error, -200);

            error.fadeOut(3000);

            return false;

        }
        else if ($('#txtPriceReductionAmount').is(":visible") && parseInt(removeThousandSeperator($('#txtPriceReductionAmount').val())) >= (parseInt(removeThousandSeperator($('#txtCeilingPrice').val())) - parseInt(removeThousandSeperator($('#txtStartingPrice').val())) / 2) && $("#ddlAuctiontype option:selected").val() == 82) {

            error.show();
            $('#spandanger').html('Please enter valid Price Reduction amount.');

            Metronic.scrollTo(error, -200);

            error.fadeOut(3000);

            return false;

        }
        else if (parseInt(removeThousandSeperator($('#txtminimumdecreament').val())) > parseInt(removeThousandSeperator($('#txtCeilingPrice').val()))) {
            error.show();
            $('#spandanger').html('Minimum increment should be less than Bid start price.');

            Metronic.scrollTo(error, -200);

            error.fadeOut(3000);

            return false;

        }
        else if ((parseInt($('#txtminimumdecreament').val()) > parseInt(20) && $("#drpdecreamenton option:selected").val() == "P")) {
            error.show();
            $('#spandanger').html('Minimum Increament should be less than 20%.');

            Metronic.scrollTo(error, -200);

            error.fadeOut(3000);

            return false;

        }
        else if (parseInt($('#txtminimumdecreament').val()) > parseFloat(20 * (removeThousandSeperator($('#txtCeilingPrice').val())) / 100) && $("#drpdecreamenton option:selected").val() == "A") {
            error.show();
            $('#spandanger').html('Minimum Increament should be less than 20% of Bid Start Price.');
            Metronic.scrollTo(error, -200);
            error.fadeOut(3000);
            return false;
        }
        else if ((parseInt($('#txtStartingPrice').val()) + parseInt(removeThousandSeperator($('#txtPriceReductionAmount').val()))) >= parseInt(removeThousandSeperator($('#txtCeilingPrice').val())) && $("#ddlAuctiontype option:selected").val() == 82) {
            error.show();
            $('#spandanger').html('Ceiling Max Price should not be less than Bid start price + Price Reduction amount.');

            Metronic.scrollTo(error, -200);

            error.fadeOut(3000);

            return false;

        }
        else {

            if ($('#tblServicesProduct >tbody >tr').length == 0) {

                PriceDetails = PriceDetails + 'insert into BidProductServicesDetails(BidID,ShortName,Quantity,Targetprice,UOM,Description,ContractDuration,DeliveryLocation,CeilingPrice,MaskVendor,MinimumDecreament,DecreamentOn,Attachments,LastInvoicePrice,AttachmentSeqID)'

                if (form.valid() == false) {

                    error.show();
                    $('#spandanger').html('You have some error.Please Check below...');

                    Metronic.scrollTo(error, -200);

                    error.fadeOut(3000);

                    return false;

                }

                else {

                    ParametersQuery()

                }

            }

            else {

                var status = "true";

                $("#tblServicesProduct tr:gt(0)").each(function () {

                    var this_row = $(this);

                    if ($.trim(this_row.find('td:eq(1)').html()) == $('#txtshortname').val()) {

                        status = "false"

                    }

                });

                if (form.valid() == false) {

                    error.show();
                    $('#spandanger').html('You have some error.Please Check below...');

                    Metronic.scrollTo(error, -200);

                    error.fadeOut(3000);

                    //return false;

                }

                else if (status == "false") {



                    error.show();
                    $('#spandanger').html('Data already exists...');


                    Metronic.scrollTo(error, -200);

                    error.fadeOut(3000);

                    // resetfun();

                    return false;

                }

                else {

                    ParametersQuery()



                }

            }



        }

    }

}






var i = 0;
var z = 0;

var PriceDetails = '';

function ParametersQuery() {
    if (jQuery("#tblServicesProduct >tbody >tr ").length >= 1 && jQuery("#ddlAuctiontype option:selected").val() != '81') {
        
        $(".alert-danger").find("span").html('').html('You can not add more than one item for Dutch Auction.')
        Metronic.scrollTo(error, -200);
        $(".alert-danger").show();
        $(".alert-danger").fadeOut(5000);
        resetfun();
        return false;
    }
    if ($("#ddlAuctiontype option:selected").val() != '81') {
        _BidDuration = (((removeThousandSeperator($("#txtCeilingPrice").val()) - removeThousandSeperator($("#txtStartingPrice").val())) / removeThousandSeperator($("#txtPriceReductionAmount").val())) * $("#txtPriceReductionFrequency").val()) + parseInt($("#txtPriceReductionFrequency").val());
        $("#txtBidDuration").val(parseInt(_BidDuration));
        $("#txtBidDurationPrev").text(parseInt(_BidDuration));

    }
   
    z = z + 1
    i = z;
    var status = "";

    status = jQuery("#checkmaskvendor option:selected").val();


    var filetoupload = '';

    filetoupload = jQuery('#fileattachment').val().substring(jQuery('#fileattachment').val().lastIndexOf('\\') + 1);
    if (filetoupload != '') {

        FileseqNo = FileseqNo + 1;
       // uploadFileattchmentsForItems(sessionStorage.getItem('CurrentBidID'))
    }



    if ($("#txtlastinvoiceprice").val() == null || $("#txtlastinvoiceprice").val() == '') {
        $("#txtlastinvoiceprice").val('0')
    }

    if ($("#ddlAuctiontype").val() == 81) {


        if (!jQuery("#tblServicesProduct thead").length) {

            jQuery("#tblServicesProduct").append("<thead><tr style='background: gray; color: #FFF;'><th style='width:100px;'></th><th>Item/Product</th><th>Target Price</th><th>Quantity</th><th>UOM</th><th>Bid Start Price</th><th>Mask Vendor</th><th>Minimum Increment</th><th>Increment On</th><th class=hide>Attachment</th><th class=hide></th><th>Last Invoice Price</th><th class=hide>FileSeqNo</th><th>Show H1 price</th><th>Show Start price</th></tr></thead>");
            jQuery("#tblServicesProduct").append('<tr id=trid' + i + '><td style="width:150px;"><button type="button" class="btn btn-sm btn-success" onclick="editvalues(trid' + i + ',tridPrev' + i + ')" ><i class="fa fa-pencil"></i></button>&nbsp;<button class="btn  btn-sm btn-danger" onclick="deleterow(trid' + i + ',tridPrev' + i + ')" ><i class="glyphicon glyphicon-remove-circle"></i></button></td><td>' + $('#txtshortname').val() + '</td><td>' + $('#txttargetprice').val() + '</td><td>' + $('#txtquantitiy').val() + '</td><td>' + $('#dropuom').val() + '</td><td>' + $('#txtCeilingPrice').val() + '</td><td>' + status + '</td><td>' + $('#txtminimumdecreament').val() + '</td><td>' + $("#drpdecreamenton option:selected").text() + '</td><td class=hide><a href=PortalDocs/Bid/' + sessionStorage.getItem('CurrentBidID') + '/' + FileseqNo + '/' + filetoupload.replace(/\s/g, "%20") + ' style="text-decoration:none;">' + filetoupload + '</a></td><td class=hide>' + $("#drpdecreamenton").val() + '</td><td>' + $("#txtlastinvoiceprice").val() + '</td><td class=hide>' + FileseqNo + '</td><td>' + $('#showhlprice').val() + '</td><td>' + $('#showstartprice').val() + '</td></tr>');
            
        } else {

            jQuery("#tblServicesProduct").append('<tr id=trid' + i + '><td style="width:150px;"><button type="button" class="btn  btn-sm btn-success" onclick="editvalues(trid' + i + ',tridPrev' + i + ')" ><i class="fa fa-pencil"></i></button>&nbsp<button class="btn  btn-sm btn-danger" onclick="deleterow(trid' + i + ',tridPrev' + i + ')" ><i class="glyphicon glyphicon-remove-circle"></i></button></td><td>' + $('#txtshortname').val() + '</td><td>' + $('#txttargetprice').val() + '</td><td>' + $('#txtquantitiy').val() + '</td><td>' + $('#dropuom').val() + '</td><td>' + $('#txtCeilingPrice').val() + '</td><td>' + status + '</td><td>' + $('#txtminimumdecreament').val() + '</td><td>' + $("#drpdecreamenton option:selected").text() + '</td><td class=hide><a href=PortalDocs/Bid/' + sessionStorage.getItem('CurrentBidID') + '/' + FileseqNo + '/' + filetoupload.replace(/\s/g, "%20") + ' style="text-decoration:none;">' + filetoupload + '</a></td><td class=hide>' + $("#drpdecreamenton").val() + '</td><td>' + $("#txtlastinvoiceprice").val() + '</td><td class=hide>' + FileseqNo + '</td><td>' + $('#showhlprice').val() + '</td><td>' + $('#showstartprice').val() + '</td></tr>');




        }

        $('#wrap_scroller').show();

        if (!jQuery("#tblServicesProductPrev thead").length) {

            jQuery("#tblServicesProductPrev").append("<thead><tr style='background: gray; color: #FFF;'><th>Item/Product</th><th>Target Price</th><th>Quantity</th><th>UOM</th><th>Bid Start Price</th><th>Mask Vendor</th><th>Minimum Increment</th><th>Increment On</th><th class=hide>Attachment</th><th class=hide></th><th>Last Invoice Price</th><th class=hide>FileSeqNo</th><th>Show H1 price</th><th>Show Start price</th></tr></thead>");
            jQuery("#tblServicesProductPrev").append('<tr id=tridPrev' + i + '><td>' + $('#txtshortname').val() + '</td><td>' + $('#txttargetprice').val() + '</td><td>' + $('#txtquantitiy').val() + '</td><td>' + $('#dropuom').val() + '</td><td>' + $('#txtCeilingPrice').val() + '</td><td>' + status + '</td><td>' + $('#txtminimumdecreament').val() + '</td><td>' + $("#drpdecreamenton option:selected").text() + '</td><td class=hide><a href=PortalDocs/Bid/' + sessionStorage.getItem('CurrentBidID') + '/' + FileseqNo + '/' + filetoupload.replace(/\s/g, "%20") + ' style="text-decoration:none;">' + filetoupload + '</a></td><td class=hide>' + $("#drpdecreamenton").val() + '</td><td>' + $("#txtlastinvoiceprice").val() + '</td><td class=hide>' + FileseqNo + '</td><td>' + $('#showhlprice').val() + '</td><td>' + $('#showstartprice').val() + '</td></tr>');
            //i = i + 1;


        } else {

            jQuery("#tblServicesProductPrev").append('<tr id=tridPrev' + i + '><td>' + $('#txtshortname').val() + '</td><td>' + $('#txttargetprice').val() + '</td><td>' + $('#txtquantitiy').val() + '</td><td>' + $('#dropuom').val() + '</td><td>' + $('#txtCeilingPrice').val() + '</td><td>' + status + '</td><td>' + $('#txtminimumdecreament').val() + '</td><td>' + $("#drpdecreamenton option:selected").text() + '</td><td class=hide><a href=PortalDocs/Bid/' + sessionStorage.getItem('CurrentBidID') + '/' + FileseqNo + '/' + filetoupload.replace(/\s/g, "%20") + ' style="text-decoration:none;">' + filetoupload + '</a></td><td class=hide>' + $("#drpdecreamenton").val() + '</td><td>' + $("#txtlastinvoiceprice").val() + '</td><td class=hide>' + FileseqNo + '</td><td>' + $('#showhlprice').val() + '</td><td>' + $('#showstartprice').val() + '</td></tr>');




        }
        $('#wrap_scrollerPrev').show();

    }
    else {

        //If Dutch Bid

        if (!jQuery("#tblServicesProduct thead").length) {


            jQuery("#tblServicesProduct").append("<thead><tr style='background: gray; color: #FFF;'><th style='width:100px;'></th><th>Item/Product</th><th>Target Price</th><th>Quantity</th><th>UOM</th><th>Ceiling/ Max Price</th><th>Mask Vendor</th><th class='hide'>Minimum Increment</th><th class='hide'>Increment On</th><th class=hide>Attachment</th><th class=hide></th><th>Last Invoice Price</th><th class=hide>FileSeqNo</th><th>Starting Price</th><th>Price Increment Frequency (mins)</th><th>Price Increment Amount</th><th class=hide>Show L1 price</th><th class=hide>Show Start price</th></tr></thead>");
            jQuery("#tblServicesProduct").append('<tr id=trid' + i + '><td style="width:150px;"><button type="button" class="btn btn-sm btn-success" onclick="editvalues(trid' + i + ',tridPrev' + i + ')" ><i class="fa fa-pencil"></i></button>&nbsp;<button class="btn  btn-sm btn-danger" onclick="deleterow(trid' + i + ',tridPrev' + i + ')" ><i class="glyphicon glyphicon-remove-circle"></i></button></td><td>' + $('#txtshortname').val() + '</td><td class=text-right>' + $('#txttargetprice').val() + '</td><td class=text-right>' + $('#txtquantitiy').val() + '</td><td>' + $('#dropuom').val() + '</td><td class=text-right>' + $('#txtCeilingPrice').val() + '</td><td>' + status + '</td><td class="hide">' + $('#txtminimumdecreament').val() + '</td><td class="hide">' + $("#drpdecreamenton option:selected").text() + '</td><td class=hide><a href=PortalDocs/Bid/' + sessionStorage.getItem('CurrentBidID') + '/' + FileseqNo + '/' + filetoupload.replace(/\s/g, "%20") + ' style="text-decoration:none;">' + filetoupload + '</a></td><td class=hide>' + $("#drpdecreamenton").val() + '</td><td class=text-right>' + $("#txtlastinvoiceprice").val() + '</td><td class=hide>' + FileseqNo + '</td><td class=text-right>' + $("#txtStartingPrice").val() + '</td><td class=text-right>' + $("#txtPriceReductionFrequency").val() + '</td><td class=text-right>' + $("#txtPriceReductionAmount").val() + '</td><td class=hide>' + $("#showhlprice").val() + '</td><td class=hide>' + $("#showstartprice").val() + '</td></tr>');
            //i = i + 1;


        } else {

            jQuery("#tblServicesProduct").append('<tr id=trid' + i + '><td style="width:150px;"><button type="button" class="btn  btn-sm btn-success" onclick="editvalues(trid' + i + ',tridPrev' + i + ')" ><i class="fa fa-pencil"></i></button>&nbsp<button class="btn  btn-sm btn-danger" onclick="deleterow(trid' + i + ',tridPrev' + i + ')" ><i class="glyphicon glyphicon-remove-circle"></i></button></td><td>' + $('#txtshortname').val() + '</td><td class=text-right>' + $('#txttargetprice').val() + '</td><td class=text-right>' + $('#txtquantitiy').val() + '</td><td>' + $('#dropuom').val() + '</td><td class=text-right>' + $('#txtCeilingPrice').val() + '</td><td>' + status + '</td><td class="hide">' + $('#txtminimumdecreament').val() + '</td><td class="hide">' + $("#drpdecreamenton option:selected").text() + '</td><td class=hide><a href=PortalDocs/Bid/' + sessionStorage.getItem('CurrentBidID') + '/' + FileseqNo + '/' + filetoupload.replace(/\s/g, "%20") + ' style="text-decoration:none;">' + filetoupload + '</a></td><td class=hide>' + $("#drpdecreamenton").val() + '</td><td class=text-right>' + $("#txtlastinvoiceprice").val() + '</td><td class=hide>' + FileseqNo + '</td><td class=text-right>' + $("#txtStartingPrice").val() + '</td><td class=text-right>' + $("#txtPriceReductionFrequency").val() + '</td><td class=text-right>' + $("#txtPriceReductionAmount").val() + '</td><td class=hide>' + $("#showhlprice").val() + '</td><td class=hide>' + $("#showstartprice").val() + '</td></tr>');




        }

        $('#wrap_scroller').show();

        if (!jQuery("#tblServicesProductPrev thead").length) {

            jQuery("#tblServicesProductPrev").append("<thead><tr style='background: gray; color: #FFF;'><th>Item/Product</th><th>Target Price</th><th>Quantity</th><th>UOM</th><th>Ceiling/ Max Price</th><th>Mask Vendor</th><th class='hide'>Minimum Increment</th><th class='hide'>Increment On</th><th class=hide >Attachment</th><th class=hide></th><th>Last Invoice Price</th><th class=hide>FileSeqNo</th><th>Starting Price</th><th>Price Increment Frequency (mins)</th><th>Price Increment Amount</th><th class=hide>Show L1 price</th><th class=hide>Show start price</th></tr></thead>");
            jQuery("#tblServicesProductPrev").append('<tr id=tridPrev' + i + '><td>' + $('#txtshortname').val() + '</td><td class=text-right>' + $('#txttargetprice').val() + '</td><td>' + $('#txtquantitiy').val() + '</td><td>' + $('#dropuom').val() + '</td><td class=text-right>' + $('#txtCeilingPrice').val() + '</td><td>' + status + '</td><td class=hide>' + $('#txtminimumdecreament').val() + '</td><td class=hide>' + $("#drpdecreamenton option:selected").text() + '</td><td class=hide><a href=PortalDocs/Bid/' + sessionStorage.getItem('CurrentBidID') + '/' + FileseqNo + '/' + filetoupload.replace(/\s/g, "%20") + ' style="text-decoration:none;">' + filetoupload + '</a></td><td class=hide>' + $("#drpdecreamenton").val() + '</td><td class=text-right>' + $("#txtlastinvoiceprice").val() + '</td><td class=hide>' + FileseqNo + '</td><td class=text-right>' + $("#txtStartingPrice").val() + '</td><td class=text-right>' + $("#txtPriceReductionFrequency").val() + '</td><td>' + $("#txtPriceReductionAmount").val() + '</td><td class=hide>' + $("#showhlprice").val() + '</td><td class=hide>' + $("#showstartprice").val() + '</td></tr>');
            //i = i + 1;


        } else {

            jQuery("#tblServicesProductPrev").append('<tr id=tridPrev' + i + '><td>' + $('#txtshortname').val() + '</td><td class=text-right>' + $('#txttargetprice').val() + '</td><td class=text-right>' + $('#txtquantitiy').val() + '</td><td>' + $('#dropuom').val() + '</td><td class=text-right>' + $('#txtCeilingPrice').val() + '</td><td>' + status + '</td><td class="hide">' + $('#txtminimumdecreament').val() + '</td><td class=hide>' + $("#drpdecreamenton option:selected").text() + '</td><td class=hide><a href=PortalDocs/Bid/' + sessionStorage.getItem('CurrentBidID') + '/' + FileseqNo + '/' + filetoupload.replace(/\s/g, "%20") + ' style="text-decoration:none;">' + filetoupload + '</a></td><td class=hide>' + $("#drpdecreamenton").val() + '</td><td class=text-right>' + $("#txtlastinvoiceprice").val() + '</td><td class=hide>' + FileseqNo + '</td><td class=text-right>' + $("#txtStartingPrice").val() + '</td><td class=text-right>' + $("#txtPriceReductionFrequency").val() + '</td><td>' + $("#txtPriceReductionAmount").val() + '</td><td class=hide>' + $("#showhlprice").val() + '</td><td class=hide>' + $("#showstartprice").val() + '</td></tr>');




        }
        $('#wrap_scrollerPrev').show();
    }

    PriceDetails = PriceDetails + " select " + sessionStorage.getItem('CurrentBidID') + ",'" + $('#txtshortname').val() + "','" + $('#txttargetprice').val() + "'," + $('#txtquantitiy').val() + ",'" + $('#dropuom').val() + "','" + $('#txtbiddescriptionP').val() + "','" + $('#txtContractDuration').val() + "','" + $('#txtedelivery').val() + "','" + $('#txtCeilingPrice').val() + "','" + status + "','" + $('#txtminimumdecreament').val() + "','" + $('#drpdecreamenton').val() + "','" + filetoupload + "','" + $("#txtlastinvoiceprice").val() + "' union";
    resetfun()

}

function editvalues(rowid, rowidPrev) {
    sessionStorage.setItem('ClickedEditID', rowid.id)
    Metronic.scrollTo($("body"), 200);
    $('#rowid').val(rowid.id)
    $('#rowidPrev').val(rowidPrev.id)

    $('#txtshortname').val($("#" + rowid.id).find("td:eq(1)").text())

    $('#txttargetprice').val($("#" + rowid.id).find("td:eq(2)").text())

    $('#txtquantitiy').val($("#" + rowid.id).find("td:eq(3)").text())

    $('#dropuom').val($("#" + rowid.id).find("td:eq(4)").text())
    $('#txtUOM').val($("#" + rowid.id).find("td:eq(4)").text())

    //$('#txtbiddescriptionP').val($("#" + rowid.id).find("td:eq(5)").text())

    //$('#txtContractDuration').val($("#" + rowid.id).find("td:eq(6)").text())

    $('#txtCeilingPrice').val($("#" + rowid.id).find("td:eq(5)").text())

    $('#txtminimumdecreament').val($("#" + rowid.id).find("td:eq(7)").text())

    $('#drpdecreamenton').val($("#" + rowid.id).find("td:eq(10)").text())
    $('#txtlastinvoiceprice').val($("#" + rowid.id).find("td:eq(11)").text())

    //$('#txtedelivery').val($("#" + rowid.id).find("td:eq(7)").text())
    if ($("#ddlAuctiontype option:selected").val() == 82) {
        $('#txtStartingPrice').val($("#" + rowid.id).find("td:eq(13)").text())
        $('#showhlprice').val($("#" + rowid.id).find("td:eq(16)").text())
        $('#showstartprice').val($("#" + rowid.id).find("td:eq(17)").text())
    }
    else {
       
        $('#showhlprice').val($("#" + rowid.id).find("td:eq(13)").text())
        $('#showstartprice').val($("#" + rowid.id).find("td:eq(14)").text())
    }
    //('#txtPriceReductionFrequency').val($("#" + rowid.id).find("td:eq(14)").text())
    //debugger;
    var frequency = $("#" + rowid.id).find("td:eq(14)").text()
    $('#txtPriceReductionAmount').val($("#" + rowid.id).find("td:eq(15)").text())
   
    $('#spinner4').spinner('value',frequency) //$("#" + rowid.id).find("td:eq(14)").html()
    FileseqNo = $("#" + rowid.id).find("td:eq(12)").text();

    if ($("#" + rowid.id).find("td:eq(9)").text() == "") {
        $('#fileattachment').attr('disabled', false);
        $('#closebtnitms').hide()
    }
    else {
        $('#fileattachment').attr('disabled', true);

        $('#closebtnitms').show()
        $('#fileattachmentforitems').show()
        $('#fileattachmentforitems').attr('href', 'PortalDocs/Bid/' + sessionStorage.getItem('CurrentBidID') + '/' + FileseqNo + '/' + $.trim($("#" + rowid.id).find('td:eq(9)').text()).replace(/\s/g, "%20"));
        $('#fileattachmentforitems').html($.trim($("#" + rowid.id).find('td:eq(9)').text()))

    }
    jQuery("#checkmaskvendor").val($.trim($("#" + rowid.id).find("td:eq(6)").text()));
    $('#add_or').text('Modify');



}

function deleterow(rowid, rowidPrev) {
    ajaxFileDelete('', 'fileattachment', 'PortalDocs/Bid/' + sessionStorage.getItem('CurrentBidID') + '/' + $.trim($("#" + rowid.id).find('td:eq(15)').text()) + '/' + $.trim($("#" + rowid.id).find('td:eq(12)').text()).replace(/%20/g, " "), 'ParameterFiles')
    $('#' + rowid.id).remove();
    $('#' + rowidPrev.id).remove();


}

function resetfun() {
    $('#add_or').text('Add');
    $('#txtshortname').val('')
    $('#txttargetprice').val('')
    $('#txtquantitiy').val('')
    $('#dropuom').val('')
    $('#txtUOM').val('')
    $('#txtbiddescriptionP').val('')
    $('#txtContractDuration').val('')
    $('#txtedelivery').val('')
    $('#txtCeilingPrice').val('')
    $('#txtminimumdecreament').val('')
    $('#drpdecreamenton').val('A')
    $('#txtlastinvoiceprice').val('')
    jQuery('#fileattachment').val('')
    jQuery('#checkmaskvendor').val('Y')
    jQuery('#showhlprice').val('N')
    jQuery('#showstartprice').val('Y')
    $('#closebtnitms').hide();
    $('#fileattachmentforitems').html('')
    $('#fileattachmentforitems').attr('href', 'javascript:;').addClass('display-none');
    $('#fileattachment').attr('disabled', false);
    $('#txtStartingPrice').val('');
    $('#txtPriceReductionFrequency').val('');
    $('#spinner4').spinner('value', 0);
    $('#txtPriceReductionAmount').val('');
}
var allUOM = '';
function FetchUOM(CustomerID) {

    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "UOM/fetchUOMCust/?CustomerID=" + CustomerID,
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        dataType: "json",
        success: function (data) {
            jQuery("#txtUOM").empty();
            if (data.length > 0) {
                allUOM = data;
            }
            else {
                allUOM = '';
            }
            //jQuery("#dropuom").append(jQuery("<option ></option>").val("").html("Select"));
            //for (var i = 0; i < data.length; i++) {
            //    jQuery("#dropuom").append(jQuery("<option></option>").val(data[i].UOM).html(data[i].UOM));
            //}

        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else {
                alert(xhr.status + ' ' + xhr.statusText);
                jQuery.unblockUI();
            }

            return false;
            jQuery.unblockUI();
        }

    });

}
jQuery("#txtUOM").keyup(function () {
    $('#dropuom').val('')

});
jQuery("#txtUOM").typeahead({
    source: function (query, process) {
        var data = allUOM;
        usernames = [];
        map = {};
        var username = "";
        jQuery.each(data, function (i, username) {
            map[username.UOM] = username;
            usernames.push(username.UOM);
        });

        process(usernames);

    },
    minLength: 2,
    updater: function (item) {
        if (map[item].UOM != "") {
            $('#dropuom').val(map[item].UOM)

        }
        else {
            gritternotification('Please select UOM  properly!!!');
        }

        return item;
    }

});
function displayUOM() {
    jQuery('.lblUOM').css('text-align', 'left');
    jQuery('.lblUOM').text('');
    if (jQuery('#dropuom').val() != '' && jQuery('#dropCurrency').val() != '') {

        var uomcaption = jQuery('#dropCurrency option:selected').text() + '/' + jQuery('#dropuom').val()
        jQuery('.lblUOM').text(uomcaption)
    }
    else {
        jQuery('.lblUOM').text('')
    }
}

function fillselectedcurrency() {
    jQuery('.currencyparam').css('text-align', 'left');
    if (jQuery('#dropCurrency').val() != '') {

        var uomcaption = jQuery('#dropCurrency option:selected').text()
        jQuery('.currencyparam').text(uomcaption)
        jQuery('.lblUOM').text(uomcaption)
    }
    else {
        jQuery('.currencyparam').text('')
        jQuery('.lblUOM').text('')
    }
}

jQuery("#txtSearch").keyup(function () {
    _this = this;
    // Show only matching TR, hide rest of them
    jQuery.each($("#tblvendorlist tbody").find("tr"), function () {
        console.log($(this).text());
        if (jQuery(this).text().toLowerCase().indexOf(jQuery(_this).val().toLowerCase()) == -1)
            jQuery(this).hide();
        else
            jQuery(this).show();
    });
});
var _bidType;
function fetchScrapSalesBidDetails() {
    var replaced1 = '';
    var replaced2 = '';
    jQuery.ajax({
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ConfigureBid/fetchPefaConfigurationData/?UserID=" + encodeURIComponent(sessionStorage.getItem('UserID')) + "&BidID=" + sessionStorage.getItem('CurrentBidID') + "&AuthenticationToken=" + sessionStorage.getItem('AuthenticationToken'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "GET",
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (BidData) {

            jQuery('#txtBidSubject').val(BidData[0].BidDetails[0].BidSubject)

            jQuery('#txtbiddescription').val(BidData[0].BidDetails[0].BidDetails)
            jQuery('#txtbidDate').val(BidData[0].BidDetails[0].BidDate)
            jQuery('#txtbidTime').val(BidData[0].BidDetails[0].BidTime)
            jQuery("#dropCurrency").val(BidData[0].BidDetails[0].CurrencyID).attr("selected", "selected");
            jQuery('#txtConversionRate').val(BidData[0].BidDetails[0].ConversionRate)
            //alert(BidData[0].BidDetails[0].BidForID)
            jQuery('#ddlAuctiontype').val(BidData[0].BidDetails[0].BidForID)
            $("#cancelBidBtn").show();
            _bidType = BidData[0].BidDetails[0].BidForID;
            //alert(BidData[0].BidDetails[0].BidDuration)
            if (BidData[0].BidDetails[0].BidForID == 82) {
                if (BidData[0].BidDetails[0].BidDuration > 0) {
                    jQuery('#txtBidDuration').attr('disabled', true).val(BidData[0].BidDetails[0].BidDuration)
                } else {
                    jQuery('#txtBidDuration').attr('disabled', true).val(0)
                }
                
            } else {
                jQuery('#txtBidDuration').attr('disabled', false).val(BidData[0].BidDetails[0].BidDuration)
                jQuery('input[name="txtBidDuration"]').rules('add', {
                    required: true,
                    minlength: 1,
                    maxlength: 3,
                    number: true
                });
            }
            if (BidData[0].BidDetails[0].TermsConditions != '') {

                $('#file1').attr('disabled', true);
                $('#closebtn').removeClass('display-none');

                replaced1 = BidData[0].BidDetails[0].TermsConditions.replace(/\s/g, "%20")

                if (BidData[0].BidDetails[0].Attachment != '') {
                    if (BidData[0].BidDetails[0].Attachment != null) {
                        $('#file2').attr('disabled', true);
                        $('#closebtn2').removeClass('display-none');

                        replaced2 = BidData[0].BidDetails[0].Attachment.replace(/\s/g, "%20")
                    }
                }
            }

            $('#filepthterms').attr('href', 'PortalDocs/Bid/' + sessionStorage.getItem('CurrentBidID') + '/' + replaced1).html(BidData[0].BidDetails[0].TermsConditions);
            $('#filepthattach').attr('href', 'PortalDocs/Bid/' + sessionStorage.getItem('CurrentBidID') + '/' + replaced2).html(BidData[0].BidDetails[0].Attachment);


            if (BidData[0].BidApproverDetails.length > 0) {
                for (var i = 0; i < BidData[0].BidApproverDetails.length; i++) {

                    //jQuery("#mapedapprover").append('<option value=' + BidData[0].BidApproverDetails[0].UserID + '  selected>' + BidData[0].BidApproverDetails[0].ApproverName + '</option>')
                    jQuery('#mapedapprover').append(jQuery('<option selected></option>').val(BidData[0].BidApproverDetails[i].UserID).html(BidData[0].BidApproverDetails[i].ApproverName))
                }
            }
            jQuery("#tblapprovers").empty();
            jQuery("#tblapproversPrev").empty();
            $('#wrap_scrollerPrevApp').show();
            jQuery('#tblapprovers').append("<thead><tr><th class='bold' style='width:30%!important'>Approver</th><th class='bold' style='width:30%!important'>Email</th><th class='bold' style='width:15%!important'>Sequence</th><th style='width:5%!important'></th></tr></thead>");
            jQuery('#tblapproversPrev').append("<thead><tr><th class='bold' style='width:30%!important'>Approver</th><th class='bold' style='width:30%!important'>Email</th><th class='bold' style='width:15%!important'>Sequence</th></tr></thead>");

            for (var i = 0; i < BidData[0].BidApproverDetails.length; i++) {

                str = "<tr><td>" + BidData[0].BidApproverDetails[i].ApproverName + "</td>";
                str += "<td>" + BidData[0].BidApproverDetails[i].EmailID + "</td>";

                str += "<td>" + BidData[0].BidApproverDetails[i].AdMinSrNo + "</td>";
                jQuery('#tblapproversPrev').append(str);
                str += "<td><button type='button' class='btn btn-xs btn-danger' id=Removebtn" + i + " onclick=fnRemoveBidApprover(\'" + BidData[0].BidApproverDetails[i].SrNo + "'\)><i class='glyphicon glyphicon-remove-circle'></i></button></td></tr>";
                jQuery('#tblapprovers').append(str);

            }
            jQuery("#tblServicesProduct").empty();
            jQuery("#tblServicesProductPrev").empty();

            if (BidData[0].BidScrapSalesDetails.length > 0) {

                var max = BidData[0].BidScrapSalesDetails[0].AttachmentSeqID;
                $('#wrap_scroller').show();
                $('#wrap_scrollerPrev').show();

                if (BidData[0].BidDetails[0].BidForID == 81) {
                    jQuery("#tblServicesProduct").append("<thead><tr style='background: gray; color: #FFF;'><th style='width:150px !important;'></th><th>Item/Name</th><th>Target Price</th><th>Quantity</th><th>UOM</th><th>Bid Start Price</th><th>Mask Vendor</th><th>Minimum Increment</th><th>Increment On</th><th class=hide>Attachment</th><th class=hide></th><th>Last Invoice Price</th><th class=hide></th><th>Show H1 Price</th><th>Show Start Price</th></tr></thead>");
                    jQuery("#tblServicesProductPrev").append("<thead><tr style='background: gray; color: #FFF;'><th>Item/Name</th><th>Target Price</th><th>Quantity</th><th>UOM</th><th>Bid Start Price</th><th>Mask Vendor</th><th>Minimum Increment</th><th>Increment On</th><th class=hide>Attachment</th><th class=hide></th><th>Last Invoice Price</th><th class=hide></th><th>Show H1 Price</th><th>Show Start Price</th></tr></thead>");
                    for (var i = 0; i < BidData[0].BidScrapSalesDetails.length; i++) {

                        if (max < BidData[0].BidScrapSalesDetails[i].AttachmentSeqID) {
                            max = BidData[0].BidScrapSalesDetails[i].AttachmentSeqID
                        }
                        FileseqNo = max
                        var decrementon = ''

                        if (BidData[0].BidScrapSalesDetails[i].IncreamentOn == 'A')
                            decrementon = 'Amount'
                        else
                            decrementon = 'Percentage'

                        var attach = (BidData[0].BidScrapSalesDetails[i].Attachments).replace(/\s/g, "%20");

                        jQuery("#tblServicesProduct").append('<tr id=trid' + i + '><td style="width:150px !important;"><button class="btn  btn-sm btn-success" onclick="editvalues(trid' + i + ',tridPrev' + i + ')" ><i class="fa fa-pencil"></i></button>&nbsp;<button class="btn  btn-sm btn-danger" onclick="deleterow(trid' + i + ',tridPrev' + i + ')" ><i class="glyphicon glyphicon-remove-circle"></i></button></td><td>' + BidData[0].BidScrapSalesDetails[i].ItemName + '</td><td>' + thousands_separators(BidData[0].BidScrapSalesDetails[i].Targetprice) + '</td><td>' + thousands_separators(BidData[0].BidScrapSalesDetails[i].Quantity) + '</td><td>' + BidData[0].BidScrapSalesDetails[i].MeasurementUnit + '</td><td>' + thousands_separators(BidData[0].BidScrapSalesDetails[i].CeilingPrice) + '</td><td>' + BidData[0].BidScrapSalesDetails[i].MaskVendor + '</td><td>' + thousands_separators(BidData[0].BidScrapSalesDetails[i].MinimumIncreament) + '</td><td>' + decrementon + '</td><td class=hide><a href=PortalDocs/Bid/' + sessionStorage.getItem('CurrentBidID') + '/' + BidData[0].BidScrapSalesDetails[i].AttachmentSeqID + '/' + attach + ' style=text-decoration:none; >' + BidData[0].BidScrapSalesDetails[i].Attachments + '</a></td><td class=hide>' + BidData[0].BidScrapSalesDetails[i].IncreamentOn + '</td><td>' + thousands_separators(BidData[0].BidScrapSalesDetails[i].LastSalePrice) + '</td><td class=hide>' + BidData[0].BidScrapSalesDetails[i].AttachmentSeqID + '</td><td>' + BidData[0].BidScrapSalesDetails[i].ShowHLPrice + '</td><td>' + BidData[0].BidScrapSalesDetails[i].ShowStartPrice + '</td></tr>');
                        jQuery("#tblServicesProductPrev").append('<tr id=tridPrev' + i + '><td>' + BidData[0].BidScrapSalesDetails[i].ItemName + '</td><td>' + thousands_separators(BidData[0].BidScrapSalesDetails[i].Targetprice) + '</td><td>' + thousands_separators(BidData[0].BidScrapSalesDetails[i].Quantity) + '</td><td>' + BidData[0].BidScrapSalesDetails[i].MeasurementUnit + '</td><td>' + thousands_separators(BidData[0].BidScrapSalesDetails[i].CeilingPrice) + '</td><td>' + BidData[0].BidScrapSalesDetails[i].MaskVendor + '</td><td>' + thousands_separators(BidData[0].BidScrapSalesDetails[i].MinimumIncreament) + '</td><td>' + decrementon + '</td><td class=hide><a href=PortalDocs/Bid/' + sessionStorage.getItem('CurrentBidID') + '/' + BidData[0].BidScrapSalesDetails[i].AttachmentSeqID + '/' + attach + ' style=text-decoration:none; >' + BidData[0].BidScrapSalesDetails[i].Attachments + ' </a></td><td class=hide>' + BidData[0].BidScrapSalesDetails[i].IncreamentOn + '</td><td>' + thousands_separators(BidData[0].BidScrapSalesDetails[i].LastSalePrice) + '</td><td class=hide>' + BidData[0].BidScrapSalesDetails[i].AttachmentSeqID + '</td><td>' + BidData[0].BidScrapSalesDetails[i].ShowHLPrice + '</td><td>' + BidData[0].BidScrapSalesDetails[i].ShowStartPrice + '</td></tr>');
                        z = i;
                    }
                }
                else { // for dutch
                    jQuery("#tblServicesProduct").append("<thead><tr style='background: gray; color: #FFF;'><th style='width:150px !important;'></th><th>Item/Product</th><th>Target Price</th><th>Quantity</th><th>UOM</th><th>Ceiling/ Max Price</th><th>Mask Vendor</th><th class=hide>Minimum Increment</th><th class=hide>Increment On</th><th class=hide>Attachment</th><th class=hide></th><th>Last Invoice Price</th><th class=hide></th><th>Starting Price</th><th>Price Increment Frequency (mins)</th><th>Price Increment Amount</th><th class=hide>Show L1 Price</th><th class=hide>Show Start Price</th></tr></thead>");
                    jQuery("#tblServicesProductPrev").append("<thead><tr style='background: gray; color: #FFF;'><th>Item/Product</th><th>Target Price</th><th>Quantity</th><th>UOM</th><th>Ceiling/ Max Price</th><th>Mask Vendor</th><th class=hide>Minimum Increment</th><th class=hide>Increment On</th><th class=hide>Attachment</th><th class=hide></th><th>Last Invoice Price</th><th class=hide></th><th>Starting Price</th><th>Price Increment Frequency (mins)</th><th>Price Increment Amount</th><th class=hide>Show L1 Price</th><th class=hide>Show Start Price</th></tr></thead>");
                    for (var i = 0; i < BidData[0].BidScrapSalesDetails.length; i++) {

                        if (max < BidData[0].BidScrapSalesDetails[i].AttachmentSeqID) {
                            max = BidData[0].BidScrapSalesDetails[i].AttachmentSeqID
                        }
                        FileseqNo = max
                        var decrementon = ''

                        if (BidData[0].BidScrapSalesDetails[i].IncreamentOn == 'A')
                            decrementon = 'Amount'
                        else
                            decrementon = 'Percentage'

                        var attach = (BidData[0].BidScrapSalesDetails[i].Attachments).replace(/\s/g, "%20");

                        jQuery("#tblServicesProduct").append('<tr id=trid' + i + '><td style="width:150px !important;"><button class="btn  btn-sm btn-success" onclick="editvalues(trid' + i + ',tridPrev' + i + ')" ><i class="fa fa-pencil"></i></button>&nbsp;<button class="btn  btn-sm btn-danger" onclick="deleterow(trid' + i + ',tridPrev' + i + ')" ><i class="glyphicon glyphicon-remove-circle"></i></button></td><td>' + BidData[0].BidScrapSalesDetails[i].ItemName + '</td><td class=text-right>' + thousands_separators(BidData[0].BidScrapSalesDetails[i].Targetprice) + '</td><td class=text-right>' + thousands_separators(BidData[0].BidScrapSalesDetails[i].Quantity) + '</td><td>' + BidData[0].BidScrapSalesDetails[i].MeasurementUnit + '</td><td class=text-right>' + thousands_separators(BidData[0].BidScrapSalesDetails[i].CeilingPrice) + '</td><td>' + BidData[0].BidScrapSalesDetails[i].MaskVendor + '</td><td class=hide>' + thousands_separators(BidData[0].BidScrapSalesDetails[i].MinimumIncreament) + '</td><td class=hide>' + decrementon + '</td><td class=hide><a href=PortalDocs/Bid/' + sessionStorage.getItem('CurrentBidID') + '/' + BidData[0].BidScrapSalesDetails[i].AttachmentSeqID + '/' + attach + ' style=text-decoration:none; >' + BidData[0].BidScrapSalesDetails[i].Attachments + '</a></td><td class=hide>' + BidData[0].BidScrapSalesDetails[i].IncreamentOn + '</td><td class=text-right>' + thousands_separators(BidData[0].BidScrapSalesDetails[i].LastSalePrice) + '</td><td class=hide>' + BidData[0].BidScrapSalesDetails[i].AttachmentSeqID + '</td><td class=text-right>' + thousands_separators(BidData[0].BidScrapSalesDetails[i].StartingPrice) + '</td><td class=text-right>' + BidData[0].BidScrapSalesDetails[i].PriceReductionFrequency + '</td><td class=text-right>' + thousands_separators(BidData[0].BidScrapSalesDetails[i].PriceReductionAmount) + '</td><td class=hide>' + BidData[0].BidScrapSalesDetails[i].ShowHLPrice + '</td><td class=hide>' + BidData[0].BidScrapSalesDetails[i].ShowStartPrice + '</td></tr>');
                        jQuery("#tblServicesProductPrev").append('<tr id=tridPrev' + i + '><td>' + BidData[0].BidScrapSalesDetails[i].ItemName + '</td><td class=text-right>' + thousands_separators(BidData[0].BidScrapSalesDetails[i].Targetprice) + '</td><td class=text-right> ' + thousands_separators(BidData[0].BidScrapSalesDetails[i].Quantity) + '</td><td>' + BidData[0].BidScrapSalesDetails[i].MeasurementUnit + '</td><td class=text-right>' + thousands_separators(BidData[0].BidScrapSalesDetails[i].CeilingPrice) + '</td><td>' + BidData[0].BidScrapSalesDetails[i].MaskVendor + '</td><td class=hide>' + thousands_separators(BidData[0].BidScrapSalesDetails[i].MinimumIncreament) + '</td><td class=hide>' + decrementon + '</td><td class=hide><a href=PortalDocs/Bid/' + sessionStorage.getItem('CurrentBidID') + '/' + BidData[0].BidScrapSalesDetails[i].AttachmentSeqID + '/' + attach + ' style=text-decoration:none; >' + BidData[0].BidScrapSalesDetails[i].Attachments + ' </a></td><td class=hide>' + BidData[0].BidScrapSalesDetails[i].IncreamentOn + '</td><td class=text-right>' + thousands_separators(BidData[0].BidScrapSalesDetails[i].LastSalePrice) + '</td><td class=hide>' + BidData[0].BidScrapSalesDetails[i].AttachmentSeqID + '</td><td class=text-right>' + thousands_separators(BidData[0].BidScrapSalesDetails[i].StartingPrice) + '</td><td class=text-right>' + BidData[0].BidScrapSalesDetails[i].PriceReductionFrequency + '</td><td class=text-right>' + thousands_separators(BidData[0].BidScrapSalesDetails[i].PriceReductionAmount) + '</td><td class=hide>' + BidData[0].BidScrapSalesDetails[i].ShowHLPrice + '</td><td class=hide>' + BidData[0].BidScrapSalesDetails[i].ShowStartPrice + '</td></tr>');
                        z = i;
                    }

                }

            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else {
                alert(xhr.status + ' ' + xhr.statusText);
                jQuery.unblockUI();
            }

            return false;
            jQuery.unblockUI();
        }
    });

    setTimeout(function () {
        fetchPSBidDetailsForPreview()
    }, 2000);

}



function ajaxFileDelete(closebtnid, fileid, filepath, deletionFor) {
    FileseqNo = FileseqNo - 1;
    //jQuery(document).ajaxStart(jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" /> Please Wait...</h5>' })).ajaxStop(jQuery.unblockUI);
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    var formData = new window.FormData();
    if (deletionFor == 'ParameterFiles') {
        formData.append("Path", filepath);
    }
    else {

        var theLinkdiv = document.getElementById(filepath)
        var path = theLinkdiv.getAttribute("href");

        formData.append("Path", path);
    }


    $.ajax({

        url: 'ConfigureFileAttachment.ashx',

        data: formData,

        processData: false,

        contentType: false,

        asyc: false,

        type: 'POST',

        success: function (data) {



            if (deletionFor != 'ParameterFiles' && deletionFor != 'ParameterFilesedit') {
                fileDeletefromdb(closebtnid, fileid, filepath, deletionFor);
            }
            else if (deletionFor == 'ParameterFilesedit') {

                var clickedrow = sessionStorage.getItem('ClickedEditID');
                $('#closebtnitms').hide();
                $('#' + filepath).html('')
                $('#' + filepath).attr('href', 'javascript:;').addClass('display-none');
                $('#' + fileid).attr('disabled', false);
                $('#spansuccess1').html('File Deleted Successfully');

                $("#" + clickedrow).find("td:eq(12)").text('')
                $("#" + clickedrow).find("td:eq(15)").text(FileseqNo)
                success.show();
                Metronic.scrollTo(success, -200);
                success.fadeOut(5000);
            }
            jQuery.unblockUI();
        },

        error: function () {

            bootbox.alert("Attachment error.");
            jQuery.unblockUI();
        }

    });
    
}


function fileDeletefromdb(closebtnid, fileid, filepath, deletionFor) {

    $('#' + closebtnid).remove();
    $('#' + filepath).html('')
    $('#' + filepath).attr('href', 'javascript:;').addClass('display-none');
    $('#' + fileid).attr('disabled', false);
    var BidData = {

        "BidId": sessionStorage.getItem('CurrentBidID'),
        "BidTypeID": '1',
        "UserId": sessionStorage.getItem('UserID'),
        "RFQRFIID": 0,
        "RFIRFQType": deletionFor
    }

    jQuery.ajax({

        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ConfigureBid/FileDeletion/",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        crossDomain: true,
        async: false,
        data: JSON.stringify(BidData),
        dataType: "json",
        success: function (data) {
            if (data[0].IsSuccess == '1') {
                $('#spansuccess1').html('File Deleted Successfully');
                success.show();
                Metronic.scrollTo(success, -200);
                success.fadeOut(5000);
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else {
                alert(xhr.status + ' ' + xhr.statusText);
                jQuery.unblockUI();
            }

            return false;
            jQuery.unblockUI();
        }

    });
}


function Dateandtimevalidate(indexNo) {

    jQuery.ajax({
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ConfigureBid/Dateandtimevalidate/?BidDate=" + jQuery("#txtbidDate").val() + "&BidTime=" + jQuery("#txtbidTime").val(),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "GET",
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function(RFQData) {
            //if ($("#ddlAuctiontype option:selected").val() == '81') {
            //    $(".for-englishbid").show();
            //    $(".for-dutch-bid").hide();
            //    $("#lblCeilingPrice").html('').html('Bid Start Price <span class="required"> *</span>');
            //    $('#lblshowprice').text('Show H1 Price')
                
            //} else {
            //    $(".for-englishbid").hide();
            //    $(".for-dutch-bid").show();
            //    $("#lblCeilingPrice").html('').html('Ceiling/ Max. Price <span class="required"> *</span>');
            //    $('#lblshowprice').text('Show L1 Price')
               
            //}
            if (RFQData[0].BidId == 1) {
                if (indexNo == 'index1') {
                    //ConfigureBidInsScrapSalesTab1();index
                    if (sessionStorage.getItem('_savedDraft') == 'Y' && _bidType != $("#ddlAuctiontype option:selected").val()) {

                        bootbox.dialog({
                            message: "By changing Auction Type for will delete previously configured event parameters. Do you want to continue?",
                            // title: "Custom title",
                            buttons: {
                                confirm: {
                                    label: "Yes",
                                    className: "btn-success",
                                    callback: function () {

                                        deleteBidParameter('B');
                                    }
                                },
                                cancel: {
                                    label: "No",
                                    className: "btn-warning",
                                    callback: function () {
                                        $('#form_wizard_1').bootstrapWizard('previous');
                                    }
                                }
                            }
                        });
                    }
                    else {
                        if ($("#ddlAuctiontype option:selected").val() == 81) {
                            if ($("#txtBidDuration").val() == '0') {
                                $('#form_wizard_1').bootstrapWizard('previous');
                                $(".alert-danger").find("span").html('').html('Bid Duration can not be zero.')
                                Metronic.scrollTo(error, -200);
                                $(".alert-danger").show();
                                $(".alert-danger").fadeOut(5000);
                                jQuery.unblockUI();
                                return false;
                            }
                            else {
                                ConfigureBidInsPefaTab1();
                               // hideshowDuration();
                            }
                        }
                        else {
                            ConfigureBidInsPefaTab1();
                          //  hideshowDuration();
                        }
                        
                    }
                        
                   
                    fetchPSBidDetailsForPreview();
                }
                else {
                    $('#BidPreviewDiv').show();
                    $('#form_wizard_1').hide();
                }

            }
            else {
                if (indexNo == 'index1') {
                    bootbox.alert("Date and Time should not be less than current date and time.");
                    $('#form_wizard_1').bootstrapWizard('previous');
                    return false;
                }
                else {
                    bootbox.alert("Date and Time should not be less than current date and time.");
                    $('#form_wizard_1').bootstrapWizard('previous');
                    $('#form_wizard_1').bootstrapWizard('previous');
                    return false;

                }



            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else {
                bootbox.alert("you have some error.Please try agian.");
            }

            return false;
            jQuery.unblockUI();
        }
        
    });

}

// For Bid Preview

function fetchPSBidDetailsForPreview() {
    var TermsConditionFileName = '';
    var AttachementFileName = '';
    //var replaced1 = '';
    //var replaced2 = '';
    jQuery('#mapedapproverPrev').html('');
   
    jQuery('#txtBidSubjectPrev').html($('#txtBidSubject').val())
    jQuery('#txtBidDurationPrev').html($('#txtBidDuration').val())
    $("#ddlauctiontypePrev").html($("#ddlAuctiontype option:selected").html())
    jQuery('#txtbiddescriptionPrev').html($('#txtbiddescription').val())
    jQuery('#txtbidDatePrev').html($('#txtbidDate').val())
    jQuery('#txtbidTimePrev').html($('#txtbidTime').val())
    jQuery("#dropCurrencyPrev").html($('#dropCurrency option:selected').text())
    jQuery('#txtConversionRatePrev').html($('#txtConversionRate').val())
    jQuery('#txtConversionRatePrev').html($('#txtConversionRate').val())
    $('#mapedapprover option').each(function () {
        // alert($(this).html())
        jQuery('#mapedapproverPrev').append($(this).html() + '<br/>')
    });

    if ($('#filepthterms').html() != '' && ($('#file1').val() == '')) {
        $('#filepthtermsPrev').attr('href', 'PortalDocs/Bid/' + sessionStorage.getItem('CurrentBidID') + '/' + $('#filepthterms').html().replace(/\s/g, "%20")).html($('#filepthterms').html());

    } else {
        TermsConditionFileName = jQuery('#file1').val().substring(jQuery('#file1').val().lastIndexOf('\\') + 1);

        $('#filepthtermsPrev').attr('href', 'PortalDocs/Bid/' + sessionStorage.getItem('CurrentBidID') + '/' + TermsConditionFileName.replace(/\s/g, "%20")).html(TermsConditionFileName);
    }


    if (($('#filepthattach').html() != '') && ($('#file2').val() == '')) {
        $('#filepthattachPrev').attr('href', 'PortalDocs/Bid/' + sessionStorage.getItem('CurrentBidID') + '/' + $('#filepthattach').html().replace(/\s/g, "%20")).html($('#filepthattach').html());
    } else {
        AttachementFileName = jQuery('#file2').val().substring(jQuery('#file2').val().lastIndexOf('\\') + 1);

        $('#filepthattachPrev').attr('href', 'PortalDocs/Bid/' + sessionStorage.getItem('CurrentBidID') + '/' + AttachementFileName.replace(/\s/g, "%20")).html(AttachementFileName);
    }
    
    


}

$('#back_prev_btn').click(function () {
    $('#BidPreviewDiv').hide();
    $('#form_wizard_1').show();
});

$("#divduration").hide();
function hideshowDuration() {

    $("#tblServicesProduct").empty();
    $("#tblServicesProductPrev").empty();
    if ($("#ddlAuctiontype option:selected").val() == 81) {
        //$("#divduration").show();
        $(".hdnfielddutch").attr('disabled', false);
        $("#drpshowL1L2").attr('disabled', false);
        $("#txtBidDuration").attr('disabled', false);
        $("#txtBidDuration").val(0);
    }
    else {
        //$("#divduration").hide();
        $(".hdnfielddutch").attr('disabled', true);
        $("#drpshowL1L2").attr('disabled', true);
        $("#txtBidDuration").attr('disabled', true);
        $("#txtBidDuration").val(0);
    }
}
function discardBid(For) {
    var BidData = {

        "BidId": sessionStorage.getItem('CurrentBidID'),
        "For": For
        
    }

    jQuery.ajax({

        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ConfigureBid/DiscardBidPefa/",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        crossDomain: true,
        async: false,
        data: JSON.stringify(BidData),
        dataType: "json",
        success: function (data) {
            if (data[0].Success == '1') {
                bootbox.alert("Bid Cancelled Successfully.", function () {                    
                    window.location = sessionStorage.getItem("HomePage")
                    return false;
                });
                
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else {
                bootbox.alert("you have some error.Please try agian.");
            }

            return false;
            jQuery.unblockUI();
        }

    });
}

function deleteBidParameter(For) {

    var BidData = {

        "BidId": sessionStorage.getItem('CurrentBidID'),
        "For": For

    }

    jQuery.ajax({

        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ConfigureBid/DiscardBidPefa/",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        crossDomain: true,
        async: false,
        data: JSON.stringify(BidData),
        dataType: "json",
        success: function (data) {
            if (data[0].Success == '1') {
                ConfigureBidInsPefaTab1();
                $("#tblServicesProduct").empty();
                $("#tblServicesProductPrev").empty();
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else {
                bootbox.alert("you have some error.Please try agian.");
            }

            return false;
            jQuery.unblockUI();
        }

    });
    
}
var vendorsForAutoComplete;
function fetchVendorGroup(categoryFor, vendorId) {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ProductandServiceCategory/fetchProductCategory/?CustomerID=" + sessionStorage.getItem('CustomerID') + "&For=" + categoryFor + "&MappedBy=" + sessionStorage.getItem('UserID') + "&VendorID=" + vendorId,
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        data: "{}",
        cache: false,
        dataType: "json",
        success: function (data) {
            if (data.length > 0) {
                vendorsForAutoComplete = data;
            }

            jQuery.unblockUI();
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else {
                bootbox.alert("you have some error.Please try agian.");
            }

            return false;
            jQuery.unblockUI();
        }
    });
}

jQuery("#txtVendorGroup").typeahead({
    source: function (query, process) {
        var data = vendorsForAutoComplete
        usernames = [];
        map = {};
        var username = "";
        jQuery.each(data, function (i, username) {
            map[username.CategoryName] = username;
            usernames.push(username.CategoryName);
        });

        process(usernames);

    },
    minLength: 2,
    updater: function (item) {
        if (map[item].CategoryID != "0") {
            getCategoryWiseVendors(map[item].CategoryID);
        }
        else {
            gritternotification('Please select Vendor  properly!!!');
        }

        return item;
    }

});
function getCategoryWiseVendors(categoryID) {

    jQuery.ajax({

        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ConfigureBid/FetchVendorCategoryWise_PEV2/?CustomerID=" + sessionStorage.getItem('CustomerID') + "&CategoryID=" + categoryID,
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        dataType: "json",
        success: function (data) {

            jQuery("#tblvendorlist > tbody").empty();
            var vName = '';
            for (var i = 0; i < data.length; i++) {
                vName = data[i].VendorName;
                var str = "<tr><td class='hide'>" + data[i].VendorID + "</td><td><div class=\"checker\" id=\"uniform-chkbidTypes\"><span  id=\"spanchecked\"><input type=\"checkbox\" Onclick=\"Check(this,\'" + vName + "'\,\'" + data[i].VendorID + "'\)\"; id=\"chkvender" + data[i].VendorID + "\" value=" + data[i].VendorID + " style=\"cursor:pointer\" name=\"chkvender\"/></span></div></td><td> " + data[i].VendorName + " </td></tr>";

                jQuery('#tblvendorlist > tbody').append(str);

            }
            //$("#selectedvendorlistsPrev> tbody > tr").each(function (index) {
            //    InsertQuery = InsertQuery + "select " + sessionStorage.getItem('CurrentBidID') + "," + $.trim($(this).find('td:eq(0)').html()) + "," + $.trim($(this).find('td:eq(2)').html()) + " union all ";
            //});
            if ($("#selectedvendorlists > tbody > tr").length > 0) {
                $("#selectedvendorlists> tbody > tr").each(function (index) {
                    console.log("vendID > ", $.trim($(this).find('td:eq(0)').html()))
                    $("#chkvender" + $.trim($(this).find('td:eq(0)').html())).prop("disabled", true);
                    $("#chkvender" + $.trim($(this).find('td:eq(0)').html())).closest("span#spanchecked").addClass("checked")

                });
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else {
                bootbox.alert("you have some error.Please try agian.");
            }

            return false;
            jQuery.unblockUI();
        }

    });

}

function cloneBid() {
    window.location = 'cloneBid.html?bidTypeId=6';
}