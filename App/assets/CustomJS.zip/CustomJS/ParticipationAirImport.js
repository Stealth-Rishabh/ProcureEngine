﻿var BidTypeID = 0;
var BidForID = 0;
var Duration = '0.00';
$(document).ready(function () {
    fetchVendorDetails();
});

function fetchVendorDetails() {
	var tncAttachment = '';
    	var anyotherAttachment = '';
    var url = '';
    if (sessionStorage.getItem("ContactEmailID") == 'null' || sessionStorage.getItem("ContactEmailID") == '') {

        url = sessionStorage.getItem("APIPath") + "VendorParticipation/FetchBidDetails/?BidID=" + sessionStorage.getItem("BidID") + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("UserID"));

    } else {
        url = sessionStorage.getItem("APIPath") + "VendorParticipation/FetchBidDetails/?BidID=" + sessionStorage.getItem("BidID") + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("BidUserID"));
    }
    
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: url,
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
            if (data.length > 0) {
                tncAttachment = data[0].TermsConditions.replace(/\s/g, "%20")
                anyotherAttachment = data[0].Attachment.replace(/\s/g, "%20")
		
                jQuery("label#lblTimeLeft").text('');
                jQuery("label#lblitem1").text(data[0].BidFor);
                jQuery("#lblbidsubject").text(data[0].BidSubject);
                jQuery("#lblbidDetails").text(data[0].BidDetails);
                jQuery("#lblbiddate").text(data[0].BidDate);
                jQuery("#lblbidtime").text(data[0].BidTime);

                jQuery("a#lnkTermsAttachment").text(data[0].TermsConditions);
                jQuery("a#lnkTermsAttachment").attr("href", "PortalDocs/Bid/" + sessionStorage.getItem("BidID") + "/" + tncAttachment)
                jQuery("a#lnkAnyOtherAttachment").text(data[0].Attachment);
                jQuery("a#lnkAnyOtherAttachment").attr("href", "PortalDocs/Bid/" + sessionStorage.getItem("BidID") + "/" + anyotherAttachment)

                jQuery("#lblbidduration").text(data[0].BidDuration);
                jQuery("#lblcurrency").text(data[0].CurrencyName);
                jQuery("#lblConvRate").text(data[0].ConversionRate);
                jQuery("#lblstatus").text(data[0].ConversionRate);
                jQuery("#lblConvRate").text(data[0].ConversionRate);

                jQuery("#tdfmin").text(data[0].TargetFreightMin == null ? '' : data[0].TargetFreightMin)
                jQuery("#tdf45").text(data[0].TargetFreightPlus45 == null ? '' : data[0].TargetFreightPlus45)
                jQuery("#tdf100").text(data[0].TargetFreightPlus100 == null ? '' : data[0].TargetFreightPlus100)
                jQuery("#tdf300").text(data[0].TargetFreightPlus300 == null ? '' : data[0].TargetFreightPlus300)
                jQuery("#tdf500").text(data[0].TargetFreightPlus500 == null ? '' : data[0].TargetFreightPlus500)
                jQuery("#tdf1000").text(data[0].TargetFreightPlus1000 == null ? '' : data[0].TargetFreightPlus1000)

                if (data[0].BidForID == "3") {
                    jQuery("#tdxmin").text(data[0].TargetExWorksMin == null ? '' : data[0].TargetExWorksMin)
                    jQuery("#tdx45").text(data[0].TargetExWorksPlus45 == null ? '' : data[0].TargetExWorksPlus45)
                    jQuery("#tdx100").text(data[0].TargetExWorksPlus100 == null ? '' : data[0].TargetExWorksPlus100)
                    jQuery("#tdx300").text(data[0].TargetExWorksPlus300 == null ? '' : data[0].TargetExWorksPlus300)
                    jQuery("#tdx500").text(data[0].TargetExWorksPlus500 == null ? '' : data[0].TargetExWorksPlus500)
                    jQuery("#tdx1000").text(data[0].TargetExWorksPlus1000 == null ? '' : data[0].TargetExWorksPlus1000)
                }
                else {
                    jQuery('#trtargetexworks').hide();
                }

                BidTypeID = data[0].BidTypeID;
                BidForID = data[0].BidForID;
                display = document.querySelector('#lblTimeLeft');
                clearInterval(mytime)
                startTimer((parseInt(data[0].TimeLeft)), display);
                fetchBidSummaryVendorAir();
            }
        },
        error: function (xhr) {
            jQuery("#error").text(xhr.d);
        }
    });
    
}
function fetchBidSummaryVendorAir() {
    var url = '';
    if (sessionStorage.getItem("ContactEmailID") == 'null' || sessionStorage.getItem("ContactEmailID") == '') {

        url = sessionStorage.getItem("APIPath") + "VendorParticipationAir/fetchBidSummaryVendorAir/?BidID=" + sessionStorage.getItem("BidID") + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("UserID")) + "&AthenticationToken=''&UserType=" + sessionStorage.getItem("UserType");

    } else {
        url = sessionStorage.getItem("APIPath") + "VendorParticipationAir/fetchBidSummaryVendorAir/?BidID=" + sessionStorage.getItem("BidID") + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("BidUserID")) + "&AthenticationToken=''&UserType=" + sessionStorage.getItem("UserType");
    }

    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: url,
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
            if (data.length > 0) {
                jQuery("#lblinitialfreightmin").text(data[0].IQFMin == '0' ? '' : data[0].IQFMin)
                jQuery("#lblinitialfreight45").text(data[0].IQF45 == '0' ? '' : data[0].IQF45)
                jQuery("#lblinitialfreight100").text(data[0].IQF100 == '0' ? '' : data[0].IQF100)
                jQuery("#lblinitialfreight300").text(data[0].IQF300 == '0' ? '' : data[0].IQF300)
                jQuery("#lblinitialfreight500").text(data[0].IQF500 == '0' ? '' : data[0].IQF500)
                jQuery("#lblinitialfreight1000").text(data[0].IQF1000 == '0' ? '' : data[0].IQF1000)

                jQuery("#lblinitialExWorkmin").text(data[0].IQEMin == '0' ? '' : data[0].IQEMin)
                jQuery("#lblinitialExWork45").text(data[0].IQE45 == '0' ? '' : data[0].IQE45)
                jQuery("#lblinitialExWork100").text(data[0].IQE100 == '0' ? '' : data[0].IQE100)
                jQuery("#lblinitialExWork300").text(data[0].IQE300 == '0' ? '' : data[0].IQE300)
                jQuery("#lblinitialExWork500").text(data[0].IQE500 == '0' ? '' : data[0].IQE500)
                jQuery("#lblinitialExWork1000").text(data[0].IQE1000 == '0' ? '' : data[0].IQE1000)

                jQuery("#lblCurrentfreightmin").text(data[0].LQFMin == '0' ? '' : data[0].LQFMin)
                jQuery("#lblCurrentfreight45").text(data[0].LQF45 == '0' ? '' : data[0].LQF45)
                jQuery("#lblCurrentfreight100").text(data[0].LQF100 == '0' ? '' : data[0].LQF100)
                jQuery("#lblCurrentfreight300").text(data[0].LQF300 == '0' ? '' : data[0].LQF300)
                jQuery("#lblCurrentfreight500").text(data[0].LQF500 == '0' ? '' : data[0].LQF500)
                jQuery("#lblCurrentfreight1000").text(data[0].LQF1000 == '0' ? '' : data[0].LQF1000)

                jQuery("#lblCurrentExWorkmin").text(data[0].LQEMin == '0' ? '' : data[0].LQEMin)
                jQuery("#lblCurrentExWork45").text(data[0].LQE45 == '0' ? '' : data[0].LQE45)
                jQuery("#lblCurrentExWork100").text(data[0].LQE100 == '0' ? '' : data[0].LQE100)
                jQuery("#lblCurrentExWork300").text(data[0].LQE300 == '0' ? '' : data[0].LQE300)
                jQuery("#lblCurrentExWork500").text(data[0].LQE500 == '0' ? '' : data[0].LQE500)
                jQuery("#lblCurrentExWork1000").text(data[0].LQE1000 == '0' ? '' : data[0].LQE1000)

                jQuery("#lblCurrentStatusFreightmin").text(data[0].LOFMin)
                jQuery("#lblCurrentStatusFreight45").text(data[0].LOF45)
                jQuery("#lblCurrentStatusFreight100").text(data[0].LOF100)
                jQuery("#lblCurrentStatusFreight300").text(data[0].LOF300)
                jQuery("#lblCurrentStatusFreight500").text(data[0].LOF500)
                jQuery("#lblCurrentStatusFreight1000").text(data[0].LOF1000)


                jQuery("#lblCurrentStatusExWorkmin").text(data[0].LOEMin)
                jQuery("#lblCurrentStatusExWork45").text(data[0].LOE45)
                jQuery("#lblCurrentStatusExWork100").text(data[0].LOE100)
                jQuery("#lblCurrentStatusExWork300").text(data[0].LOE300)
                jQuery("#lblCurrentStatusExWork500").text(data[0].LOE500)
                jQuery("#lblCurrentStatusExWork1000").text(data[0].LOE1000)

                if (data[0].LOFMin == 'L1') {
                    jQuery('#lblCurrentStatusFreightmin').css('color', 'Blue');
                }
                else {
                    jQuery('#lblCurrentStatusFreightmin').css('color', 'Red');
                }

                if (data[0].LOF45 == 'L1') {
                    jQuery('#lblCurrentStatusFreight45').css('color', 'Blue');
                }
                else {
                    jQuery('#lblCurrentStatusFreight45').css('color', 'Red');
                }

                if (data[0].LOF100 == 'L1') {
                    jQuery('#lblCurrentStatusFreight100').css('color', 'Blue');
                }
                else {
                    jQuery('#lblCurrentStatusFreight100').css('color', 'Red');
                }

                if (data[0].LOF300 == 'L1') {
                    jQuery('#lblCurrentStatusFreight300').css('color', 'Blue');
                }
                else {
                    jQuery('#lblCurrentStatusFreight300').css('color', 'Red');
                }

                if (data[0].LOF500 == 'L1') {
                    jQuery('#lblCurrentStatusFreight500').css('color', 'Blue');
                }
                else {
                    jQuery('#lblCurrentStatusFreight500').css('color', 'Red');
                }

                if (data[0].LOF1000 == 'L1') {
                    jQuery('#lblCurrentStatusFreight1000').css('color', 'Blue');
                }
                else {
                    jQuery('#lblCurrentStatusFreight1000').css('color', 'Red');
                }

                if (data[0].LOEMin == 'L1') {
                    jQuery('#lblCurrentStatusExWorkmin').css('color', 'Blue');
                }
                else {
                    jQuery('#lblCurrentStatusExWorkmin').css('color', 'Red');
                }

                if (data[0].LOE45 == 'L1') {
                    jQuery('#lblCurrentStatusExWork45').css('color', 'Blue');
                }
                else {
                    jQuery('#lblCurrentStatusExWork45').css('color', 'Red');
                }

                if (data[0].LOE100 == 'L1') {
                    jQuery('#lblCurrentStatusExWork100').css('color', 'Blue');
                }
                else {
                    jQuery('#lblCurrentStatusExWork100').css('color', 'Red');
                }

                if (data[0].LOE300 == 'L1') {
                    jQuery('#lblCurrentStatusExWork300').css('color', 'Blue');
                }
                else {
                    jQuery('#lblCurrentStatusExWork300').css('color', 'Red');
                }

                if (data[0].LOE500 == 'L1') {
                    jQuery('#lblCurrentStatusExWork500').css('color', 'Blue');
                }
                else {
                    jQuery('#lblCurrentStatusExWork500').css('color', 'Red');
                }

                if (data[0].LOE1000 == 'L1') {
                    jQuery('#lblCurrentStatusExWork1000').css('color', 'Blue');
                }
                else {
                    jQuery('#lblCurrentStatusExWork1000').css('color', 'Red');
                }

				display = document.querySelector('#lblTimeLeft');
                      startTimer(data[0].TimeLeft, display);
				 if (data[0].NoOfExtension >= 1) {
                          jQuery('#lblTimeLeft').css('color', 'red');
						  jQuery('#lblTimeLeftTxt').removeClass('display-none');
					jQuery('#lblTimeLeftTxt').html('<b>Bid Time Extended.</b>').css('color', 'red');
                      }
                      else {
						  jQuery('#lblTimeLeftTxt').addClass('display-none');
                          jQuery('#lblTimeLeft').css('color', '');
                      }


            }
        },
        error: function (xhr) {
            jQuery("#error").text(xhr.d);
        }
    });
}

function InsUpdQuoteAir() {
    
    var vendorID = 0;
    if (sessionStorage.getItem("ContactEmailID") == 'null' || sessionStorage.getItem("ContactEmailID") == '') {
        vendorID = sessionStorage.getItem('UserID');
    } else {
        vendorID = sessionStorage.getItem('BidUserID');
    }
	
	if ($('#hdnval').val() >= 60) {
		
		var QuoteAir = {
        "VendorID": vendorID,
        "BidID": sessionStorage.getItem("BidID"),
        "BidTypeID": BidTypeID,
        "BidForID": BidForID,
        "TargetFreightMin": (jQuery("#txtfreightmin").val() == '') ? jQuery("#lblCurrentfreightmin").text() : jQuery("#txtfreightmin").val() ,
        "TargetFreightPlus45": (jQuery("#txtfreight45").val() == '') ? jQuery("#lblCurrentfreight45").text() : jQuery("#txtfreight45").val() ,
        "TargetFreightPlus100": (jQuery("#txtfreight100").val() == '') ? jQuery("#lblCurrentfreight100").text() : jQuery("#txtfreight100").val(),
        "TargetFreightPlus300": (jQuery("#txtfreight300").val() == '') ? jQuery("#lblCurrentfreight300").text() : jQuery("#txtfreight300").val(),
        "TargetFreightPlus500": (jQuery("#txtfreight500").val() == '') ? jQuery("#lblCurrentfreight500").text() : jQuery("#txtfreight500").val(),
        "TargetFreightPlus1000": (jQuery("#txtfreight1000").val() == '') ? jQuery("#lblCurrentfreight1000").text() : jQuery("#txtfreight1000").val(),

        "TargetExWorksMin": (jQuery("#txtexworkmin").val() == '') ? jQuery("#lblCurrentExWorkmin").text() : jQuery("#txtexworkmin").val(),
        "TargetExWorksPlus45": (jQuery("#txtexwork45").val() == '') ? jQuery("#lblCurrentExWork45").text() : jQuery("#txtexwork45").val(),
        "TargetExWorksPlus100": (jQuery("#txtexwork100").val() == '') ? jQuery("#lblCurrentExWork100").text() : jQuery("#txtexwork100").val(),
        "TargetExWorksPlus300": (jQuery("#txtexwork300").val() == '') ? jQuery("#lblCurrentExWork300").text() : jQuery("#txtexwork300").val(),
        "TargetExWorksPlus500": (jQuery("#txtexwork500").val() == '') ? jQuery("#lblCurrentExWork500").text() : jQuery("#txtexwork500").val(),
        "TargetExWorksPlus1000": (jQuery("#txtexwork1000").val() == '') ? jQuery("#lblCurrentExWork1000").text() : jQuery("#txtexwork1000").val(),
        "LoginUserID": vendorID,
        "Remarks": ''
    }
    //alert(JSON.stringify(QuoteAir))
    jQuery.ajax({
        url: sessionStorage.getItem("APIPath") + "VendorParticipationAir/ParticipationAir/",
        type: "POST",
        data: JSON.stringify(QuoteAir),
        contentType: "application/json; charset=utf-8",
        success: function (data, status, jqXHR) {
            fetchBidSummaryVendorAir(BidTypeID, BidForID);
        },
        error: function (xhr) {
            jQuery("#error").text(xhr.d);
        }
    });
		
	}else{
		var QuoteAir = {
        "VendorID": vendorID,
        "BidID": sessionStorage.getItem("BidID"),
        "BidTypeID": BidTypeID,
        "BidForID": BidForID,
        "TargetFreightMin": (jQuery("#txtfreightmin").val() == '') ? jQuery("#lblCurrentfreightmin").text() : jQuery("#txtfreightmin").val() ,
        "TargetFreightPlus45": (jQuery("#txtfreight45").val() == '') ? jQuery("#lblCurrentfreight45").text() : jQuery("#txtfreight45").val() ,
        "TargetFreightPlus100": (jQuery("#txtfreight100").val() == '') ? jQuery("#lblCurrentfreight100").text() : jQuery("#txtfreight100").val(),
        "TargetFreightPlus300": (jQuery("#txtfreight300").val() == '') ? jQuery("#lblCurrentfreight300").text() : jQuery("#txtfreight300").val(),
        "TargetFreightPlus500": (jQuery("#txtfreight500").val() == '') ? jQuery("#lblCurrentfreight500").text() : jQuery("#txtfreight500").val(),
        "TargetFreightPlus1000": (jQuery("#txtfreight1000").val() == '') ? jQuery("#lblCurrentfreight1000").text() : jQuery("#txtfreight1000").val(),

        "TargetExWorksMin": (jQuery("#txtexworkmin").val() == '') ? jQuery("#lblCurrentExWorkmin").text() : jQuery("#txtexworkmin").val(),
        "TargetExWorksPlus45": (jQuery("#txtexwork45").val() == '') ? jQuery("#lblCurrentExWork45").text() : jQuery("#txtexwork45").val(),
        "TargetExWorksPlus100": (jQuery("#txtexwork100").val() == '') ? jQuery("#lblCurrentExWork100").text() : jQuery("#txtexwork100").val(),
        "TargetExWorksPlus300": (jQuery("#txtexwork300").val() == '') ? jQuery("#lblCurrentExWork300").text() : jQuery("#txtexwork300").val(),
        "TargetExWorksPlus500": (jQuery("#txtexwork500").val() == '') ? jQuery("#lblCurrentExWork500").text() : jQuery("#txtexwork500").val(),
        "TargetExWorksPlus1000": (jQuery("#txtexwork1000").val() == '') ? jQuery("#lblCurrentExWork1000").text() : jQuery("#txtexwork1000").val(),
        "LoginUserID": vendorID,
        "Remarks": ''
    }
    //alert(JSON.stringify(QuoteAir))
    jQuery.ajax({
        url: sessionStorage.getItem("APIPath") + "VendorParticipationAir/ParticipationAir/",
        type: "POST",
        data: JSON.stringify(QuoteAir),
        contentType: "application/json; charset=utf-8",
        success: function (data, status, jqXHR) {
            fetchBidSummaryVendorAir(BidTypeID, BidForID);
        },
        error: function (xhr) {
            jQuery("#error").text(xhr.d);
        }
    });
	
			var data = {
                "BidID": sessionStorage.getItem("BidID")

            }
            //alert(JSON.stringify(data))
            jQuery.ajax({
                url: sessionStorage.getItem("APIPath") + "VendorParticipation/ExtendDuration/",
                type: "POST",
                data: JSON.stringify(data),
                contentType: "application/json; charset=utf-8",
                success: function (data, status, jqXHR) {
                    

                    //display = document.querySelector('#lblTimeLeft');
                   // startTimer((parseInt(data[0].TimeLeft)), display);
                    fetchVendorDetails()
                    return true
                },
                error: function (xhr) {
                    jQuery("#error").text(xhr.d);
                }
            });
		
	}
    
}
//var timer;
var mytime = 0;
function startTimer(duration, display) {
    //if (timer) 
		clearInterval(mytime);
	var timer = duration, hours, minutes, seconds;
    timer = duration;
    var hours, minutes, seconds;
    mytime = setInterval(function () {
        hours = parseInt(timer / 3600, 10)
        minutes = parseInt(timer / 60, 10) - (hours * 60)
        seconds = parseInt(timer % 60, 10);

        hours = hours < 10 ? "0" + hours : hours;
        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;

        if (hours > 0) {
            display.textContent = hours + ":" + minutes + ":" + seconds;
        }
        else {
            display.textContent = minutes + ":" + seconds;
        }


        if ((seconds.toString().substring(1, 2) == '0') || (seconds.toString().substring(1, 2) == '5')) {
            fetchBidSummaryVendorAir(BidTypeID, BidForID);
        }
        //if (seconds.toString().substring(0, 2) == '02') {
        //    fetchVendorDetails();

        //}

        if (--timer == 0) {
            timer = 0;
            closeBidAir();
        }
		 $('#hdnval').val(timer)
    }, 1000);
}

//function startTimer(duration, display) {
//    clearInterval(timer);
//    var timer = duration, hours, minutes, seconds;
    
//    setInterval(function () {
//        hours = parseInt(timer / 3600, 10)
//        minutes = parseInt(timer / 60, 10) - (hours * 60)
//        seconds = parseInt(timer % 60, 10);

//        hours = hours < 10 ? "0" + hours : hours;
//        minutes = minutes < 10 ? "0" + minutes : minutes;
//        seconds = seconds < 10 ? "0" + seconds : seconds;

//        if (hours > 0) {
//            display.textContent = hours + ":" + minutes + ":" + seconds;
//        }
//        else {
//            display.textContent = minutes + ":" + seconds;
//        }


//        if ((seconds.toString().substring(1, 2) == '0') || (seconds.toString().substring(1, 2) == '5')) {
//            fetchBidSummaryVendorAir(BidTypeID, BidForID);
//        }
//        //if (seconds.toString().substring(0, 2) == '10') {
//        //    fetchVendorDetails();

//        //}

//        if (--timer < 0) {
//            timer = 0;
//            closeBidAir();
//        }
//    }, 1000);
//}

function closeBidAir() {
	clearInterval(mytime)
    jQuery.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "VendorParticipation/CloseBid/?BidID=" + sessionStorage.getItem("BidID"),
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
            bootbox.alert("Bid time has been over. Thanks for Participation.", function () {
            window.location = sessionStorage.getItem('MainUrl');
                return false;
            });
        }
    });
}

var FormValidation = function () {
    var ValidateQuote = function () {
        var form1 = $('#FormparticipateAir');
        var error1 = $('.alert-danger', form1);
        var success1 = $('.alert-success', form1);
        var isValidationOverruled = "N";
        form1.validate({
            errorElement: 'span',
            errorClass: 'help-block',
            focusInvalid: false,
            ignore: "",

            rules: {
                txtfreightmin: {
                    required: function (element) {
                        //debugger;
                        if ($("#lblCurrentfreightmin").text() == '') {
                            return true;
                        }
                        //else if ($("#lblCurrentfreightmin").text() < $("#txtfreightmin").val()) {
                        //    return false;
                        //}
                        //if ($("#txtfreightmin").val() < 0) {
                        //    return true;
                        //}

                        return false;
                        

                        //if (isValidData=="N")
                        //    return false;
                        //else 
                        //    return true;
                        

                    },
                    number: true,
                    minlength: 1,
                    maxlength: 5
                },
                txtfreight45: {
                    required: function (element) {
                        if ($("#lblCurrentfreight45").text() == '') {
                            return true;
                        }
                        else {
                            return false;
                        }
                    },
                    number: true,
                    minlength: 1,
                    maxlength: 5
                },
                txtfreight100: {
                    required: function (element) {
                        if ($("#lblCurrentfreight100").text() == '') {
                            return true;
                        }
                        else {
                            return false;
                        }
                    },
                    number: true,
                    minlength: 1,
                    maxlength: 5
                },
                txtfreight300: {
                    required: function (element) {
                        if ($("#lblCurrentfreight300").text() == '') {
                            return true;
                        }
                        else {
                            return false;
                        }
                    },
                    number: true,
                    minlength: 1,
                    maxlength: 5
                },
                txtfreight500: {
                    required: function (element) {
                        if ($("#lblCurrentfreight500").text() == '') {
                            return true;
                        }
                        else {
                            return false;
                        }
                    },
                    number: true,
                    minlength: 1,
                    maxlength: 5
                },
                txtfreight1000: {
                    required: function (element) {
                        if ($("#lblCurrentfreight1000").text() == '') {
                            return true;
                        }
                        else {
                            return false;
                        }
                    },
                    number: true,
                    minlength: 1,
                    maxlength: 5
                },

                txtexworkmin: {
                    required: function (element) {
                        if ($("#lblinitialExWorkmin").text() == '') {
                            return true;
                        }
                        else {
                            return false;
                        }
                    },
                    number: true,
                    minlength: 1,
                    maxlength: 5
                },
                txtexwork45: {
                    required: function (element) {
                        if ($("#lblinitialExWork45").text() == '') {
                            return true;
                        }
                        else {
                            return false;
                        }
                    },
                    number: true,
                    minlength: 1,
                    maxlength: 5
                },
                txtexwork100: {
                    required: function (element) {
                        if ($("#lblinitialExWork100").text() == '') {
                            return true;
                        }
                        else {
                            return false;
                        }
                    },
                    number: true,
                    minlength: 1,
                    maxlength: 5
                },
                txtexwork300: {
                    required: function (element) {
                        if ($("#lblinitialExWork300").text() == '') {
                            return true;
                        }
                        else {
                            return false;
                        }
                    },
                    number: true,
                    minlength: 1,
                    maxlength: 5
                },
                txtexwork500: {
                    required: function (element) {
                        if ($("#lblinitialExWork500").text() == '') {
                            return true;
                        }
                        else {
                            return false;
                        }
                    },
                    number: true,
                    minlength: 1,
                    maxlength: 5
                },
                txtexwork1000: {
                    required: function (element) {
                        if ($("#lblinitialExWork1000").text() == '') {
                            return true;
                        }
                        else {
                            return false;
                        }
                    },
                    number: true,
                    minlength: 1,
                    maxlength: 5
                }
            },
            messages: {
                txtfreightmin: {
                    required: "Please enter amount",
                    number: "number only"
                },
                txtfreight45: {
                    required: "Please enter amount",
                    number: "number only"
                },
                txtfreight100: {
                    required: "Please enter amount",
                    number: "number only"
                },
                txtfreight300: {
                    required: "Please enter amount",
                    number: "number only"
                },
                txtfreight500: {
                    required: "Please enter amount",
                    number: "number only"
                },
                txtfreight1000: {
                    required: "Please enter amount",
                    number: "number only"
                },

                txtexworkmin: {
                    required: "Please enter amount",
                    number: "number only"
                },
                txtexwork45: {
                    required: "Please enter amount",
                    number: "number only"
                },
                txtexwork100: {
                    required: "Please enter amount",
                    number: "number only"
                },
                txtexwork300: {
                    required: "Please enter amount",
                    number: "number only"
                },
                txtexwork500: {
                    required: "Please enter amount",
                    number: "number only"
                },
                txtexwork1000: {
                    required: "Please enter amount",
                    number: "number only"
                }
            },
            invalidHandler: function (event, validator) { //display error alert on form submit              
                success1.hide();
                error1.show();
                App.scrollTo(error1, -300);
            },
            highlight: function (element) { // hightlight error inputs
                $(element)
                        .closest('.form-group').addClass('has-error'); // set error class to the control group
            },
            unhighlight: function (element) { // revert the change done by hightlight
                $(element)
                        .closest('.form-group').removeClass('has-error'); // set error class to the control group
            },
            success: function (label) {
                label
                        .closest('.form-group').removeClass('has-error'); // set success class to the control group
            },
            submitHandler: function (form) {
                InsUpdQuoteAir();
                //App.scrollTo(error1, -100);
            }
        });
    }
    var handleWysihtml5 = function () {
        if (!jQuery().wysihtml5) {
            return;
        }
        if ($('.wysihtml5').size() > 0) {
            $('.wysihtml5').wysihtml5({
                "stylesheets": ["assets/plugins/bootstrap-wysihtml5/wysiwyg-color.css"]
            });
        }
    }
    return {
        init: function () {
            handleWysihtml5();
            ValidateQuote();
        }
    };
} ();