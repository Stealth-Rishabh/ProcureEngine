﻿

function fetchAttachments() {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "eRequestForQuotation/eRFQDetails/?RFQID=" + sessionStorage.getItem('hddnRFQID') + "&CustomerID=" + sessionStorage.getItem('CustomerID') + "&UserID=" + sessionStorage.getItem('UserID'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {

            jQuery("#tblAttachments").empty();
            jQuery("#tblotherrfqattachmentprev").empty();
            if (data[0].Attachments.length > 0) {
                jQuery("#tblAttachments").append("<thead><tr  style='background: gray; color: #FFF;'><th class='bold' style='width:50%!important'>Description</th><th style='width:50%!important'>Attachment</th></tr></thead>")
                jQuery("#tblotherrfqattachmentprev").append("<thead><tr  style='background: gray; color: #FFF;'><th class='bold' style='width:50%!important'>Description</th><th style='width:50%!important'>Attachment</th></tr></thead>")
                $('#div_attachments').removeClass('hide')
                $('#div_otherrfqattachprev').removeClass('hide')
                $('#headerotherrfqattach').removeClass('hide')
                $('#wrap_scrollerPrevAtt').show();
                for (var i = 0; i < data[0].Attachments.length; i++) {
                    var str = "<tr><td style='width:50%!important'>" + data[0].Attachments[i].RFQAttachmentDescription + "</td>";
                    str += '<td class=style="width:50%!important"><a style="pointer:cursur;text-decoration:none;" target=_blank href=PortalDocs/eRFQ/' + sessionStorage.getItem("hddnRFQID") + '/' + data[0].Attachments[i].RFQAttachment.replace(/\s/g, "%20") + '>' + data[0].Attachments[i].RFQAttachment + '</a></td>';
                    jQuery('#tblAttachments').append(str);
                    jQuery('#tblotherrfqattachmentprev').append(str);
                }
            }
            else {
                $('#div_attachments').addClass('hide')
                $('#div_otherrfqattachprev').addClass('hide')
                $('#headerotherrfqattach').addClass('hide')
            }

        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
    })
}

function fetchRFQParameterComponent(version, BoqPID) {
    // alert(sessionStorage.getItem("APIPath") + "eRequestForQuotation/eRFQfetchTCQuotation/?RFQId=" + sessionStorage.getItem("hddnRFQID") + "&ParameterID=" + BoqPID + "&VendorID=" + sessionStorage.getItem("VendorId") + "&RFQVersionId=" + version)

    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "eRequestForQuotation/eRFQfetchTCQuotation/?RFQId=" + sessionStorage.getItem("hddnRFQID") + "&ParameterID=" + BoqPID + "&VendorID=" + sessionStorage.getItem("VendorId") + "&RFQVersionId=" + version,
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        data: "{}",
        cache: false,
        dataType: "json",
        success: function (data) {

            jQuery('#icon').html('<i class="fa fa-list-ul"></i>');
            jQuery("#tblRFQParameterComponet").empty();
            $('#scrolr').show();

            if (data.length > 0) {

                jQuery("#tblRFQParameterComponet").append("<thead><tr style='background: gray; color: #FFF;'><th>Commercial Terms</th><th>Applicable Rate (%)</th></tr></thead>");
                for (var i = 0; i < data.length; i++) {

                    // jQuery('<tr id=trid' + i + '><td class=hidden >' + data[i].RFQParameterId + '</td><td class=hidden >' + data[i].RFQID + '</td><td>' + data[i].ConditionType + '</td><td>' + data[i].TCName + '</td><td><input type="text"  id="mks1' + i + '" class="form-control input-circle text-right" value="' + thousands_separators(data[i].RFQVendorPrice) + '"  autocomplete=off onkeyup=thousands_separators_input(this) /></td><td><input type="text"  id="mkswithtax1' + i + '" class="form-control input-circle text-right" value="' + thousands_separators(data[i].RFQVendorPricewithTax) + '"  autocomplete=off onkeyup=thousands_separators_input(this) /></td></tr>').appendTo("#tblRFQParameterComponet");
                    if (data[i].isDefault == "N") {
                        jQuery('<tr id=trid' + i + '><td class=hidden >' + data[i].RFQParameterId + '</td><td class=hidden >' + data[i].RFQID + '</td><td class=hidden >' + data[i].TCID + '</td><td>' + data[i].TCName + '</td><td><input type="text"  id="mkswithtax1' + i + '" class="form-control text-right" value="' + thousands_separators(data[i].RFQVendorPricewithTax) + '"  autocomplete=off   onkeyup="this.value = minmax(this.value, 0, 50)" /></td></tr>').appendTo("#tblRFQParameterComponet");

                    }
                }
            }
            else {

                jQuery("#tblRFQParameterComponet").append('<tr><td>No Information is there..</td></tr>');
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else {
                alert('error')
            }
            return false;
            jQuery.unblockUI();
        }
    });
}

function fetchRFQLevelTC(ver) {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "eRequestForQuotation/eRFQfetchTCQuotation/?RFQId=" + sessionStorage.getItem("hddnRFQID") + "&ParameterID=" + 0 + "&VendorID=" + sessionStorage.getItem("VendorId") + "&RFQVersionId=" + ver,
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        data: "{}",
        cache: false,
        dataType: "json",
        success: function (data) {
            jQuery('#icon').html('<i class="fa fa-list-ul"></i>');
            
            jQuery("#tbltermsconditionprev").empty();
            $('#scrolr').show();
            //alert(JSON.stringify(data))
            if (data.length > 0) {
               
                jQuery("#tbltermsconditionprev").append("<thead><tr style='background: gray; color: #FFF;'><th>Other Commercial Terms</th><th>Our Requirement</th><th>Your Offer</th></tr></thead>");
                for (var i = 0; i < data.length; i++) {
                    
                    jQuery('<tr id=trid' + i + '><td class=hidden>' + data[i].TCID + '</td><td class=hidden >' + data[i].RFQID + '</td><td class=hide>' + data[i].ConditionType + '</td><td style="width:20%">' + data[i].TCName + '</td><td>' + data[i].Requirement + '</td><td><label class="control-label" >' + data[i].RFQRemark + '</label></td></tr>').appendTo("#tbltermsconditionprev");
                }
            }
            else {

                jQuery("#tbltermsconditionprev").append('<tr><td>No Information is there..</td></tr>');
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else {
                alert('error')
            }
            return false;
            jQuery.unblockUI();
        }
    });
}

function fetchRFQResponse(Flag, version) {

    var strprev = "";
    // alert(sessionStorage.getItem("APIPath") + "eRFQVendor/efetchVendorResponse/?RFQId=" + sessionStorage.getItem('hddnRFQID') + "&VendorID=" + sessionStorage.getItem('VendorId') + "&RFQVersionId=" + sessionStorage.getItem('RFQVersionId') + "&Flag=" + Flag)
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "eRFQVendor/efetchVendorResponse/?RFQId=" + sessionStorage.getItem('hddnRFQID') + "&VendorID=" + sessionStorage.getItem('VendorId') + "&RFQVersionId=" + version + "&Flag=" + Flag,
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        data: "{}",
        cache: false,
        dataType: "json",
        success: function (data) {
            if (Flag == 'Question') {
               
                jQuery("#tblQuestionsPrev").empty();

                if (data.length > 0) {
                    $('#headerspecificresponse').removeClass('hide')
                    $('#divspecificresponse').removeClass('hide')
                   
                    jQuery('#tblQuestionsPrev').append("<thead><tr  style='background: gray; color: #FFF;'><th class='bold' style='width:30%!important'>Questions</th><th class='bold' style='width:30%!important'>Our Requirement</th><th style='width:40%!important'>Answer</th></tr></thead>");

                    for (var i = 0; i < data.length; i++) {

                        
                        strprev = "<tr><td style='width:30%!important'>" + data[i].RFQQuestions + "</td>";
                        
                        strprev += "<td style='width:30%!important'>" + data[i].RFQQuestionsRequirement + "</td>";
                        
                        strprev += '<td style="width:40%!important"><label class="control-label" >' + data[i].Answer + '</label></td></tr>';
                       
                        jQuery('#tblQuestionsPrev').append(strprev);

                    }
                }
                else {
                    $('#headerspecificresponse').addClass('hide')
                    $('#divspecificresponse').addClass('hide')
                }
            }
            else {

                
                jQuery("#tblAttachmentsPrev").empty();
                if (data.length > 0) {
                    $('#headerresposeatt').removeClass('hide')
                    $('#dicresponseatt').removeClass('hide')
                   
                    jQuery('#tblAttachmentsPrev').append("<thead><tr  style='background: gray; color: #FFF;'><th class='bold' style='width:50%!important'>Description</th><th style='width:50%!important'>Attachment</th></tr></thead>");

                    for (var i = 0; i < data.length; i++) {
                        var str = "<tr><td style='width:47%!important'>" + data[i].Attachmentdescription + "</td>";
                        str += '<td class=style="width:47%!important"><a style="pointer:cursur;text-decoration:none;" target=_blank href=PortalDocs/eRFQ/' + sessionStorage.getItem("hddnRFQID") + '/' + data[i].RFQAttachment + '>' + data[i].Attachment + '</a></td>';
                        jQuery('#tblAttachmentsPrev').append(str);
                        
                    }
                }
                else {
                    $('#headerresposeatt').addClass('hide')
                    $('#dicresponseatt').addClass('hide')
                }

            }

        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            
            return false;
            jQuery.unblockUI();
        }

    })
}

function fetchReguestforQuotationDetails() {
    // jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    var replaced1 = '';

    jQuery.ajax({
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "eRequestForQuotation/eRFQDetails/?RFQID=" + sessionStorage.getItem('hddnRFQID') + "&CustomerID=" + sessionStorage.getItem('CustomerID') + "&UserID=" + sessionStorage.getItem('UserID'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "GET",
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (RFQData) {

            sessionStorage.setItem('hddnRFQID', RFQData[0].General[0].RFQId)
            jQuery('#RFQSubject').text(RFQData[0].General[0].RFQSubject)

            jQuery('#RFQDescription').html(RFQData[0].General[0].RFQDescription)
            $('#Currency').html(RFQData[0].General[0].CurrencyNm)
          
            $('#txtcurrency').val(RFQData[0].General[0].CurrencyNm)
            jQuery('#ConversionRate').html(RFQData[0].General[0].RFQConversionRate);
            jQuery('#refno').html(RFQData[0].General[0].RFQReference);
            jQuery('#txtRFQReference').html(RFQData[0].General[0].RFQReference)
            jQuery('#RFQStartDate').html(RFQData[0].General[0].RFQStartDate)
            jQuery('#RFQEndDate').html(RFQData[0].General[0].RFQEndDate)

            if (RFQData[0].General[0].RFQTermandCondition != '') {
                replaced1 = RFQData[0].General[0].RFQTermandCondition.replace(/\s/g, "%20")
            }
            jQuery('#TermCondition').attr('href', 'PortalDocs/RFQ/' + sessionStorage.getItem('hddnRFQID') + '/' + replaced1.replace(/\s/g, "%20")).html(RFQData[0].General[0].RFQTermandCondition)
            $('#filepthtermsPrev').attr('href', 'PortalDocs/RFQ/' + sessionStorage.getItem('hddnRFQID') + '/' + replaced1.replace(/\s/g, "%20")).html(RFQData[0].General[0].RFQTermandCondition);

            //Preview Details
            var TermsConditionFileName = '';

            jQuery('#lblRfqsubject').html(RFQData[0].General[0].RFQSubject)

            jQuery('#lblrfqstartdate').html(RFQData[0].General[0].RFQStartDate)
            jQuery('#lblrfqenddate').html(RFQData[0].General[0].RFQEndDate)
            jQuery('#lblrfqdescription').html(RFQData[0].General[0].RFQDescription)

            jQuery("#dropCurrencyPrev").html(RFQData[0].General[0].CurrencyNm)
            jQuery('#lblConversionRatePrev').html(RFQData[0].General[0].RFQConversionRate)
            jQuery("#txtRFQReferencePrev").html(RFQData[0].General[0].RFQReference);



        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
    });
    jQuery.unblockUI();
}



function fetchRFIParameteronload(ver) {
    fetchRFQLevelTC(ver);
    var attachment = '';
    var vendorAttachment = '';
    var replaced = '';
     // alert(sessionStorage.getItem("APIPath") + "RequestForQuotation/fetchRFQParameter/?RFQId=" + sessionStorage.getItem('hddnRFQID') + "&VendorID=" + sessionStorage.getItem('VendorId') + "&RFQVersionId=" + ver)
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "eRFQVendor/efetchRFQParameter/?RFQId=" + sessionStorage.getItem('hddnRFQID') + "&VendorID=" + sessionStorage.getItem('VendorId') + "&RFQVersionId=" + ver,
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        data: "{}",
        cache: false,
        dataType: "json",
        success: function (data) {
            jQuery('#icon').html('<i class="fa fa-list-ul"></i>');
            jQuery("#tblServicesProduct").empty();
            jQuery("#tblRFQPrev").empty();

            $('#divdomestic').show();
            var description = "";
            var totalammwithoutGST = 0;
            var totalammwithGST = 0;
           // alert(data.length)
            if (data.length > 0) {
               
                jQuery("#tblRFQPrev").append("<thead><tr style='background: gray; color: #FFF;'><th>Item/Service</th><th>UOM</th><th>Qty</th><th class=hide>TAT</th><th class=hide>Currency</th><th class=hide>Delivery Location</th><th>Landed Unit Price<br/>(Without GST)</th><th>Landed Unit Price<br/>(With GST)</th><th>Amount<br/>(Without GST)</th><th>Amount<br/>(Without GST)</th><th class='hidden'>Description</th></tr></thead>");
                // alert(data[0].VendorRemarks)
                $('#txtvendorremarks').val(data[0].VendorRemarks);
                for (var i = 0; i < data.length; i++) {
                    description = stringDivider(data[i].RFQDescription, 40, "<br/>\n");
                    var detailsdesc = (data[i].RFQDescription).replace(/(\r\n|\n|\r)/gm, "");
                    detailsdesc = detailsdesc.replace(/'/g, '');
                    $('#wrap_scrollerPrev').show();
                   // alert(data[i].RFQVendorPricewithTax)
                    //if (data[i].RFQVendorPricewithTax > 0 && data[i].RFQVendorPrice > 0) {
                    totalammwithoutGST = totalammwithoutGST + (data[i].RFQPriceWithoutGST * data[i].RFQuantity);
                    totalammwithGST = totalammwithGST + (data[i].RFQVendorPricewithTax * data[i].RFQuantity);
                    jQuery('<tr id=trid' + i + '><td class=hidden>' + data[i].RFQParameterId + '</td><td class=hidden>' + data[i].RFQID + '</td><td><a href="#responsiveDescModal" data-toggle="modal" onClick="showDetailedDescription(\'' + detailsdesc + '\')" >' + data[i].RFQShortName + '</a></td><td>' + data[i].RFQUomId + '</td><td>' + thousands_separators(data[i].RFQuantity) + '</td><td class="fit hide">' + data[i].TAT + '</td><td class="fit hide">' + $('#txtcurrency').val() + '</td><td class=hide>' + data[i].RFQDelivery + '</td><td class="text-right">' + thousands_separators(data[i].RFQPriceWithoutGST) + '</td><td class="text-right">' + thousands_separators(data[i].RFQVendorPricewithTax) + '</td><td class="text-right">' + thousands_separators((data[i].RFQPriceWithoutGST * data[i].RFQuantity).round(2)) + '</td><td class="text-right">' + thousands_separators((data[i].RFQVendorPricewithTax * data[i].RFQuantity).round(2)) + '</td><td class="hidden">' + description + '</td><td class="hidden">' + data[i].RFQRemark + '</td></tr>').appendTo("#tblRFQPrev");

                   // }
                    //else {
                      //  $('#wrap_scrollerPrev').hide();
                      //  jQuery('<tr id=trid' + i + '><td class=hidden>' + data[i].RFQParameterId + '</td><td class=hidden>' + data[i].RFQID + '</td><td><a href="#responsiveDescModal" data-toggle="modal" onClick="showDetailedDescription(\'' + detailsdesc + '\')" >' + data[i].RFQShortName + '</a></td><td>' + data[i].RFQUomId + '</td><td>' + thousands_separators(data[i].RFQuantity) + '</td><td class=fit>' + data[i].TAT + '</td><td class=fit>' + $('#txtcurrency').val() + '</td><td>' + data[i].RFQDelivery + '</td><td><label class="control-label text-right" >' + thousands_separators(data[i].RFQPriceWithoutGST) + '</label></td><td><label class="control-label text-right" >' + thousands_separators(data[i].RFQVendorPricewithTax) + '</label></td><td class="hidden">' + description + '</td><td class="hidden">' + data[i].RFQRemark + '</td></tr>').appendTo("#tblRFQPrev");

                   // }

                   
                }
                jQuery('<tr><td colspan=5><b>Total</b></td><td class="text-right">' + thousands_separators(totalammwithoutGST) + '</td><td class="text-right">' + thousands_separators(totalammwithGST) + '</td></tr>').appendTo("#tblRFQPrev");
            }


        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else {
                alert('error')
            }
            return false;
            jQuery.unblockUI();
        }
    });
}

function showDetailedDescription(descText) {
    //alert(descText)
    $("#paraItemDescription").html(descText);
}



setTimeout(function () { sessionStorage.removeItem('selectedboqtxtboxid') }, 5000);
sessionStorage.removeItem('selectedboqtxtboxidTax');



