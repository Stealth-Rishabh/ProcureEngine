﻿var BidTypeID = 0;
var BidForID = 0;
var Duration = '0.00';

var error1 = $('.alert-danger');
var success1 = $('.alert-success');


function fetchVendorDetails() {
    var url = '';
    if (sessionStorage.getItem("ContactEmailID") == 'null' || sessionStorage.getItem("ContactEmailID") == '') {
        url = sessionStorage.getItem("APIPath") + "VendorParticipation/FetchBidDetails/?BidID=" + sessionStorage.getItem("BidID") + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("UserID"));
    } else {
        url = sessionStorage.getItem("APIPath") + "VendorParticipation/FetchBidDetails/?BidID=" + sessionStorage.getItem("BidID") + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("BidUserID"));
    }
    
    var tncAttachment = '';
    var anyotherAttachment = '';	

    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: url,
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {

            if (data.length > 0) {
                tncAttachment = data[0].TermsConditions.replace(/\s/g, "%20");
                anyotherAttachment = data[0].Attachment.replace(/\s/g, "%20");

                jQuery("label#lblitem1").text(data[0].BidFor);
                jQuery("#lblbidsubject").text(data[0].BidSubject);
                jQuery("#lblbidDetails").text(data[0].BidDetails);
                jQuery("#lblbiddate").text(data[0].BidDate);
                jQuery("#lblbidtime").text(data[0].BidTime);

                jQuery("a#lnkTermsAttachment").text(data[0].TermsConditions);
                jQuery("a#lnkTermsAttachment").attr("href", "PortalDocs/Bid/" + sessionStorage.getItem("BidID") + "/" + tncAttachment)

                jQuery("a#lnkAnyOtherAttachment").text(data[0].Attachment);
                jQuery("a#lnkAnyOtherAttachment").attr("href", "PortalDocs/Bid/" + sessionStorage.getItem("BidID") + "/" + anyotherAttachment)

                jQuery("#lblwarehousearea").text(data[0].WareHouseArea);

                jQuery("#lblbidduration").text(data[0].BidDuration);
                jQuery("#lblcurrency").text(data[0].CurrencyName);
                jQuery("#lblConvRate").text(data[0].ConversionRate);
                jQuery("#lblstatus").text(data[0].ConversionRate);
                jQuery("#lblConvRate").text(data[0].ConversionRate);


                BidTypeID = data[0].BidTypeID;
                BidForID = data[0].BidForID;
                fetchBidSummaryVendorproduct()
				
                display = document.querySelector('#lblTimeLeft');
                startTimer((parseInt(data[0].TimeLeft)), display);
               
              
            }
        },
        error: function (xhr) {
            jQuery("#error").text(xhr.d);
        }
    });

}
var count ;
function fetchBidSummaryVendorproduct() {
   
    var url = '';
    count = 0;
   // alert(sessionStorage.getItem("APIPath") + "VendorParticipation/BidSummaryProductService/?VendorID=" + sessionStorage.getItem("BidUserID") + "&BidID=" + sessionStorage.getItem("BidID") + "&UserType=" + sessionStorage.getItem("UserType") + "&AthenticationToken=''")
   
    if (sessionStorage.getItem("ContactEmailID") == 'null' || sessionStorage.getItem("ContactEmailID") == '') {
        
        url = sessionStorage.getItem("APIPath") + "VendorParticipation/BidSummaryProductService/?VendorID=" + encodeURIComponent(sessionStorage.getItem("UserID")) + "&BidID=" + sessionStorage.getItem("BidID") + "&UserType=" + sessionStorage.getItem("UserType") + "&AthenticationToken=''";
    } else {
        url = sessionStorage.getItem("APIPath") + "VendorParticipation/BidSummaryProductService/?VendorID=" + encodeURIComponent(sessionStorage.getItem("BidUserID")) + "&BidID=" + sessionStorage.getItem("BidID") + "&UserType=" + sessionStorage.getItem("UserType") + "&AthenticationToken=''";
    }

    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: url,
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function(data, status, jqXHR) {

            jQuery("#tblParticipantsService").empty()
            if (data.length > 0) {
                if (sessionStorage.getItem('CustomerID') == 20) {
                    jQuery("#tblParticipantsService").append("<thead> <tr style='background: gray; color: #FFF'><th>Short Name</th><th>Quantity</th><th>Minimum Decrement</th><th>UOM</th><th>Initial Quote</th><th>Last Quote</th><th> Status (L1/ Not L1)</th><th>Quote</th><th>Action</th></thead>");
                } else {
                    jQuery("#tblParticipantsService").append("<thead> <tr style='background: gray; color: #FFF'><th>Short Name</th><th>Quantity</th><th>UOM</th><th>Initial Quote</th><th>Last Quote</th><th> Status (L1/ Not L1)</th><th>Quote</th><th>Action</th></thead>");
                }
                for (var i = 0; i < data.length; i++) {

                    var IQuote = data[i].IQQuotedPrice == '0' ? '' : data[i].IQQuotedPrice;
                    var LqQuote = data[i].LQQuotedPrice == '0' ? '' : data[i].LQQuotedPrice;
                    if (sessionStorage.getItem('CustomerID') == 20) {
                        jQuery("#tblParticipantsService").append("<tr><td class=hide id=ceilingprice" + i + ">" + data[i].CeilingPrice + "</td><td class=hide id=decon" + i + ">" + data[i].DecreamentOn + "</td><td class=hide id=psid" + i + ">" + data[i].PSID + "</td><td class=hide id=psheaderid" + i + ">" + data[i].PSHeaderID + "</td><td>" + data[i].ShortName + "</td><td>" + data[i].Quantity + "</td><td id=minimumdec" + i + ">" + data[i].MinimumDecreament + "</td><td>" + data[i].UOM + "</td><td id=iqquote" + i + ">" + IQuote + "</td><td id=lastQuote" + i + ">" + LqQuote + "</td><td><label class=control-label id=lblstatus" + i + ">" + data[i].LOQuotedPrice + "</label></td><td> <input type=text class=form-control autocomplete=off  id=txtquote" + i + " name=txtquote" + i + " /> <span id=spanamount" + i + "   style=color:#a94442></span></td><td id=psid" + i + " class='display-none'>" + data[i].PSID + "</td><td><button id='btnsubmit' type='button' class='btn yellow col-lg-offset-5' onclick='InsUpdQuoteServiceProduct(" + i + ")'>Submit</button></td></tr>");
                    } else {
                        jQuery("#tblParticipantsService").append("<tr><td class=hide id=ceilingprice" + i + ">" + data[i].CeilingPrice + "</td><td class=hide id=minimumdec" + i + ">" + data[i].MinimumDecreament + "</td><td class=hide id=decon" + i + ">" + data[i].DecreamentOn + "</td><td class=hide id=psid" + i + ">" + data[i].PSID + "</td><td class=hide id=psheaderid" + i + ">" + data[i].PSHeaderID + "</td><td>" + data[i].ShortName + "</td><td>" + data[i].Quantity + "</td><td>" + data[i].UOM + "</td><td id=iqquote" + i + ">" + IQuote + "</td><td id=lastQuote" + i + ">" + LqQuote + "</td><td><label class=control-label id=lblstatus" + i + ">" + data[i].LOQuotedPrice + "</label></td><td> <input type=text class=form-control autocomplete=off  id=txtquote" + i + " name=txtquote" + i + " /> <span id=spanamount" + i + "   style=color:#a94442></span></td><td id=psid" + i + " class='display-none'>" + data[i].PSID + "</td><td><button id='btnsubmit' type='button' class='btn yellow col-lg-offset-5' onclick='InsUpdQuoteServiceProduct(" + i + ")'>Submit</button></td></tr>");
                    }
                    $('#spanamount' + i).addClass('hide spanclass');
                    $('#txtquote' + i).val(data[i].LQQuotedPrice);
                    //sessionStorage.setItem("PSHeaderID" + i, data[i].PSHeaderID)
                    if (data[i].LOQuotedPrice == 'L1') {
                        jQuery('#lblstatus' + i).css('color', 'Blue');
                    }
                    else {

                        jQuery('#lblstatus' + i).css('color', 'Red');
                    }
                    count = count + 1;
                }
            }
            else {
                jQuery("#tblParticipantsService").append("<tr><td>Nothing Participation</td></tr>")
            }


        }
    })

}
$(document).on("keyup", ".form-control", function () {
    var txt = this.id
    $('#' + txt).next(':first').addClass('hide');

});
function refreshColumnsStaus() {
    clearInterval(mytime)
    var url = '';   
    if (sessionStorage.getItem("ContactEmailID") == 'null' || sessionStorage.getItem("ContactEmailID") == '') {
        url = sessionStorage.getItem("APIPath") + "VendorParticipation/BidSummaryProductService/?VendorID=" + encodeURIComponent(sessionStorage.getItem("UserID")) + "&BidID=" + sessionStorage.getItem("BidID") + "&UserType=" + sessionStorage.getItem("UserType") + "&AthenticationToken=''";
    } else {
        url = sessionStorage.getItem("APIPath") + "VendorParticipation/BidSummaryProductService/?VendorID=" + encodeURIComponent(sessionStorage.getItem("BidUserID")) + "&BidID=" + sessionStorage.getItem("BidID") + "&UserType=" + sessionStorage.getItem("UserType") + "&AthenticationToken=''";
    }
    
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: url,
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {

        if (data.length > 0) {
            $('#hdnnoofextension').val(data[0].NoOfExtension)
                for (var i = 0; i < data.length; i++) {
                    
                    if (data[i].NoOfExtension >= 1) {
                        
                        jQuery('#lblTimeLeft').css('color', 'red');
						jQuery('#lblTimeLeftTxt').removeClass('display-none');
						jQuery('#lblTimeLeftTxt').html('<b>Bid Time Extended.</b>').css('color', 'red')
                    }
                    else {
						jQuery('#lblTimeLeftTxt').addClass('display-none');
                        jQuery('#lblTimeLeft').css('color', '');
                    }
                   
                    $("#iqquote" + i).html(data[i].IQQuotedPrice == '0' ? '' : data[i].IQQuotedPrice)
                    $("#lastQuote" + i).html(data[i].LQQuotedPrice == '0' ? '' : data[i].LQQuotedPrice)
                    $("#lblstatus" + i).html(data[i].LOQuotedPrice)

                    if (data[i].LOQuotedPrice == 'L1') {
                        jQuery('#lblstatus' + i).css('color', 'Blue');
                    }
                    else {

                        jQuery('#lblstatus' + i).css('color', 'Red');

                    }
                  
                  
                    display = document.querySelector('#lblTimeLeft');
                    startTimer(data[i].TimeLeft, display);
                    
				}
            }
            
        }
    });

}

var mytime = 0;

function startTimer(duration, display) {
 
    clearInterval(mytime)
   // var timer = 0, hours = 0, minutes = 0, seconds = 0;
    //timer = duration;
  
    var timer = duration, hours, minutes, seconds;
    mytime=  setInterval(function () {
        hours = parseInt(timer / 3600, 10)
        minutes = parseInt(timer / 60, 10) - (hours * 60)
        seconds = parseInt(timer % 60, 10);

        hours = hours < 10 ? "0" + hours : hours;
        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;

        if (hours > 0) {
            display.textContent = hours + ":" + minutes + ":" + seconds;
        }
        else {
            display.textContent = minutes + ":" + seconds;
        }
        if ((seconds.toString().substring(1, 2) == '0') || (seconds.toString().substring(1, 2) == '5')) {

            refreshColumnsStaus()

        }
       
        if (--timer < 0) {
            timer = 0;
            closeBidAir();
        }
        $('#hdnval').val(timer)
     
    }, 1000);
   
}
//function InsUpdQuoteServiceProduct() {
//	var vendorID = 0;
//    if (sessionStorage.getItem('ContactEmailID') == 'null' || sessionStorage.getItem('ContactEmailID') == '') {
//        vendorID = sessionStorage.getItem('UserID');
//    }
//    else {
//        vendorID =sessionStorage.getItem('BidUserID');
//    }
// 
//    var insertquery = '';
//    var value = 0;
//    var v = 0;
//    for (var i = 0; i < count; i++) {

//        var Amount = $('#minimumdec' + i).text()
//        if ($('#decon' + i).text() == "A") {
//            if (jQuery("#lastQuote" + i).text() == '') {
//                value = parseFloat($('#txtquote' + i).val())

//            }
//            else {
//                value = parseFloat(jQuery("#lastQuote" + i).text()) - parseFloat($('#txtquote' + i).val())
//            }

//        }
//        else {
//            if (jQuery("#lastQuote" + i).text() == '') {
//                value = (parseFloat(Amount) / 100) * (parseFloat(jQuery("#txtquote" + i).val()));
//                v = parseFloat($('#txtquote' + i).val())
//            }
//            else {
//                value = (parseFloat(Amount) / 100) * (parseFloat(jQuery("#lastQuote" + i).text()));
//                v = parseFloat(jQuery("#lastQuote" + i).text()) - parseFloat($('#txtquote' + i).val());
//            }
//        }

//        if (($('#txtquote' + i).val() == 0) || (!/^[0-9]+(\.[0-9]{1,2})?$/.test($('#txtquote' + i).val()))) {
//            $('#spanamount' + i).removeClass('hide')
//            $('#spanamount' + i).text('Amount is required in number only')
//            return false
//        }

//        else if (parseFloat($('#ceilingprice' + i).text()) < parseFloat($('#txtquote' + i).val())) {
//            $('#spanamount' + i).removeClass('hide')
//            $('#spanamount' + i).text('Amount should be less than Bid start price')
//            return false
//        }
//        else if (value < parseFloat(Amount) && $('#decon' + i).text() == "A" && value != 0) {

//            $('#spanamount' + i).removeClass('hide')
//            // $('#spanamount' + i).text('Amount should be less than last Quote or Minimum decrement is ' + Amount)
//            $('#spanamount' + i).text('Amount should be less than minimum decrement value ')
//            return false
//        }

//        else if (v < value && $('#decon' + i).text() == "P") {
//            $('#spanamount' + i).removeClass('hide')
//            // $('#spanamount' + i).text('Amount should be less than last Quote or Minimum decrement is ' + Amount + ' %')
//            $('#spanamount' + i).text('Amount should be less than minimum decrement value is' + Amount + ' %')
//            return false
//        }
//        else {
//           
//            if (i == 0) {
//                
//                insertquery = insertquery + 'insert into VendorPSParticipationDetails(PSHeaderID,VendorID,QuotedPrice,PSID,SubmissionTime)'
//                insertquery = insertquery + " select " + $('#psheaderid' + i).html() + ",dbo.Decrypt('" + vendorID + "')," + $('#txtquote' + i).val() + "," + $('#psid' + i).html() + ",getdate() union";
//                
//            }
//            else {
//                insertquery = insertquery + " select " + $('#psheaderid' + i).html() + ",dbo.Decrypt('" + vendorID + "')," + $('#txtquote' + i).val() + "," + $('#psid' + i).html() + ",getdate() union";

//            }
//            
//        }
//    }
//    
//    insertquery = insertquery.substring(0, insertquery.length - 6);
//    var vendorID = 0;
//    if (sessionStorage.getItem('ContactEmailID') == 'null' || sessionStorage.getItem('ContactEmailID') == '') {
//        vendorID = sessionStorage.getItem('UserID');
//    }
//    else {
//        vendorID = sessionStorage.getItem('BidUserID');
//    }
//   
//    if ($('#hdnval').val() >= 60) {
//        var QuoteProduct = {
//            "VendorID": vendorID,
//            "BidID": sessionStorage.getItem("BidID"),
//            "insertQuery": insertquery,
//            "EnteredBy": vendorID

//        }
//       // alert(JSON.stringify(QuoteProduct))
//        jQuery.ajax({
//            url: sessionStorage.getItem("APIPath") + "VendorParticipation/ParticipationProductServices/",
//            type: "POST",
//            data: JSON.stringify(QuoteProduct),
//            contentType: "application/json; charset=utf-8",
//            success: function (data, status, jqXHR) {
//                //resetSessions(count);
//                fetchVendorDetails();

//            },
//            error: function (xhr) {
//                jQuery("#error").text(xhr.d);
//            }
//        });
//    }
//    else {
//        var QuoteProduct = {
//            "VendorID": vendorID,
//            "BidID": sessionStorage.getItem("BidID"),
//            "insertQuery": insertquery,
//            "EnteredBy": vendorID

//        }
//        //alert(JSON.stringify(QuoteProduct))
//        jQuery.ajax({
//            url: sessionStorage.getItem("APIPath") + "VendorParticipation/ParticipationProductServices/",
//            type: "POST",
//            data: JSON.stringify(QuoteProduct),
//            contentType: "application/json; charset=utf-8",
//            success: function (data, status, jqXHR) {
//                //resetSessions(count);
//            fetchVendorDetails();
//            refreshColumnsStaus();

//            },
//            error: function (xhr) {
//                jQuery("#error").text(xhr.d);
//            }
//        });
//       
//       // if ($('#hdnnoofextension').val() < 2) {
//            var data = {
//                "BidID": sessionStorage.getItem("BidID")

//            }
//            //alert(JSON.stringify(data))
//            jQuery.ajax({
//                url: sessionStorage.getItem("APIPath") + "VendorParticipation/ExtendDuration/",
//                type: "POST",
//                data: JSON.stringify(data),
//                contentType: "application/json; charset=utf-8",
//                success: function (data, status, jqXHR) {
//                   // display = document.querySelector('#lblTimeLeft');
//                   // startTimer((parseInt(data[0].TimeLeft)), display);
//                    //fetchVendorDetails()
//                    return true
//                },
//                error: function (xhr) {
//                    jQuery("#error").text(xhr.d);
//                }
//            });
//        }
//   // }

//}
function InsUpdQuoteServiceProduct(rowID) {
    var vendorID = 0;
    var i = rowID;
    if (sessionStorage.getItem('ContactEmailID') == 'null' || sessionStorage.getItem('ContactEmailID') == '') {
        vendorID = sessionStorage.getItem('UserID');
    }
    else {
        vendorID = sessionStorage.getItem('BidUserID');
    }
    
    
    var value = 0;
    var v = 0;
//    for (var i = 0; i < count; i++) {

        var Amount = $('#minimumdec' + i).text()
        if ($('#decon' + i).text() == "A") {
            if (jQuery("#lastQuote" + i).text() == '') {
                value = parseFloat($('#txtquote' + i).val())

            }
            else {
                value = parseFloat(jQuery("#lastQuote" + i).text()) - parseFloat($('#txtquote' + i).val())
            }

        }
        else {
            if (jQuery("#lastQuote" + i).text() == '') {
                value = (parseFloat(Amount) / 100) * (parseFloat(jQuery("#txtquote" + i).val()));
                v = parseFloat($('#txtquote' + i).val())
            }
            else {
                value = (parseFloat(Amount) / 100) * (parseFloat(jQuery("#lastQuote" + i).text()));
                v = parseFloat(jQuery("#lastQuote" + i).text()) - parseFloat($('#txtquote' + i).val());
            }
        }

        if (($('#txtquote' + i).val() == 0) || (!/^[0-9]+(\.[0-9]{1,2})?$/.test($('#txtquote' + i).val()))) {
            $('#spanamount' + i).removeClass('hide')
            $('#spanamount' + i).text('Amount is required in number only')
            return false
        }

        else if (parseFloat($('#ceilingprice' + i).text()) < parseFloat($('#txtquote' + i).val())) {
            $('#spanamount' + i).removeClass('hide')
            $('#spanamount' + i).text('Amount should be less than Bid start price')
            return false
        }
        else if (value < parseFloat(Amount) && $('#decon' + i).text() == "A" && value != 0) {

            $('#spanamount' + i).removeClass('hide')
            // $('#spanamount' + i).text('Amount should be less than last Quote or Minimum decrement is ' + Amount)
            $('#spanamount' + i).text('Amount should be less than minimum decrement value ')
            return false
        }

        else if (v < value && $('#decon' + i).text() == "P") {
            $('#spanamount' + i).removeClass('hide')
            // $('#spanamount' + i).text('Amount should be less than last Quote or Minimum decrement is ' + Amount + ' %')
            $('#spanamount' + i).text('Amount should be less than minimum decrement value is' + Amount + ' %')
            return false
        }
        else {

            var vendorID = 0;
            if (sessionStorage.getItem('ContactEmailID') == 'null' || sessionStorage.getItem('ContactEmailID') == '') {
                vendorID = sessionStorage.getItem('UserID');
            }
            else {
                vendorID = sessionStorage.getItem('BidUserID');
            }

            if ($('#hdnval').val() >= 60) {
                var QuoteProduct = {
                    "VendorID": vendorID,
                    "BidID": sessionStorage.getItem("BidID"),
                    "PSHeaderID": $('#psheaderid' + i).html(),
                    "QuotedPrice": $('#txtquote' + i).val(),
                    "PSID": $('#psid' + i).html(),
                    "EnteredBy": vendorID

                }
                 //alert(JSON.stringify(QuoteProduct))
                 jQuery.ajax({
                     url: sessionStorage.getItem("APIPath") + "VendorParticipation/ParticipationProductServicesSingleItem/",
                     type: "POST",
                     data: JSON.stringify(QuoteProduct),
                     contentType: "application/json; charset=utf-8",
                     success: function(data, status, jqXHR) {
                        // alert(data[0].insertQuery)
                         if (data[0].insertQuery == "1") {
                             fetchVendorDetails();
                         }
                         else if (data[0].insertQuery == "-1") {
                             $('#spanamount' + i).removeClass("hide");
                             $('#spanamount' + i).text("Someone already quoted this price. Please Quote another price.")
                         }


                     },
                     error: function(xhr) {
                         jQuery("#error").text(xhr.d);
                     }
                 });
            }
            else {
                
                
                var QuoteProduct = {
                    "VendorID": vendorID,
                    "BidID": sessionStorage.getItem("BidID"),
                    "PSHeaderID": $('#psheaderid' + i).html(),
                    "QuotedPrice": $('#txtquote' + i).val(),
                    "PSID": $('#psid' + i).html(),
                    "EnteredBy": vendorID

                }
                //alert(JSON.stringify(QuoteProduct))
                jQuery.ajax({
                    url: sessionStorage.getItem("APIPath") + "VendorParticipation/ParticipationProductServicesSingleItem/",
                    type: "POST",
                    data: JSON.stringify(QuoteProduct),
                    contentType: "application/json; charset=utf-8",
                    success: function(data, status, jqXHR) {
                        if (data[0].insertQuery == "1") {
                            fetchVendorDetails();
                            refreshColumnsStaus();
                        }
                        else if (data[0].insertQuery == "-1") {
                            $('#spanamount' + i).text("Someone already quoted this price. Please Quote another price.")
                        }


                    },
                    error: function(xhr) {
                        jQuery("#error").text(xhr.d);
                    }
                });
                if (sessionStorage.getItem('CustomerID') == 20) {
                    if ($('#hdnnoofextension').val() < 3) {
                        var data = {
                            "BidID": sessionStorage.getItem("BidID")

                        }
                        //alert(JSON.stringify(data))
                        jQuery.ajax({
                            url: sessionStorage.getItem("APIPath") + "VendorParticipation/ExtendDuration/",
                            type: "POST",
                            data: JSON.stringify(data),
                            contentType: "application/json; charset=utf-8",
                            success: function(data, status, jqXHR) {

                                return true
                            },
                            error: function(xhr) {
                                jQuery("#error").text(xhr.d);
                            }
                        });
                    }
                    else {
                        bootbox.alert("Bid time can not be extended more than 3 times.", function() {
                            return false;

                        });
                    } // nof extension Check else ends

                } else {
                        var data = {
                            "BidID": sessionStorage.getItem("BidID")

                        }
                        //alert(JSON.stringify(data))
                        jQuery.ajax({
                            url: sessionStorage.getItem("APIPath") + "VendorParticipation/ExtendDuration/",
                            type: "POST",
                            data: JSON.stringify(data),
                            contentType: "application/json; charset=utf-8",
                            success: function(data, status, jqXHR) {

                                return true
                            },
                            error: function(xhr) {
                                jQuery("#error").text(xhr.d);
                            }
                        }); 
                }// customer ID else ends here
            } //$('#hdnval').val() >= 60) else Ends here

          }
//    }

   
    
    // }

}
//function resetSessions(c) {
//    count = 0;
//    for (var i = 0; i < c; i++) {
//        sessionStorage.removeItem("PSHeaderID" + i)
//    }
//}

function closeBidAir() {
    clearInterval(mytime)
    jQuery.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "VendorParticipation/CloseBid/?BidID=" + sessionStorage.getItem("BidID"),
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
            bootbox.alert("Bid time has been over. Thanks for Participation.", function () {
            window.location = sessionStorage.getItem('MainUrl');
                return false;
                
            });
        }
    });
}