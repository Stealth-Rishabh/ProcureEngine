﻿var BidTypeID = 0;
var BidForID = 0;
var Duration = '0.00';

var error1 = $('.alert-danger');
var success1 = $('.alert-success');


function fetchVendorDetails() {
    var url = '';
    //if (sessionStorage.getItem("ContactEmailID") == 'null' || sessionStorage.getItem("ContactEmailID") == '') {
        url = sessionStorage.getItem("APIPath") + "VendorParticipation/FetchBidDetailsForVendorMain/?BidID=" + sessionStorage.getItem("hdnselectedBidSubjID") + "&VendorID=" + encodeURIComponent($('#ddlinvitedVendors option:selected').val());
    //} else {
   //     url = sessionStorage.getItem("APIPath") + "VendorParticipation/FetchBidDetails/?BidID=" + sessionStorage.getItem("BidID") + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("BidUserID"));
    //}
    
    var tncAttachment = '';
    var anyotherAttachment = '';	

    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: url,
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {

            if (data.length > 0) {
                tncAttachment = data[0].TermsConditions.replace(/\s/g, "%20");
                anyotherAttachment = data[0].Attachment.replace(/\s/g, "%20");

                jQuery("label#lblitem1").text(data[0].BidFor);
                jQuery("#lblbidsubject").text(data[0].BidSubject);
                jQuery("#lblbidDetails").text(data[0].BidDetails);
                jQuery("#lblbiddate").text(data[0].BidDate);
                jQuery("#lblbidtime").text(data[0].BidTime);

                jQuery("a#lnkTermsAttachment").text(data[0].TermsConditions);
                jQuery("a#lnkTermsAttachment").attr("href", "PortalDocs/Bid/" + sessionStorage.getItem("BidID") + "/" + tncAttachment)

                jQuery("a#lnkAnyOtherAttachment").text(data[0].Attachment);
                jQuery("a#lnkAnyOtherAttachment").attr("href", "PortalDocs/Bid/" + sessionStorage.getItem("BidID") + "/" + anyotherAttachment)

                jQuery("#lblwarehousearea").text(data[0].WareHouseArea);

                jQuery("#lblbidduration").text(data[0].BidDuration);
                jQuery("#lblcurrency").text(data[0].CurrencyName);
                jQuery("#lblConvRate").text(data[0].ConversionRate);
                jQuery("#lblstatus").text(data[0].ConversionRate);
                jQuery("#lblConvRate").text(data[0].ConversionRate);


                BidTypeID = data[0].BidTypeID;
                BidForID = data[0].BidForID;
                fetchBidSummaryVendorproduct()
				
                
                
              
            }
        },
        error: function (xhr) {
            jQuery("#error").text(xhr.d);
        }
    });

}
var count ;
function fetchBidSummaryVendorproduct() {
   
    var url = '';
    count = 0;
   
   
   // if (sessionStorage.getItem("ContactEmailID") == 'null' || sessionStorage.getItem("ContactEmailID") == '') {
    url = sessionStorage.getItem("APIPath") + "VendorParticipation/BidSummaryProductService/?VendorID=" + encodeURIComponent(sessionStorage.getItem("VendorId")) + "&BidID=" + sessionStorage.getItem("hdnselectedBidSubjID") + "&UserType=" + sessionStorage.getItem('UserType') + "&AthenticationToken=''";
   // } else {
   //     url = sessionStorage.getItem("APIPath") + "VendorParticipation/BidSummaryProductService/?VendorID=" + encodeURIComponent(sessionStorage.getItem("BidUserID")) + "&BidID=" + sessionStorage.getItem("BidID") + "&UserType=" + sessionStorage.getItem("UserType") + "&AthenticationToken=''";
   // }
    
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: url,
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {

            jQuery("#tblParticipantsService").empty()
            if (data.length > 0) {
                jQuery("#tblParticipantsService").append("<thead> <tr style='background: gray; color: #FFF'><th>Short Name</th><th>Quantity</th><th>UOM</th><th>Initial Quote</th><th>Last Quote</th><th>Quote</th></thead>");
                for (var i = 0; i < data.length; i++) {

                    var IQuote = data[i].IQQuotedPrice == '0' ? '' : data[i].IQQuotedPrice;
                    var LqQuote = data[i].LQQuotedPrice == '0' ? '' : data[i].LQQuotedPrice;
                    jQuery("#tblParticipantsService").append("<tr><td class=hide id=ceilingprice" + i + ">" + data[i].CeilingPrice + "</td><td class=hide id=minimumdec" + i + ">" + data[i].MinimumDecreament + "</td><td class=hide id=decon" + i + ">" + data[i].DecreamentOn + "</td><td class=hide id=psid" + i + ">" + data[i].PSID + "</td><td class=hide id=psheaderid" + i + ">" + data[i].PSHeaderID + "</td><td>" + data[i].ShortName + "</td><td>" + data[i].Quantity + "</td><td>" + data[i].UOM + "</td><td id=iqquote" + i + ">" + IQuote + "</td><td id=lastQuote" + i + ">" + LqQuote + "</td><td> <input type=text class=form-control autocomplete=off  id=txtquote" + i + " name=txtquote" + i + " /> <span id=spanamount" + i + "   style=color:#a94442></span></td><td id=psid" + i + " class='display-none'>" + data[i].PSID + "</td></tr>");

                    $('#spanamount' + i).addClass('hide spanclass');
                    $('#txtquote' + i).val(data[i].LQQuotedPrice);
                    
                    count = count + 1;
                }
            }
            else {
                jQuery("#tblParticipantsService").append("<tr><td>Nothing Participation</td></tr>")
            }


        }
    })

}
$(document).on("keyup", ".form-control", function () {
    var txt = this.id
    $('#' + txt).next(':first').addClass('hide');

});


function InsUpdQuoteServiceProduct() {
    var vendorID = 0;    
    vendorID = sessionStorage.getItem('VendorId');
   

    var insertquery = '';
    var value = 0;
    var v = 0;
    for (var i = 0; i < count; i++) {

        var Amount = $('#minimumdec' + i).text()
        if ($('#decon' + i).text() == "A") {
            if (jQuery("#lastQuote" + i).text() == '') {
                value = parseFloat($('#txtquote' + i).val())

            }
            else {
                value = parseFloat(jQuery("#lastQuote" + i).text()) - parseFloat($('#txtquote' + i).val())
            }

        }
        else {
            if (jQuery("#lastQuote" + i).text() == '') {
                value = (parseFloat(Amount) / 100) * (parseFloat(jQuery("#txtquote" + i).val()));
                v = parseFloat($('#txtquote' + i).val())
            }
            else {
                value = (parseFloat(Amount) / 100) * (parseFloat(jQuery("#lastQuote" + i).text()));
                v = parseFloat(jQuery("#lastQuote" + i).text()) - parseFloat($('#txtquote' + i).val());
            }
        }

        if (($('#txtquote' + i).val() == 0) || (!/^[0-9]+(\.[0-9]{1,2})?$/.test($('#txtquote' + i).val()))) {
            $('#spanamount' + i).removeClass('hide')
            $('#spanamount' + i).text('Amount is required in number only')
            return false
        }

        else if (parseFloat($('#ceilingprice' + i).text()) < parseFloat($('#txtquote' + i).val())) {
            $('#spanamount' + i).removeClass('hide')
            $('#spanamount' + i).text('Amount should be less than Bid start price')
            return false
        }
        else if (value < parseFloat(Amount) && $('#decon' + i).text() == "A" && value != 0) {

            $('#spanamount' + i).removeClass('hide')
            // $('#spanamount' + i).text('Amount should be less than last Quote or Minimum decrement is ' + Amount)
            $('#spanamount' + i).text('Amount should be less than minimum decrement value ')
            return false
        }

        else if (v < value && $('#decon' + i).text() == "P") {
            $('#spanamount' + i).removeClass('hide')
            // $('#spanamount' + i).text('Amount should be less than last Quote or Minimum decrement is ' + Amount + ' %')
            $('#spanamount' + i).text('Amount should be less than minimum decrement value is' + Amount + ' %')
            return false
        }
        else {

            if (i == 0) {

                insertquery = insertquery + 'insert into VendorPSParticipationDetails(PSHeaderID,VendorID,QuotedPrice,PSID,SubmissionTime)'
                insertquery = insertquery + " select " + $('#psheaderid' + i).html() + ",dbo.Decrypt('" + vendorID + "')," + $('#txtquote' + i).val() + "," + $('#psid' + i).html() + ",getdate() union";

            }
            else {
                insertquery = insertquery + " select " + $('#psheaderid' + i).html() + ",dbo.Decrypt('" + vendorID + "')," + $('#txtquote' + i).val() + "," + $('#psid' + i).html() + ",getdate() union";

            }

        }
    }

    insertquery = insertquery.substring(0, insertquery.length - 6);
    
    var QuoteProduct = {
        "VendorID": vendorID,
        "BidID": sessionStorage.getItem("hdnselectedBidSubjID"),
        "insertQuery": insertquery,
        "EnteredBy": sessionStorage.getItem("UserID")

    }
    //alert(JSON.stringify(QuoteProduct))
    jQuery.ajax({
        url: sessionStorage.getItem("APIPath") + "VendorParticipation/ParticipationProductServices/",
        type: "POST",
        data: JSON.stringify(QuoteProduct),
        contentType: "application/json; charset=utf-8",
        success: function(data, status, jqXHR) {

            bootbox.alert("Transaction successful.", function() {
                window.location = sessionStorage.getItem("HomePage");
                return false;
            });

        },
        error: function(xhr) {
            jQuery("#error").text(xhr.d);
        }
    });
}

var form = $('#frm_remarks');
var error = $('.alert-success');
var success = $('.alert-danger');

function FormValidate() {
    form.validate({

        doNotHideMessage: true, //this option enables to show the error/success messages on tab switch.

        errorElement: 'span', //default input error message container

        errorClass: 'help-block help-block-error', // default input error message class

        focusInvalid: false, // do not focus the last invalid input

        rules: {

            txtremarks_mq: {

                required: true,
                maxlength: 100

            },
            file1: {

                required: true

            }


        },

        messages: {

    },



    invalidHandler: function(event, validator) {

    },

    highlight: function(element) {

        $(element).closest('.form-group').removeClass('has-success').addClass('has-error');

    },

    unhighlight: function(element) {

        $(element).closest('.form-group').removeClass('has-error');
    },

    success: function(label) {
    },
    submitHandler: function(form) {

        InsManualQuotesHisotry();
    }



});
    
}

function showreasonmq_modal(){
    $('#reasonmq_modal').modal('show');
}

function cancelmanualQuote() {
    window.location = sessionStorage.getItem('HomePage')
}


function InsManualQuotesHisotry() {

    var attachment = jQuery('#file1').val().substring(jQuery('#file1').val().lastIndexOf('\\') + 1);
    
    var mquotes = {
    
        "BidID": sessionStorage.getItem("hdnselectedBidSubjID"),
        "BidSubject": $.trim($('#lblbidsubject').html()),
        "CustomerID": sessionStorage.getItem('CustomerID'),
        "Remarks": $('#txtremarks_mq').val(),
        "Attachment": attachment,
        "BidtypeID": $.trim(BidTypeID),
        "ForVendorID": sessionStorage.getItem("VendorId"),
        "EnteredBy": sessionStorage.getItem("UserName")        

    }

    //alert(JSON.stringify(mquotes))

    jQuery.ajax({
    type: "POST",

    contentType: "application/json; charset=utf-8",

    url: sessionStorage.getItem("APIPath") + "VendorParticipation/InsManualQuotesHisotry/",

    crossDomain: true,

    async: false,

    data: JSON.stringify(mquotes),
        
    
        success: function(data, status, jqXHR) {
        //alert(data[0].Success)
        if (data[0].Success == '1') {
            
            fileUploader(sessionStorage.getItem("hdnselectedBidSubjID"))
                
            }else{
                bootbox.alert("Error Connecting server. Please try later.") ; 
            }
                

        },
        error: function(xhr) {
            jQuery("#error").text(xhr.d);
        }
    });
    
    
}


function fileUploader(bidID) {
    
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    
    var fileTerms = $('#file1');
    
    var fileDataTerms = fileTerms.prop("files")[0];

    var formData = new window.FormData();

    formData.append("fileTerms", fileDataTerms);

    formData.append("fileAnyOther", '');

    formData.append("AttachmentFor", 'ManualBids');

    formData.append("BidID", bidID);
    formData.append("VendorID", '');



    $.ajax({

        url: 'ConfigureFileAttachment.ashx',

        data: formData,

        processData: false,

        contentType: false,

        asyc: false,

        type: 'POST',

        success: function(data) {
        $('#reasonmq_modal').modal('hide');
        jQuery.unblockUI();
            InsUpdQuoteServiceProduct()
            
        },

        error: function() {

            bootbox.alert("Attachment error.");
            jQuery.unblockUI();
        }

    });

}