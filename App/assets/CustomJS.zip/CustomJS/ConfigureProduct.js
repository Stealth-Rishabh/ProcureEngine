﻿
function AddProduct() {
    var status = "";
    if (jQuery('#chkIsActive').is(':checked') == true) {
        status = 'Y';
    }
    else {
        status = 'N';
    }
    var AddProducts = {
        "ProductID": jQuery("#hiddenproductID").val(),
        "ProductName": jQuery("#txtProductName").val(),
        "IsActive": status,
        "UserID": sessionStorage.getItem('UserID')
    };
    jQuery.ajax({
        url: sessionStorage.getItem("APIPath") + "Product/AddProducts/",
        type: "POST",
        data: JSON.stringify(AddProducts),
        contentType: "application/json; charset=utf-8",
        success: function (data, status, jqXHR) {
            jQuery("#tblProduct > tbody").empty();
            if (data.length > 0) {
                jQuery.each(data, function (key, value) {
                    var str = "<tr><td style=\"display:none;\">" + value.ProductID + "</td><td>" + value.ProductName + "</td>";
                        str+="<td>" + value.isActive + "</td>";
                        str+="<td style=\"text-align:right\">";
                        str += "<a href=\"#\" href=\"#\"  onclick=\"EditProduct(this)\" class=\"btn default btn-xs purple\"><i class=\"fa fa-edit\"></i>Edit</a>&nbsp;&nbsp;";
                        str += "<a href=\"#\" onclick=\"DeleteProduct(this)\" class=\"btn default btn-xs black\"><i class=\"fa fa-trash-o\"></i>Delete</a>";
                        str+="</td></tr>";
                        jQuery('#tblProduct > tbody').append(str);
                });
            }
            else {
                jQuery('#tblProduct > tbody').append("<tr><td colspan='3' style='text-align: center; color:red;'>No product Added</td></tr>");
            }
        },
        error: function (xhr) {
            jQuery("#error").text(xhr.d);

        }
    });
}

function EditProduct(ctrl, ProductId) {
    jQuery(ctrl).parent().parent().hide();
    var ProductID = jQuery(ctrl).parent().parent().find("td").eq(0).html();
    var ProductName = jQuery(ctrl).parent().parent().find("td").eq(1).html();
    jQuery("#hiddenproductID").val(ProductID);
    jQuery("#txtProductName").val(ProductName);
}
//function DeleteProduct(ProductId) {
//    alert(ProductId);
//}
function clearForm() {
    jQuery("#hiddenproductID").val('0');
    jQuery("#txtProductName").val('');
}

jQuery("#txtSearch").keyup(function () {
    _this = this;
    // Show only matching TR, hide rest of them
    jQuery.each($("#tblProduct tbody").find("tr"), function () {
        console.log($(this).text());
        if (jQuery(this).text().toLowerCase().indexOf(jQuery(_this).val().toLowerCase()) == -1)
            jQuery(this).hide();
        else
            jQuery(this).show();
    });
});

////  validation parts ///////

var FormValidation = function () {
    var ValidateconfitureProduct = function () {
        var form1 = $('#entryForm');
        var error1 = $('.alert-danger', form1);
        var success1 = $('.alert-success', form1);

        form1.validate({
            errorElement: 'span', //default input error message container
            errorClass: 'help-block', // default input error message class
            focusInvalid: false, // do not focus the last invalid input
            ignore: "",
            rules: {
                txtProductName: {
                    required: true
                }
            },
            messages: {
                txtProductName: {
                    required: "Please enter product name"
                }
            },

            invalidHandler: function (event, validator) { //display error alert on form submit              
                success1.hide();
                error1.show();
                //App.scrollTo(error1, -200);
            },

            highlight: function (element) { // hightlight error inputs
                $(element)
                        .closest('.form-group').addClass('has-error'); // set error class to the control group
            },

            unhighlight: function (element) { // revert the change done by hightlight
                $(element)
                        .closest('.form-group').removeClass('has-error'); // set error class to the control group
            },

            success: function (label) {
                label
                        .closest('.form-group').removeClass('has-error'); // set success class to the control group
            },

            submitHandler: function (form) {
                AddProduct();
                clearForm();
            }
        });
    }


    var handleWysihtml5 = function () {
        if (!jQuery().wysihtml5) {
            return;
        }
        if ($('.wysihtml5').size() > 0) {
            $('.wysihtml5').wysihtml5({
                "stylesheets": ["assets/plugins/bootstrap-wysihtml5/wysiwyg-color.css"]
            });
        }
    }

    return {
        init: function () {
            handleWysihtml5();
            ValidateconfitureProduct();
        }
    };

} ();