﻿

$(".thousandseparated").inputmask({
    alias: "decimal",
    rightAlign: false,
    groupSeparator: ",",
    radixPoint: ".",
    autoGroup: true,
    integerDigits: 40,
    digitsOptional: true,
    allowPlus: false,
    allowMinus: false,
    'removeMaskOnSubmit': true

});
$('#txtloadingfactorreason').maxlength({
    limitReachedClass: "label label-danger",
    alwaysShow: true
});
if (window.location.search) {
    
    var param = getUrlVars()["param"];
    var decryptedstring = fndecrypt(param);
    var RFQID = getUrlVarsURL(decryptedstring)["RFQID"];
    $('#hdnRfqID').val(RFQID);
    var sub = getUrlVarsURL(decryptedstring)["RFQSubject"].replace(/%20/g, ' ');
    jQuery("#txtrfirfqsubject").val(decodeURIComponent(sub) + ' - ' + RFQID)

    fetchReguestforQuotationDetails()
    FetchRFQVersion();
    fetchApproverRemarks();
    fetchAttachments();
}
function fetchRFIRFQSubjectforReport(subjectFor) {
    
    jQuery.ajax({
        url: sessionStorage.getItem("APIPath") + "eRFQReport/fetchRFQSubjectforReport/?SubjectFor=" + subjectFor + "&Userid=" + encodeURIComponent(sessionStorage.getItem('UserID')) + "&CustomerID=" + sessionStorage.getItem('CustomerID'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "GET",
        async: false,
        contentType: "application/json; charset=utf-8",
        success: function (data, status, jqXHR) {
           sessionStorage.setItem('hdnRfqSubject', JSON.stringify(data));
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
    });

}

jQuery("#txtrfirfqsubject").typeahead({
    source: function(query, process) {
        var data = sessionStorage.getItem('hdnRfqSubject');
        Subject = [];
        map = {};
        var commonsubject = "";
        jQuery.each(jQuery.parseJSON(data), function(i, commonsubject) {
            map[commonsubject.RFQSubject] = commonsubject;
            Subject.push(commonsubject.RFQSubject);
        });

        process(Subject);

    },
    minLength: 2,
    updater: function(item) {

        if (map[item].RFQID != '0') {
           
            $('#hdnRfqID').val(map[item].RFQID);
            fetchReguestforQuotationDetails()
            FetchRFQVersion();
            fetchAttachments();
            fetchApproverRemarks();
        }

        return item;
    }

});
//jQuery("#txtrfirfqsubject").keyup(function () {
//    $('#hdnRfqID').val(0);
   
// });

 sessionStorage.setItem("RFQVersionId", "0")


function stringDivider(str, width, spaceReplacer) {
    if (str.length > width) {
        var p = width
        for (; p > 0 && str[p] != ' '; p--) {
        }
        if (p > 0) {
            var left = str.substring(0, p);
            var right = str.substring(p + 1);
            return left + spaceReplacer + stringDivider(right, width, spaceReplacer);
        }
    }
    return str;
}
function getSummary(vendorid) {
    var encrypdata = fnencrypt("RFQID=" + $('#hdnRfqID').val() + "&VendorId=" + vendorid + "&max=" + max + "&RFQVersionId=" + sessionStorage.getItem("RFQVersionId") + "&RFQVersionTxt=" + $("#ddlrfqVersion option:selected").text().replace(' ', '%20'))
    window.open("eRFQReport.html?param=" + encrypdata, "_blank")
    
}

var Vendor;
function fetchrfqcomprative() {
   
     var reInvited = '';
    var dtfrom = '';
    var dtto = '';
    sessionStorage.setItem("RFQVersionId", $("#ddlrfqVersion option:selected").val()) 
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    if ($("#txtFromDate").val() == null || $("#txtFromDate").val() == '') {
        dtfrom = '';

    }
    else {
        dtfrom = $("#txtFromDate").val()
    }

    if ($("#txtToDate").val() == null || $("#txtToDate").val() == '') {
        dtto = '';

    }
    else {
        dtto = $("#txtToDate").val()
    }
    
    //alert(sessionStorage.getItem("APIPath") + "eRFQReport/efetchRFQComprativeDetails/?RFQID=" + $('#hdnRfqID').val() + "&dateTo=" + dtto + "&dateFrom=" + dtfrom + "&UserID=" + encodeURIComponent(sessionStorage.getItem('UserID')) + "&RFQVersionId=" + $('#ddlrfqVersion option:selected').val())
    jQuery.ajax({
        url: sessionStorage.getItem("APIPath") + "eRFQReport/efetchRFQComprativeDetails/?RFQID=" + $('#hdnRfqID').val() + "&dateTo=" + dtto + "&dateFrom=" + dtfrom + "&UserID=" + encodeURIComponent(sessionStorage.getItem('UserID')) + "&RFQVersionId=" + $('#ddlrfqVersion option:selected').val(),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "GET",
        async: false,
        contentType: "application/json; charset=utf-8",
        success: function(data, status, jqXHR) {
            //   alert(data[0].VendorNames.length)
            var str = '';
            var strHead = '';
            var strHeadExcel = '';
            var strExcel = '';
            var totalWithouTax = 0;
            var totalWithTax = 0;
            var VendorID = 0;
            var totallowestValue = 0;
            var strQ = '';
            var strHeadQ = '';
            var strHeadExcelQ = '';
            var strExcelQ = '';
           var FlagForLowest='L'
          
            jQuery('#tblRFQComprative > thead').empty()
            jQuery("#tblRFQComprativeForExcel > thead").empty();
            jQuery('#tblRFQComprativetest > thead').empty()
            $('#tblRFQComprative > tbody').empty();
            $('#tblRFQComprativetest > tbody').empty();
            jQuery("#tblRFQComprativeForExcel > tbody").empty();

            jQuery('#tblRFQComprativeQ > thead').empty()
            jQuery("#tblRFQComprativeForExcelQ > thead").empty();
            jQuery('#tblRFQComprativetestQ > thead').empty()
            $('#tblRFQComprativeQ > tbody').empty();
            $('#tblRFQComprativetestQ > tbody').empty();
            jQuery("#tblRFQComprativeForExcelQ > tbody").empty();
           
           // ShowPrice = data[0].ShowPrice[0].ShowQuotedPrice;
            sessionStorage.setItem('ShowPrice', '');
           
            
            if (data[0].VendorNames.length > 0) {
                Vendor = data[0].VendorNames;
                $('#displayTable').show();
                $('#btnExport').show()
                $('#btnPDF').show()
                $('#displayComparativetabs').show();
                //For Printing Header
                strHead = "<tr  style='background: #f5f5f5; color:light black;'><th class='hide'>&nbsp;</th><th>SrNo</th><th>ItemCode</th><th>Short Name</th><th>Quantity</th><th>UOM</th>"
                strHeadExcel = "<tr><th>SrNo</th><th>ItemCode</th><th>Short Name</th><th>Quantity</th><th>UOM</th>"

                strHeadQ = "<tr  style='background:#f5f5f5; color:light black;'><th>Question</th><th>Our Requirement</th>"
                strHeadExcelQ = "<tr><th colspan=4>Question</th><th>Our Requirement</th>"
                for (var i = 0; i < data[0].VendorNames.length; i++) {
                    
                    if (data[0].VendorNames[i].SeqNo != 0) {
                       
                        strHead += "<th colspan='3' style='text-align:center;'><a onclick=getSummary(\'" + data[0].VendorNames[i].VendorID + "'\) href='javascript:;'  style='color:#2474f6; text-decoration:underline;'>" + data[0].VendorNames[i].VendorName; +"</a></th>";
                        strHeadExcel += "<th colspan='3'>" + data[0].VendorNames[i].VendorName; +"</th>";

                        strHeadQ += "<th style='text-align:center;'><a onclick=getSummary(\'" + data[0].VendorNames[i].VendorID + "'\) href='javascript:;'  style='color:#2474f6; text-decoration:underline;'>" + data[0].VendorNames[i].VName; +"</a></th>";
                        strHeadExcelQ += "<th>" + data[0].VendorNames[i].VName; +"</th>";
                      
                    }
                    else
                    {
                        strHead += "<th colspan='3' style='text-align:center;'>" + data[0].VendorNames[i].VendorName; +"</th>";
                        strHeadExcel += "<th colspan='3'>" + data[0].VendorNames[i].VendorName; +"</th>";

                        strHeadQ += "<th style='text-align:center;'>" + data[0].VendorNames[i].VName; +"</th>";
                        strHeadExcelQ += "<th>" + data[0].VendorNames[i].VName; +"</th>";

                    }
                }
                strHead += "<th>Line-wise Lowest Quote</th><th colspan='5' style='text-align:center;'>Last PO Details</th>";
                strHeadExcel += "<th>Line-wise Lowest Quote</th><th colspan='5'>Last PO Details</th>";

                strHead += "</tr>"
                strHeadExcel += "</tr>"

                strHeadQ += "</tr>"
                strHeadExcelQ += "</tr>"
               
                strHead += "<tr style='background: #f5f5f5; color:light black;'><th>&nbsp;</th><th>&nbsp;</th><th>&nbsp;</th><th>&nbsp;</th><th>&nbsp;</th>";
                strHeadExcel += "<tr><th>&nbsp;</th><th>&nbsp;</th><th>&nbsp;</th><th>&nbsp;</th><th>&nbsp;</th>";

               // strHeadQ += "<tr style='background: #f5f5f5; color:light black;'><th>&nbsp;</th>";
               // strHeadExcelQ += "<tr style='background: grey; color:light black;'><th>&nbsp;</th>";
              
                var taxHRTextinc =  stringDivider("Landed Unit Price (With GST)", 18, "<br/>\n");
                var taxHRTextEx = stringDivider("Landed Unit Price (Without GST)", 18, "<br/>\n");
                var HRAmount = stringDivider("Amount (Inc. GST)", 8, "<br/>\n");
                for (var j = 0; j < data[0].VendorNames.length; j++) {
                    
                    strHead += "<th>" + taxHRTextEx + "</th><th>" + taxHRTextinc + "</th><th>" + HRAmount + "</th>";
                    strHeadExcel += "<th>Landed Unit Price (Without GST)</th><th>Landed Unit Price (With GST)</th><th>Amount (Inc. GST)</th>"

                }
                strHead += "<th>" + taxHRTextEx + "</th><th>Po No</th><th>PO Date</th><th>Vendor Name</th><th>Unit Rate</th><th>PO Value</th>";
                strHeadExcel += "<th>"+taxHRTextEx+"</th><th>Po No</th><th>PO Date</th><th>Vendor Name</th><th>Unit Rate</th><th>PO Value</th>";

                strHead += "</tr>";
                strHeadExcel += "</tr>";

                //strHeadQ += "</tr>";
                //strHeadExcelQ += "</tr>";
                jQuery('#tblRFQComprative > thead').append(strHead);
                jQuery('#tblRFQComprativeForExcel > thead').append(strHeadExcel);

                jQuery('#tblRFQComprativeQ > thead').append(strHeadQ);
                jQuery('#tblRFQComprativeForExcelQ > thead').append(strHeadExcelQ);
               
                //For Printing Header Ends

  
                var x = 0;
               
                var unitrate = 0;
                for (var i = 0; i < data[0].NoofQuotes[0].NoofRFQParameter; i++) {
                    unitrate = 0;
                    var flag = 'T';
                    $("#tblRFQComprativetest > tbody > tr").each(function (index) {
                        var this_row = $(this);

                        if ($.trim(this_row.find('td:eq(2)').html()) == data[0].QuotesDetails[i].RFQParameterId) {
                            flag = 'F';

                        }

                    });
                    x = -1;
                    if (flag == 'T') {
                      
                     
                        str += "<tr><td class='hide'>" + data[0].QuotesDetails[i].VendorID + "</td><td>" + (i + 1) + "</td><td class='hide'>" + data[0].QuotesDetails[i].RFQParameterId + "</td><td>" + data[0].QuotesDetails[i].RFQItemCode + "</td><td>" + data[0].QuotesDetails[i].RFQShortName + "</td><td class=text-right>" + thousands_separators(data[0].QuotesDetails[i].Quantity) + "</td><td>" + data[0].QuotesDetails[i].UOM + "</td>";
                        strExcel += "<tr><td>" + (i+1) + "</td><td>" + data[0].QuotesDetails[i].RFQItemCode + "</td><td>" + data[0].QuotesDetails[i].RFQShortName + "</td><td>" + data[0].QuotesDetails[i].Quantity + "</td><td>" + data[0].QuotesDetails[i].UOM + "</td>";

                        for (var j = 0; j < data[0].QuotesDetails.length; j++) {
                        
                            if ((data[0].QuotesDetails[i].RFQParameterId) == (data[0].QuotesDetails[j].RFQParameterId)) {// true that means reflect on next vendor
                                x = x + 1;
                            
                                    if (data[0].QuotesDetails[j].VendorID == data[0].VendorNames[x].VendorID) {
                                        
                                        if (data[0].QuotesDetails[j].LowestPrice == "Y" && data[0].QuotesDetails[j].HighestPrice == "N" && data[0].QuotesDetails[j].UnitRate != 0 && data[0].QuotesDetails[j].RFQVendorPricewithoutGST != 0 && data[0].QuotesDetails[j].RFQVendorPricewithoutGST != -1 && data[0].QuotesDetails[j].RFQVendorPricewithoutGST != -2) {
                                            strExcel += "<td>" + data[0].QuotesDetails[j].RFQVendorPricewithoutGST + "</td><td>" + data[0].QuotesDetails[j].RFQVendorPricewithGST + "</td><td>" + data[0].QuotesDetails[j].UnitRate + "</td>";
                                            str += "<td class='text-right' id=unitrate" + i + x + " style='color: blue!important;'>" + thousands_separators(data[0].QuotesDetails[j].RFQVendorPricewithoutGST) + "</td><td class='VendorPriceNoTax text-right'>" + thousands_separators(data[0].QuotesDetails[j].RFQVendorPricewithGST) + "</td><td class='VendorPriceWithTax  text-right' >" + thousands_separators(data[0].QuotesDetails[j].UnitRate) + "</td>";

                                        }
                                        else if (data[0].QuotesDetails[j].LowestPrice == "N" && data[0].QuotesDetails[j].HighestPrice == "N" && data[0].QuotesDetails[j].UnitRate != 0 && data[0].QuotesDetails[j].RFQVendorPricewithoutGST != 0 && data[0].QuotesDetails[j].RFQVendorPricewithoutGST != -1 && data[0].QuotesDetails[j].RFQVendorPricewithoutGST != -2) {
                                            strExcel += "<td>" + data[0].QuotesDetails[j].RFQVendorPricewithoutGST + "</td><td>" + data[0].QuotesDetails[j].RFQVendorPricewithGST + "</td><td>" + data[0].QuotesDetails[j].UnitRate + "</td>";
                                            str += "<td class='text-right' id=unitrate" + i + x + ">" + thousands_separators(data[0].QuotesDetails[j].RFQVendorPricewithoutGST) + "</td><td class='VendorPriceNoTax text-right'>" + thousands_separators(data[0].QuotesDetails[j].RFQVendorPricewithGST) + "</td><td class='VendorPriceWithTax  text-right' >" + thousands_separators(data[0].QuotesDetails[j].UnitRate) + "</td>";

                                        }
                                        else if (data[0].QuotesDetails[j].LowestPrice == "N" && data[0].QuotesDetails[j].HighestPrice == "Y" && data[0].QuotesDetails[j].UnitRate != 0 && data[0].QuotesDetails[j].RFQVendorPricewithoutGST != 0 && data[0].QuotesDetails[j].RFQVendorPricewithoutGST != -1 && data[0].QuotesDetails[j].RFQVendorPricewithoutGST != -2) {
                                            strExcel += "<td>" + data[0].QuotesDetails[j].RFQVendorPricewithoutGST + "</td><td>" + data[0].QuotesDetails[j].RFQVendorPricewithGST + "</td><td>" + data[0].QuotesDetails[j].UnitRate + "</td>";
                                            str += "<td class='text-right' id=unitrate" + i + x + " style='color: red!important;'>" + thousands_separators(data[0].QuotesDetails[j].RFQVendorPricewithoutGST) + "</td><td class='VendorPriceNoTax text-right'>" + thousands_separators(data[0].QuotesDetails[j].RFQVendorPricewithGST) + "</td><td class='VendorPriceWithTax  text-right' >" + thousands_separators(data[0].QuotesDetails[j].UnitRate) + "</td>";

                                        }

                                       
                                       else if (data[0].QuotesDetails[j].LowestPrice == "Y" && data[0].QuotesDetails[j].HighestPrice == "Y" && data[0].QuotesDetails[j].UnitRate != 0 && data[0].QuotesDetails[j].RFQVendorPricewithoutGST != 0 && data[0].QuotesDetails[j].RFQVendorPricewithoutGST != -1 && data[0].QuotesDetails[j].RFQVendorPricewithoutGST != -2) {
                                            strExcel += "<td>" + data[0].QuotesDetails[j].RFQVendorPricewithoutGST + "</td><td>" + data[0].QuotesDetails[j].RFQVendorPricewithGST + "</td><td>" + data[0].QuotesDetails[j].UnitRate + "</td>";
                                            str += "<td class='text-right' id=unitrate" + i + x + " style='color: blue!important;'>" + thousands_separators(data[0].QuotesDetails[j].RFQVendorPricewithoutGST) + "</td><td class='VendorPriceNoTax text-right'>" + thousands_separators(data[0].QuotesDetails[j].RFQVendorPricewithGST) + "</td><td class='VendorPriceWithTax  text-right' >" + thousands_separators(data[0].QuotesDetails[j].UnitRate) + "</td>";

                                        }
                                        else if (data[0].QuotesDetails[j].UnitRate == -1 && data[0].QuotesDetails[j].RFQVendorPricewithoutGST == -1) {
                                            str += "<td colspan=3  style='color: blue!important; text-align: center;' >Not Invited</td>";
                                            strExcel += "<td colspan=3 >Not Invited </td>";
                                        }
                                        else if (data[0].QuotesDetails[j].UnitRate == -2 && data[0].QuotesDetails[j].RFQVendorPricewithoutGST == -2) {
                                            str += "<td colspan=3  style='color: red!important; text-align: center;' >Regretted</td>";
                                            strExcel += "<td colspan=3 >Regretted </td>";
                                        }
                                        else {

                                            str += "<td colspan=3  style='color: red!important; text-align: center;' >Not Quoted</td>";
                                            strExcel += "<td colspan=3 >Not Quoted </td>";
                                            //FlagForLowest = 'NOTL';
                                        }


                                  //  }
                                }
                               
                               

                            }

                        }
                        totallowestValue = totallowestValue + (data[0].QuotesDetails[i].Quantity * data[0].QuotesDetails[i].LowestPriceValue)
                        str += "<td class=text-right>" + thousands_separators(data[0].QuotesDetails[i].LowestPriceValue) + "</td><td>" + data[0].QuotesDetails[i].PoNo + "</td><td>" + data[0].QuotesDetails[i].PODate + "</td><td>" + data[0].QuotesDetails[i].POVendorName + "</td><td class=text-right>" + thousands_separators(data[0].QuotesDetails[i].POUnitRate) + "</td><td class=text-right>" + thousands_separators(data[0].QuotesDetails[i].POValue) + "</td>";
                        strExcel += "<td class=text-right>" + thousands_separators(data[0].QuotesDetails[i].LowestPriceValue) + "</td><td>" + data[0].QuotesDetails[i].PoNo + "</td><td>" + data[0].QuotesDetails[i].PODate + "</td><td>" + data[0].QuotesDetails[i].POVendorName + "</td><td>" + (data[0].QuotesDetails[i].POUnitRate) + "</td><td>" + (data[0].QuotesDetails[i].POValue) + "</td>";
                        str += "</tr>"
                        strExcel += "</tr>"
                           
                        jQuery('#tblRFQComprativetest').append(str);
                            
                    }

                }
             
                str += "<tr><td colspan=5 style='text-align:center;'><b>Total</b></td>";// <td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>
                strExcel += "<tr><td colspan=5><b>Total</b></td>";//<td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>
                for (var k = 0; k < data[0].VendorNames.length; k++) {
                    if (data[0].VendorNames[k].SeqNo != 0) {
                         RFQFetchTotalPriceForReport(data[0].VendorNames[k].VendorID, k)
                         str += "<td id=totBoxwithoutgst" + data[0].VendorNames[k].VendorID + " class=text-right></td><td id=totBoxwithgst" + data[0].VendorNames[k].VendorID + " class=text-right></td><td id=totBoxTax" + data[0].VendorNames[k].VendorID + " class=text-right></td>";
                         strExcel += "<td id=totBoxwithoutgstExcel" + data[0].VendorNames[k].VendorID + "></td><td id=totBoxwithExcel" + data[0].VendorNames[k].VendorID + "></td><td id=totBoxTaxExcel" + data[0].VendorNames[k].VendorID + "></td>";
                    }
                    else {
                        str += "<td colspan=3>&nbsp;</td>"; //
                        strExcel += "<td colspan=3>&nbsp;</td>";
                    }

                }
                str += "<td class=text-right>" + thousands_separators(totallowestValue) + "</td><td colspan=5>&nbsp;</td></tr>";
                strExcel += "<td>" + thousands_separators(totallowestValue) + "</td><td colspan=5>&nbsp;</td></tr>";

                

                //For Loading Factor
                str += "<tr><td colspan=3 style='text-align:center;'><b>Loading Factor</b></td><td colspan=2 style='text-align:center;'><b>Loaded Price</b></td>";// <td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>
                strExcel += "<tr><td colspan=3 ><b>Loading Factor</b></td><td colspan=2 style='text-align:center;'><b>Loaded Price</b></td>";
                for (var l = 0; l < data[0].VendorNames.length; l++) {
                    for (var k = 0; k < data[0].LoadedFactor.length; k++) {
                        if (data[0].LoadedFactor[k].VendorID == data[0].VendorNames[l].VendorID) {
                          
                                //var p = data[0].LoadedFactor[k].LoadedFactor + parseFloat(removeThousandSeperator($('#totBoxwithgst' + data[0].LoadedFactor[k].VendorID).html()))
                              
                            var p = thousands_separators(data[0].LoadedFactor[k].LoadedFactor + data[0].LoadedFactor[k].SumwithGST);
                            if (p != 0) {
                                str += "<td style='text-align:right;' id=LFactor" + data[0].VendorNames[k].VendorID +">" + thousands_separators(data[0].LoadedFactor[k].LoadedFactor) + "</td><td  id=LoadingF" + data[0].VendorNames[k].VendorID + " style='text-align:right;'>" + p + "</td><td>&nbsp;</td>";
                                strExcel += "<td id=LFactorexcel" + data[0].VendorNames[k].VendorID + ">" + thousands_separators(data[0].LoadedFactor[k].LoadedFactor) + "</td><td id=LoadingFexcel" + data[0].VendorNames[k].VendorID + ">" + p + "</td><td>&nbsp;</td>";
                            }
                            else {
                               
                                str += "<td colspan=3>&nbsp;</td>";
                                strExcel += "<td colspan=3>&nbsp;</td>";
                            }
                           
                        }
                        

                    }
                }
                str += "<td colspan=6>&nbsp;</td></tr>";
                strExcel += "<td colspan=6>&nbsp;</td></tr>";
               
                //For Loading Factor reason Row
                str += "<tr><td colspan=5 style='text-align:center;'><b>Loading Reason</b></td>";
                strExcel += "<tr><td colspan=5 ><b>Loading Reason</b></td>";
                for (var l = 0; l < data[0].VendorNames.length; l++) {
                    for (var k = 0; k < data[0].LoadedFactor.length; k++) {
                        if (data[0].LoadedFactor[k].VendorID == data[0].VendorNames[l].VendorID) {

                            if (data[0].LoadedFactor[k].LoadingFactorReason != '') {
                                str += "<td style='text-align:left;' colspan=3 id=LoadingReason" + data[0].VendorNames[k].VendorID + ">" + data[0].LoadedFactor[k].LoadingFactorReason + "</td>";
                                strExcel += "<td colspan=3 id=LoadingReasonexcel" + data[0].VendorNames[k].VendorID + ">" + data[0].LoadedFactor[k].LoadingFactorReason + "</td>";
                            }
                            else {

                                str += "<td colspan=3>&nbsp;</td>";
                                strExcel += "<td colspan=3>&nbsp;</td>";
                            }

                        }


                    }
                }
                str += "<td colspan=6>&nbsp;</td></tr>";
                strExcel += "<td colspan=6>&nbsp;</td></tr>";

                //For Commercial Rank
                str += "<tr><td colspan=5 style='text-align:center;'><b>Commercial Rank</b></td>";// <td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>
                strExcel += "<tr><td colspan=5 ><b>Commercial Rank</b></td>";
                for (var l = 0; l < data[0].VendorNames.length; l++) {
                    for (var k = 0; k < data[0].LStatus.length; k++) {

                        if (data[0].LStatus[k].VendorID == data[0].VendorNames[l].VendorID) {
                            if (data[0].LStatus[k].Status != 'N/A') {
                                str += "<td colspan=3 style='text-align:center;color: blue!important;'>" + data[0].LStatus[l].Status + "</td>";
                                strExcel += "<td colspan=3>" + data[0].LStatus[l].Status + "</td>";
                            }
                            else {
                                str += "<td colspan=3 style='text-align:center;color: red!important;'>" + data[0].LStatus[k].Status + "</td>";
                                strExcel += "<td colspan=3>" + data[0].LStatus[k].Status + "</td>";
                            }

                        }

                    }
                }
                str += "<td colspan=6>&nbsp;</td></tr>";
                strExcel += "<td colspan=6>&nbsp;</td></tr>";

                //For Blank Row
                 str += "<tr>";
                 strExcel += " <tr>";
                 var t = 0;
                 for (var k = 1; k <= data[0].VendorNames.length; k++) {
                     t = k;
                  }

                 str += "<td colspan="+(t+10)+">&nbsp;</td></tr>";
                 strExcel += "<td colspan=" + (t + 10) + ">&nbsp;</td></tr>";
               
                //For Commercial Header Row
                // ***************** Start  Commercial Row
                 if (data[0].CommercialTerms.length > 0) {
                     //alert(data[0].CommercialTerms.length)
                     str += "<tr style='background: #f5f5f5; color:light black;'>";
                     strExcel += " <tr>";
                     str += "<td><b>SrNo</b></td><td colspan=4><b>Other Commercial Terms</b></td>";
                     strExcel += "<td>SrNo</td><td colspan=4><b>Other Commercial Terms</b></td>";
                     for (var k = 0; k < data[0].VendorNames.length; k++) {

                         // str += "<td colspan=3>&nbsp;</td>";
                         // strExcel += "<td colspan=3>&nbsp;</td>";
                         if (data[0].VendorNames[k].SeqNo != '0') {

                             str += "<td colspan=3 style='text-align:center;'><a onclick=getSummary(\'" + data[0].VendorNames[k].VendorID + "'\)  style='color:#2474f6; text-decoration:underline;'><b>" + data[0].VendorNames[k].VName + "<b></a></td>";
                             strExcel += "<td colspan=3 ><b>" + data[0].VendorNames[k].VName; +"</b></td>";
                             // str += "<td colspan=3>&nbsp;</td>";
                             //strExcel += "<td colspan=3>&nbsp;</td>";
                         }
                         else {
                             str += "<td colspan=3 style='text-align:center;'><b>" + data[0].VendorNames[k].VName; +"</b></td>";
                             strExcel += "<td colspan=3><b>" + data[0].VendorNames[k].VName; +"</b></td>";

                         }

                     }
                     str += "<td colspan=6><b>Our Requirement</b></td></tr>";
                     strExcel += "<td colspan=6><b>Our Requirement</b></td></tr>";

                     $('#tblRFQComprativetest > tbody').empty(); // clear again for comparision of Commercial

                     //For  Commercial table 
                     for (var p = 0; p < data[0].NoOfTermsForRFQ[0].NoOfTermsSelectedForRFQ; p++) {

                         var flag1 = 'T';
                         $("#tblRFQComprativetest > tbody > tr").each(function (index) {
                             var this_row = $(this);
                             if ($.trim(this_row.find('td:eq(0)').html()) == data[0].CommercialTerms[p].TermName) {
                                 flag1 = 'F';
                             }

                         });


                         if (flag1 == 'T') {

                             str += "<tr><td>" + (p + 1) + "</td><td colspan=4>" + data[0].CommercialTerms[p].TermName + "</td>";
                             strExcel += "<tr><td>" + (p + 1) + "</td><td colspan=4>" + data[0].CommercialTerms[p].TermName + "</td>";

                             for (var s = 0; s < data[0].CommercialTerms.length; s++) {
                                 //alert(data[0].CommercialTerms[i].RFQTCID)
                                 // alert(data[0].CommercialTerms[s].RFQTCID)
                                 if ((data[0].CommercialTerms[p].RFQTCID) == (data[0].CommercialTerms[s].RFQTCID)) {// true that means reflect on next vendor

                                     //  q = q + 1;
                                     for (var q = 0; q < data[0].VendorNames.length; q++) {
                                         if (data[0].CommercialTerms[s].VendorID == data[0].VendorNames[q].VendorID) {

                                             if (data[0].CommercialTerms[s].Remarks != '' && data[0].CommercialTerms[s].Remarks != 'Rejected') {
                                                 str += "<td colspan=3>" + data[0].CommercialTerms[s].Remarks + "</td>";
                                                 strExcel += "<td colspan=3>" + data[0].CommercialTerms[s].Remarks + "</td>";

                                             }
                                             else if (data[0].CommercialTerms[s].Remarks == 'Rejected') {
                                                 str += "<td colspan=3 style='color: red!important; text-align: center;'>Regretted</td>";
                                                 strExcel += "<td colspan=3>Regretted</td>";

                                             }
                                             else {
                                                 str += "<td colspan=3  style='color: red!important; text-align: center;' >Not Quoted</td>";
                                                 strExcel += "<td colspan=3 >Not Quoted </td>";
                                             }

                                         }

                                     }
                                 }
                             }
                             str += "<td colspan=6>" + data[0].CommercialTerms[p].Requirement + "</td>";
                             strExcel += "<td colspan=6>" + data[0].CommercialTerms[p].Requirement + "</td>";

                             str += " </tr>";
                             strExcel += " </tr>";
                             jQuery('#tblRFQComprativetest').append(str);
                         }
                     }
                 }

                // ***************** End  Commercial Row



                //For Vendor Comments
                // str += "<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>";
                  str += "<tr><td colspan=5><b>Vendor Remarks :</b></td>";
                  strExcel += "<tr><td colspan=5><b>Vendor Remarks :</b></td>";
                  for (var k = 0; k < data[0].VendorNames.length; k++) {

                      if (data[0].VendorNames[k].VendorRemarks != "") {
                          var VRemarks = stringDivider(data[0].VendorNames[k].VendorRemarks, 40, "<br/>\n");
                          str += "<td colspan='3' class='text-left' >" + VRemarks + "</td>";
                          strExcel += "<td colspan='3' >" + VRemarks + "</td>";
                      }
                      else {
                          str += "<td colspan=3>&nbsp;</td>";
                          strExcel += "<td colspan=3>&nbsp;</td>";
                      }
                  }
                  str += "<td colspan=6>&nbsp;</td>";
                  strExcel += "<td colspan=6>&nbsp;</td>";
                  str += " </tr>";
                  strExcel += " </tr>";

                //For Qusetion table
                // ***************** Start  Answer Question Row
                  if (data[0].Questions.length > 0) {

                      $('#tblRFQComprativetestQ > tbody').empty(); // clear again for comparision of Question
                      for (var p = 0; p < data[0].NoOfQuestions[0].NoOfQuestionsCount; p++) {

                          var flag2 = 'T';
                          $("#tblRFQComprativetestQ > tbody > tr").each(function (index) {
                              var this_row = $(this);
                              if ($.trim(this_row.find('td:eq(0)').html().toLowerCase()) == data[0].Questions[p].Question.toLowerCase()) {
                                  flag2 = 'F';

                              }

                          });


                          if (flag2 == 'T') {

                              strQ += "<tr><td>" + data[0].Questions[p].Question + "</td><td>" + data[0].Questions[p].Requirement + "</td>";
                              strExcelQ += "<tr><td colspan=4>" + data[0].Questions[p].Question + "</td><td>" + data[0].Questions[p].Requirement + "</td>";

                              for (var s = 0; s < data[0].Questions.length; s++) {

                                  if ((data[0].Questions[p].QuestionID) == (data[0].Questions[s].QuestionID)) {// true that means reflect on next vendor

                                      //  q = q + 1;
                                      for (var q = 0; q < data[0].VendorNames.length; q++) {
                                          if (data[0].Questions[s].VendorID == data[0].VendorNames[q].VendorID) {

                                              if (data[0].Questions[s].Answer != '' && data[0].Questions[s].Answer != 'Rejected') {
                                                  strQ += "<td>" + data[0].Questions[s].Answer + "</td>";
                                                  strExcelQ += "<td>" + data[0].Questions[s].Answer + "</td>";

                                              }
                                              else if (data[0].Questions[s].Answer == 'Rejected') {
                                                  strQ += "<td  style='color: red!important; text-align: center;'>Regretted</td>"
                                                  strExcelQ += "<td>Regretted</td>";

                                              }
                                              else {
                                                  strQ += "<td  style='color: red!important; text-align: center;' >Not Quoted</td>";
                                                  strExcelQ += "<td >Not Quoted </td>";
                                              }

                                          }

                                      }
                                  }
                              }


                              strQ += " </tr>";
                              strExcelQ += " </tr>";
                              jQuery('#tblRFQComprativetestQ').append(strQ);

                         }
                     }
                  }
                  else {
                      strQ += "<tr>";
                      strExcelQ += " <tr><td>&nbsp;</td>";
                      t = 0;
                      for (var k = 1; k <= data[0].VendorNames.length; k++) {

                          t = k;

                      }
                      strQ += "<td colspan=" + (t + 2) + ">No Questions Mapped</td>";
                      strExcelQ += "<td colspan=" + (t + 2) + ">No Questions Mapped</td>";
                      strQ += "</tr>";
                      strExcelQ += "</tr>";
                  }
                //// ***************** END  Answer Question Row
                //// ***************** Start  Define Technical  Approver Row**********************
                  strQ += " <tr><td><b>Technical Approver Required</b></td>";
                //for (var k = 0; k < data[0].VendorNames.length; k++) {
                  
                  if (data[0].VendorNames[0].IsApproverRequired == "Y" ) {
                      strQ += "<td colspan=4><input style='width:16px!important;height:16px!important;' onclick='fncheckradiotext()' type='radio' name=AppRequired id=AppYes class='md-radio'  value='Y' checked disabled/> &nbsp;<span for=AppYes>Yes</span><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><input style='width:16px!important;height:16px!important;' type='radio' class='md-radio' name=AppRequired id=AppNo   onclick='fncheckradiotext()' disabled /> &nbsp;<span for=AppNo >No</span></td>"
                  }
                  else {
                      if ($("#ddlrfqVersion option:selected").val() == 99)
                      {
                          strQ += "<td colspan=4><input style='width:16px!important;height:16px!important;' onclick='fncheckradiotext()' type='radio' name=AppRequired id=AppYes class='md-radio' value='Y' disabled/> &nbsp;<span for=AppYes >Yes</span><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><input style='width:16px!important;height:16px!important;' type='radio' class='md-radio' name=AppRequired id=AppNo checked  onclick='fncheckradiotext()'  value='N'   /> &nbsp;<span for=AppNo >No</span></td>"
                      }
                      else {
                          strQ += "<td colspan=4><input style='width:16px!important;height:16px!important;' onclick='fncheckradiotext()' type='radio' name=AppRequired id=AppYes class='md-radio' value='Y'/> &nbsp;<span for='AppYes' >Yes</span><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><input style='width:16px!important;height:16px!important;' type='radio' class='md-radio' name=AppRequired id='AppNo' checked  onclick='fncheckradiotext()'  value='N'   /> &nbsp;<span for=AppNo >No</span></td>"
                      }
                  }
                //}
                  strQ += "</tr>"
                //// ***************** END  Define Technical  Row **********************
                //// ***************** Start  Technical Approver Row**********************
                //  if ($("#ddlrfqVersion option:selected").val() == 0) {
                           
                      if (data[0].ApproverStatus.length > 0) {
                          $('#tblRFQComprativetestQ > tbody').empty(); // clear again for comparision of Question
                          for (var p = 0; p < data[0].NoOfTApprover[0].NoOfTechnicalApprover; p++) {

                              var flag3 = 'T';
                              $("#tblRFQComprativetestQ > tbody > tr").each(function (index) {
                                  var this_row = $(this);
                                  if ($.trim(this_row.find('td:eq(0)').html().toLowerCase()) == data[0].ApproverStatus[p].ApproverName.toLowerCase()) {
                                      flag3 = 'F';

                                  }

                              });

                              if (flag3 == 'T') {
                                
                                  strQ += "<tr><td>" + data[0].ApproverStatus[p].ApproverName + "</td><td>" + data[0].ApproverStatus[p].Remarks + "</td>";
                                  strExcelQ += "<tr><td>" + data[0].ApproverStatus[p].ApproverName + "</td><td>" + data[0].ApproverStatus[p].Remarks + "</td>";

                                  for (var s = 0; s < data[0].ApproverStatus.length; s++) {
                                     
                                      if ((data[0].ApproverStatus[p].ApproverID) == (data[0].ApproverStatus[s].ApproverID)) {// true that means reflect on next vendor
                                         
                                           for (var q = 0; q < data[0].VendorNames.length; q++) {
                                              if (data[0].ApproverStatus[s].VendorID == data[0].VendorNames[q].VendorID) {
                                                  
                                                  if (data[0].ApproverStatus[s].Status == 'Approved') {
                                                      strQ += "<td style='color: green!important; text-align: center;'>" + data[0].ApproverStatus[s].Status + "</td>";
                                                      strExcelQ += "<td>" + data[0].ApproverStatus[s].Status + "</td>";

                                                  }
                                                  else if (data[0].ApproverStatus[s].Status == 'Rejected') {
                                                      strQ += "<td style='color: red!important; text-align: center;'>Not Approved</td>";
                                                      strExcelQ += "<td>Not Approved</td>";

                                                  }
                                                 else  if (data[0].ApproverStatus[s].Status == 'Pending') {
                                                      strQ += "<td style='color: blue!important; text-align: center;'>Pending</td>";
                                                      strExcelQ += "<td>Pending</td>";

                                                  }

                                              }
                                           }
                                      }
                                  }


                                  strQ += " </tr>";
                                  strExcelQ += " </tr>";
                                  jQuery('#tblRFQComprativetestQ').append(strQ);

                              }

                          }

                      }
                //  }
                //// ***************** END  Technical Approver Row

                      //For Blank Row after question table 
                      strQ += "<tr>";
                      strExcelQ += " <tr><td>&nbsp;</td>";
                      t = 0;
                      for (var k = 1; k <= data[0].VendorNames.length; k++) {

                          t = k;

                      }
                      strQ += "<td colspan=" + (t + 2) + ">&nbsp;</td>";
                      strExcelQ += "<td colspan=" + (t + 2) + ">&nbsp;</td>";
                      strQ += "</tr>";
                      strExcelQ += "</tr>";
                  
               

                    if ($("#ddlrfqVersion option:selected").val() != 99) {
                        //For ReInvite Row
                        str += "<tr id='reinvitationTR'><td colspan=5><b>Re-Invitation Row</b></td>";
                        var maxValue = -1;
                        for (var k = 0; k < data[0].VendorNames.length; k++) {
                            $("#ddlrfqVersion option").each(function () {
                                var thisVal = $(this).val();

                                //if (maxValue == -1 || maxValue < thisVal) {
                                //    maxValue = thisVal;

                                //}
                                if (maxValue < thisVal && thisVal != 99) {
                                    maxValue = thisVal;
                                }
                                //if ($("#ddlrfqVersion option:selected").val() < maxValue) {
                                if ($("#ddlrfqVersion option:selected").val() == maxValue) {
                                    reInvited = 'Y'
                                }
                            });

                            if (maxValue == $("#ddlrfqVersion option:selected").val()) {

                                $("#btn-reInvite").attr('disabled', false)
                                str += "<td colspan='3' class='text-center'><label class='checkbox-inline'><input type='checkbox' class='chkReinvitation' style='position:relative;margin-right:5px;' value=" + data[0].VendorNames[k].VendorID + " />Re-Invite Vendor For Fresh Quote</label></td>"; //<a class='btn green'>Re-Invite Vendor</a>


                            }
                            else {

                                $("#btn-reInvite").attr('disabled', true);
                                str += "<td colspan=3>&nbsp;</td>";
                            }

                           
                        }
                        str += "<td colspan='5'>&nbsp;</td>";
                        str += " </tr>";
                    }
                   
                    if ($("#ddlrfqVersion option:selected").val() == 99) {

                        $("#btn-reInvite").attr('disabled', true);
                        $("#btn_commercial").removeClass('hide');
                        $("#btn_mapaaprover").addClass('hide');
                        $(".lambdafactor").addClass('hide');

                    }
                    else {
                        $("#btn_mapaaprover").removeClass('hide');
                        $("#btn_commercial").addClass('hide');
                        $("#btn-reInvite").attr('disabled', false)

                    }


                    jQuery('#tblRFQComprative').append(str);
                    jQuery("#tblRFQComprativeForExcel").append(strExcel);

                    jQuery('#tblRFQComprativeQ').append(strQ);
                   jQuery("#tblRFQComprativeForExcelQ").append(strExcelQ);
                   if (data[0].CommApprover[0].isFwdCommApp == "Y") {
                       $('#btn_commercial').attr('disabled', 'disabled')
                       $('#btn_commercial').text('Approval Pending')
                       
                       $("#btn-reInvite").attr('disabled', true);
                       $('#reinvitationTR').hide()
                   }
                   else {
                       $('#btn_commercial').removeAttr('disabled')
                       $('#btn_commercial').text('Commercial Approval')
                       //$('#tblCommercialApproval').hide();
                       $("#btn-reInvite").attr('disabled', false);
                       $('#reinvitationTR').show()
                   }
                    
        } 
    else {
                
                $('#displayTable').show();
                $('#displayComparativetabs').show();
                $('<tr><td style="color:red !important; text-align: center;" colspan="5"> No results </td></tr>').appendTo('#tblRFQComprative');
                $('<tr><td style="color:red !important; text-align: center;" colspan="5"> No results </td></tr>').appendTo("#tblRFQComprativeForExcel")

            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }

    });
   
    jQuery.unblockUI();

}
function fetchAttachments() {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "eRequestForQuotation/eRFQDetails/?RFQID=" + $('#hdnRfqID').val() + "&CustomerID=" + sessionStorage.getItem('CustomerID') + "&UserID=" + sessionStorage.getItem('UserID'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
           // alert(data[0].Attachments.length)
            jQuery("#tblAttachments").empty();
           
            if (data[0].Attachments.length > 0) {
                jQuery("#tblAttachments").append("<thead><tr  style='background: gray; color: #FFF;'><th class='bold' style='width:50%!important'>Description</th><th style='width:50%!important'>Attachment</th></tr></thead>")
               
              //  $('#div_attachments').removeClass('hide')
                
                for (var i = 0; i < data[0].Attachments.length; i++) {
                    var str = "<tr><td style='width:50%!important'>" + data[0].Attachments[i].RFQAttachmentDescription + "</td>";
                    str += '<td class=style="width:50%!important"><a style="pointer:cursur;text-decoration:none;" target=_blank href=PortalDocs/eRFQ/' + $('#hdnRfqID').val() + '/' + data[0].Attachments[i].RFQAttachment.replace(/\s/g, "%20") + '>' + data[0].Attachments[i].RFQAttachment + '</a></td>';
                    jQuery('#tblAttachments').append(str);
                   
                }
            }
            else {
                jQuery('#tblAttachments').append("<tr><td>No Attachments</td></tr>");
               // $('#div_attachments').addClass('hide')
                
            }

        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
    })
}
function fncheckradiotext() {
    var flagMapApprover = 'F';
    $("input[type='radio']:checked").each(function () {
        var idVal = $(this).attr("id");
        //alert($("span[for='" + idVal + "']").text())
        if($("span[for='" + idVal + "']").text() == "Yes")
        {
            flagMapApprover = 'T';
        }
        //else{
        //    flagMapApprover = 'T';
        //}
    });
  
    if (flagMapApprover == "T") {
        $('#btn_mapaaprover').removeAttr('disabled')
    }
    else {
        $('#btn_mapaaprover').attr('disabled','disabled')
    }
}

function RFQFetchTotalPriceForReport(VendorID,Counter) {
   
//alert(sessionStorage.getItem("APIPath") + "RFI_RFQReport/RFQFetchTotalPriceForReport/?RFQID=" + $('#hdnRfiRfqID').val() + "&VendorId=" + VendorID + "&RFQVersionId=" + sessionStorage.getItem("RFQVersionId"))
    jQuery.ajax({
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "eRFQReport/eRFQFetchTotalPriceForReport/?RFQID=" + $('#hdnRfqID').val() + "&VendorId=" + VendorID + "&RFQVersionId=" + sessionStorage.getItem("RFQVersionId") + "&BidID=0",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "GET",
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function(data) {
            
            $("#totBoxwithoutgst" + VendorID).html(thousands_separators(data[0].TotalPriceExTax));
            $("#totBoxwithgst" + VendorID).html(thousands_separators(data[0].TotalPriceIncTax) + " &nbsp;<a class='lambdafactor' style='cursor:pointer' onclick=editwithgstlambdafactor(" + data[0].TotalPriceIncTax + ","+ Counter + ","+VendorID+")><i class='fa fa-pencil'></i></a>");
            $("#totBoxTax" + VendorID).html(thousands_separators(data[0].TotalPriceIncTax));
            $("#totBoxwithoutgstExcel" + VendorID).html(data[0].TotalPriceExTax);
            $("#totBoxwithgstExcel" + VendorID).html(thousands_separators(data[0].TotalPriceIncTax));
            $("#totBoxTaxExcel" + VendorID).html(data[0].TotalPriceIncTax);
            if ($("#ddlrfqVersion option:selected").val() == 99) {

               
                $(".lambdafactor").addClass('hide');

            }
            else {
                $(".lambdafactor").removeClass('hide');

            }


        }, error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
    });
}
function editwithgstlambdafactor(pricewithgst,rowid,vendorid) {
    $("#editloadingfactor").modal('show');
    $("#hdngstprice").val(pricewithgst);
    $("#hdnvendorid").val(vendorid);
}
function updloadingfactor() {
    var Data = {
        "RFQID": $('#hdnRfqID').val(),
        "VersionID": sessionStorage.getItem("RFQVersionId"),
        "VendorID":  $("#hdnvendorid").val(),
        "LoadingFactor": removeThousandSeperator($("#txtloadingfactor").val()),
        "LoadingFactorReason": $("#txtloadingfactorreason").val()
    }
   // alert(JSON.stringify(Data))
    jQuery.ajax({
        url: sessionStorage.getItem("APIPath") + "eRFQReport/eRFQ_VendorLoadingFactor/",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "POST",
        data: JSON.stringify(Data),
        contentType: "application/json; charset=utf-8",
        success: function (data, status, jqXHR) {
           
            //if (data[0].LoadingFactor > 0) {
               
                var price = parseFloat(data[0].LoadingFactor + data[0].TotalPriceIncTax)
                $('#LFactor' + $("#hdnvendorid").val()).html(thousands_separators(data[0].LoadingFactor))
                $('#LoadingF' + $("#hdnvendorid").val()).html(thousands_separators(price))
                $('#LoadingReason' + $("#hdnvendorid").val()).html($("#txtloadingfactorreason").val())
                $('#LFactorexcel' + $("#hdnvendorid").val()).html(thousands_separators(data[0].LoadingFactor))
                $('#LoadingFexcel' + $("#hdnvendorid").val()).html(thousands_separators(price))
                $('#LoadingReasonexcel' + $("#hdnvendorid").val()).html($("#txtloadingfactorreason").val())
                setTimeout(function () {
                    $("#editloadingfactor").modal('hide');
                    fetchrfqcomprative();
                },1000)
           // }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
    })
}
$("#editloadingfactor").on("hidden.bs.modal", function () {
    $("#txtloadingfactor").val('')
    $("#hdngstprice").val('');
    $("#hdnvendorid").val('');
    $("#txtloadingfactorreason").val('');
});

var max = 0;
function FetchRFQVersion() {
    max = 0;
    jQuery.ajax({
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "eRFQReport/efetchRFQVersions/?RFQID=" + $('#hdnRfqID').val(),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "GET",
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data) {
            $("#ddlrfqVersion").empty();
            if (data.length > 0) {
                $('#ddlrfqVersion').append('<option  value="99" >Final Version</option>');
                $('#ddlrfqVersion').append('<option  value=' + data[0].RFQVersionId + '>' + (data[0].RFQVersionId + 1) + ' Quote</option>');
                max = data[0].RFQVersionId;
                for (var i = 0; i < data[0].RFQVersionId; i++) {

                    $('#ddlrfqVersion').append(jQuery('<option ></option>').val(i).html((i + 1) + " Quote"));

                }
            }

        }, error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
    });

}


$("#ddlrfqVersion").change(function() {
    $("#displayTable").hide();
    $('#displayComparativetabs').hide();
    $("#btnExport").hide();
    $("#btnPDF").hide()
});
jQuery("#txtSearch").keyup(function () {
    _this = this;
    // Show only matching TR, hide rest of them
    jQuery.each($("#tblRFQComprative tbody").find("tr"), function () {
        console.log($(this).text());
        if (jQuery(this).text().toLowerCase().indexOf(jQuery(_this).val().toLowerCase()) == -1)
            jQuery(this).hide();
        else
            jQuery(this).show();
    });
});
function fetchReguestforQuotationDetails() {
    var attachment = '';
    var termattach = '';

    jQuery.ajax({
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "eRequestForQuotation/eRFQDetails/?RFQID=" + $('#hdnRfqID').val() + "&CustomerID=" + sessionStorage.getItem('CustomerID') + "&UserID=" + sessionStorage.getItem('UserID'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "GET",
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (RFQData) {
            var replaced1 = '';
            $('#tbldetailsExcel > tbody').empty();
            if (RFQData.length > 0) {
                jQuery('#RFQSubject').text(RFQData[0].General[0].RFQSubject)
                jQuery('#RFQDescription').html(RFQData[0].General[0].RFQDescription)
                $('#Currency').html(RFQData[0].General[0].CurrencyNm)
                jQuery('#ConversionRate').html(RFQData[0].General[0].RFQConversionRate);
                jQuery('#refno').html(RFQData[0].General[0].RFQReference)
                
                jQuery('#RFQStartDate').html(RFQData[0].General[0].RFQStartDate)
                jQuery('#RFQDeadline').html(RFQData[0].General[0].RFQEndDate)
                jQuery('#lblrfqconfigby').html(RFQData[0].General[0].RFQConfigureByName)


                if (RFQData[0].General[0].RFQTermandCondition != '') {
                    replaced1 = RFQData[0].General[0].RFQTermandCondition.replace(/\s/g, "%20")
                }

                $('#TermCondition').attr('href', 'PortalDocs/eRFQ/' + $('#hdnRfqID').val() + '/' + replaced1.replace(/\s/g, "%20") + '').html(RFQData[0].General[0].RFQTermandCondition)
                //  $('#Attachment').attr('href', 'PortalDocs/RFQ/' + $('#hdnRfqID').val() + '/' + attachment + '').html(RFQData[0].RFQAttachment)
                $('#tbldetails').append("<tr><td>" + RFQData[0].General[0].RFQSubject + "</td><td>" + RFQData[0].General[0].RFQDescription + "</td><td>" + RFQData[0].General[0].CurrencyNm + "</td><td >" + RFQData[0].General[0].RFQConversionRate + "</td><td>" + RFQData[0].General[0].RFQEndDate + "</td></tr>")
                $('#tbldetailsExcel > tbody').append("<tr><td>" + RFQData[0].General[0].RFQSubject + "</td><td>" + RFQData[0].General[0].RFQDescription + "</td><td>" + RFQData[0].General[0].CurrencyNm + "</td><td >" + RFQData[0].General[0].RFQConversionRate + "</td><td>" + RFQData[0].General[0].RFQEndDate + "</td></tr>")

            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
    });

}


var form = $('#RFIRFQREport');
var formApprover = $('#frmMapApprover');
var formCommApprover = $('#frmcommMapApprover');
function formvalidate() {

    form.validate({

        doNotHideMessage: true, //this option enables to show the error/success messages on tab switch.

        errorElement: 'span', //default input error message container

        errorClass: 'help-block help-block-error', // default input error message class

        focusInvalid: false, // do not focus the last invalid input

        rules: {

            txtrfirfqsubject: {
                required: true
            }

        },

        messages: {

    },



    invalidHandler: function(event, validator) {

    },

    highlight: function(element) {

        $(element).closest('.form-group').addClass('has-error');

    },

    unhighlight: function(element) {

        $(element).closest('.form-group').removeClass('has-error');

    },

    success: function(label) {


    },
    submitHandler: function (form) {
       
        if ($('#hdnRfiRfqID').val() == "0") {
            gritternotification('Please Select RFQ properly!!!')
         }
        else {
            fetchrfqcomprative()
        }
    }

});

$("#frmReInvite").validate({

    doNotHideMessage: true, //this option enables to show the error/success messages on tab switch.

    errorElement: 'span', //default input error message container

    errorClass: 'help-block help-block-error', // default input error message class

    focusInvalid: false, // do not focus the last invalid input

    rules: {

        txtextendDate: {
            required: true
        }

    },

    messages: {

},



invalidHandler: function(event, validator) {

},

highlight: function(element) {

    $(element).closest('.col-md-8').addClass('has-error');

},

unhighlight: function(element) {

    $(element).closest('.col-md-8').removeClass('has-error');

},
errorPlacement: function(error, element) {

    if (element.attr("name") == "txtextendDate") {

        error.insertAfter("#daterr");

    }
    else {

        error.insertAfter(element);
    }
},
success: function(label) {


},
submitHandler: function(form) {
ReInviteVendorsForRFQ();
}

});

    // Map Approver Validation
formApprover.validate({

    doNotHideMessage: true, //this option enables to show the error/success messages on tab switch.
    errorElement: 'span', //default input error message container
    errorClass: 'help-block help-block-error', // default input error message class
    focusInvalid: false, // do not focus the last invalid input
    rules: {

        txtApprover: {
            required: true
        }

    },

    messages: {

    },

     invalidHandler: function (event, validator) {
        },

    highlight: function (element) {
         $(element).closest('.col-md-6').addClass('has-error');

    },

    unhighlight: function (element) {
          $(element).closest('.col-md-6').removeClass('has-error');

    },
    errorPlacement: function (error, element) {
        
    },
    success: function (label) {
    },
    submitHandler: function (form) {
        MapApprover();
    }

});
    // Forward to Commercial Approver Validation
formCommApprover.validate({

    doNotHideMessage: true, //this option enables to show the error/success messages on tab switch.
    errorElement: 'span', //default input error message container
    errorClass: 'help-block help-block-error', // default input error message class
    focusInvalid: false, // do not focus the last invalid input
    rules: {
         txtfwdToCommApproverrem: {
            required: true
        }
     },

    messages: {

    },

    invalidHandler: function (event, validator) {
    },

    highlight: function (element) {
        $(element).closest('.col-md-9').addClass('has-error');

    },

    unhighlight: function (element) {
        $(element).closest('.col-md-9').removeClass('has-error');

    },
    errorPlacement: function (error, element) {

    },
    success: function (label) {
    },
    submitHandler: function (form) {
        // MapApprover();
        fnSendActivityToCommercial();
    }

});
}
var allUsers
function fetchRegisterUser(bidtypeid) {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "RegisterUser/fetchRegisterUser/?CustomerID=" + sessionStorage.getItem("CustomerID") + "&UserID=0&BidTypeID=" + bidtypeid + "&LoginUserID=" + encodeURIComponent(sessionStorage.getItem('UserID')) + "&AuthenticationToken=" + sessionStorage.getItem('AuthenticationToken'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data) {
            if (data.length > 0) {
                allUsers = data;
            }
            else {
                allUsers = '';
            }

        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }

    });

}
jQuery("#txtApprover").keyup(function () {
   $('#hdnApproverID').val('0')

});

jQuery("#txtApprover").typeahead({
    source: function (query, process) {
        var data = allUsers;
        usernames = [];
        map = {};
        var username = "";
        jQuery.each(data, function (i, username) {
            map[username.UserName] = username;
            usernames.push(username.UserName);
        });

        process(usernames);

    },
    minLength: 2,
    updater: function (item) {
        if (map[item].UserID != "0") {
            sessionStorage.setItem('hdnApproverid', map[item].UserID);
            $('#hdnApproverID').val(map[item].UserID)

        }
        else {
            gritternotification('Please select Approver  properly!!!');
        }

        return item;
    }

});

function MapApprover() {
    
    if ( $('#hdnApproverID').val() == "0") {
        $('.alert-danger').show();
        $('#spandanger').html('Please Select Approver Properly');
        Metronic.scrollTo($(".alert-danger"), -200);
        $('.alert-danger').fadeOut(7000);
        return false;
    }
    else {

        var Approvers = {
            "ApproverType": "T",
            "UserID": $('#hdnApproverID').val(),
            "RFQID": $('#hdnRfqID').val(),
            "CreatedBy": sessionStorage.getItem('UserID'),
            "ShowQuotedPrice": $('#drp_ShowPrice').val(),
            "CustomerID": sessionStorage.getItem('CustomerID')
        }
       //  alert(JSON.stringify(Approvers))
        jQuery.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: sessionStorage.getItem("APIPath") + "eRequestForQuotation/eRFQInsApprover",
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            crossDomain: true,
            async: false,
            data: JSON.stringify(Approvers),
            dataType: "json",
            success: function (data) {
                if (data.length > 0) {

                    if (data[0].OutPut == "1") {

                       // fnGetApproversPaintQuestionagain();
                        $('#msgSuccessApp').show();
                        $('#msgSuccessApp').html('Approver mapped successfully!');
                        Metronic.scrollTo($('#msgSuccessApp'), -200);
                        $('#msgSuccessApp').fadeOut(7000);
                        jQuery("#txtApprover").val('')
                        jQuery("#hdnApproverID").val('0')
                        $('#drp_ShowPrice').val('N')
                      
                        fnGetApprovers();
                        fetchrfqcomprative();
                         return false;

                    }
                    else {
                        $('#msgErrorApp').show();
                        $('#msgErrorApp').html('Technical Approver is already mapped for this RFQ.');
                        Metronic.scrollTo($('#msgErrorApp'), -200);
                        $('#msgErrorApp').fadeOut(7000);
                        return false;
                    }
                    
                    
                }
                //setTimeout(function () {
                //    $("#MapTechnicalApprover").modal("hide");
                //},7000)

            },
            error: function (xhr, status, error) {

                var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }

                return false;
                jQuery.unblockUI();
            }

        });
    }
}
function fnSendActivityToCommercial() {
    var Approvers = {
        "ApproverType": "C",
        "FromUserId": sessionStorage.getItem('UserID'),
        "Remarks": $('#txtfwdToCommApproverrem').val(),
        "RFQID": $('#hdnRfqID').val(),
        "CustomerID": sessionStorage.getItem('CustomerID'),
        "ActionType": "Forward",
        "Action": 'Forward'
    }
    // alert(JSON.stringify(Approvers))
    jQuery.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "eRFQApproval/eRFQCommercialActivity",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        crossDomain: true,
        async: false,
        data: JSON.stringify(Approvers),
        dataType: "json",
        success: function (data) {
            if (data.length > 0) {
                //alert(data[0].OutPut)
                if (data[0].OutPut == "1") {
                    
                    $('#msgSuccesscommApp').show();
                    $('#msgSuccesscommApp').html('RFQ Sent to Commercial Approver successfully!');
                    Metronic.scrollTo($('#msgSuccesscommApp'), -200);
                    $('#msgSuccesscommApp').fadeOut(7000);
                    $('#txtfwdToCommApproverrem').val('')
                    $('#btn_commercial').attr('disabled', 'disabled')
                    setTimeout(function () {
                        $("#FwdCommercialApprover").modal('hide');
                        fetchrfqcomprative();
                    }, 1000)
                }
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
     });
}
function fetchApproverRemarks() {
   // alert(sessionStorage.getItem("APIPath") + "eRFQApproval/FetchApproverRemarks/?UserID=" + encodeURIComponent(sessionStorage.getItem("UserID")) + "&RFQID=" + $('#hdnRfqID').val() + "&ApprovalType=C")
    jQuery.ajax({
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "eRFQApproval/FetchApproverRemarks/?UserID=" + encodeURIComponent(sessionStorage.getItem("UserID")) + "&RFQID=" + $('#hdnRfqID').val() + "&ApprovalType=C",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "GET",
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data) {
          
            $('#tblCommercialApproval').empty()
            $('#tblCommercialApprovalprev').empty()
            if (data.length > 0) {
                $('#tblCommercialApproval').removeClass('hide')
                $('#tblCommercialApprovalprev').removeClass('hide')
                $('#tblCommercialApproval').append('<tr><th>Action Taken By</th><th>Remarks</th><th>Action Type</th><th>Completion DT</th></tr>')
                $('#tblCommercialApprovalprev').append('<tr><th>Action Taken By</th><th>Remarks</th><th>Action Type</th><th>Completion DT</th></tr>')
                 for (var i = 0; i < data.length; i++) {

                     $('#tblCommercialApproval').append('<tr><td>' + data[i].ActionTakenBy + '</td><td>' + data[i].Remarks + '</td><td>' + data[i].FinalStatus + '</td><td>' + data[i].ReceiptDt + '</td></tr>')
                     $('#tblCommercialApprovalprev').append('<tr><td>' + data[i].ActionTakenBy + '</td><td>' + data[i].Remarks + '</td><td>' + data[i].FinalStatus + '</td><td>' + data[i].ReceiptDt + '</td></tr>')

                }
            }
            else {
                $('#tblCommercialApproval').addClass('hide')
                $('#tblCommercialApprovalprev').addClass('hide')
                $('#tblapprovalprocess').append('<tr><td colspan="15" style="text-align: center; color: Red">No record found</td></tr>')
                $('#tblapprovalprocessprev').append('<tr><td colspan="15" style="text-align: center; color: Red">No record found</td></tr>')
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
    })
}


$("#MapTechnicalApprover").on("hidden.bs.modal", function () {
    jQuery("#txtApprover").val('')
    $('#hdnApproverID').val('0')
    $('#drp_ShowPrice').val('N')
    $("#AppYes").attr('disabled', 'disabled')
    $("#AppNo").attr('disabled', 'disabled')
});
function fnGetApprovers() {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "eRequestForQuotation/eRFQDetails/?RFQID=" + $('#hdnRfqID').val() + "&CustomerID=" + sessionStorage.getItem('CustomerID') + "&UserID=" + sessionStorage.getItem('UserID'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data) {
            var str = "";
         
            jQuery("#tblapprovers").empty();
            if (data[0].Approvers.length > 0) {
                jQuery('#tblapprovers').append("<thead><tr><th class='bold' style='width:30%!important'>Approver</th><th class='bold' style='width:30%!important'>Email</th><th class='bold' style='width:15%!important'>Sequence</th><th class='bold' style='width:15%!important'>Show Price</th><th style='width:5%!important'></th></tr></thead>");
               
                for (var i = 0; i < data[0].Approvers.length; i++) {

                    if (data[0].Approvers[i].ApproverType != "C") {

                        str = "<tr><td>" + data[0].Approvers[i].UserName + "</td>";
                        str += "<td>" + data[0].Approvers[i].EmailID + "</td>";
                        str += "<td>" + data[0].Approvers[i].AdminSrNo + "</td>";
                        str += "<td>" + data[0].Approvers[i].ShowQuotedPrice + "</td>";
                        str += "<td><button type='button' class='btn btn-xs btn-danger' id=Removebtn" + i + " onclick=fnRemoveApprover(\'" + data[0].Approvers[i].SrNo + "'\,\'" + data[0].Approvers[i].ApproverType + "'\)><i class='glyphicon glyphicon-remove-circle'></i></button></td></tr>";
                        jQuery('#tblapprovers').append(str);
                    }

                }
            }
            else {
                // jQuery('#tblapprovers').append("<tr><td colspan=4>Map Approvers</td></tr>")
            }

        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
    })
}
function fnRemoveApprover(rowsrno, approvertype) {
    var Approvers = {
        "ApproverType": approvertype,
        "SrNo": rowsrno,
        "RFQID": $('#hdnRfqID').val()
    }
    //alert(JSON.stringify(Approvers))
    jQuery.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "eRequestForQuotation/eRFQApproveRemove",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        crossDomain: true,
        async: false,
        data: JSON.stringify(Approvers),
        dataType: "json",
        success: function (data) {
            if (data[0].OutPut == "1") {
                 fnGetApprovers();
                 $('#msgSuccessApp').show();
                 $('#msgSuccessApp').html('Approver removed successfully!');
                 Metronic.scrollTo($('#msgSuccessApp'), -200);
                 $('#msgSuccessApp').fadeOut(7000);
                return false;

            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
    })
}
function fnUpdateApproverFlag() {
    var Querystring = '';
    var checkedval = '';
    //for (var i = 0; i < Vendor.length; i++) {
       
    //    if ($("#AppYes" + Vendor[i].VendorID).is(":checked")) {
    //        checkedval = $("#AppYes" + Vendor[i].VendorID).val()
    //        $("#AppYes" + Vendor[i].VendorID).attr('disabled','disabled')
    //    }
    //    else {
    //        checkedval = $("#AppNo" + Vendor[i].VendorID).val()
    //        $("#AppNo" + Vendor[i].VendorID).removeAttr('disabled')
    //    }
       
    //    Querystring = Querystring + "Update eRFQVendorDetails set IsApproverRequired='" + checkedval + "' where VendorID=" + Vendor[i].VendorID + " and RFQID=" + $('#hdnRfqID').val() + ";";
    //}

        if ($("#AppYes").is(":checked")) {
            checkedval = $("#AppYes").val()
           // $("#AppYes").attr('disabled','disabled')
        }
        else {
            checkedval = $("#AppNo").val()
           // $("#AppNo").removeAttr('disabled')
        }

        Querystring = Querystring + "Update eRFQVendorDetails set IsApproverRequired='" + checkedval + "' where  RFQID=" + $('#hdnRfqID').val() + ";";//VendorID=" + Vendor[i].VendorID + " and
    var Attachments = {
        "RFQId": $('#hdnRfqID').val(),
        "QueryString": Querystring
        
    }
   // alert(JSON.stringify(Attachments))
    jQuery.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "eRFQReport/eUpdateApproverRequiredNot",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        crossDomain: true,
        async: false,
        data: JSON.stringify(Attachments),
        dataType: "json",
        success: function (data) {
            if (data[0].OutPut == "1") {
                fnGetApprovers();
                return;
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
        });
}

var str = '';
function checkForSelectedVendors() {

    //getting value for Checked Checheck boxes
    $(".chkReinvitation:checked").each(function(x, i) {
        str += $(this).val() + ',';

    });

    if (str == '') {
        $("#error").html("PLease select atleast one vendor");
        $(".alert-danger").show();
        Metronic.scrollTo($(".alert-danger"), -200);
        $(".alert-danger").fadeOut(7000);
        return false;

    } else {
        $("#modalreInviteDate").modal("show");
    }




}

function ReInviteVendorsForRFQ() {
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    str = str.substring(0, str.length - 1);
    $('#SaveExsist').attr('disabled', 'disabled')
    var data = {
        "RFQID": $("#hdnRfqID").val(),
        "VendorIDs": str,
        "ExtendedDate": $("#txtextendDate").val(),
        "RFQSubject": $("#RFQSubject").html(),
        "UserID": sessionStorage.getItem("UserID"),
        "ReInviteRemarks": $("#txtReInviteRemarks").val()
        
      }
   // alert(JSON.stringify(data))
    jQuery.ajax({
        url: sessionStorage.getItem("APIPath") + "eRFQReport/eRFQ_ReInviteVendor/",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "POST",
        data: JSON.stringify(data),
        contentType: "application/json; charset=utf-8",
        success: function(data, status, jqXHR) {
            if (data[0].IsSuccess == '1') {
                $("#modalreInviteDate").modal("hide");
                bootbox.alert("Re-Invitation For RFQ sent successfully", function() {                
                    location.reload();
                    $('#SaveExsist').removeAttr('disabled')
                    jQuery.unblockUI();
                });
            } else {
                alert("Some Error")
                $('#SaveExsist').removeAttr('disabled')
                jQuery.unblockUI();
            }

        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else{
                jQuery("#error").text(xhr.d);
                $('#SaveExsist').removeAttr('disabled')
                $("#modalreInviteDate").modal("hide");
            }
            return false;
            jQuery.unblockUI();
        }
        
    });

        
}

$('#btnPDF').click(function () {
    var encrypdata = fnencrypt("RFQID=" + $("#hdnRfqID").val()+"&FromPage=Analysis&BidID=" + 0+"&Version="+$('#ddlrfqVersion').val())
    var url = "ViewReportRFQ.html?param="+encrypdata;
    var win = window.open(url, "_blank");


    // var win = window.open('ViewReport2.html?BidID=' + BidID + '&BidTypeID=' + BidTypeID + '&BidForID=' + BidForID+', _blank');
    win.focus();
    //window.location = "ViewReport2.html?BidID=" + BidID + "&BidTypeID=" + BidTypeID + "&BidForID=" + BidForID
})


