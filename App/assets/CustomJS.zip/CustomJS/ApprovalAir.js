﻿var BidID = "";
var ButtonType = '';
var App1 = '';
jQuery(document).ready(function () {
    BidID = getUrlVars()["BidID"];
	App1 = getUrlVars()['App'];
    fillhelp(App1);
    FetchVendors(BidID);
    FetchTargetBid(BidID)
	
});

function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}
function FetchVendors(BidID) {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ApprovalAir/fetchVendor/?BidID=" + BidID + "&VendorType=YES&AuthenticationToken=" + sessionStorage.getItem('AuthenticationToken'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data) {
            jQuery("#ddlVendors,#ddlVendorsAdmin").empty();
            jQuery("#ddlVendors,#ddlVendorsAdmin").append(jQuery("<option ></option>").val("").html("Select"));
            for (var i = 0; i < data.length; i++) {
                jQuery("#ddlVendors,#ddlVendorsAdmin").append(jQuery("<option ></option>").val(data[i].VendorID).html(data[i].VendorName));
            }
            FetchRecomendedVendor(BidID)
        }
    });
    
}
function FetchTargetBid(bidid) {
    //alert('test')
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ApprovalAir/FetchTargetBid/?BidID=" + bidid,
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
            if (data.length > 0) {
              
                $('#tdfmin').text(data[0].TargetFreightMin);
                        $('#tdf45').text(data[0].TargetFreightPlus45)
                        $('#tdf100').text(data[0].TargetFreightPlus100)
                        $('#tdf300').text(data[0].TargetFreightPlus300)
                        $('#tdf500').text(data[0].TargetFreightPlus500)
                        $('#tdf1000').text(data[0].TargetFreightPlus1000)
                  
                        $('#tdxmin').text(data[0].TargetExWorksMin)
                        $('#tdx45').text(data[0].TargetExWorksPlus45)
                        $('#tdx100').text(data[0].TargetExWorksPlus100)
                        $('#tdx300').text(data[0].TargetExWorksPlus300)
                        $('#tdx500').text(data[0].TargetExWorksPlus500)
                        $('#tdx1000').text(data[0].TargetExWorksPlus1000)
            }
        }
    });
}

var FormValidation = function () {
    var validateModication = function () {
        var form1 = $('#formModify');
        var error1 = $('.alert-danger', form1);
        var success1 = $('.alert-success', form1);

        form1.validate({
            errorElement: 'span',
            errorClass: 'help-block',
            focusInvalid: false,
            ignore: "",
            rules: {
                txtfreightMin: {
                    required: true,
                    number: true,
                    minlength: 1,
                    maxlength: 10
                },
                txtfreight45: {
                    required: true,
                    number: true,
                    minlength: 1,
                    maxlength: 10
                },
                txtfreight100: {
                    required: true,
                    number: true,
                    minlength: 1,
                    maxlength: 10
                },
                txtfreight300: {
                    required: true,
                    number: true,
                    minlength: 1,
                    maxlength: 10
                },
                txtfreight500: {
                    required: true,
                    number: true,
                    minlength: 1,
                    maxlength: 10
                },
                txtfreight1000: {
                    required: true,
                    number: true,
                    minlength: 1,
                    maxlength: 10
                },
                 txtexworksMin: {
                    required: true,
                    number: true,
                    minlength: 1,
                    maxlength: 10
                },
                txtexworks45: {
                    required: true,
                    number: true,
                    minlength: 1,
                    maxlength: 10
                },
                txtexworks100: {
                    required: true,
                    number: true,
                    minlength: 1,
                    maxlength: 10
                },
                txtexworks300: {
                    required: true,
                    number: true,
                    minlength: 1,
                    maxlength: 10
                },
                txtexworks500: {
                    required: true,
                    number: true,
                    minlength: 1,
                    maxlength: 10
                },
                txtexworks1000: {
                    required: true,
                    number: true,
                    minlength: 1,
                    maxlength: 10
                }
            },
            messages: {
                txtfreightMin: {
                    required: "Please enter freight"
                },
                txtfreight45: {
                    required: "Please enter freight"
                },
                txtfreight100: {
                    required: "Please enter freight"
                },
                txtfreight300: {
                    required: "Please enter freight"
                },
                txtfreight500: {
                    required: "Please enter freight"
                },
                txtfreight1000: {
                    required: "Please enter freight"
                },
                txtexworksMin: {
                    required: "Please enter ex-works"
                },
                txtexworks45: {
                    required: "Please enter ex-works"
                },
                txtexworks100: {
                    required: "Please enter ex-works"
                },
                txtexworks300: {
                    required: "Please enter ex-works"
                },
                txtexworks500: {
                    required: "Please enter ex-works"
                },
                txtexworks1000: {
                    required: "Please enter ex-works"
                }
            },

            invalidHandler: function (event, validator) { //display error alert on form submit              
                success1.hide();
                error1.show();
               // App.scrollTo(error1, -300);
            },

            highlight: function (element) { // hightlight error inputs
                $(element)
                        .closest('.Input-group').addClass('has-error'); // set error class to the control group
            },

            unhighlight: function (element) { // revert the change done by hightlight
                $(element)
                        .closest('.Input-group').removeClass('has-error'); // set error class to the control group
            },

            success: function (label) {
                label
                        .closest('.Input-group').removeClass('has-error'); // set success class to the control group
            },

            submitHandler: function (form) {
                InsertBidModificationAir();
                //App.scrollTo(error1, -100);
            }
        });
    }
    var validateforwardedQuoteData = function () {
        var form1 = $('#formsubmitforwardbid');
        var error1 = $('.alert-danger', form1);
        var success1 = $('.alert-success', form1);
        form1.validate({
            errorElement: 'span',
            errorClass: 'help-block',
            focusInvalid: false,
            ignore: "",

            rules: {
                ddlVendorsAdmin: {
                    required: true
                },
                txtbidspecification: {
                    required: true
                }
            },
            messages: {
                ddlVendorsAdmin: {
                    required: "Please select Action"
                },
                txtbidspecification: {
                    required: "Please enter your comment"
                }
            },

            invalidHandler: function (event, validator) {              
                success1.hide();
                error1.show();
                // App.scrollTo(error1, -300);
            },

            highlight: function (element) {
                $(element)
                        .closest('.Input-group').addClass('has-error'); 
            },

            unhighlight: function (element) { 
                $(element)
                        .closest('.Input-group').removeClass('has-error');
            },

            success: function (label) {
                label
                        .closest('.Input-group').removeClass('has-error'); 
            },

            submitHandler: function (form) {
				if (AppStatus == 'Reverted') {
                    //if (ButtonType == 'Cancel') {
                      //  CancelBid(BidID);
                    //} else {
                        ApprovalAdmin();
                    //} 
                }
                else {
                    //if (ButtonType == 'Cancel') {
                      //  CancelBid(BidID);
                    //} else {
                        ForwardBid(BidID, BidTypeID, BidForID)
                    //}
                }
                //App.scrollTo(error1, -100)
            }
        });
    }
    var validateAppsubmitData = function () {
        var form1 = $('#frmsubmitapp');
        var error1 = $('.alert-danger', form1);
        var success1 = $('.alert-success', form1);
        form1.validate({
            errorElement: 'span',
            errorClass: 'help-block',
            focusInvalid: false,
            ignore: "",

            rules: {
                ddlActionType: {
                    required: true,
                },
                ddlVendors: {
                    required: true,
                },
                txtRemarksApp: {
                    required: true,
                }
            },
            messages: {
                ddlActionType: {
                    required: "Please select Action"
                },
                ddlVendors: {
                    required: "Please select vendor"
                },
                txtRemarksApp: {
                    required: "Please enter your comment"
                }
            },

            invalidHandler: function (event, validator) { //display error alert on form submit              
                success1.hide();
                error1.show();
                // App.scrollTo(error1, -300);
            },

            highlight: function (element) { // hightlight error inputs
                $(element)
                        .closest('.Input-group').addClass('has-error'); // set error class to the control group
            },

            unhighlight: function (element) { // revert the change done by hightlight
                $(element)
                        .closest('.Input-group').removeClass('has-error'); // set error class to the control group
            },

            success: function (label) {
                label
                        .closest('.Input-group').removeClass('has-error'); // set success class to the control group
            },

            submitHandler: function (form) {
                 //if (ButtonType != 'Cancel') {
                    ApprovalApp();                    
                //} else {                    
                  // CancelBid(BidID);
                //} 
				
               // App.scrollTo(error1, -100)
            }
        });
    }
    var validateformAwardedsubmit = function () {
        var form1 = $('#formAwardedsubmit');
        var error1 = $('.alert-danger', form1);
        var success1 = $('.alert-success', form1);
        form1.validate({
            errorElement: 'span',
            errorClass: 'help-block',
            focusInvalid: false,
            ignore: "",

            rules: {
                txtRemarksAward: {
                    required: true
                }
            },
            messages: {
                txtRemarksAward: {
                    required: "Please enter youe comment"
                }
            },

            invalidHandler: function (event, validator) { //display error alert on form submit              
                success1.hide();
                error1.show();
                
            },

            highlight: function (element) { // hightlight error inputs
                $(element)
                        .closest('.Input-group').addClass('has-error'); // set error class to the control group
            },

            unhighlight: function (element) { // revert the change done by hightlight
                $(element)
                        .closest('.Input-group').removeClass('has-error'); // set error class to the control group
            },

            success: function (label) {
                label
                        .closest('.Input-group').removeClass('has-error'); // set success class to the control group
            },

            submitHandler: function (form) {               
                 //if (ButtonType != 'Cancel') {
                   AwardBid(BidID)                 
                //} else {                    
                  // CancelBid(BidID);
                //}
            }
        });
    }
  
    var handleWysihtml5 = function () {
        if (!jQuery().wysihtml5) {
            return;
        }
        if ($('.wysihtml5').size() > 0) {
            $('.wysihtml5').wysihtml5({
                "stylesheets": ["assets/plugins/bootstrap-wysihtml5/wysiwyg-color.css"]
            });
        }
    }
    return {
        init: function () {
            handleWysihtml5();
            validateModication();
            validateforwardedQuoteData();
            validateAppsubmitData();
            validateformAwardedsubmit();
        }
    };
} ();


function fillhelp(App1) {

    if (App1 == 'N') {
        $('#Approver').show()
    }
    
    else  {
        $('#awarded').show()
    }

}

jQuery("#btnCancelbidAdmin").click(function () {
    ButtonType = 'Cancel'
    cancelBtnclick();
});

jQuery("#btnCancelbidApp").click(function () {
    ButtonType = 'Cancel'
    cancelBtnclick();
});

jQuery("#btnSubmitApp").click(function () {
    ButtonType = ''
});

jQuery("#btnSubmitAdmin").click(function () {
    ButtonType = ''
});

jQuery("#btnCancelbidAward").click(function () {
    ButtonType = 'Cancel'
    cancelBtnclick();
});

jQuery("#btnSubmitAward").click(function () {
    ButtonType = ''
});
