﻿
jQuery('#btnpush').click(function (e) {
    jQuery('#approverList > option:selected').appendTo('#mapedapprover');
});
jQuery('#btnpull').click(function (e) {
    jQuery('#mapedapprover > option:selected').appendTo('#approverList');
});


function fetchVendorparticipanType() {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "BidType/fetchBidType/?CustomerID=" + sessionStorage.getItem("CustomerID") + "&BidTypeID=0&excludeStatus=N&UserID=" + sessionStorage.getItem('UserID') + "&AuthenticationToken=" + sessionStorage.getItem('AuthenticationToken'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (bidTypedata) {
            var strbidtypes = "<div id=\"divrblist\" class=\"checkbox-list\">";
            for (i = 0; i < bidTypedata.length; i++) {
                //strbidtypes += "<label><div class=\"radio\" style=\"cursor:pointer\" ><span id=\"spanrb\"><input type=\"radio\" grou name=\"rbradio\"  onchange=\"Validate(this)\" value=" + bidTypedata[i].BidTypeID + "></span></div>" + bidTypedata[i].BidTypeName + " </label>";
                strbidtypes += "<div class=\"col-md-3\">";
                strbidtypes += "<div class=\"checker\" id=\"uniform-chkbidTypes\"><span  id=\"spanchecked\"><input type=\"checkbox\" id=\"chkBidType\" style=\"cursor:pointer\"  onchange=\"Validate(this)\" name=\"chkBidType\"/></span></div>";
                strbidtypes += "<label class=\"control-label\" id=\"BidTypeID\">&nbsp;&nbsp;" + bidTypedata[i].BidTypeName + "</label><input type=\"hidden\" id=\"hdnBidTypeID\" value=" + bidTypedata[i].BidTypeID + " /></div>";

            }
            strbidtypes += "</div>";
            jQuery("div#divbidtypelist").append(strbidtypes);
        }
    });
}

function FetchContinent(ContinentID) {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ConfigureBid/FetchContinent/?ContinentID=" + ContinentID + "&excludeStatus=N",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        dataType: "json",
        success: function (data) {
            jQuery("#ddlSector").empty();
            jQuery("#ddlSector").append(jQuery("<option ></option>").val("").html("Select"));
            for (var i = 0; i < data.length; i++) {
                jQuery("#ddlSector").append(jQuery("<option></option>").val(data[i].ContinentId).html(data[i].ContinentNm));
            }
        }
    });
    jQuery("#ddlCountry").append(jQuery("<option ></option>").val("").html("Select"));
}
jQuery("#ddlSector").change(function () {
    var continentID = $("#ddlSector option:selected").val();
    var countryID = "0";
    fetchCountry(continentID, countryID)
});
function fetchCountry(continentID,countryID) {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ConfigureBid/fetchCountry/?ContinentId=" + continentID + "&CountryID=" + countryID + "&excludeStatus=N",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        dataType: "json",
        success: function (data) {
            jQuery("#ddlCountry").empty();
            jQuery("#ddlCountry").append(jQuery("<option ></option>").val("").html("Select"));
            for (var i = 0; i < data.length; i++) {
                jQuery("#ddlCountry").append(jQuery("<option ></option>").val(data[i].CountryId).html(data[i].CountryNm));
            } 
        }
    });
}
function fetchBidTypeMapping() {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ConfigureBid/fetchBidTypeMapping/?CustomerID=" + sessionStorage.getItem("CustomerID") + "&BidTypeID=0",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        dataType: "json",
        success: function (data) {
            jQuery("#ddlBidForId").empty();
            jQuery("#ddlBidForId").append(jQuery("<option ></option>").val("").html("Select"));
            for (var i = 0; i < data.length; i++) {
                jQuery("#ddlBidForId").append(jQuery("<option ></option>").val(data[i].BidTypeID).html(data[i].BidTypeName));
            }
            jQuery("#ddlBidForId").val('3').attr("selected", "selected");
        }
    });
    fetchBidFor("3");
    jQuery("#ddlBidForId").prop("disabled", true);
   
}

function fetchBidFor(BidTypeID) {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ConfigureBid/fetchBidFor/?BidTypeID=" + BidTypeID,
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        dataType: "json",
        success: function (data) {
            jQuery("#ddlBidFor").empty();
            jQuery("#ddlBidFor").append(jQuery("<option ></option>").val("").html("Select"));
            for (var i = 0; i < data.length; i++) {
                jQuery("#ddlBidFor").append(jQuery("<option></option>").val(data[i].BidForID).html(data[i].BidFor));
            }
        }
    });
}

function FetchCurrency(CurrencyID) {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ConfigureBid/FetchCurrency/?CurrencyID=" + CurrencyID + "&excludeStatus=N",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        dataType: "json",
        success: function (data) {
            jQuery("#dropCurrency").empty();
            jQuery("#dropCurrency").append(jQuery("<option ></option>").val("").html("Select"));
            for (var i = 0; i < data.length; i++) {
                jQuery("#dropCurrency").append(jQuery("<option></option>").val(data[i].CurrencyId).html(data[i].CurrencyNm));
            }
        }
    });
}



function FetchVender(ByBidTypeID) {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ConfigureBid/FetchVendor/?ByBidTypeID=" + ByBidTypeID,
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        dataType: "json",
        success: function (data) {
            jQuery("#ddlvendor").empty();
            for (var i = 0; i < data.length; i++) {
                jQuery("#ddlvendor").append(jQuery("<option></option>").val(data[i].VendorID).html(data[i].VendorName));
            }
        }
    });
}

function fetchRegisterUser(bidid) {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "RegisterUser/fetchRegisterUser/?CustomerID=" + sessionStorage.getItem("CustomerID") + "&UserID=0&BidID=" + bidid + "&AuthenticationToken=" + sessionStorage.getItem('AuthenticationToken'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data) {
            jQuery("#approverList").empty();
            for (var i = 0; i < data.length; i++) {
                jQuery("#approverList").append(jQuery("<option></option>").val(data[i].UserID).html(data[i].UserName));
            }
        }
    });
}

//function fetchRegisterUser(bidid) {
//    var BidDetails = {
//        "SectorID": sessionStorage.getItem('CustomerID'),
//        "CountryID": jQuery("#hdnUserID").val(),
//        "BidTypeID": jQuery("#txtUsername").val(),
//        "BidForID": jQuery("#txtemail").val(),
//        "BidSubject": jQuery("#txtmobilno").val(),
//        "BidDescription": jQuery("#txtuserrole").val(),
//        "BidDate": jQuery("#txtmobilno").val(),
//        "BidTime": jQuery("#txtuserrole").val(),
//        "BidDuration": jQuery("#txtmobilno").val(),
//        "Currency": jQuery("#txtuserrole").val(),
//        "AuthenticationToken=" : sessionStorage.getItem('AuthenticationToken'),
//    };
//    jQuery.ajax({
//        type: "GET",
//        contentType: "application/json; charset=utf-8",
//        url: sessionStorage.getItem("APIPath") + "RegisterUser/fetchRegisterUser"&AuthenticationToken=" + sessionStorage.getItem('AuthenticationToken'),
//        cache: false,
//        crossDomain: true,
//        dataType: "json",
//        success: function (data) {
//            jQuery("#approverList").empty();
//            for (var i = 0; i < data.length; i++) {
//                jQuery("#approverList").append(jQuery("<option></option>").val(data[i].UserID).html(data[i].UserName));
//            }
//        }
//    });
//}


















////  validation parts ///////

















var FormValidation = function () {
    var ValidateConfigureGeneralBidForm = function () {
        var form1 = $('#entryForm');
        var error1 = $('.alert-danger', form1);
        var success1 = $('.alert-success', form1);

        form1.validate({
            errorElement: 'span', //default input error message container
            errorClass: 'help-block', // default input error message class
            focusInvalid: false, // do not focus the last invalid input
            ignore: "",
            rules: {
                txtBidSubject: {
                    required: true
                }
            },
            messages: {
                txtBidSubject: {
                    required: "Please enter product name"
                }
            },

            invalidHandler: function (event, validator) { //display error alert on form submit              
                success1.hide();
                error1.show();
                //App.scrollTo(error1, -200);
            },

            highlight: function (element) { // hightlight error inputs
                $(element)
                        .closest('.form-group').addClass('has-error'); // set error class to the control group
            },

            unhighlight: function (element) { // revert the change done by hightlight
                $(element)
                        .closest('.form-group').removeClass('has-error'); // set error class to the control group
            },

            success: function (label) {
                label
                        .closest('.form-group').removeClass('has-error'); // set success class to the control group
            },

            submitHandler: function (form) {
                //AddProduct();
                //clearForm();
            }
        });
    }


    var handleWysihtml5 = function () {
        if (!jQuery().wysihtml5) {
            return;
        }
        if ($('.wysihtml5').size() > 0) {
            $('.wysihtml5').wysihtml5({
                "stylesheets": ["assets/plugins/bootstrap-wysihtml5/wysiwyg-color.css"]
            });
        }
    }

    return {
        init: function () {
            handleWysihtml5();
            ValidateConfigureGeneralBidForm();
        }
    };

} ();