﻿var APIPath = sessionStorage.getItem("APIPath");
clearsession()

$(".thousandseparated").inputmask({
    alias: "decimal",
    rightAlign: false,
    groupSeparator: ",",
    radixPoint: ".",
    autoGroup: true,
    integerDigits: 40,
    digitsOptional: true,
    allowPlus: false,
    allowMinus: false,
    'removeMaskOnSubmit': true

});
$('#txtbid,#txtvendor,#txtBidDurationPrev,#txtvendorSurrogateBid,#txtdestinationPort,#txtshortname,#txtpricefrequency').maxlength({
    limitReachedClass: "label label-danger",
    alwaysShow: true
});
//var form1 = $('#entryForm');
$(".surrogateFormElements").hide();
var error1 = $('.alert-danger');
var success1 = $('.alert-success');
var error2 = $('#errormapdiv');
var erroropenbid = $('#errorOpenbid'); 
var errorremainder = $('#errorsendremainder');
var success2 = $('#successmapdiv');
var successopenbid = $('#successopenbid');
var succesremainder = $('#successremainder');
var hdnSeId = 0;
var isBidEventChanged = false;
var isRunningBid = '';
var _bidClosingType = '';

// edit mode inputs for events editddlbid

jQuery("#divbidDatePrevtab_0").hide();
$("#btn-submit-datetime").hide();
    jQuery("#divbidTimePrevtab_0").hide();
    jQuery("#divbidTermsFilePrevtab_0").hide();
    jQuery("#divbidAttachFilePrevtab_0").hide();
    jQuery("#divbidItemsPrevtab_0").hide();
    jQuery("#eventDetailstab_0").hide();
    jQuery("#btnuserConfirmation").hide();
    jQuery("#eventUpdateStatusTab5").hide();
    jQuery("#divbidShowL1L2").hide();
    
    
    $("#editValuesModal").on("hidden.bs.modal", function () {
        jQuery("#divbidDatePrevtab_0").hide();
        $("#btn-submit-datetime").hide();
        $("#btn-submit-modal").show();
        jQuery("#divbidTimePrevtab_0").hide();
        jQuery("#divbidTermsFilePrevtab_0").hide();
        jQuery("#divbidAttachFilePrevtab_0").hide();
        jQuery("#divbidItemsPrevtab_0").hide();
        jQuery("#divbidShowL1L2").hide();
    });

//
//jQuery("#").hide();
//

function FormValidate() {
    sessionStorage.removeItem("shname")
    sessionStorage.removeItem("price")
    sessionStorage.removeItem("subtime")
    sessionStorage.removeItem("psid")
    sessionStorage.removeItem("psheaderid")
    sessionStorage.removeItem("VehicleID")
    sessionStorage.removeItem("OriginID")
    sessionStorage.removeItem("DestinationID")
    sessionStorage.removeItem("QPriceD")
    sessionStorage.removeItem("SubmissionTymD")
    sessionStorage.removeItem("VHeaderID")
     sessionStorage.removeItem("persquarefeet")
    sessionStorage.removeItem("manpower")
    sessionStorage.removeItem("infra")
    sessionStorage.removeItem("utility")
    sessionStorage.removeItem("SubmissionTymW")
    sessionStorage.removeItem("fixedManagement")
    sessionStorage.removeItem("PriceSea")
    sessionStorage.removeItem("ExworkSea")
    sessionStorage.removeItem("SubmissionTymSea")
    sessionStorage.removeItem("fmin")
    sessionStorage.removeItem("f45")
    sessionStorage.removeItem("f100")
    sessionStorage.removeItem("f300")
    sessionStorage.removeItem("f500")
    sessionStorage.removeItem("f1000")
    sessionStorage.removeItem("exmin")
    sessionStorage.removeItem("ex45")
    sessionStorage.removeItem("ex100")
    sessionStorage.removeItem("ex300")
    sessionStorage.removeItem("ex500")
    sessionStorage.removeItem("ex1000")
    sessionStorage.removeItem("subtym")
    $('#maphead').validate({
        doNotHideMessage: true, //this option enables to show the error/success messages on tab switch.
        errorElement: 'span', //default input error message container
        errorClass: 'help-block help-block-error', // default input error message class
        focusInvalid: false, // do not focus the last invalid input

        rules: {
            txtremarks: {
                required: true
            }
        },
        messages: {
            txtremarks: {
                required: "Remarks is required."
            }
        },

        errorPlacement: function (error, element) { // render error placement for each input type
            error.insertAfter(element); // for other inputs, just perform default behavior
        },

        invalidHandler: function (event, validator) { //display error alert on form submit
          
            success2.hide();
            jQuery("#err").text("You have some form errors. Please check below.");
            error2.show();
            error2.fadeOut(5000);
            App.scrollTo(error2, -200);
        },

        highlight: function (element) { // hightlight error inputs
            $(element)
                .closest('.col-lg-4').removeClass('has-success').addClass('has-error'); // set error class to the control group
        },

        unhighlight: function (element) { // revert the change done by hightlight
            $(element)
                .closest('.col-lg-4').removeClass('has-error'); // set error class to the control group
        },

        success: function (label) {
            label.closest('.col-lg-4').removeClass('has-error').addClass('has-success');
            label.remove(); // remove error label here

        },
        submitHandler: function (form) {
            error2.hide();
            if (sessionStorage.getItem("hdnbidtypeid") == 7) {
                deletePSquote();
            }
            else if (sessionStorage.getItem("hdnbidtypeid") == 4) {
                deleteDomesticQuote()
            }
            else if (sessionStorage.getItem("hdnbidtypeid") == 5) {
                deletewarehouseQuote()
            }
            else if (sessionStorage.getItem("hdnbidtypeid") == 3) {
                deleteseaQuote()
            }
            else if (sessionStorage.getItem("hdnbidtypeid") == 2) {
                deleteAirQuote()
            }
            else if (sessionStorage.getItem("hdnbidtypeid") == 6) {
                deletePEFAquote();
            }
            
        }
    });

}


function fetchUserBids() {
  
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
  //  alert(APIPath + "ResetInviteVendor/fetchBidForSelfUserManage/?UserID=" + encodeURIComponent(sessionStorage.getItem("UserID")) + "&BidID=0&CustomerID=" + sessionStorage.getItem('CustomerID'))
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: APIPath + "ResetInviteVendor/fetchBidForSelfUserManage/?UserID=" + encodeURIComponent(sessionStorage.getItem("UserID")) + "&BidID=0&CustomerID=" + sessionStorage.getItem('CustomerID'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        data: "{}",
        cache: false,
        dataType: "json",
        success: function (data) {
            //jQuery('#ddlbid').empty();
            if (data.length > 0) {
                
                sessionStorage.setItem('hdnAllBids', JSON.stringify(data));
                //jQuery('#ddlbid').append(jQuery("<option ></option>").val("").html("Select Bid"));
                //for (var i = 0; i < data.length; i++) {
                //    jQuery('#ddlbid').append(jQuery("<option ></option>").val(data[i].BidId).html(data[i].BidSubject));
                //}
            }
            else {
                //$('#ddlbid').append(jQuery("<option ></option>").val("").html("Select Bid"));
                error1.show();
                $('#spandanger').html('No pending bids for which you can invite vendors.!');
                error1.fadeOut(6000);
                App.scrollTo(error1, -200);
               
            }
          
            jQuery.unblockUI();

        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else{
                alert("error");
            }       
            return false;
            jQuery.unblockUI();
        }
      
    });
}


//jQuery('#ddlbid').change(function() {
//    var data = sessionStorage.getItem('hdnAllBids');
//    var _thisVal = $(this).val();

//    if (_thisVal == '') {
//        sessionStorage.setItem('hdnbid', '0');
//        sessionStorage.setItem("hdnbidtypeid", '0')
//        $('#inviteVendorBody').hide();
//    }
//    else {
//        jQuery("#eventUpdateStatusTab5").show(); 
        
//        hdnSeId = 0;
//        isRunningBid= '';
//        var isBidEventChanged = false;
//        jQuery("#btnuserConfirmation").hide();
//        sessionStorage.setItem('hdnbid', _thisVal);
//        jQuery.each(jQuery.parseJSON(data), function(i, bid) {
//            if (bid.BidId == _thisVal) {
//                sessionStorage.setItem("hdnbidtypeid", bid.BidTypeID)
//            }
//        });        
//        fetchvendors(_thisVal);
//        FetchVenderNotInvited(_thisVal)
//        fetchallexportdetails(); // For Time Extension feature added on 11 Nov
//    }
//});

jQuery("#txtbid").typeahead({
    source: function (query, process) {
        var data = sessionStorage.getItem('hdnAllBids');
        usernames = [];
        map = {};
        var username = "";
        jQuery.each(jQuery.parseJSON(data), function (i, username) {
            map[username.BidSubject] = username;
            usernames.push(username.BidSubject);
        });

        process(usernames);

    },
    minLength: 2,
    updater: function (item) {
        if (map[item].BidId != "0") {
                    jQuery("#eventUpdateStatusTab5").show(); 

                    hdnSeId = 0;
                    isRunningBid= '';
                    var isBidEventChanged = false;
                    jQuery("#btnuserConfirmation").hide();
                    sessionStorage.setItem('hdnbid', map[item].BidId);
                    jQuery("#ddlbid").val(map[item].BidId);
           
                    sessionStorage.setItem("hdnbidtypeid", map[item].BidTypeID)
                            
                    fetchvendors(map[item].BidId);
                    FetchVenderNotInvited(map[item].BidId)
                    fetchallexportdetails(); // For Time Extension feature added on 11 Nov
                   
         }
        else {
            gritternotification('Please select Bid  properly!!!');
            sessionStorage.setItem('hdnbid', '0');
                    sessionStorage.setItem("hdnbidtypeid", '0')
                    $('#inviteVendorBody').hide();
                    jQuery("#ddlbid").val(0);
        }
        
        return item;
    }

});
//jQuery("#txtbid").keyup(function () {
   
//    sessionStorage.setItem('hdnbid', '0');
//    sessionStorage.setItem("hdnbidtypeid", '0')
//    jQuery("#ddlbid").val(0);

//});
function fetchvendors(bidid) {
    
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
   // alert(APIPath + "ResetInviteVendor/fetchBidsAuto/?UserID=" + encodeURIComponent(sessionStorage.getItem("UserID")) + "&BidID=" + bidid + "&CustomerID=" + sessionStorage.getItem('CustomerID'))
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: APIPath + "ResetInviteVendor/fetchBidsAuto/?UserID=" + encodeURIComponent(sessionStorage.getItem("UserID")) + "&BidID=" + bidid + "&CustomerID=" + sessionStorage.getItem('CustomerID'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        data: "{}",
        cache: false,
        dataType: "json",
        success: function (data) {
            jQuery('#ddlvendors').empty()
            if (data.length > 0) {
                sessionStorage.setItem('hdnAllBidsVendor', JSON.stringify(data));
                //alert(JSON.stringify(data))
                jQuery('#ddlvendors').append(jQuery("<option ></option>").val("0").html("Select Vendor"));
                for (var i = 0; i < data.length; i++) {
                    jQuery('#ddlvendors').append(jQuery("<option ></option>").val(data[i].VendorID).html(data[i].VendorName));
                }
            }
            else {
                error1.show();
                $('#spandanger').html('Bid not mapped');
                error1.fadeOut(3000);
                App.scrollTo(error1, -200);

            }
            //  alert(sessionStorage.getItem('hdnAllBids'))
            jQuery.unblockUI();

        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else {
                alert("error");
            }
            return false;
            jQuery.unblockUI();
        }
    });
}
function fetchparticationQuotes() {
    var url = '';
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    //alert(APIPath + "RemoveParticipatedQuotedPrices/fetchPSQuotedPrices/?BidID=" + $('#ddlbid').val() + "&VendorID=" + $('#ddlvendors').val())
    if( sessionStorage.getItem("hdnbidtypeid")==7){
        url=APIPath + "RemoveParticipatedQuotedPrices/fetchPSQuotedPrices/?BidID=" + $('#ddlbid').val() + "&VendorID=" + $('#ddlvendors').val();
    }
    else if (sessionStorage.getItem("hdnbidtypeid") == 6) {
        url = APIPath + "RemoveParticipatedQuotedPrices/fetchPEFAQuotedPrices/?BidID=" + $('#ddlbid').val() + "&VendorID=" + $('#ddlvendors').val();
    }
    else if (sessionStorage.getItem("hdnbidtypeid") == 4) {
        url = APIPath + "RemoveParticipatedQuotedPrices/fetchdomesticQuotedPrices/?BidID=" + $('#ddlbid').val() + "&VendorID=" + $('#ddlvendors').val();
    }
    else  {
        url = APIPath + "RemoveParticipatedQuotedPrices/fetchQuotedPrices/?BidID=" + $('#ddlbid').val() + "&VendorID=" + $('#ddlvendors').val();
    }
   // alert(url)
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        url: url,
        data: "{}",
        cache: false,
        dataType: "json",
        success: function (data) {
            $('#tblquotedprices').show()
            jQuery('#tblquotedprices').empty()
            var shortname = "";
            if (data.length > 0) {
                if (sessionStorage.getItem("hdnbidtypeid") == 7) {
                    $('#tbllbl').removeClass('display-none')
                    $('#tbldiv').removeClass('col-lg-12')
                    $('#tbldiv').addClass('col-lg-10')
                    $('#tblquotedprices').append('<thead><tr style="background: gray; color: #FFF"><th>ShortName</th><th>Quoted Price</th><th>Submission Time</th><th>Action</th></tr></thead>')
                    for (var i = 0; i < data.length; i++) {
                        //alert(data[i].PSHeaderID)
                         shortname = (data[i].ShortName).replace(/(\r\n|\n|\r)/gm, "");
                        $('#tblquotedprices').append('<tr><td>' + data[i].ShortName + '</td><td>' + data[i].QuotedPrice + '</td><td>' + data[i].SubmissionTime + '</td><td><a href="#" class="btn  btn-icon-only btn-danger" onclick="removeQuotationPS(\'' + shortname + '\',\'' + data[i].QuotedPrice + '\',\'' + data[i].SubmissionTime + '\',\'' + data[i].PSID + '\',\'' + data[i].PSHeaderID + '\')"><i class="glyphicon glyphicon-remove-circle"></i></a></td></tr>')
                    }
                }
                else if (sessionStorage.getItem("hdnbidtypeid") == 4) {
                    $('#tbllbl').removeClass('display-none')
                    $('#tbldiv').removeClass('col-lg-12')
                    $('#tbldiv').addClass('col-lg-10')
                    $('#tblquotedprices').append('<thead><tr style="background: gray; color: #FFF"><th>VehicleType</th><th>Origin</th><th>Destination</th><th>Quoted Price</th><th>Submission Time</th><th>Action</th></tr></thead>')
                    for (var i = 0; i < data.length; i++) {
                        $('#tblquotedprices').append('<tr><td>' + data[i].VehicleTypeName + '</td><td>' + data[i].OriginName + '</td><td>' + data[i].DestinationName + '</td><td>' + data[i].QuotedPrice + '</td><td>' + data[i].SubmissionTime + '</td><td><a href="#" class="btn  btn-icon-only btn-danger" onclick="removeQuotationDOM(\'' + data[i].VehicleID + '\',\'' + data[i].OriginID + '\',\'' + data[i].DestinationID + '\',\'' + data[i].QuotedPrice + '\',\'' + data[i].SubmissionTime + '\',\'' + data[i].VDomesticHeaderID + '\')"><i class="glyphicon glyphicon-remove-circle"></i></a></td></tr>')
                    }
                }
                else if (sessionStorage.getItem("hdnbidtypeid") == 5)
                {
                    $('#tbllbl').removeClass('display-none')
                    $('#tbldiv').removeClass('col-lg-12')
                    $('#tbldiv').addClass('col-lg-10')
                    $('#tblquotedprices').append('<thead><tr style="background: gray; color: #FFF"><th>PerSquareFeetRate</th><th>ManPowerCost</th><th>InfrastructureCost</th><th>UtilitiesCost</th><th>FixedManagementFee</th><th>Submission Time</th><th>Action</th></tr></thead>')
                    for (var i = 0; i < data.length; i++) {
                        $('#tblquotedprices').append('<tr><td>' + data[i].PerSquareFeetRate + '</td><td>' + data[i].ManPowerCost + '</td><td>' + data[i].InfrastructureCost + '</td><td>' + data[i].UtilitiesCost + '</td><td>' + data[i].FixedManagementFee + '</td><td>' + data[i].SubmissionTime + '</td><td><a href="#" class="btn  btn-icon-only btn-danger" onclick="removeQuotationWare(\'' + data[i].PerSquareFeetRate + '\',\'' + data[i].ManPowerCost + '\',\'' + data[i].InfrastructureCost + '\',\'' + data[i].UtilitiesCost + '\',\'' + data[i].SubmissionTime + '\',\'' + data[i].FixedManagementFee + '\')"><i class="glyphicon glyphicon-remove-circle"></i></a></td></tr>')
                    }
                }
                else if (sessionStorage.getItem("hdnbidtypeid") == 3) {
                    $('#tbllbl').removeClass('display-none')
                    $('#tbldiv').removeClass('col-lg-12')
                    $('#tbldiv').addClass('col-lg-10')
                    $('#tblquotedprices').append('<thead><tr style="background: gray; color: #FFF"><th>Price</th><th>Ex-Works</th><th>Submission Time</th><th>Action</th></tr></thead>')
                    for (var i = 0; i < data.length; i++) {
                        $('#tblquotedprices').append('<tr><td>' + data[i].Price + '</td><td>' + data[i].ExWorks + '</td><td>' + data[i].SubmissionTime + '</td><td><a href="#" class="btn  btn-icon-only btn-danger" onclick="removeQuotationSea(\'' + data[i].Price + '\',\'' + data[i].ExWorks + '\',\'' + data[i].SubmissionTime + '\')"><i class="glyphicon glyphicon-remove-circle"></i></a></td></tr>')
                    }
                }
                else if (sessionStorage.getItem("hdnbidtypeid") == 2) {
                    $('#tbllbl').addClass('display-none')
                    $('#tbldiv').removeClass('col-lg-10')
                    $('#tbldiv').addClass('col-lg-12')
                    $('#tblquotedprices').append('<thead><tr style="background: gray; color: #FFF"><th>Action</th><th>Submission Time</th><th>FreightMin</th><th>FreightPlus45</th><th>FreightPlus100</th><th>FreightPlus300</th><th>FreightPlus500</th><th>FreightPlus1000</th><th>ExWorksMin</th><th>ExWorksPlus45</th><th>ExWorksPlus100</th><th>ExWorksPlus300</th><th>ExWorksPlus500</th><th>ExWorksPlus1000</th></tr></thead>')
                    for (var i = 0; i < data.length; i++) {
                        
                        $('#tblquotedprices').append('<tr><td><a href="#" class="btn  btn-icon-only btn-danger" onclick="removeQuotationair(\'' + data[i].FreightMin + '\',\'' + data[i].FreightPlus45 + '\',\'' + data[i].FreightPlus100 + '\',\'' + data[i].FreightPlus300 + '\',\'' + data[i].FreightPlus500 + '\',\'' + data[i].FreightPlus1000 + '\',\'' + data[i].ExWorksMin + '\',\'' + data[i].ExWorksPlus45 + '\',\'' + data[i].ExWorksPlus100 + '\',\'' + data[i].ExWorksPlus300 + '\',\'' + data[i].ExWorksPlus500 + '\',\'' + data[i].ExWorksPlus1000 + '\',\'' + data[i].SubmissionTime + '\')"><i class="glyphicon glyphicon-remove-circle"></i></a></td><td>' + data[i].SubmissionTime + '</td><td>' + data[i].FreightMin + '</td><td>' + data[i].FreightPlus45 + '</td><td>' + data[i].FreightPlus100 + '</td><td>' + data[i].FreightPlus300 + '</td><td>' + data[i].FreightPlus500 + '</td><td>' + data[i].FreightPlus1000 + '</td><td>' + data[i].ExWorksMin + '</td><td>' + data[i].ExWorksPlus45 + '</td><td>' + data[i].ExWorksPlus100 + '</td><td>' + data[i].ExWorksPlus300 + '</td><td>' + data[i].ExWorksPlus500 + '</td><td>' + data[i].ExWorksPlus1000 + '</td></tr>')
                    }
                }
                else if (sessionStorage.getItem("hdnbidtypeid") == 6) {
                    $('#tbllbl').removeClass('display-none')
                    $('#tbldiv').removeClass('col-lg-12')
                    $('#tbldiv').addClass('col-lg-10')
                    $('#tblquotedprices').append('<thead><tr style="background: gray; color: #FFF"><th>ShortName</th><th>Quoted Price</th><th>Submission Time</th><th>Action</th></tr></thead>')
                    for (var i = 0; i < data.length; i++) {
                        shortname = (data[i].ShortName).replace(/(\r\n|\n|\r)/gm, "");
                        $('#tblquotedprices').append('<tr><td>' + data[i].ShortName + '</td><td>' + data[i].QuotedPrice + '</td><td>' + data[i].SubmissionTime + '</td><td><a href="#" class="btn  btn-icon-only btn-danger" onclick="removeQuotationPS(\'' + shortname + '\',\'' + data[i].QuotedPrice + '\',\'' + data[i].SubmissionTime + '\',\'' + data[i].PSID + '\',\'' + 0 + '\')"><i class="glyphicon glyphicon-remove-circle"></i></a></td></tr>')
                    }
                }
            }
            else {
                $('#tblquotedprices').append('<tr><td>No Record found</td></tr>');
                // $('#tblquotedprices').hide()
            }
            
            jQuery.unblockUI();
        },
        
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
           
            return false;
            jQuery.unblockUI();
        }
    });

}
function removeQuotationair(fmin,f45,f100,f300,f500,f1000,exmin,ex45,ex100,ex300,ex500,ex1000,subtym) {
    $('#deletepopup').modal('show')
    sessionStorage.setItem("fmin", fmin)
    sessionStorage.setItem("f45", f45)
    sessionStorage.setItem("f100", f100)
    sessionStorage.setItem("f300", f300)
    sessionStorage.setItem("f500", f500)
    sessionStorage.setItem("f1000", f1000)
    sessionStorage.setItem("exmin", exmin)
    sessionStorage.setItem("ex45", ex45)
    sessionStorage.setItem("ex100", ex100)
    sessionStorage.setItem("ex300", ex300)
    sessionStorage.setItem("ex500", ex500)
    sessionStorage.setItem("ex1000", ex1000)
    sessionStorage.setItem("subtym", subtym)
}
function removeQuotationPS(shname, price, subtime, psid, psheaderid) {
    $('#deletepopup').modal('show')
    sessionStorage.setItem("shname", shname)
    sessionStorage.setItem("price", price)
    sessionStorage.setItem("subtime", subtime)
    sessionStorage.setItem("psid", psid)
    sessionStorage.setItem("psheaderid", psheaderid)
}
function removeQuotationDOM(shname, price, subtime, psid, psheaderid, VHeaderID) {
    $('#deletepopup').modal('show')
     sessionStorage.setItem("VehicleID", shname)
    sessionStorage.setItem("OriginID", price)
    sessionStorage.setItem("DestinationID", subtime)
    sessionStorage.setItem("QPriceD", psid)
    sessionStorage.setItem("SubmissionTymD", psheaderid)
    sessionStorage.setItem("VHeaderID", VHeaderID)
}
function removeQuotationWare(persquare, manpower, infra, utility, subtym, fmanagemnt) {
    $('#deletepopup').modal('show')
    sessionStorage.setItem("persquarefeet", persquare)
    sessionStorage.setItem("manpower", manpower)
    sessionStorage.setItem("infra", infra)
    sessionStorage.setItem("utility", utility)
    sessionStorage.setItem("SubmissionTymW", subtym)
    sessionStorage.setItem("fixedManagement", fmanagemnt)
}
function removeQuotationSea(price, Exwork, subtym) {
    $('#deletepopup').modal('show')
    sessionStorage.setItem("PriceSea", price)
    sessionStorage.setItem("ExworkSea", Exwork)
    sessionStorage.setItem("SubmissionTymSea", subtym)

}
function deletePEFAquote() {
    var AttachementFileName = '';
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    if ($('#filepthattach').html != '') {
        AttachementFileName = jQuery('#fileToUpload').html();
    }
    AttachementFileName = AttachementFileName.replace(/[&\/\\#,+$~%'":*?<>{}]/g, '_'); //Replace special Characters
    var QuoteProduct = {
        "VendorID": $('#ddlvendors').val(),
        "BidID": $('#ddlbid').val(),
        "ShortName": sessionStorage.getItem("shname"),
        "QuotedPrice": sessionStorage.getItem("price"),
        "SubmissionTime": sessionStorage.getItem("subtime"),
        "PSID": sessionStorage.getItem("psid"),
        "PSHeaderID": 0,
        "Remarks": $('#txtremarks').val(),
        "Attachment": AttachementFileName,
        "DeletedBy": sessionStorage.getItem("UserID")

    }
   // alert(JSON.stringify(QuoteProduct))
    jQuery.ajax({
        url: sessionStorage.getItem("APIPath") + "RemoveParticipatedQuotedPrices/RemovePEFAQuote/",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "POST",
        data: JSON.stringify(QuoteProduct),
        contentType: "application/json; charset=utf-8",
        success: function (data, status, jqXHR) {

            if (data[0].Output == "1") {
                fileUploader($('#ddlbid').val())
                success1.show();
                $('#spansuccess1').html("Quoted Price deleted Successfully..");
                success1.fadeOut(6000);
                App.scrollTo(success1, -200);
                fetchparticationQuotes()
                $('#deletepopup').modal('hide')
                $('#txtremarks').val('')
                $('#fileToUpload').val('')
            }
            else if (data[0].Output == "99") {
                $('#deletepopup').modal('hide')
                bootbox.alert("You cant't delete entries more than 2 times for a vendor in a particular Bid.")
            }
            else {
                error2.show();
                $('#err').html('You have some error.Please try agian.');
                error2.fadeOut(3000);
                App.scrollTo(error2, -200);
            }
            jQuery.unblockUI();
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            
            return false;
            jQuery.unblockUI();
        }
    })
}
function deletePSquote() {
    var AttachementFileName = '';
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    if ($('#filepthattach').html != '') {
        AttachementFileName = jQuery('#fileToUpload').html();
    }
    AttachementFileName = AttachementFileName.replace(/[&\/\\#,+$~%'":*?<>{}]/g, '_'); //Replace special Characters
    var QuoteProduct = {
        "VendorID": $('#ddlvendors').val(),
        "BidID": $('#ddlbid').val(),
        "ShortName": sessionStorage.getItem("shname"),
        "QuotedPrice": sessionStorage.getItem("price"),
        "SubmissionTime": sessionStorage.getItem("subtime"),
        "PSID": sessionStorage.getItem("psid"),
        "PSHeaderID": sessionStorage.getItem("psheaderid"),
        "Remarks": $('#txtremarks').val(),
        "Attachment": AttachementFileName,
        "DeletedBy": sessionStorage.getItem("UserID")
      
    }
   // alert(JSON.stringify(QuoteProduct))
    jQuery.ajax({
        url: sessionStorage.getItem("APIPath") + "RemoveParticipatedQuotedPrices/RemovePSQuote/",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "POST",
        data: JSON.stringify(QuoteProduct),
        contentType: "application/json; charset=utf-8",
        success: function (data, status, jqXHR) {
          
            if (data[0].Output == "1") {
                fileUploader($('#ddlbid').val())
                success1.show();
                $('#spansuccess1').html("Quoted Price deleted Successfully..");
                success1.fadeOut(6000);
                App.scrollTo(success1, -200);
                fetchparticationQuotes()
                $('#deletepopup').modal('hide')
                $('#txtremarks').val('')
                $('#fileToUpload').val('')
            }
            else if (data[0].Output == "99") {
                $('#deletepopup').modal('hide')
                bootbox.alert("You cant't delete entries more than 2 times for a vendor in a particular Bid.")
            }
            else {
                error2.show();
                $('#err').html('You have some error.Please try agian.');
                error2.fadeOut(3000);
                App.scrollTo(error2, -200);
            }
            jQuery.unblockUI();
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            
            return false;
            jQuery.unblockUI();
        }
    })
}
function deleteDomesticQuote() {
  
    var AttachementFileName = '';
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    if ($('#filepthattach').html != '') {
        AttachementFileName = jQuery('#fileToUpload').html();
    }

    var QuoteProduct = {
        "VendorID": $('#ddlvendors').val(),
        "BidID": $('#ddlbid').val(),
        "VehicleID": sessionStorage.getItem("VehicleID"),
        "OriginID": sessionStorage.getItem("OriginID"),
        "DestinationID": sessionStorage.getItem("DestinationID"),
        "SubmissionTime": sessionStorage.getItem("SubmissionTymD"),
        "VDomesticHeaderID": sessionStorage.getItem("VHeaderID"),
        "QuotedPrice": sessionStorage.getItem("QPriceD"),
        "Remarks": $('#txtremarks').val(),
        "Attachment": AttachementFileName,
        "DeletedBy": sessionStorage.getItem("UserID")

    }
    // alert(JSON.stringify(QuoteProduct))
    jQuery.ajax({
        url: sessionStorage.getItem("APIPath") + "RemoveParticipatedQuotedPrices/RemovedomesticQuote/",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "POST",
        data: JSON.stringify(QuoteProduct),
        contentType: "application/json; charset=utf-8",
        success: function (data, status, jqXHR) {

            if (data[0].Output == "1") {
                fileUploader($('#ddlbid').val())
                success1.show();
                $('#spansuccess1').html("Quoted Price deleted Successfully..");
                success1.fadeOut(6000);
                App.scrollTo(success1, -200);
                fetchparticationQuotes()
                $('#deletepopup').modal('hide')
                $('#txtremarks').val('')
                $('#fileToUpload').val('')
            }
            else if (data[0].Output == "99") {
                $('#deletepopup').modal('hide')
                bootbox.alert("You cant't delete entries more than 2 times for a vendor in a particular Bid.")
            }
            else {
                error2.show();
                $('#err').html('You have some error.Please try agian.');
                error2.fadeOut(3000);
                App.scrollTo(error2, -200);
            }
            jQuery.unblockUI();
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            
            return false;
            jQuery.unblockUI();
        }
    })
}
function deletewarehouseQuote() {
    var AttachementFileName = '';
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    if ($('#filepthattach').html != '') {
        AttachementFileName = jQuery('#fileToUpload').html();
    }

    var QuoteProduct = {
        "VendorID": $('#ddlvendors').val(),
        "BidID": $('#ddlbid').val(),
        "PerSquareFeetRate": sessionStorage.getItem("persquarefeet"),
        "ManPowerCost": sessionStorage.getItem("manpower"),
        "InfrastructureCost": sessionStorage.getItem("infra"),
        "UtilitiesCost": sessionStorage.getItem("utility"),
        "FixedManagementFee": sessionStorage.getItem("fixedManagement"),
        "SubmissionTime": sessionStorage.getItem("SubmissionTymW"),
        "Remarks": $('#txtremarks').val(),
        "Attachment": AttachementFileName,
        "EnteredBy": sessionStorage.getItem("UserID")

    }
    // alert(JSON.stringify(QuoteProduct))
    jQuery.ajax({
        url: sessionStorage.getItem("APIPath") + "RemoveParticipatedQuotedPrices/RemoveWrehouseQuote/",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "POST",
        data: JSON.stringify(QuoteProduct),
        contentType: "application/json; charset=utf-8",
        success: function (data, status, jqXHR) {

            if (data[0].Output == "1") {
                fileUploader($('#ddlbid').val())
                success1.show();
                $('#spansuccess1').html("Quoted Price deleted Successfully..");
                success1.fadeOut(6000);
                App.scrollTo(success1, -200);
                fetchparticationQuotes()
                $('#deletepopup').modal('hide')
                $('#txtremarks').val('')
                $('#fileToUpload').val('')
            }
            else if (data[0].Output == "99") {
                $('#deletepopup').modal('hide')
                bootbox.alert("You can not delete entries more than 2 times for a vendor in a particular Bid.")
            }
            else {
                error2.show();
                $('#err').html('You have some error.Please try agian.');
                error2.fadeOut(3000);
                App.scrollTo(error2, -200);
            }
            jQuery.unblockUI();
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            
            return false;
            jQuery.unblockUI();
        }
    })
}
function deleteseaQuote() {
    var AttachementFileName = '';
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    if ($('#filepthattach').html != '') {
        AttachementFileName = jQuery('#fileToUpload').html();
    }

    var QuoteProduct = {
        "VendorID": $('#ddlvendors').val(),
        "BidID": $('#ddlbid').val(),
        "Price": sessionStorage.getItem("PriceSea"),
        "ExWorks": sessionStorage.getItem("ExworkSea"),
        "SubmissionTime": sessionStorage.getItem("SubmissionTymSea"),
        "Remarks": $('#txtremarks').val(),
        "Attachment": AttachementFileName,
        "EnteredBy": sessionStorage.getItem("UserID")

    }
   // alert(JSON.stringify(QuoteProduct))
    jQuery.ajax({
        url: sessionStorage.getItem("APIPath") + "RemoveParticipatedQuotedPrices/RemoveSeaQuote/",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "POST",
        data: JSON.stringify(QuoteProduct),
        contentType: "application/json; charset=utf-8",
        success: function (data, status, jqXHR) {

            if (data[0].Output == "1") {
                fileUploader($('#ddlbid').val())
                success1.show();
                $('#spansuccess1').html("Quoted Price deleted Successfully..");
                success1.fadeOut(6000);
                App.scrollTo(success1, -200);
                fetchparticationQuotes()
                $('#deletepopup').modal('hide')
                $('#txtremarks').val('')
                $('#fileToUpload').val('')
            }
            else if (data[0].Output == "99") {
                $('#deletepopup').modal('hide')
                bootbox.alert("You can not delete entries more than 2 times for a vendor in a particular Bid.")
            }
            else {
                error2.show();
                $('#err').html('You have some error.Please try agian.');
                error2.fadeOut(3000);
                App.scrollTo(error2, -200);
            }
            jQuery.unblockUI();
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            
            return false;
            jQuery.unblockUI();
        }
    })
}
function deleteAirQuote() {
    var AttachementFileName = '';
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    if ($('#filepthattach').html != '') {
        AttachementFileName = jQuery('#fileToUpload').html();
    }
  

    var QuoteProduct = {
        "VendorID": $('#ddlvendors').val(),
        "BidID": $('#ddlbid').val(),
        "FreightMin": sessionStorage.getItem("fmin"),
        "FreightPlus45": sessionStorage.getItem("f45"),
        "FreightPlus100": sessionStorage.getItem("f100"),
        "FreightPlus300": sessionStorage.getItem("f300"),
        "FreightPlus500": sessionStorage.getItem("f500"),
        "FreightPlus1000": sessionStorage.getItem("f1000"),
        "ExWorksMin": sessionStorage.getItem("exmin"),
        "ExWorksPlus45": sessionStorage.getItem("ex45"),
        "ExWorksPlus100": sessionStorage.getItem("ex100"),
        "ExWorksPlus300": sessionStorage.getItem("ex300"),
        "ExWorksPlus500": sessionStorage.getItem("ex500"),
        "ExWorksPlus1000": sessionStorage.getItem("ex1000"),
       
        "SubmissionTime": sessionStorage.getItem("subtym"),
        "Remarks": $('#txtremarks').val(),
        "Attachment": AttachementFileName,
        "EnteredBy": sessionStorage.getItem("UserID")

    }
    // alert(JSON.stringify(QuoteProduct))
    jQuery.ajax({
        url: sessionStorage.getItem("APIPath") + "RemoveParticipatedQuotedPrices/RemoveairQuote/",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "POST",
        data: JSON.stringify(QuoteProduct),
        contentType: "application/json; charset=utf-8",
        success: function (data, status, jqXHR) {

            if (data[0].Output == "1") {
                fileUploader($('#ddlbid').val())
                success1.show();
                $('#spansuccess1').html("Quoted Price deleted Successfully..");
                success1.fadeOut(6000);
                App.scrollTo(success1, -200);
                fetchparticationQuotes()
                $('#deletepopup').modal('hide')
                $('#txtremarks').val('')
                $('#fileToUpload').val('')
            }
            else if (data[0].Output == "99") {
                $('#deletepopup').modal('hide')
                bootbox.alert("You can not delete entries more than 2 times for a vendor in a particular Bid.")
            }
            else {
                error2.show();
                $('#err').html('You have some error.Please try agian.');
                error2.fadeOut(3000);
                App.scrollTo(error2, -200);
            }
            jQuery.unblockUI();
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            
            return false;
            jQuery.unblockUI();
        }
    })
}
$('#deletepopup').on('hidden.bs.modal', function () {
    $('#txtremarks').val('');
    
});
function fileUploader(bidID) {

    var fileTerms = $('#fileToUpload');

    var fileDataTerms = fileTerms.prop("files")[0];

    var formData = new window.FormData();

    formData.append("fileTerms", fileDataTerms);
    formData.append("AttachmentFor", 'ManageBid');

    formData.append("BidID", bidID);
    formData.append("VendorID", '');
 $.ajax({

        url: 'ConfigureFileAttachment.ashx',
        data: formData,
        processData: false,

        contentType: false,

        asyc: false,

        type: 'POST',

        success: function (data) {

        },

        error: function () {

            bootbox.alert("Attachment error.");

        }

    });

}
jQuery("#txtvendor, #txtvendorSurrogateBid").keyup(function () {
    sessionStorage.setItem('hdnselectedvendor', '0');
    sessionStorage.setItem('hdnselectedEmail', '');
});

jQuery("#txtvendor,#txtvendorSurrogateBid").typeahead({
    source: function (query, process) {
        var data = sessionStorage.getItem('hdnAllBidsVendor');
        usernames = [];
        map = {};
        var username = "";
        jQuery.each(jQuery.parseJSON(data), function (i, username) {
            map[username.VendorName] = username;
            usernames.push(username.VendorName);
        });

        process(usernames);

    },
    minLength: 2,
    updater: function (item) {
    if (map[item].VendorID != "0") {
     
        sessionStorage.setItem('hdnselectedvendor', map[item].VendorID);
        sessionStorage.setItem('hdnselectedEmail', map[item].EmailId);
            if ($("#txtvendorSurrogateBid").val() != '') {
                $(".surrogateFormElements").show();
            }
        }
        else {
            gritternotification('Please select Vendor  properly!!!');
        }

        return item;
    }

});

function FetchVenderNotInvited(bidid) {
   
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: APIPath + "ResetInviteVendor/fetchBidsAuto/?UserID=&BidID=" + bidid + "&CustomerID=" + sessionStorage.getItem('CustomerID'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        dataType: "json",
        success: function (data) {
            jQuery("#tblvendorlist > tbody").empty();
            if (data.length > 0) {
                $('#inviteVendorBody').show();
                for (var i = 0; i < data.length; i++) {
                    var str = "<tr><td><div class=\"checker\" id=\"uniform-chkbidTypes\"><span  id=\"spanchecked\"><input class=\"chkboxwithval\"  type=\"checkbox\" Onclick=\"Check(this)\"; id=\"chkvender\" value=" + (data[i].VendorID + ',' + data[i].EmailId) + " style=\"cursor:pointer\" name=\"chkvender\"/></span></div></td><td> " + data[i].VendorName + " </td></tr>";
                    jQuery('#tblvendorlist > tbody').append(str);
                }
            }
            else {
                $('#inviteVendorBody').hide();
            }
            
            
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
           // alert(xhr.status)
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            jQuery.unblockUI();
            return false;
        }
    });
}
$("#chkAll").click(function () {
    if ($("#chkAll").is(':checked') == true) {
        $('#divvendorlist').find('span#spandynamic').hide();
        $('table#tblvendorlist').closest('.inputgroup').removeClass('has-error');
        $("#tblvendorlist> tbody > tr").each(function (index) {
            $(this).find("span#spanchecked").addClass("checked");
        });
    }
    else {
        $("#tblvendorlist> tbody > tr").each(function (index) {
            $(this).find("span#spanchecked").removeClass("checked");
        });
    }
});

function Check(event) {
    if ($(event).closest("span#spanchecked").attr('class') == 'checked') {
        $(event).closest("span#spanchecked").removeClass("checked")
    }
    else {
        $(event).closest("span#spanchecked").addClass("checked")
        $('#divvendorlist').find('span#spandynamic').hide();
        $('table#tblvendorlist').closest('.inputgroup').removeClass('has-error');
    }
}

function ValidateVendor() {
    var status = "false";
    var evement = "";
    $('#divvendorlist').find('span#spandynamic').hide();
    $("#tblvendorlist> tbody > tr").each(function (index) {
        if ($(this).find("span#spanchecked").attr('class') == 'checked') {
            status = "True";
        }
    });
    if (status == "false") {
        error1.show();
        $('#spandanger').html('Please select at least one element');
        error1.fadeOut(3000);
        App.scrollTo(error1, -200);
       
        status = "false";
    }
    return status;
}
function resetpasswordForBidVendor() {
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
   
    if (sessionStorage.getItem("hdnbid") == '0') {
       error1.show();
        $('#spandanger').html('Please select Bid...');
        error1.fadeOut(3000);
        App.scrollTo(error1, -200);
        gritternotification('Please select Bid!!!');
        jQuery.unblockUI();
      
        return false;

    }
    else if(sessionStorage.getItem("hdnselectedvendor")=="0") {
        error1.show();
        $('#spandanger').html('Please select Vendor...');
        error1.fadeOut(3000);
        App.scrollTo(error1, -200);
        jQuery.unblockUI();
       // gritternotification('Please select Vendor!!!');
        return false;
    }
    else{
        var data = {
            "EmailId": sessionStorage.getItem("hdnselectedEmail"),
            "BidId": sessionStorage.getItem("hdnbid"),
            "VendorID": sessionStorage.getItem("hdnselectedvendor"),
            "UserID": sessionStorage.getItem("UserID")
        
        }
     // alert(JSON.stringify(data))
        jQuery.ajax({
            url: APIPath + "ResetInviteVendor/ResetPassword",
            data: JSON.stringify(data),
            type: "POST",
            contentType: "application/json",
            success: function (data) {
                if (data[0].Flag = "1") {
                    success1.show();
                    $('#spansuccess1').html('New password is sent to registered email of vendor..');
                   // clearsession()
                    success1.fadeOut(6000);
                    App.scrollTo(success1, -200);
                    jQuery.unblockUI();
                }
            },
            error: function (xhr, status, error) {

                var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }
                
                return false;
                jQuery.unblockUI();
            }
        });
    }


}
function clearsession() {
    sessionStorage.setItem('hdnselectedvendor', '0');
    sessionStorage.setItem('hdnselectedEmail', '');
    sessionStorage.setItem('hdnbid', '0');
    sessionStorage.setItem("hdnbidtypeid", '0')
    jQuery("#txtvendor, #txtvendorSurrogateBid").val('')
   // jQuery("#ddlbid").val('')
   // $('#litab1,#tab1').removeClass('active')
   // $('#litab0,#tab0').addClass('active')
    //$('#tab1').hide()
}
function sendremainderstoparicipants() {
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    if (sessionStorage.getItem("hdnbid") == '0') {
      errorremainder.show();
        $('#errrem').html('Please select Bid...');
        errorremainder.fadeOut(3000);
        App.scrollTo(errorremainder, -200);
        jQuery.unblockUI();
        gritternotification('Please select Bid!!!');
        return false;

    }
    else {
        var checkedValue = '';
        var temp = new Array();
        $("#tblparicipantslists> tbody > tr").each(function (index) {
            //if ($(this).find("span#spanchecked").attr('class') == 'checked') {
            // temp = ($(this).find("#chkvender").val()).split(",");
            vemail = $(this).find("td").eq(1).html();
            vid = $(this).find("td").eq(0).html();
            checkedValue = checkedValue + " select  " + sessionStorage.getItem("hdnbid") + ",'" + vemail + "','N','" + vid + "'  union";
            // }
        });
        if (checkedValue != '') {
            checkedValue = 'insert into #temp(BidId,EmailId,MailSent,VendorID) ' + checkedValue
            checkedValue = checkedValue.substring(0, checkedValue.length - 6);
        }

        var data = {
            "QueryString": checkedValue,
            "BidId": sessionStorage.getItem("hdnbid"),
            "BidTypeID": sessionStorage.getItem("hdnbidtypeid"),
            "UserID": sessionStorage.getItem("UserID")
        }
         // alert(JSON.stringify(data))
        jQuery.ajax({
            url: APIPath + "ResetInviteVendor/SendRemainderToParticipant",
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            data: JSON.stringify(data),
            type: "POST",
            contentType: "application/json",
            success: function (data) {
               // alert(data[0].Flag)
                if (data[0].Flag == "1") {
                    errorremainder.hide();
                    succesremainder.show();
                    $('#succrem').html('Reminder has been sent Successfully..');
                    
                    clearsession();

                    succesremainder.fadeOut(3000);
                    App.scrollTo(succesremainder, -200);
                    jQuery.unblockUI();
                }
            },
            
            error: function (xhr, status, error) {

                var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }

                return false;
                jQuery.unblockUI();
            }
        });

        return true;
    }
}
function invitevendors() {

    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    if (sessionStorage.getItem("hdnbid") == '0') {
        error1.show();
        $('#spandanger').html('Please select Bid...');
        error1.fadeOut(3000);
        App.scrollTo(error1, -200);
        jQuery.unblockUI();
        gritternotification('Please select Bid!!!');
        return false;

    }
    else if (ValidateVendor() == 'false') {
        jQuery.unblockUI();
        return false;

    }
    else {
        var checkedValue = '';
        var temp = new Array();
        $("#tblvendorlist> tbody > tr").each(function (index) {
            if ($(this).find("span#spanchecked").attr('class') == 'checked') {
                temp = ($(this).find("#chkvender").val()).split(",");

                checkedValue = checkedValue + " select  " + sessionStorage.getItem("hdnbid") + ",'" + temp[1] + "','N','" + temp[0] + "'  union";
            }
        });
        if (checkedValue != '') {
            checkedValue = 'insert into BidVendorDetails(BidId,EmailId,MailSent,VendorID) ' + checkedValue
            checkedValue = checkedValue.substring(0, checkedValue.length - 6);
        }

        var data = {
            "QueryString": checkedValue,
            "BidId": sessionStorage.getItem("hdnbid"),
            "BidTypeID": sessionStorage.getItem("hdnbidtypeid"),
            "UserID": sessionStorage.getItem("UserID")
        }
         // alert(JSON.stringify(data))
        jQuery.ajax({
            url: APIPath + "ResetInviteVendor/Invitevendors",
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            data: JSON.stringify(data),
            type: "POST",
            contentType: "application/json",
            success: function (data) {
                if (data[0].Flag == "1") {
                    success1.show();
                    $('#spansuccess1').html('Vendor Invited Successfully..');
                    fetchallexportdetails();
                    FetchVenderNotInvited(sessionStorage.getItem("hdnbid"))
                    fetchvendors(sessionStorage.getItem("hdnbid"));
                    // FetchVenderNotInvited(sessionStorage.getItem("hdnbid"))
                    //clearsession()


                    success1.fadeOut(3000);
                    App.scrollTo(success1, -200);
                    jQuery.unblockUI();
                }
            },
            error: function (xhr, status, error) {

                var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }

                return false;
                jQuery.unblockUI();
            }
        });

        return true;
    }
}
jQuery("#search").keyup(function () {
   
    jQuery("#tblvendorlist tr:has(td)").hide(); // Hide all the rows.

    var iCounter = 0;
    var sSearchTerm = jQuery('#search').val(); //Get the search box value

    if (sSearchTerm.length == 0) //if nothing is entered then show all the rows.
    {
        jQuery("#tblvendorlist tr:has(td)").show();
        return false;
    }

    //Iterate through all the td.
    jQuery("#tblvendorlist tr:has(td)").children().each(function () {

        var cellText = jQuery(this).text().toLowerCase();
        if (cellText.indexOf(sSearchTerm.toLowerCase()) >= 0) //Check if data matches
        {

            jQuery(this).parent().show();
            iCounter++;

            return true;
        }

    });
});


//Time Extension Feature 4th TAB

var SeId = 0;
var FlagForCheckShowPrice = "N";
function fetchallexportdetails() {
    var bidTypeFetchUrl='';
    $('#extendedDurationPara').hide();
    var replaced1 = '';
    var replaced2 = '';
    if (sessionStorage.getItem("hdnbidtypeid") == 6) {
        bidTypeFetchUrl = sessionStorage.getItem("APIPath") + "ConfigureBid/fetchPefaConfigurationData/?UserID=" + encodeURIComponent(sessionStorage.getItem('UserID')) + "&BidID=" + jQuery('#ddlbid').val() + "&AuthenticationToken=" + sessionStorage.getItem('AuthenticationToken');
    }
    if (sessionStorage.getItem("hdnbidtypeid") == 7) {
        bidTypeFetchUrl = sessionStorage.getItem("APIPath") + "ConfigureBid/fetchSeaExportConfigurationData/?UserID=" + encodeURIComponent(sessionStorage.getItem('UserID')) + "&BidID=" + jQuery('#ddlbid').val() + "&AuthenticationToken=" + sessionStorage.getItem('AuthenticationToken');
    }
   
    jQuery.ajax({
        contentType: "application/json; charset=utf-8",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        url: bidTypeFetchUrl,
        type: "GET",
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function(BidData) {
            $("#eventDetailstab_0").show();
            $('#BidPreviewDiv').show()
            jQuery('#mapedapproverPrev').html('');
            jQuery('#mapedapproverPrevtab_0').html('');

            jQuery('#txtBidSubjectPrev').html(BidData[0].BidDetails[0].BidSubject)
            jQuery('#txtBidSubjectPrevtab_0').html(BidData[0].BidDetails[0].BidSubject)
            //jQuery('#txtBidDurationPrev').val(BidData[0].BidDetails[0].BidDuration)
            jQuery('#txtbiddescriptionPrev').html(BidData[0].BidDetails[0].BidDetails)
            jQuery('#txtbiddescriptionPrevtab_0').html(BidData[0].BidDetails[0].BidDetails)
            jQuery('#txtbidDatePrev').html(BidData[0].BidDetails[0].BidDate)
            jQuery('#txtbidDatePrevtab_0').html(BidData[0].BidDetails[0].BidDate)
            jQuery('#txtbidTimePrevtab_0').html(BidData[0].BidDetails[0].BidTime)
            jQuery('#txtbidTimePrev').html(BidData[0].BidDetails[0].BidTime)
            jQuery("#dropCurrencyPrev").html(BidData[0].BidDetails[0].CurrencyName)
            jQuery("#dropCurrencyPrevtab_0").html(BidData[0].BidDetails[0].CurrencyName)
            jQuery('#txtConversionRatePrev').html(BidData[0].BidDetails[0].ConversionRate)
            jQuery('#txtConversionRatePrevtab_0').html(BidData[0].BidDetails[0].ConversionRate)
            if (sessionStorage.getItem("hdnbidtypeid") == 7) {
                if (BidData[0].BidDetails[0].ShowRankToVendor == "Y") {
                    jQuery('#showL1l2').text("As L1, L2, L3 etc.")
                }
                else {
                    jQuery('#showL1l2').text("As L1 or Not L1")
                }
            }
            else if (sessionStorage.getItem("hdnbidtypeid") == 6) {
                if (BidData[0].BidDetails[0].ShowRankToVendor == "Y") {
                    jQuery('#showL1l2').text("As H1, H2, H3 etc.")
                }
                else {
                    jQuery('#showL1l2').text("As H1 or Not H1")
                }
            }
           
            //var ClosingType=''
            $('#hdnClosingval').val(BidData[0].BidDetails[0].BidClosingType)
            //$('#hdnClosingvaltab_0').val(BidData[0].BidDetails[0].BidClosingType)
            //alert(BidData[0].BidDetails[0].BidClosingType)
            jQuery("#txtBidDurationPrevtab_0").html(BidData[0].BidDetails[0].BidDuration);

           

            if (BidData[0].BidDetails[0].Status.toLowerCase() == "close") {
              
                $("#ddlBidStatus").val(2);
                $('#btnsendreminder').attr("disabled","disabled")
            }
            else if (BidData[0].BidDetails[0].Status == "OPEN") {
                $("#ddlBidStatus").val(1);
                $('#btnsendreminder').removeAttr("disabled")
            }
            $("#ctrlbidTimeandDate").attr('onclick', "editValues('divbidTimePrevtab_0', 'txtbidDatePrevtab_0')");
            $("#ctrlFileTerms").attr('onclick', "editValues('divbidTermsFilePrevtab_0', '')");
            $("#ctrlFileAttachment").attr('onclick', "editValues('divbidAttachFilePrevtab_0', '')");
            $("#ctrlShwL1").attr('onclick', "editValues('divbidShowL1L2', '')");
//**************************** Change by Pooja sppinner to Textbox  Start**************************
          //  $('#spinnerBidDetails').show()
           // $('#spinnerBidDetails').spinner({ value: BidData[0].BidDetails[0].BidDuration, step: 1, min: 0, max: 999 });
            $('#txtBidDurationForBidOpen').val(BidData[0].BidDetails[0].BidDuration)
            $('#txtbidTime').val(BidData[0].BidDetails[0].BidTime)
            $('#txtbidDate').val(BidData[0].BidDetails[0].BidDate)
           
            $('#ddlBidfinalStatus').val(BidData[0].BidDetails[0].FinalStatus)
          
           
            if ( BidData[0].BidDetails[0].FinalStatus.toLowerCase() == "cancel") {
                if (sessionStorage.getItem("UserID") == "..") {
                    $('#divfinalstatus').removeClass('hide');
                   
                }
            }
            else {
                 $('#divfinalstatus').addClass('hide');
            }

//**************************** Change by Pooja sppinner to Textbox   End**************************
            
            _bidClosingType = BidData[0].BidDetails[0].BidClosingType;
            if (BidData[0].BidDetails[0].BidClosingType == "A") {
                SeId = 0;
                $('#spinnerBidclosingTab').show()
                $('#btndiv').show()
                $('#txtbidduration').hide()
                $('#spinnerBidclosingTab').spinner({ value: BidData[0].BidDetails[0].BidDuration, step: 1, min: 0, max: 999 });
                jQuery('#ddlbidclosetypePrev').html('All items in one go')
                jQuery('#ddlbidclosetypePrevtab_0').html('All items in one go')
                $(".staggered-item").show();
              
                $('#txtBidDurationForBidOpen').removeAttr("disabled");
            }
            else if (BidData[0].BidDetails[0].BidClosingType == "S") {
                $("#txtBidDurationForBidOpen").attr("disabled", "disabled"); 
                $('#spinnerBidclosingTab').hide()
                $('#btndiv').hide()
                $('#txtbidduration').show()
                $('#txtbidduration').html(BidData[0].BidDetails[0].BidDuration)
                jQuery('#ddlbidclosetypePrev').html('Stagger at: Item level')
                jQuery('#ddlbidclosetypePrevtab_0').html('Stagger at: Item level')
            } else {
                $("#head-stagger").hide();
                $(".staggered-item").hide();
                $('#spinnerBidclosingTab').show()
                $('#btndiv').show()
                $('#txtbidduration').hide()
                $('#spinnerBidclosingTab').spinner({ value: BidData[0].BidDetails[0].BidDuration, step: 1, min: 0, max: 999 });
                //jQuery('#ddlbidclosetypePrev').html('Stagger at: Item level')
                $('#hdnClosingval').val('A')
            }


            if (BidData[0].BidDetails[0].TermsConditions != '') {
                    replaced1 = BidData[0].BidDetails[0].TermsConditions.replace(/\s/g, "%20")
            if (BidData[0].BidDetails[0].Attachment != '') {
                    if (BidData[0].BidDetails[0].Attachment != null) {
                        replaced2 = BidData[0].BidDetails[0].Attachment.replace(/\s/g, "%20")
                    }
                }



            }
            $('#filepthtermsPrev').attr('href', 'PortalDocs/Bid/' + jQuery('#ddlbid').val() + '/' + replaced1).html(BidData[0].BidDetails[0].TermsConditions);
            $('#filepthattachPrev').attr('href', 'PortalDocs/Bid/' + jQuery('#ddlbid').val() + '/' + replaced2).html(BidData[0].BidDetails[0].Attachment);
            $('#filepthtermsPrevtab_0').attr('href', 'PortalDocs/Bid/' + jQuery('#ddlbid').val() + '/' + replaced1).html(BidData[0].BidDetails[0].TermsConditions);
            $('#filepthattachPrevtab_0').attr('href', 'PortalDocs/Bid/' + jQuery('#ddlbid').val() + '/' + replaced2).html(BidData[0].BidDetails[0].Attachment);

            if (BidData[0].BidApproverDetails.length > 0) {
                for (var i = 0; i < BidData[0].BidApproverDetails.length; i++) {

                    jQuery('#mapedapproverPrev').append(jQuery('<option selected></option>').val(BidData[0].BidApproverDetails[i].UserID).html(BidData[0].BidApproverDetails[i].ApproverName))
                    jQuery('#mapedapproverPrevtab_0').append(jQuery('<option selected></option>').val(BidData[0].BidApproverDetails[i].UserID).html(BidData[0].BidApproverDetails[i].ApproverName))
                }
            }


            jQuery("#tblServicesProductPrev").empty();
            jQuery("#tblServicesProductPrevtab_0").empty();
            if (sessionStorage.getItem('hdnbidtypeid') == 7){
            if (BidData[0].BidSeaExportDetails.length > 0) {

                $('#wrap_scrollerPrev').show();
                $('#wrap_scrollerPrevtab_0').show();

                if ($('#hdnClosingval').val() == "S") {
                    $(".staggered-item").show();

                    jQuery("#tblServicesProductPrev").append("<thead><tr style='background: gray; color: #FFF;'><th>Item/Product/Service</th><th>Remarks</th><th>Target Price</th><th>Quantity</th><th>UOM</th><th>Bid start price</th><th class=hide>Mask Vendor</th><th style='width:60px !important'>Minimum<br/>Decrement</th><th>Decrement On</th><th>Last<br/>Invoice Price</th><th>Item<br/>Duration(Min)</th><th>Show L1 Price</th><th>Show Start Price</th><th>PO Unit Rate</th><th>PO No.</th><th>PO Vendor Name</th><th>PO Date</th><th>PO Value</th><th>Closing Time</th><th style=width:200px>Bid Duration<br/>(in minutes)</th></tr></thead>");
                    jQuery("#tblServicesProductPrevtab_0").append("<thead><tr style='background: gray; color: #FFF;'><th style='width:150px !important;'></th><th>Item/Product/Service</th><th>Remarks</th><th>Target Price</th><th>Quantity</th><th>UOM</th><th>Bid start price</th><th>Mask Vendor</th><th style='width:60px !important'>Minimum<br/>Decrement</th><th>Decrement On</th><th>Last<br/>Invoice Price</th><th>Item<br/>Duration(Min)</th><th>Closing Time</th><th>Show L1 Price</th><th>Show Start Price</th><th>PO Unit Rate</th><th>PO No.</th><th>PO Vendor Name</th><th>PO Date</th><th>PO Value</th></tr></thead>");
                }
                else {
                    jQuery("#tblServicesProductPrevtab_0").append("<thead><tr style='background: gray; color: #FFF;'><th style='width:150px !important;'></th><th>Item/Product/Service</th><th>Remarks</th><th>Target Price</th><th>Quantity</th><th>UOM</th><th>Bid start price</th><th>Mask Vendor</th><th>Minimum Decrement</th><th>Decrement On</th><th>Last InvoicePrice</th><th>Show L1 Price</th><th>Show Start Price</th><th>PO Unit Rate</th><th>PO No.</th><th>PO Vendor Name</th><th>PO Date</th><th>PO Value</th></tr></thead>");
                    jQuery("#tblServicesProductPrev").append("<thead><tr style='background: gray; color: #FFF;'><th>Item/Product/Service</th><th>Remarks</th><th>Target Price</th><th>Quantity</th><th>UOM</th><th>Bid start price</th><th class=hide>Mask Vendor</th><th>Minimum Decrement</th><th>Decrement On</th><th>Last InvoicePrice</th><th>Show L1 Price</th><th>Show Start Price</th><th>PO Unit Rate</th><th>PO No.</th><th>PO Vendor Name</th><th>PO Date</th><th>PO Value</th></tr></thead>");
                }

                for (var i = 0; i < BidData[0].BidSeaExportDetails.length; i++) {


                    var decrementon = ''

                    if (BidData[0].BidSeaExportDetails[i].DecreamentOn == 'A')
                        decrementon = 'Amount'
                    else
                        decrementon = '%age'


                    if ($('#hdnClosingval').val() == "S") {
                        //alert(BidData[0].BidSeaExportDetails[i].ItemBidDuration)
                        jQuery("#tblServicesProductPrev").append('<tr id=tridPrev' + i + '><td>' + BidData[0].BidSeaExportDetails[i].DestinationPort + '</td><td>' + BidData[0].BidSeaExportDetails[i].Remarks + '</td><td class=text-right>' + BidData[0].BidSeaExportDetails[i].Targetprice + '</td><td class=text-right>' + BidData[0].BidSeaExportDetails[i].Quantity + '</td><td>' + BidData[0].BidSeaExportDetails[i].UOM + '</td><td class=text-right>' + BidData[0].BidSeaExportDetails[i].CeilingPrice + '</td><td class=hide>' + BidData[0].BidSeaExportDetails[i].MaskVendor + '</td><td class=text-right>' + BidData[0].BidSeaExportDetails[i].MinimumDecreament + '</td><td>' + decrementon + '</td><td class=hide>' + BidData[0].BidSeaExportDetails[i].DecreamentOn + '</td><td class=text-right>' + BidData[0].BidSeaExportDetails[i].LastInvoicePrice + '</td><td class=text-right>' + BidData[0].BidSeaExportDetails[i].ItemBidDuration + '</td><td>' + BidData[0].BidSeaExportDetails[i].MaskL1Price + '</td><td>' + BidData[0].BidSeaExportDetails[i].ShowStartPrice + '</td><td class=text-right>' + BidData[0].BidSeaExportDetails[i].PoUnitRate + '</td><td>' + BidData[0].BidSeaExportDetails[i].PoNo + '</td><td>' + BidData[0].BidSeaExportDetails[i].PoVendorName + '</td><td>' + BidData[0].BidSeaExportDetails[i].PoDate + '</td><td class=text-right>' + BidData[0].BidSeaExportDetails[i].PoValue + '</td><td>' + BidData[0].BidSeaExportDetails[i].ItemClosingTime + '</td><td><div class="pull-left"> <div id=spinner' + i + ' class="pull-left"><div class="input-group" style="width:110px;"><div class="spinner-buttons input-group-btn"><button type="button" class="btn spinner-down red btn-sm"><i class="fa fa-minus"></i></button> </div><input type=text class="spinner-input form-control input-sm" id=txtitemBidDuration' + i + ' maxlength="3" readonly><div class="spinner-buttons input-group-btn "><button type="button" class="btn spinner-up blue btn-sm"><i class="fa fa-plus"></i></button></div></div></div><button id="btnextendA" type="button" class="btn green btn-sm" onclick="fnTimeUpdateS(\'' + i + '\',\'' + BidData[0].BidSeaExportDetails[i].SEID + '\')">Go</button><div class="col-md-12"><p class="form-control-static" id=extendedDuration' + i + ' style="color:#3c763d; font-weight: 600; display: none;">Time&nbsp;Extended&nbsp;Successfully</p></div></td></tr>');
                        $('#spinner' + i).spinner({ value: 0, step: 1, min: 0, max: 999 }); //BidData[0].BidSeaExportDetails[i].ItemBidDuration
                        
                        if (BidData[0].BidDetails[0].BidForID == "81" || BidData[0].BidDetails[0].BidForID=="1") {
                            jQuery("#tblServicesProductPrevtab_0").append("<tr id=trid" + i + "><td><a class=isDisabledClass onclick=editValues(\'divbidItemsPrevtab_0\',\'trid" + i + "\') ><i class='fa fa-pencil'></i></a></td><td>" + BidData[0].BidSeaExportDetails[i].DestinationPort + "</td><td>" + BidData[0].BidSeaExportDetails[i].Remarks + "</td><td class=text-right>" + BidData[0].BidSeaExportDetails[i].Targetprice + "</td><td class=text-right>" + BidData[0].BidSeaExportDetails[i].Quantity + "</td><td>" + BidData[0].BidSeaExportDetails[i].UOM + "</td><td class=text-right>" + BidData[0].BidSeaExportDetails[i].CeilingPrice + " <a class='changeMinDecreament ml-1' onclick=editbidstartprice(" + BidData[0].BidSeaExportDetails[i].SEID + ",\'trid" + i + "\')><i class='fa fa-pencil'></i></a></td><td>" + BidData[0].BidSeaExportDetails[i].MaskVendor + "</td><td class=text-right>" + BidData[0].BidSeaExportDetails[i].MinimumDecreament + " <a class='changeMinDecreament ml-1' onclick=editMinDecreament(" + BidData[0].BidSeaExportDetails[i].SEID + ",\'trid" + i + "\')><i class='fa fa-pencil'></i></a></td><td>" + decrementon + "</td><td class=hide>" + BidData[0].BidSeaExportDetails[i].DecreamentOn + "</td><td class=text-right>" + BidData[0].BidSeaExportDetails[i].LastInvoicePrice + "</td><td class=text-right>" + BidData[0].BidSeaExportDetails[i].ItemBidDuration + "</td><td>" + BidData[0].BidSeaExportDetails[i].ItemClosingTime + "</td><td class=hide>" + BidData[0].BidSeaExportDetails[i].SEID + "</td><td>" + BidData[0].BidSeaExportDetails[i].MaskL1Price + "&nbsp;<a class='lambdafactor' onclick=editShowL1Price(" + BidData[0].BidSeaExportDetails[i].SEID + ",\'trid" + i + "\')><i class='fa fa-pencil'></i></a></td><td>" + BidData[0].BidSeaExportDetails[i].ShowStartPrice + "&nbsp;<a class='lambdafactor' onclick=editShowStartPrice(" + BidData[0].BidSeaExportDetails[i].SEID + ",\'trid" + i + "\')><i class='fa fa-pencil'></i></a></td><td class=text-right>" + BidData[0].BidSeaExportDetails[i].PoUnitRate + "</td><td>" + BidData[0].BidSeaExportDetails[i].PoNo + "</td><td>" + BidData[0].BidSeaExportDetails[i].PoVendorName + "</td><td>" + BidData[0].BidSeaExportDetails[i].PoDate + "</td><td class=text-right>" + BidData[0].BidSeaExportDetails[i].PoValue + "</td></tr>");
                        }
                        else {
                            jQuery("#tblServicesProductPrevtab_0").append("<tr id=trid" + i + "><td><a class=isDisabledClass onclick=editValues(\'divbidItemsPrevtab_0\',\'trid" + i + "\') ><i class='fa fa-pencil'></i></a></td><td>" + BidData[0].BidSeaExportDetails[i].DestinationPort + "</td><td>" + BidData[0].BidSeaExportDetails[i].Remarks + "</td><td class=text-right>" + BidData[0].BidSeaExportDetails[i].Targetprice + "</td><td class=text-right>" + BidData[0].BidSeaExportDetails[i].Quantity + "</td><td>" + BidData[0].BidSeaExportDetails[i].UOM + "</td><td class=text-right>" + BidData[0].BidSeaExportDetails[i].CeilingPrice + " <a class='changeMinDecreament ml-1' onclick=editbidstartprice(" + BidData[0].BidSeaExportDetails[i].SEID + ",\'trid" + i + "\')><i class='fa fa-pencil'></i></a></td><td>" + BidData[0].BidSeaExportDetails[i].MaskVendor + "</td><td class=text-right>" + BidData[0].BidSeaExportDetails[i].MinimumDecreament + " <a class='changeMinDecreament ml-1' onclick=editMinDecreament(" + BidData[0].BidSeaExportDetails[i].SEID + ",\'trid" + i + "\')><i class='fa fa-pencil'></i></a></td><td>" + decrementon + "</td><td class=hide>" + BidData[0].BidSeaExportDetails[i].DecreamentOn + "</td><td class=text-right>" + BidData[0].BidSeaExportDetails[i].LastInvoicePrice + "</td><td class=text-right>" + BidData[0].BidSeaExportDetails[i].ItemBidDuration + "</td><td>" + BidData[0].BidSeaExportDetails[i].ItemClosingTime + "</td><td class=hide>" + BidData[0].BidSeaExportDetails[i].SEID + "</td><td>" + BidData[0].BidSeaExportDetails[i].MaskL1Price + "</td><td>" + BidData[0].BidSeaExportDetails[i].ShowStartPrice + "&nbsp;<a class='lambdafactor' onclick=editShowStartPrice(" + BidData[0].BidSeaExportDetails[i].SEID + ",\'trid" + i + "\')><i class='fa fa-pencil'></i></a></td><td class=text-right>" + BidData[0].BidSeaExportDetails[i].PoUnitRate + "</td><td>" + BidData[0].BidSeaExportDetails[i].PoNo + "</td><td>" + BidData[0].BidSeaExportDetails[i].PoVendorName + "</td><td>" + BidData[0].BidSeaExportDetails[i].PoDate + "</td><td class=text-right>" + BidData[0].BidSeaExportDetails[i].PoValue + "</td></tr>");
                        }
                        
                    }
                    else {

                        jQuery("#tblServicesProductPrev").append("<tr id=tridPrev" + i + "><td>" + BidData[0].BidSeaExportDetails[i].DestinationPort + "</td><td>" + BidData[0].BidSeaExportDetails[i].Remarks + "</td><td class=text-right>" + BidData[0].BidSeaExportDetails[i].Targetprice + "</td><td class=text-right>" + BidData[0].BidSeaExportDetails[i].Quantity + "</td><td>" + BidData[0].BidSeaExportDetails[i].UOM + "</td><td class=text-right>" + BidData[0].BidSeaExportDetails[i].CeilingPrice + "</td><td class=hide>" + BidData[0].BidSeaExportDetails[i].MaskVendor + "</td><td class=text-right>" + BidData[0].BidSeaExportDetails[i].MinimumDecreament + "</td><td>" + decrementon + "</td><td class=hide>" + BidData[0].BidSeaExportDetails[i].DecreamentOn + "</td><td class=text-right>" + BidData[0].BidSeaExportDetails[i].LastInvoicePrice + '</td><td>' + BidData[0].BidSeaExportDetails[i].MaskL1Price + '</td><td>' + BidData[0].BidSeaExportDetails[i].ShowStartPrice + '</td><td class=text-right>' + BidData[0].BidSeaExportDetails[i].PoUnitRate + '</td><td>' + BidData[0].BidSeaExportDetails[i].PoNo + '</td><td>' + BidData[0].BidSeaExportDetails[i].PoVendorName + '</td><td>' + BidData[0].BidSeaExportDetails[i].PoDate + '</td><td class=text-right>' + BidData[0].BidSeaExportDetails[i].PoValue + '</td></tr>');
                        if (BidData[0].BidDetails[0].BidForID == "81" || BidData[0].BidDetails[0].BidForID == "1") {
                            jQuery("#tblServicesProductPrevtab_0").append("<tr id=trid" + i + "><td style='width:150px !important;'><a class='isDisabledClass' onclick=editValues('\divbidItemsPrevtab_0\',\'trid" + i + "\') ><i class='fa fa-pencil'></i></a></td><td>" + BidData[0].BidSeaExportDetails[i].DestinationPort + "</td><td>" + BidData[0].BidSeaExportDetails[i].Remarks + "</td><td class=text-right>" + BidData[0].BidSeaExportDetails[i].Targetprice + "</td><td class=text-right>" + BidData[0].BidSeaExportDetails[i].Quantity + "</td><td>" + BidData[0].BidSeaExportDetails[i].UOM + "</td><td class=text-right>" + BidData[0].BidSeaExportDetails[i].CeilingPrice + " <a class='changeMinDecreament ml-1' onclick=editbidstartprice(" + BidData[0].BidSeaExportDetails[i].SEID + ",\'trid" + i + "\')><i class='fa fa-pencil'></i></a></td><td>" + BidData[0].BidSeaExportDetails[i].MaskVendor + "</td><td class=text-right>" + BidData[0].BidSeaExportDetails[i].MinimumDecreament + " <a class='changeMinDecreament ml-1' onclick=editMinDecreament(" + BidData[0].BidSeaExportDetails[i].SEID + ",\'trid" + i + "\')><i class='fa fa-pencil'></i></a></td><td>" + decrementon + "</td><td class=hide>" + BidData[0].BidSeaExportDetails[i].DecreamentOn + "</td><td class=text-right>" + BidData[0].BidSeaExportDetails[i].LastInvoicePrice + "</td><td class=hide>" + BidData[0].BidSeaExportDetails[i].SEID + "</td><td>" + BidData[0].BidSeaExportDetails[i].MaskL1Price + "&nbsp;<a class='lambdafactor' onclick=editShowL1Price(" + BidData[0].BidSeaExportDetails[i].SEID + ",\'trid" + i + "\')><i class='fa fa-pencil'></i></a></td><td>" + BidData[0].BidSeaExportDetails[i].ShowStartPrice + "&nbsp;<a class='lambdafactor' onclick=editShowStartPrice(" + BidData[0].BidSeaExportDetails[i].SEID + ",\'trid" + i + "\')><i class='fa fa-pencil'></i></a></td><td class=text-right>" + BidData[0].BidSeaExportDetails[i].PoUnitRate + "</td><td>" + BidData[0].BidSeaExportDetails[i].PoNo + "</td><td>" + BidData[0].BidSeaExportDetails[i].PoVendorName + "</td><td>" + BidData[0].BidSeaExportDetails[i].PoDate + "</td><td class=text-right>" + BidData[0].BidSeaExportDetails[i].PoValue + "</td></tr>");
                        }
                        else {
                            jQuery("#tblServicesProductPrevtab_0").append("<tr id=trid" + i + "><td style='width:150px !important;'><a class='isDisabledClass' onclick=editValues('\divbidItemsPrevtab_0\',\'trid" + i + "\') ><i class='fa fa-pencil'></i></a></td><td>" + BidData[0].BidSeaExportDetails[i].DestinationPort + "</td><td>" + BidData[0].BidSeaExportDetails[i].Remarks + "</td><td class=text-right>" + BidData[0].BidSeaExportDetails[i].Targetprice + "</td><td class=text-right>" + BidData[0].BidSeaExportDetails[i].Quantity + "</td><td>" + BidData[0].BidSeaExportDetails[i].UOM + "</td><td class=text-right>" + BidData[0].BidSeaExportDetails[i].CeilingPrice + " <a class='changeMinDecreament ml-1' onclick=editbidstartprice(" + BidData[0].BidSeaExportDetails[i].SEID + ",\'trid" + i + "\')><i class='fa fa-pencil'></i></a></td><td>" + BidData[0].BidSeaExportDetails[i].MaskVendor + "</td><td class=text-right>" + BidData[0].BidSeaExportDetails[i].MinimumDecreament + " <a class='changeMinDecreament ml-1' onclick=editMinDecreament(" + BidData[0].BidSeaExportDetails[i].SEID + ",\'trid" + i + "\')><i class='fa fa-pencil'></i></a></td><td>" + decrementon + "</td><td class=hide>" + BidData[0].BidSeaExportDetails[i].DecreamentOn + "</td><td class=text-right>" + BidData[0].BidSeaExportDetails[i].LastInvoicePrice + "</td><td class=hide>" + BidData[0].BidSeaExportDetails[i].SEID + "</td><td>" + BidData[0].BidSeaExportDetails[i].MaskL1Price + "</td><td>" + BidData[0].BidSeaExportDetails[i].ShowStartPrice + "&nbsp;<a class='lambdafactor' onclick=editShowStartPrice(" + BidData[0].BidSeaExportDetails[i].SEID + ",\'trid" + i + "\')><i class='fa fa-pencil'></i></a></td><td class=text-right>" + BidData[0].BidSeaExportDetails[i].PoUnitRate + "</td><td>" + BidData[0].BidSeaExportDetails[i].PoNo + "</td><td>" + BidData[0].BidSeaExportDetails[i].PoVendorName + "</td><td>" + BidData[0].BidSeaExportDetails[i].PoDate + "</td><td class=text-right>" + BidData[0].BidSeaExportDetails[i].PoValue + "</td></tr>");
                        }
                    }

                    //+ BidData[0].BidSeaExportDetails[i].ItemBidDuration + 
                }
                jQuery('#selectedvendorlistsPrev> tbody').empty()
                jQuery('#selectedvendorlistsPrevtab_0> tbody').empty()
                FlagForCheckShowPrice = 'N';
                for (var i = 0; i < BidData[0].BidVendorDetails.length; i++) {

                    jQuery('#selectedvendorlistsPrev').append('<tr ><td class=hide>' + BidData[0].BidVendorDetails[i].VendorID + '</td><td>' + BidData[0].BidVendorDetails[i].VendorName + '</td><td>' + BidData[0].BidVendorDetails[i].AdvFactor + '</td></tr>');
                    jQuery('#selectedvendorlistsPrevtab_0').append('<tr ><td class=hide>' + BidData[0].BidVendorDetails[i].VendorID + '</td><td>' + BidData[0].BidVendorDetails[i].VendorName + '</td><td class=text-right>' + BidData[0].BidVendorDetails[i].AdvFactor + '</td></tr>')
                    if (BidData[0].BidVendorDetails[i].AdvFactor != 0) {
                        FlagForCheckShowPrice = "Y";
                    }
                }
               // jQuery('#selectedvendorlistsPrev> tbody').empty()
                jQuery('#tblparicipantslists> tbody').empty()
                for (var i = 0; i < BidData[0].BidVendorDetails.length; i++) {
                    jQuery('#tblparicipantslists').append('<tr ><td class=hide>' + BidData[0].BidVendorDetails[i].VendorID + '</td><td class=hide>' + BidData[0].BidVendorDetails[i].EmailID + '</td><td>' + BidData[0].BidVendorDetails[i].VendorName + '</td></tr>')
                }
               
                if (FlagForCheckShowPrice == "Y") {
                    $("a.lambdafactor").removeAttr("onclick");
                 // $('.lambdafactor').attr("disabled", "disabled");
                }
                //else {
                //    $('.lambdafactor').removeAttr("disabled", "disabled");
                //}

            }
            }

            if (sessionStorage.getItem('hdnbidtypeid') == 6) {
                $('#hdnClosingval').val('').val(BidData[0].BidDetails[0].BidForID)
                if (BidData[0].BidScrapSalesDetails.length > 0) {
                    var max = BidData[0].BidScrapSalesDetails[0].AttachmentSeqID;
                    $('#wrap_scrollerPrev').show();
                    $('#wrap_scrollerPrevtab_0').show();
                   
                    $('#hdnauctiontype').val(BidData[0].BidDetails[0].BidForID)
                    if (BidData[0].BidDetails[0].BidForID == 81) {
                        jQuery("#tblServicesProductPrev").append("<thead><tr style='background: gray; color: #FFF;'><th>Item/Product</th><th>Target Price</th><th>Quantity</th><th>UOM</th><th>Bid Start Price</th><th>Mask Vendor</th><th>Minimum Increament</th><th>Increament On</th><th>Attachment</th><th class=hide></th><th>Last Invoice Price</th><th class=hide></th><th>Show H1 Price</th><th>Show Start Price</th></tr></thead>");
                        $("#txtBidDurationForBidOpen").removeAttr("disabled", "disabled");
                        $('#btndiv').show()
                        $('#plusbtn').removeAttr("disabled", "disabled");
                        $('#minusbtn').removeAttr("disabled", "disabled");
                        jQuery("#tblServicesProductPrevtab_0").append("<thead><tr style='background: gray; color: #FFF;'><th></th><th>Item/Product</th><th>Target Price</th><th>Quantity</th><th>UOM</th><th>Bid Start Price</th><th>Mask Vendor</th><th>Minimum Increament</th><th>Increament On</th><th>Attachment</th><th class=hide></th><th>Last Invoice Price</th><th class=hide></th><th>Show H1 Price</th><th>Show Start Price</th></tr></thead>");
                    }
                    if (BidData[0].BidDetails[0].BidForID == 82) {
                        jQuery("#tblServicesProductPrev").append("<thead><tr style='background: gray; color: #FFF;'><th>Item/Product</th><th>Target Price</th><th>Quantity</th><th>UOM</th><th>Bid Start Price</th><th>Mask Vendor</th><th>Minimum Increament</th><th>Increament On</th><th>Attachment</th><th class=hide></th><th>Last Invoice Price</th><th class=hide></th><th class=hide>Show L1 Price</th></tr></thead>");
                        $("#txtBidDurationForBidOpen").attr("disabled", "disabled");
                        $('#btndiv').hide()
                        $('#plusbtn').attr("disabled", "disabled");
                        $('#minusbtn').attr("disabled", "disabled");
                        jQuery("#tblServicesProductPrevtab_0").append("<thead><tr style='background: gray; color: #FFF;'><th></th><th>Item/Product</th><th>Target Price</th><th>Quantity</th><th>UOM</th><th>Ceiling/ Max Price</th><th>Mask Vendor</th><th class=hide>Minimum Increament</th><th class=hide>Increament On</th><th>Attachment</th><th class=hide></th><th>Last Invoice Price</th><th class=hide></th><th>Starting Price</th><th>Price Increment Frequency</th><th>Price Increment Amount</th><th class=hide>Show L1 Price</th></tr></thead>");
                    }
                    for (var i = 0; i < BidData[0].BidScrapSalesDetails.length; i++) {
                        if (max < BidData[0].BidScrapSalesDetails[i].AttachmentSeqID) {
                            max = BidData[0].BidScrapSalesDetails[i].AttachmentSeqID
                        }
                        FileseqNo = max
                        var increamenton = ''

                        if (BidData[0].BidScrapSalesDetails[i].IncreamentOn == 'A')
                            increamenton = 'Amount'
                        else
                            increamenton = '%age'

                        var attach = (BidData[0].BidScrapSalesDetails[i].Attachments).replace(/\s/g, "%20");

                       
                        if (BidData[0].BidDetails[0].BidForID == 81) {

                            jQuery("#tblServicesProductPrev").append('<tr id=tridPrev' + i + '><td>' + BidData[0].BidScrapSalesDetails[i].ItemName + '</td><td class=text-right>' + thousands_separators(BidData[0].BidScrapSalesDetails[i].Targetprice) + '</td><td class=text-right>' + thousands_separators(BidData[0].BidScrapSalesDetails[i].Quantity) + '</td><td>' + BidData[0].BidScrapSalesDetails[i].MeasurementUnit + '</td><td class=text-right >' + BidData[0].BidScrapSalesDetails[i].CeilingPrice + '</td><td>' + BidData[0].BidScrapSalesDetails[i].MaskVendor + '</td><td class=text-right>' + BidData[0].BidScrapSalesDetails[i].MinimumIncreament + '</td><td>' + increamenton + '</td><td><a href=PortalDocs/Bid/' + sessionStorage.getItem('CurrentBidID') + '/' + BidData[0].BidScrapSalesDetails[i].AttachmentSeqID + '/' + attach + ' style=text-decoration:none; >' + BidData[0].BidScrapSalesDetails[i].Attachments + ' </a></td><td class=text-right>' + BidData[0].BidScrapSalesDetails[i].LastSalePrice + '</td><td class=hide>' + BidData[0].BidScrapSalesDetails[i].AttachmentSeqID + '</td><td>' + BidData[0].BidScrapSalesDetails[i].ShowHLPrice + '</td><td>' + BidData[0].BidScrapSalesDetails[i].ShowStartPrice + '</td></tr>');
                            jQuery("#tblServicesProductPrevtab_0").append('<tr id=trid' + i + '><td><a class="isDisabledClass" onclick="editValues(\'divbidItemsPrevtab_0\',\'trid' + i + '\')" ><i class="fa fa-pencil"></i></a></td><td>' + BidData[0].BidScrapSalesDetails[i].ItemName + '</td><td class=text-right>' + thousands_separators(BidData[0].BidScrapSalesDetails[i].Targetprice) + '</td><td class=text-right>' + thousands_separators(BidData[0].BidScrapSalesDetails[i].Quantity) + '</td><td>' + BidData[0].BidScrapSalesDetails[i].MeasurementUnit + '</td><td class=text-right>' + thousands_separators(BidData[0].BidScrapSalesDetails[i].CeilingPrice) + '&nbsp;<a class="editbidstartprice ml-1" onclick=editbidstartpriceFA(' + BidData[0].BidScrapSalesDetails[i].PSID + ',\"trid' + i + '"\)><i class="fa fa-pencil"></i></a></td><td>' + BidData[0].BidScrapSalesDetails[i].MaskVendor + '</td><td>' + BidData[0].BidScrapSalesDetails[i].MinimumIncreament + '&nbsp;<a class="changeMinDecreament ml-1" onclick=editincreament(' + BidData[0].BidScrapSalesDetails[i].PSID + ',\"trid' + i + '"\)><i class="fa fa-pencil"></i></a></td><td>' + increamenton + '</td><td><a href=PortalDocs/Bid/' + jQuery('#ddlbid').val() + '/' + BidData[0].BidScrapSalesDetails[i].AttachmentSeqID + '/' + attach + ' style=text-decoration:none; >' + BidData[0].BidScrapSalesDetails[i].Attachments + '</a></td><td class=hide>' + BidData[0].BidScrapSalesDetails[i].IncreamentOn + '</td><td class=text-right>' + thousands_separators(BidData[0].BidScrapSalesDetails[i].LastSalePrice) + '</td><td class=hide>' + BidData[0].BidScrapSalesDetails[i].AttachmentSeqID + '</td><td  class=hide>' + BidData[0].BidScrapSalesDetails[i].PSID + '</td><td>' + BidData[0].BidScrapSalesDetails[i].ShowHLPrice + '&nbsp;<a  onclick=editShowL1Price(' + BidData[0].BidScrapSalesDetails[i].PSID + ',\"trid' + i + '"\)><i class="fa fa-pencil"></i></a></td><td>' + BidData[0].BidScrapSalesDetails[i].ShowStartPrice + '&nbsp;<a class=lambdafactor onclick=editShowStartPrice(' + BidData[0].BidScrapSalesDetails[i].PSID + ',\'trid' + i + '\')><i class="fa fa-pencil"></i></a></td></tr>');

                        }

                        if (BidData[0].BidDetails[0].BidForID == 82) {
                            jQuery("#tblServicesProductPrev").append('<tr id=tridPrev' + i + '><td>' + BidData[0].BidScrapSalesDetails[i].ItemName + '</td><td class=text-right>' + thousands_separators(BidData[0].BidScrapSalesDetails[i].Targetprice) + '</td><td class=text-right>' + thousands_separators(BidData[0].BidScrapSalesDetails[i].Quantity) + '</td><td>' + BidData[0].BidScrapSalesDetails[i].MeasurementUnit + '</td><td class=text-right >' + BidData[0].BidScrapSalesDetails[i].CeilingPrice + '</td><td>' + BidData[0].BidScrapSalesDetails[i].MaskVendor + '</td><td class=text-right>' + BidData[0].BidScrapSalesDetails[i].MinimumIncreament + '</td><td>' + increamenton + '</td><td><a href=PortalDocs/Bid/' + sessionStorage.getItem('CurrentBidID') + '/' + BidData[0].BidScrapSalesDetails[i].AttachmentSeqID + '/' + attach + ' style=text-decoration:none; >' + BidData[0].BidScrapSalesDetails[i].Attachments + ' </a></td><td class=text-right>' + BidData[0].BidScrapSalesDetails[i].LastSalePrice + '</td><td class=hide>' + BidData[0].BidScrapSalesDetails[i].AttachmentSeqID + '</td><td class=hide>' + BidData[0].BidScrapSalesDetails[i].ShowHLPrice + '</td></tr>');
                            
                            jQuery("#tblServicesProductPrevtab_0").append('<tr id=tridPrev' + i + '><td><a class="isDisabledClass" onclick="editValues(\'divbidItemsPrevtab_0\',\'tridPrev' + i + '\')" ><i class="fa fa-pencil"></i></a></td><td>' + BidData[0].BidScrapSalesDetails[i].ItemName + '</td><td class=text-right>' + thousands_separators(BidData[0].BidScrapSalesDetails[i].Targetprice) + '</td><td class=text-right>' + thousands_separators(BidData[0].BidScrapSalesDetails[i].Quantity) + '</td><td class=text-right>' + BidData[0].BidScrapSalesDetails[i].MeasurementUnit + '</td><td class=text-right>' + thousands_separators(BidData[0].BidScrapSalesDetails[i].CeilingPrice) + '&nbsp;<a class="editbidstartprice ml-1" onclick=editbidstartpriceFA(' + BidData[0].BidScrapSalesDetails[i].PSID + ',\"trid' + i + '"\)><i class="fa fa-pencil"></i></a></td><td>' + BidData[0].BidScrapSalesDetails[i].MaskVendor + '</td><td class=hide>' + BidData[0].BidScrapSalesDetails[i].MinimumIncreament + '&nbsp;<a class="changeMinDecreament ml-1" onclick=editincreament(' + BidData[0].BidScrapSalesDetails[i].PSID + ',\"tridPrev' + i + '"\)><i class="fa fa-pencil"></i></a></td><td class=hide>' + increamenton + '</td><td><a href=PortalDocs/Bid/' + sessionStorage.getItem('CurrentBidID') + '/' + BidData[0].BidScrapSalesDetails[i].AttachmentSeqID + '/' + attach + ' style=text-decoration:none; >' + BidData[0].BidScrapSalesDetails[i].Attachments + ' </a></td><td class=hide>' + BidData[0].BidScrapSalesDetails[i].IncreamentOn + '</td><td class=text-right>' + thousands_separators(BidData[0].BidScrapSalesDetails[i].LastSalePrice) + '</td><td class=hide>' + BidData[0].BidScrapSalesDetails[i].AttachmentSeqID + '</td><td class=text-right>' + thousands_separators(BidData[0].BidScrapSalesDetails[i].StartingPrice) + '</td><td class=text-right>' + thousands_separators(BidData[0].BidScrapSalesDetails[i].PriceReductionFrequency) + '</td><td class=text-right>' + thousands_separators(BidData[0].BidScrapSalesDetails[i].PriceReductionAmount) + '</td><td  class=hide>' + BidData[0].BidScrapSalesDetails[i].PSID + '</td><td class=hide>' + BidData[0].BidScrapSalesDetails[i].ShowHLPrice + '&nbsp;<a  onclick=editShowL1Price(' + BidData[0].BidScrapSalesDetails[i].PSID + ',\"tridPrev' + i + '"\)><i class="fa fa-pencil"></i></a></td></tr>');

                        }

                    }
                }

                jQuery('#selectedvendorlistsPrev> tbody').empty()
                jQuery('#selectedvendorlistsPrevtab_0> tbody').empty()
                for (var i = 0; i < BidData[0].BidVendorDetails.length; i++) {
                    jQuery('#selectedvendorlistsPrev').append('<tr ><td class=hide>' + BidData[0].BidVendorDetails[i].VendorID + '</td><td>' + BidData[0].BidVendorDetails[i].VendorName + '</td><td>' + BidData[0].BidVendorDetails[i].AdvFactor + '</td></tr>');
                    jQuery('#selectedvendorlistsPrevtab_0').append('<tr ><td class=hide>' + BidData[0].BidVendorDetails[i].VendorID + '</td><td>' + BidData[0].BidVendorDetails[i].VendorName + '</td><td>' + BidData[0].BidVendorDetails[i].AdvFactor + '</td></tr>')
                }
                jQuery('#tblparicipantslists> tbody').empty()
                for (var i = 0; i < BidData[0].BidVendorDetails.length; i++) {
                    jQuery('#tblparicipantslists').append('<tr ><td class=hide>' + BidData[0].BidVendorDetails[i].VendorID + '</td><td class=hide>' + BidData[0].BidVendorDetails[i].EmailID + '</td><<td>' + BidData[0].BidVendorDetails[i].VendorName + '</td></tr>')
                }
            }
            if (BidData[0].BidDetails[0].isRunningBid == 'RunningBid' || BidData[0].BidDetails[0].isRunningBid == 'ClosedBid') {
               
                $("a.isDisabledClass").removeAttr("onclick");
            } else if (BidData[0].BidDetails[0].isRunningBid == 'ClosedBid') {
                //$("a.changeMinDecreament").hide();
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
        });



}

function fnTimeUpdateS(index, seaid) {

    SeId = seaid


    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    var Data = {
        "BidClosingType": $('#hdnClosingval').val(),
        "BidID": jQuery('#ddlbid').val(),
        "BidDuration": jQuery('#txtitemBidDuration' + index).val(),
        "SEID": SeId
    }
    // alert(JSON.stringify(Data))
    jQuery.ajax({
        url: sessionStorage.getItem("APIPath") + "ConfigureBid/UpdateBidTime/",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "POST",
        data: JSON.stringify(Data),
        contentType: "application/json; charset=utf-8",
        success: function(data, status, jqXHR) {

            if (data[0].Status == "1") {
                $('#extendedDuration' + index).show()

            }
            else if (data[0].Status == "-1") {
                $('#extendedDuration' + index).text("This Item is already expired.").css('color', 'red')
                $('#extendedDuration' + index).show()

            }
            setTimeout(function() { fetchallexportdetails() }, 5000)
            jQuery.unblockUI();
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
    })
}

function Dateandtimevalidate(indexNo) {

    jQuery.ajax({
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ConfigureBid/Dateandtimevalidate/?BidDate=" + jQuery("#txtinputBidDatePrevtab_0").val() + "&BidTime=" + jQuery("#txtinputbidTimePrevtab_0").val(),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "GET",
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (RFQData) {

            if (RFQData[0].BidId == 1) {
                formSubmitEditEvent();
            } else {
                bootbox.alert("Date and Time should not be less than current date and time.");
                return false;
            }
            
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else{
                bootbox.alert("you have some error. Please try again.");
            } 
            return false;
            jQuery.unblockUI();
        }
        

    });

}
function closeOpenForBidOpen() {
    //bootbox.dialog({
    //    message: "You have made changes to the event, Do you want to send notifications to participants.",
    //    buttons: {
    //        confirm: {
    //            label: "Yes",
    //            className: "btn-success",
    //            callback: function () {
    //                DateandtimevalidateForBidOpen('Y')
    //            }
    //        },
    //        cancel: {
    //            label: "No",
    //            className: "btn-default",
    //            callback: function () {
    //                DateandtimevalidateForBidOpen('N')
    //            }
    //        }
    //    }
    //});
    DateandtimevalidateForBidOpen('Y')
}
function convertTo24Hour(time) {
    var hours = parseInt(time.substr(0, 2));
    if (time.indexOf('am') != -1 && hours == 12) {
        time = time.replace('12', '0');
    }
    if (time.indexOf('pm') != -1 && hours < 12) {
        time = time.replace(hours, (hours + 12));
    }
    return time.replace(/(am|pm)/, '');
}
function DateandtimevalidateForBidOpen(ismailsend) {
    var s = new Date();
    console.log(s)
    s.setMinutes(s.getMinutes() + 5);
    var datearray = $("#txtbidDate").val().split("/");
    var selectedtime = datearray[1] + '/' + datearray[0] + '/' + datearray[2];
    selectedtime = new Date(selectedtime + ' ' + convertTo24Hour($("#txtbidTime").val().toLowerCase()));
    
    if (jQuery("#txtbidTime").val() == "" || jQuery("#txtbidDate").val() == "" || jQuery("#txtBidDurationForBidOpen").val() == "") {
        
        erroropenbid.show();
        $('#erropenbid').html('Please fill all Details');
        erroropenbid.fadeOut(3000);
        App.scrollTo(erroropenbid, -200);
       
    }
    //else if (selectedtime < s && $('#hdnClosingval').val() == "S") {
    //    erroropenbid.show();
    //    $('#erropenbid').html('Please select  5 min later of current time.');
    //    erroropenbid.fadeOut(3000);
    //    App.scrollTo(erroropenbid, -200);
    //}
    else {
        fnTimeUpdateClosedBid(ismailsend);
        //jQuery.ajax({
        //    contentType: "application/json; charset=utf-8",
        //    url: sessionStorage.getItem("APIPath") + "ConfigureBid/Dateandtimevalidate/?BidDate=" + jQuery("#txtbidDate").val() + "&BidTime=" + jQuery("#txtbidTime").val(),
        //    type: "GET",
        //    cache: false,
        //    crossDomain: true,
        //    dataType: "json",
        //    success: function (RFQData) {

        //        if (RFQData[0].BidId == 1) {
        //            fnTimeUpdateClosedBid();
        //        } else {
        //            bootbox.alert("Date and Time should not be less than current date and time.");
        //            return false;
        //        }

        //    },
        //    error: function () {

        //        bootbox.alert("you have some error. Please try again.");

        //    }

        //});
    }

}


function fnTimeUpdate() {
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    var Data = {
        "BidClosingType": $('#hdnClosingval').val(),
        "BidID": jQuery('#ddlbid').val(),
        "BidDuration": jQuery('#txtBidDurationPrev').val(),
        "SEID": 0
       


    }
    //alert(JSON.stringify(Data))
    jQuery.ajax({
        url: sessionStorage.getItem("APIPath") + "ConfigureBid/UpdateBidTime/",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "POST",
        data: JSON.stringify(Data),
        contentType: "application/json; charset=utf-8",
        success: function(data, status, jqXHR) {

            if (data[0].Status == "1") {
                $('#extendedDurationPara').show()
            }

            jQuery.unblockUI();
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
           
            return false;
            jQuery.unblockUI();
        }
    })
}

function fnTimeUpdateClosedBid(isMailSend) {
    
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    
    var Data = {
        "BidStatus": $('#ddlBidStatus option:selected').val(),
        "BidID": jQuery('#ddlbid').val(),
        "BidDuration": jQuery('#txtBidDurationForBidOpen').val(),
        "BidDate": jQuery('#txtbidDate').val(),
        "BidTime": jQuery('#txtbidTime').val(),
        "IsMailSend": isMailSend,
        "FinalStatus": $('#ddlBidfinalStatus').val()
    }
  // alert(JSON.stringify(Data))
    jQuery.ajax({
        url: sessionStorage.getItem("APIPath") + "ConfigureBid/UpdateBidStatus",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "POST",
        data: JSON.stringify(Data),
        contentType: "application/json; charset=utf-8",
        success: function (data, status, jqXHR) {

            if (data[0].Status == "1") {
               // $('#extendedDurationPara').show()
                erroropenbid.hide();
                successopenbid.show();
                $('#succopenbid').html('Bid updated successfully');
                successopenbid.fadeOut(3000);
                App.scrollTo(successopenbid, -200);
            }

            jQuery.unblockUI();
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else{
                successopenbid.hide();
                erroropenbid.show();
                $('#erropenbid').html('You have error.Please try agian.');
                erroropenbid.fadeOut(3000);
                App.scrollTo(erroropenbid, -200);
            }
           
            return false;
            jQuery.unblockUI();
        }
       
    })
}

function editValues(divName, rowid) {
    
    showhideItemBidDuration();
    isBidEventChanged = true;
    //if (divName == 'divbidDatePrevtab_0') {
    //    $("#" + divName).show();
    //    $("#txtinputBidDatePrevtab_0").val(jQuery("#txtbidDatePrevtab_0").html());
    //}
    if (divName == 'divbidTimePrevtab_0') {
        $("#divbidDatePrevtab_0").show();
        $("#btn-submit-datetime").show();
        $("#btn-submit-modal").hide();
        $("#" + divName).show();
        $("#txtinputbidTimePrevtab_0").val(jQuery("#txtbidTimePrevtab_0").html());
        $("#" + rowid).show();
        $("#txtinputBidDatePrevtab_0").val(jQuery("#txtbidDatePrevtab_0").html());
    }
    if (divName == 'divbidAttachFilePrevtab_0') {
        $("#" + divName).show();
    }
    if (divName == 'divbidTermsFilePrevtab_0') {
        $("#" + divName).show();
    }
    if (divName == 'divbidShowL1L2') {
        $("#" + divName).show();
        
        if (sessionStorage.getItem('hdnbidtypeid') == 7) {
            $('#div_RArank').removeClass('hide')
            $('#div_FArank').addClass('hide')
            $("#drpshowL1L2").val(jQuery("#showL1l2").text() == 'As L1, L2, L3 etc.' ? 'Y' : 'N');
            
        }
        else if (sessionStorage.getItem('hdnbidtypeid') == 6) {
           
            $('#div_FArank').removeClass('hide')
            $('#div_RArank').addClass('hide')
            $("#drpshowH1H2").val(jQuery("#showL1l2").text() == 'As H1, H2, H3 etc.' ? 'Y' : 'N');
           
        }
      
    }
    if (divName == 'divbidItemsPrevtab_0') {

        if (sessionStorage.getItem('hdnbidtypeid') == 7) {
            $('#lblshowprice').html("Show L1 Price")
            $(".RaAuctionFields").show();
            $(".faEngilshAuctionFields").hide();
            $(".fadutchAuctionFields").hide();
            $("#" + divName).show();
            $('#rowid').val(rowid.id);
            console.log(' > ', $("#" + rowid));
            $('#txtdestinationPort').val($("#" + rowid).find("td:eq(1)").text())
            $('#txtbiddescriptionP').val($("#" + rowid).find("td:eq(2)").text())

            $('#txttargetprice').val($("#" + rowid).find("td:eq(3)").text())

            $('#txtquantitiy').val($("#" + rowid).find("td:eq(4)").text())
            $('#dropuom').val($("#" + rowid).find("td:eq(5)").text())
            $('#txtUOM').val($("#" + rowid).find("td:eq(5)").text())
            $('#txtCeilingPrice').val($("#" + rowid).find("td:eq(6)").text())
            $('#checkmaskvendor').val($("#" + rowid).find("td:eq(7)").text())
          
            if ($('#hdnClosingval').val() == 'A') {
                hdnSeId = $("#" + rowid).find("td:eq(12)").text()
                
                $('#checkL1Price').val($("#" + rowid).find("td:eq(13)").text().trim())
                $('#checkshowstartPrice').val($("#" + rowid).find("td:eq(14)").text().trim())
            } else {
                hdnSeId = $("#" + rowid).find("td:eq(14)").text()
                
                $('#checkL1Price').val($("#" + rowid).find("td:eq(15)").text().trim())
                $('#checkshowstartPrice').val($("#" + rowid).find("td:eq(16)").text().trim())
            }
            $('#txtminimumdecreament').val($("#" + rowid).find("td:eq(8)").text())
            $("#txtselectedCurrency").val($("#dropCurrencyPrevtab_0").html());
            $('#drpdecreamenton').val($("#" + rowid).find("td:eq(10)").text())
            $('#txtlastinvoiceprice').val($("#" + rowid).find("td:eq(11)").text())
            $('#txtitembidduration').val($("#" + rowid).find("td:eq(12)").text())
           

        }
        else if (sessionStorage.getItem('hdnbidtypeid') == 6) {
            $(".RaAuctionFields").hide();
            $(".faEngilshAuctionFields").show();
            $("#" + divName).show();
            $('#rowid').val(rowid.id);
            console.log(' > ', $("#" + rowid));
           // alert($("#" + rowid).find("td:eq(1)").text())
            $('#txtshortname').val($("#" + rowid).find("td:eq(1)").text())
            //$('#txtbiddescriptionP').val($("#" + rowid).find("td:eq(2)").text())

            $('#txttargetprice').val($("#" + rowid).find("td:eq(2)").text())

            $('#txtquantitiy').val($("#" + rowid).find("td:eq(3)").text())
            $('#dropuom').val($("#" + rowid).find("td:eq(4)").text())
            $('#txtUOM').val($("#" + rowid).find("td:eq(4)").text())
            $('#txtCeilingPrice').val($("#" + rowid).find("td:eq(5)").text())
            $('#checkmaskvendor').val($("#" + rowid).find("td:eq(6)").text())
            if ($('#hdnClosingval').val() == 81) {
                $('#lblshowprice').html("Show H1 Price")
                hdnSeId = $("#" + rowid).find("td:eq(13)").text()
                $('#txtminimumdecreament').val($("#" + rowid).find("td:eq(7)").text())
                $('#checkL1Price').val($("#" + rowid).find("td:eq(14)").text().trim())
                $('#checkshowstartPrice').val($("#" + rowid).find("td:eq(15)").text().trim())

                $('#lblforonltfaeng').show();
                $('#RAFAEnglishonly').show();
                $('.RAFAEnglishonly').show();
                $('#BSPENG').show();
                $(".fadutchAuctionFields").hide();
                
            } else {
               
                $('#lblshowprice').html("Show L1 Price")
                hdnSeId = $("#" + rowid).find("td:eq(16)").text()
                $('#txtminimumdecreament').val($("#" + rowid).find("td:eq(13)").text())
                //$('#checkL1Price').val($("#" + rowid).find("td:eq(17)").text())
                $('#checkL1Price').val('N');
                $(".fadutchAuctionFields").show();
                $('#lblforonltfaeng').hide();
                $('#RAFAEnglishonly').hide();
                $('.RAFAEnglishonly').hide();
                $('#BSPENG').hide();
                $(".fadutchAuctionFields").show();
            }
           
            $("#txtselectedCurrency").val($("#dropCurrencyPrevtab_0").html());
            $('#drpdecreamenton').val($("#" + rowid).find("td:eq(10)").text())
            $('#txtlastinvoiceprice').val($("#" + rowid).find("td:eq(11)").text())
            
            $('#txtpriceincreamentamount').val($("#" + rowid).find("td:eq(15)").text())
            $('#txtpricefrequency').val($("#" + rowid).find("td:eq(14)").text())
           
            
            
        }
    }
    
    $("#editValuesModal").modal('show');
}

function formSubmitEditEvent() {
    
    var Data = {};

    //if ($("#txtinputBidDatePrevtab_0").val() != '' && $('#divbidDatePrevtab_0').is(':visible')) {
    //    Data = {
    //        "QueryString": $("#txtinputBidDatePrevtab_0").val(),
    //        "valType": "BD",
    //        "BidId": sessionStorage.getItem('hdnbid'),
    //        "BidClosingType": 'NA',
    //        "SeId": 0
    //        }
    //}

    if ($("#txtinputbidTimePrevtab_0").val() != '' && $('#divbidTimePrevtab_0').is(':visible')) {
        Data = {
            "QueryString": $("#txtinputbidTimePrevtab_0").val(),
            "QueryStringDT":$("#txtinputBidDatePrevtab_0").val(),
            "valType": "BTD",
            "BidId": sessionStorage.getItem('hdnbid'),
            "BidClosingType": _bidClosingType,
            "SeId": 0

        }
    }

    if ($('#file1').val() != '' && $('#divbidTermsFilePrevtab_0').is(':visible')) {
        var filename1 = (jQuery('#file1').val().substring(jQuery('#file1').val().lastIndexOf('\\') + 1)).replace(/[&\/\\#,+$~%'":*?<>{}]/g, '_'); //Replace special Characters
        Data = {
            "QueryString": filename1,
            "QueryStringDT":'NA',
            "valType": "BAT",
            "BidId": sessionStorage.getItem('hdnbid'),
            "BidClosingType": 'NA',
            "SeId": 0

        }
    }
    if ($('#drpshowL1L2').val() != '' && $('#divbidShowL1L2').is(':visible')) {
        
        Data = {
            "QueryString": sessionStorage.getItem('hdnbidtypeid') == 6 ? $("#drpshowH1H2").val() : $("#drpshowL1L2").val(),
            "QueryStringDT": 'NA',
            "valType": "BAL",
            "BidId": sessionStorage.getItem('hdnbid'),
            "BidClosingType": 'NA',
            "SeId": 0

        }
    }
    if ($('#file2').val() != '' && $('#divbidAttachFilePrevtab_0').is(':visible')) {
        var filename2 = (jQuery('#file2').val().substring(jQuery('#file2').val().lastIndexOf('\\') + 1)).replace(/[&\/\\#,+$~%'":*?<>{}]/g, '_'); //Replace special Characters
        Data = {
            "QueryString": filename2,
            "QueryStringDT":'NA',
            "valType": "BAO",
            "BidId": sessionStorage.getItem('hdnbid'),
            "BidClosingType": 'NA',
            "SeId": 0

        }
    }
    var targetprice = 0;
    var lastinvoice = 0;
    var _Totalbiddurationfordutch=0;
    if ($("#divbidItemsPrevtab_0").is(':visible')) {
        
        if ($('#txttargetprice').val() != '') {
            targetprice = $('#txttargetprice').val();
        }
        if ($('#txtlastinvoiceprice').val() != '') {
            lastinvoice = $('#txtlastinvoiceprice').val();
        }
        var upateQuery = '';
        if ($('#hdnClosingval').val() == 'A' && sessionStorage.getItem("hdnbidtypeid") == 7) {
            
            upateQuery = "Update BidSeaExportDetails set ItemBidDuration=0,DestinationPort='" + $('#txtdestinationPort').val() + "',Targetprice=" + removeThousandSeperator(targetprice) + ",Quantity=" + removeThousandSeperator($("#txtquantitiy").val()) + ",UOM='" + $('#dropuom').val() + "',LastInvoicePrice=" + removeThousandSeperator(lastinvoice) + ",Remarks='" + $('#txtbiddescriptionP').val() + "',CeilingPrice=" + removeThousandSeperator($('#txtCeilingPrice').val()) + ",MaskVendor='" + $('#checkmaskvendor option:selected').val() + "',MinimumDecreament=" + removeThousandSeperator($('#txtminimumdecreament').val()) + ",DecreamentOn='" + $('#drpdecreamenton option:selected').val() + "',SelectedCurrency='" + $('#txtselectedCurrency').val() + "',MaskL1Price='" + $('#checkL1Price').val() + "',ShowStartPrice='" + $('#checkshowstartPrice').val() + "'  where SEID= " + hdnSeId + " and BidID = " + sessionStorage.getItem('hdnbid');  //,ClosingTime=' + $("#").val() + ',Extension=' + $("#").val() + ',NoofExtension=' + $("#").val() + ',ItemStatus=' + $("#").val(0);
        }
        if ($('#hdnClosingval').val() == 'S' && sessionStorage.getItem("hdnbidtypeid") == 7) {
           upateQuery = "Update BidSeaExportDetails set ItemBidDuration=" + $("#txtitembidduration").val() + ",DestinationPort='" + $('#txtdestinationPort').val() + "',Targetprice=" + removeThousandSeperator(targetprice) + ",Quantity=" + removeThousandSeperator($("#txtquantitiy").val()) + ",UOM='" + $('#dropuom').val() + "',LastInvoicePrice=" + removeThousandSeperator(lastinvoice) + ",Remarks='" + $('#txtbiddescriptionP').val() + "',CeilingPrice=" + removeThousandSeperator($('#txtCeilingPrice').val()) + ",MaskVendor='" + $('#checkmaskvendor option:selected').val() + "',MinimumDecreament=" + removeThousandSeperator($('#txtminimumdecreament').val()) + ",DecreamentOn='" + $('#drpdecreamenton option:selected').val() + "',SelectedCurrency='" + $('#txtselectedCurrency').val() + "',MaskL1Price='" + $('#checkL1Price').val() + "',ShowStartPrice='" + $('#checkshowstartPrice').val() + "'  where SEID= " + hdnSeId + " and BidID = " + sessionStorage.getItem('hdnbid');  //,ClosingTime=' + $("#").val() + ',Extension=' + $("#").val() + ',NoofExtension=' + $("#").val() + ',ItemStatus=' + $("#").val(0);            
        }
        if (sessionStorage.getItem("hdnbidtypeid") == 6) {
            if ($('#hdnClosingval').val() == 81) {
                upateQuery = "Update BidPefaDetails set ItemName='" + $('#txtshortname').val() + "',Targetprice=" + removeThousandSeperator(targetprice) + ",Quantity=" + removeThousandSeperator($("#txtquantitiy").val()) + ",MeasurementUnit='" + $('#dropuom').val() + "',LastSalePrice=" + removeThousandSeperator(lastinvoice) + ",CeilingPrice=" + removeThousandSeperator($('#txtCeilingPrice').val()) + ",MaskVendor='" + $('#checkmaskvendor option:selected').val() + "',MinimumIncreament=" + removeThousandSeperator($('#txtminimumdecreament').val()) + ",IncreamentOn='" + removeThousandSeperator($('#drpdecreamenton option:selected').val()) + "',ShowHLPrice='" + $('#checkL1Price option:selected').val() + "',ShowStartPrice='" + $('#checkshowstartPrice option:selected').val() + "'  where PSID= " + hdnSeId + " and BidID = " + sessionStorage.getItem('hdnbid');
            }
            else {
                upateQuery = "Update BidPefaDetails set ItemName='" + $('#txtshortname').val() + "',Targetprice=" + removeThousandSeperator(targetprice) + ",Quantity=" + removeThousandSeperator($("#txtquantitiy").val()) + ",MeasurementUnit='" + $('#dropuom').val() + "',LastSalePrice=" + removeThousandSeperator(lastinvoice) + ",CeilingPrice=" + removeThousandSeperator($('#txtCeilingPrice').val()) + ",MaskVendor='" + $('#checkmaskvendor option:selected').val() + "',MinimumIncreament=" + 0.0 + ",StartingPrice=" + removeThousandSeperator($('#txtminimumdecreament').val()) + ",PriceReductionFrequency=" + $('#txtpricefrequency').val() + ",PriceReductionAmount=" + removeThousandSeperator($('#txtpriceincreamentamount').val()) + ",IncreamentOn='',ShowHLPrice='" + $('#checkL1Price option:selected').val() + "'  where PSID= " + hdnSeId + " and BidID = " + sessionStorage.getItem('hdnbid') + ";";
                _Totalbiddurationfordutch=(((removeThousandSeperator($("#txtCeilingPrice").val()) - removeThousandSeperator($("#txtminimumdecreament").val())) / removeThousandSeperator($("#txtpriceincreamentamount").val())) * $("#txtpricefrequency").val()) + parseInt($("#txtpricefrequency").val());
                upateQuery = upateQuery + " Update Biddetails set BidDuration=" + _Totalbiddurationfordutch + " where BidID = " + sessionStorage.getItem('hdnbid')
            }
        }
        Data = {
            "QueryString": upateQuery,
            "QueryStringDT":'NA',
            "valType": "BI",
            "BidId": sessionStorage.getItem('hdnbid'),
            "BidClosingType": $('#hdnClosingval').val(),
            "SeId": hdnSeId

        }
    }
    console.log(upateQuery)
   // alert(upateQuery)
  //  alert(JSON.stringify(Data))
    if (Data != '' || Data != null) {

        jQuery.ajax({
            url: sessionStorage.getItem("APIPath") + "ResetInviteVendor/ManageUpdateBidDetails/",
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            type: "POST",
            data: JSON.stringify(Data),
            contentType: "application/json; charset=utf-8",
            success: function (data, status, jqXHR) {

                if (data[0].isSuccess == "1") {
                    if ($('#divbidAttachFilePrevtab_0').is(':visible') || $('#divbidTermsFilePrevtab_0').is(':visible')) {
                        fileUploader(sessionStorage.getItem('hdnbid'));
                    }
                    if (isBidEventChanged == true) {
                        $("#btnuserConfirmation").show();
                    }
                    fetchallexportdetails();
                    setTimeout(function () {
                        $("#editValuesModal").modal("hide")
                    },5000)
                   
                    $("#msgSuccessEditEvent").find("span").html('Data Successfully saved.')
                    $("#msgSuccessEditEvent").show();
                    $("#msgSuccessEditEvent").fadeOut(5000);
                }
                else {
                    $("#msgErrorEditEvent").find("span").html('You have error in saving data.Please try again.')
                    $("#msgErrorEditEvent").show();
                    $("#msgErrorEditEvent").fadeOut(5000);
                }

                jQuery.unblockUI();
            },
            error: function (xhr, status, error) {

                var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }
                else{
                    $("#msgErrorEditEvent").find("span").html('You have error in saving data.Please try again.')
                    $("#msgErrorEditEvent").show();
                    $("#msgErrorEditEvent").fadeOut(5000);
                }
           
                return false;
                jQuery.unblockUI();
            }
       
        });
    }
}

function fileUploader(bidID) {
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });

    var fileTerms = $('#file1');
    if ($('#file1').is('[disabled=disabled]')) {

        var fileDataTerms = $('#file2').prop("files")[0];

    }
    else {
        var fileDataTerms = fileTerms.prop("files")[0];
    }


    var fileAnyOther = $('#file2');

    var fileDataAnyOther = fileAnyOther.prop("files")[0];



    var formData = new window.FormData();

    formData.append("fileTerms", fileDataTerms);

    formData.append("fileAnyOther", fileDataAnyOther);

    formData.append("AttachmentFor", 'Bid');

    formData.append("BidID", bidID);
    formData.append("VendorID", '');



    $.ajax({

        url: 'ConfigureFileAttachment.ashx',

        data: formData,

        processData: false,

        contentType: false,

        asyc: false,

        type: 'POST',

        success: function (data) {
            jQuery.unblockUI();
        },

        error: function () {

            bootbox.alert("Attachment error.");
            jQuery.unblockUI();
        }

    });

}

function showhideItemBidDuration() {
    var bidCloseType = $('#hdnClosingval').val();

    if (bidCloseType == 'A') {

        jQuery('#divItemBiduration').css('visibility', 'hidden');
        //$('#txtBidDuration').prop('disabled', false)
        $('#txtitembidduration').prop('disabled', true)
        //$('#spanbidduration').show()

        //$('input[name="txtBidDuration"]').rules('add', {
        //    required: true,
        //    minlength: 1,
        //    maxlength: 3,
        //    number: true
        //});

    }
    else {
        //$('input[name="txtBidDuration"]').rules('remove');
        $('#txtitembidduration').prop('disabled', false)
        $('#spanbidduration').hide()
        //$('.condition-based-validate').removeClass('has-error')
        //$('.condition-based-validate').find('.help-block').remove()
        //$('#txtBidDuration').val('')
        //$('#txtBidDuration').prop('disabled', true)
        jQuery('#divItemBiduration').css('visibility', 'visible');
    }
}
var allUOM = '';
function FetchUOM(CustomerID) {

    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "UOM/fetchUOMCust/?CustomerID=" + CustomerID,//FetchUOM
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        dataType: "json",
        success: function (data) {
            //jQuery("#dropuom").empty();
            //jQuery("#dropuom").append(jQuery("<option ></option>").val("").html("Select"));
            //for (var i = 0; i < data.length; i++) {
            //    jQuery("#dropuom").append(jQuery("<option></option>").val(data[i].UOM).html(data[i].UOM));
            //}
            jQuery("#txtUOM").empty();
            if (data.length > 0) {
                allUOM = data;
            }
            else {
                allUOM = '';
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
           
            return false;
            jQuery.unblockUI();
        }

    });

}
jQuery("#txtUOM").keyup(function () {
    $('#dropuom').val('')

});
jQuery("#txtUOM").typeahead({
    source: function (query, process) {
        var data = allUOM;
        usernames = [];
        map = {};
        var username = "";
        jQuery.each(data, function (i, username) {
            map[username.UOM] = username;
            usernames.push(username.UOM);
        });

        process(usernames);

    },
    minLength: 2,
    updater: function (item) {
        if (map[item].UOM != "") {
            $('#dropuom').val(map[item].UOM)

        }
        else {
            gritternotification('Please select UOM  properly!!!');
        }

        return item;
    }

});
function FetchCurrency(CurrencyID) {

    jQuery.ajax({

        type: "GET",

        contentType: "application/json; charset=utf-8",

        url: sessionStorage.getItem("APIPath") + "ConfigureBid/FetchCurrency/?CurrencyID=" + CurrencyID + "&excludeStatus=N",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },

        cache: false,

        dataType: "json",

        success: function (data) {

            jQuery("#dropCurrency").empty();

            jQuery("#dropCurrency").append(jQuery("<option ></option>").val("").html("Select"));

            for (var i = 0; i < data.length; i++) {

                jQuery("#dropCurrency").append(jQuery("<option></option>").val(data[i].CurrencyId).html(data[i].CurrencyNm));

            }

        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }

    });

}

function displayUOM() {
    jQuery('#lblUOM').css('text-align', 'left');
    jQuery('#lblUOM').text('');
    if (jQuery('#dropuom').val() != '' && jQuery('#dropCurrency').val() != '') {

        var uomcaption = jQuery('#dropCurrency option:selected').text() + '/' + jQuery('#dropuom').val()
        jQuery('#lblUOM').text(uomcaption)
    }
    else {
        jQuery('#lblUOM').text('')
    }
}

function closeOrSubmitAfterEditEvents() {
    bootbox.dialog({
        message: "You have made changes to the event, Do you want to send notifications to participants.",
        buttons: {
            confirm: {
                label: "Yes",
                className: "btn-success",
                callback: function () {
                    confirmEditEventAction('submit')
                }
            },
            cancel: {
                label: "No",
                className: "btn-default",
                callback: function () {
                    confirmEditEventAction('close')
                }
            }
        }
    });

}

function confirmEditEventAction(eventType){
    //if (eventType == 'close') {
    //    return false;
    //}
    //else {
        var Data = {
            "BidId": sessionStorage.getItem('hdnbid'),
            "ParamType": eventType
       }


        if (Data != '' || Data != null) {

            jQuery.ajax({
                url: sessionStorage.getItem("APIPath") + "ResetInviteVendor/SendEmailConfirmationEditBidDetails/",
                beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
                type: "POST",
                data: JSON.stringify(Data),
                contentType: "application/json; charset=utf-8",
                success: function (data, status, jqXHR) {

                    if (data[0].isSuccess == "1") {
                        bootbox.alert("An email notification has been sent to all participants invited for the bid.", function () {
                            window.location = sessionStorage.getItem('HomePage');
                            return false;
                        });
                    } else {
                        alert("error")
                    }

                    jQuery.unblockUI();
                },
                error: function (xhr, status, error) {

                    var err = eval("(" + xhr.responseText + ")");
                    if (xhr.status === 401) {
                        error401Messagebox(err.Message);
                    }

                    return false;
                    jQuery.unblockUI();
                }
            });
        }
   // }
    
} 
function editShowL1Price(seId, rowid) {
    
    $("#editshowL1PriceModal").modal('show');
    $("#hdnshowL1Price").val(seId);
    if (sessionStorage.getItem('hdnbidtypeid') == 7) {
        if ($('#hdnClosingval').val() == "S") {
            var flag = $("#" + rowid).find("td:eq(15)").text().trim()
        }
        else {
            var flag = $("#" + rowid).find("td:eq(13)").text().trim()
        }
       
    }
    else {
        if ($('#hdnauctiontype').val() == 81) {
            var flag = $("#" + rowid).find("td:eq(14)").text().trim()
        }
        else {
            var flag = $("#" + rowid).find("td:eq(17)").text().trim()
        }
    }
    $('#maskL1Pricetab_0').val(flag)
    
}
function editShowStartPrice(seId, rowid) {

    $("#editshowStartPriceModal").modal('show');
    $("#hdnshowStartPrice").val(seId);
    if (sessionStorage.getItem('hdnbidtypeid') == 7) {
        if ($('#hdnClosingval').val() == "S") {
            var flag = $("#" + rowid).find("td:eq(16)").text().trim()
        }
        else {
            var flag = $("#" + rowid).find("td:eq(14)").text().trim()
        }

    }
    else {
        if ($('#hdnauctiontype').val() == 81) {
            var flag = $("#" + rowid).find("td:eq(15)").text().trim()
        }
       
    }
    $('#maskStartPricetab_0').val(flag)

}
function editbidstartprice(seId, rowid) {
    $("#hddnbidstartprice").val(seId);
    $("#txtbidstartpricetab_0").val($.trim($("#" + rowid).find("td:eq(6)").text()))
    $("#editbidstartprice").modal('show');
}
function editbidstartpriceFA(psid,rowid) {
    $("#hddnbidstartprice").val(psid);
    $("#txtbidstartpricetab_0").val($.trim($("#" + rowid).find("td:eq(5)").text()))
    $("#editbidstartprice").modal('show');
}
function editMinDecreament(seId, rowid) {
    $("#hddnSeIdForMinDecreament").val(seId);
    $('#drpdecreamentontab_0').val($("#" + rowid).find("td:eq(10)").text())
    $("#txtminimumdecreamenttab_0").val($.trim($("#" + rowid).find("td:eq(8)").text()))
    $("#editMinDecreamentModal").modal('show');
}
function editincreament(psid, rowid) {
    $("#hddnPSForMinIncreament").val(psid);
    $('#drpincreamentontab_0').val($("#" + rowid).find("td:eq(10)").text())
    $("#txtminimumincreamenttab_0").val($.trim($("#" + rowid).find("td:eq(7)").text()))
    $("#editMinincreamentModal").modal('show');

}
var error1 = $('#msgErrorEditEventFA')
function updMinIncreament() {
  
    if ((parseInt($('#txtminimumincreamenttab_0').val()) > parseInt(20) && $("#drpincreamentontab_0 option:selected").val() == "P")) {

        error1.find("span").html('Minimum increament should be less than 20%.');
        error1.show();
        Metronic.scrollTo(error1, -200);
        error1.fadeOut(3000);
        return false;

    }
    var Data = {
        "QueryString": removeThousandSeperator($("#txtminimumincreamenttab_0").val()),
        "QueryStringDT": 'NA',
        "valType": "BMIPE",
        "BidId": sessionStorage.getItem('hdnbid'),
        "BidClosingType": 'NA',
        "SeId": $("#hddnPSForMinIncreament").val(),
        "DecreamentOn": $("#drpincreamentontab_0 option:selected").val()

    }

    if (Data != '' || Data != null) {
        // alert(JSON.stringify(Data))
        jQuery.ajax({
            url: sessionStorage.getItem("APIPath") + "ResetInviteVendor/ManageUpdateBidDetails/",
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            type: "POST",
            data: JSON.stringify(Data),
            contentType: "application/json; charset=utf-8",
            success: function (data, status, jqXHR) {

                if (data[0].isSuccess == "1") {
                   
                    if (isBidEventChanged == true) {
                        $("#btnuserConfirmation").show();
                    }
                    fetchallexportdetails();
                    $("#editMinincreamentModal").modal("hide")
                    
                } else {
                   // alert("error vickrant")
                }

                jQuery.unblockUI();
            },
            error: function (xhr, status, error) {

                var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }

                return false;
                jQuery.unblockUI();
            }
        });
    }
}

var error = $('#msgErrorEditEvent');

function updMinDecreament() {

    if ((parseInt($('#txtminimumdecreamenttab_0').val()) > parseInt(20) && $("#drpdecreamentontab_0 option:selected").val() == "P")) {

        error.find("span").html('Minimum decrement should be less than 20%.');
        error.show();
        Metronic.scrollTo(error, -200);
        error.fadeOut(3000);
        return false;

    }
    var Data = {
        "QueryString": removeThousandSeperator($("#txtminimumdecreamenttab_0").val()),
        "QueryStringDT": 'NA',
        "valType": "BMD",
        "BidId": sessionStorage.getItem('hdnbid'),
        "BidClosingType": 'NA',
        "SeId": $("#hddnSeIdForMinDecreament").val(),
        "DecreamentOn": $("#drpdecreamentontab_0 option:selected").val()

    }

    if (Data != '' || Data != null) {
       // alert(JSON.stringify(Data))
        jQuery.ajax({
            url: sessionStorage.getItem("APIPath") + "ResetInviteVendor/ManageUpdateBidDetails/",
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            type: "POST",
            data: JSON.stringify(Data),
            contentType: "application/json; charset=utf-8",
            success: function (data, status, jqXHR) {

                if (data[0].isSuccess == "1") {
                    //if ($('#divbidAttachFilePrevtab_0').is(':visible') || $('#divbidTermsFilePrevtab_0').is(':visible')) {
                    //    fileUploader(sessionStorage.getItem('hdnbid'));
                    //}
                    if (isBidEventChanged == true) {
                        $("#btnuserConfirmation").show();
                    }
                    fetchallexportdetails();
                    $("#editMinDecreamentModal").modal("hide")
                    //$("#msgSuccessEditEvent").find("span").html('Data Successfully saved.')
                    //$("#msgSuccessEditEvent").show();
                    //$("#msgSuccessEditEvent").fadeOut(5000);
                } else {
                    alert("error vickrant")
                }

                jQuery.unblockUI();
            },
            error: function (xhr, status, error) {

                var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }

                return false;
                jQuery.unblockUI();
            }
        });
    }
}
var error2 = $('#msgErrorL1');
function UpdShowL1Price() {
    if (sessionStorage.getItem('hdnbidtypeid') == 7) {
        var valtype = "RAL1";
    }
    else {
        var valtype = "FAL1";
    }
    var Data = {
        "QueryString": $("#maskL1Pricetab_0").val(),
        "QueryStringDT": 'NA',
        "valType": valtype,
        "BidId": sessionStorage.getItem('hdnbid'),
        "BidClosingType": 'NA',
        "SeId": $("#hdnshowL1Price").val(),
        "DecreamentOn": ''

    }

    if (Data != '' || Data != null) {
      //   alert(JSON.stringify(Data))
        jQuery.ajax({
            url: sessionStorage.getItem("APIPath") + "ResetInviteVendor/ManageUpdateBidDetails/",
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            type: "POST",
            data: JSON.stringify(Data),
            contentType: "application/json; charset=utf-8",
            success: function (data, status, jqXHR) {

                if (data[0].isSuccess == "1") {

                    if (isBidEventChanged == true) {
                        $("#btnuserConfirmation").show();
                    }
                    fetchallexportdetails();
                    $("#editshowL1PriceModal").modal("hide")

                } else {
                    // alert("error vickrant")
                }

                jQuery.unblockUI();
            },
            error: function (xhr, status, error) {

                var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }

                return false;
                jQuery.unblockUI();
            }
        });
    }
}

var errorStart = $('#msgErrorStart');
function UpdShowStartPrice() {
    if (sessionStorage.getItem('hdnbidtypeid') == 7) {
        var valtype = "RAStartP";
    }
    else {
        var valtype = "FAStartP";
    }
    var Data = {
        "QueryString": $("#maskStartPricetab_0").val(),
        "QueryStringDT": 'NA',
        "valType": valtype,
        "BidId": sessionStorage.getItem('hdnbid'),
        "BidClosingType": 'NA',
        "SeId": $("#hdnshowStartPrice").val(),
        "DecreamentOn": ''

    }

    if (Data != '' || Data != null) {
        //   alert(JSON.stringify(Data))
        jQuery.ajax({
            url: sessionStorage.getItem("APIPath") + "ResetInviteVendor/ManageUpdateBidDetails/",
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            type: "POST",
            data: JSON.stringify(Data),
            contentType: "application/json; charset=utf-8",
            success: function (data, status, jqXHR) {

                if (data[0].isSuccess == "1") {

                    if (isBidEventChanged == true) {
                        $("#btnuserConfirmation").show();
                    }
                    fetchallexportdetails();
                    $("#editshowStartPriceModal").modal("hide")

                } else {
                    // alert("error vickrant")
                }

                jQuery.unblockUI();
            },
            error: function (xhr, status, error) {

                var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }

                return false;
                jQuery.unblockUI();
            }
        });
    }
}
var errorStart = $('#msgErrorStart');
var errorBSP = $('#msgErrorEditEventBP');
function updBidStartPrice() {
    if (sessionStorage.getItem('hdnbidtypeid') == 7) {
        var valtype = "BSPRA";
    }
    else {
        var valtype = "BSPFA";
    }
    //if ((parseInt($('#txtminimumdecreamenttab_0').val()) > parseInt(20) && $("#drpdecreamentontab_0 option:selected").val() == "P")) {

    //    error.find("span").html('Minimum decrement should be less than 20%.');
    //    error.show();
    //    Metronic.scrollTo(error, -200);
    //    error.fadeOut(3000);
    //    return false;

    //}
    var Data = {
        "QueryString": removeThousandSeperator($("#txtbidstartpricetab_0").val()),
        "QueryStringDT": 'NA',
        "valType": valtype,
        "BidId": sessionStorage.getItem('hdnbid'),
        "BidClosingType": 'NA',
        "SeId": $("#hddnbidstartprice").val(),
        "DecreamentOn": ''

    }

    if (Data != '' || Data != null) {
        // alert(JSON.stringify(Data))
        jQuery.ajax({
            url: sessionStorage.getItem("APIPath") + "ResetInviteVendor/ManageUpdateBidDetails/",
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            type: "POST",
            data: JSON.stringify(Data),
            contentType: "application/json; charset=utf-8",
            success: function (data, status, jqXHR) {

                if (data[0].isSuccess == "1") {
                    //if ($('#divbidAttachFilePrevtab_0').is(':visible') || $('#divbidTermsFilePrevtab_0').is(':visible')) {
                    //    fileUploader(sessionStorage.getItem('hdnbid'));
                    //}
                    if (isBidEventChanged == true) {
                        $("#btnuserConfirmation").show();
                    }
                    fetchallexportdetails();
                    $("#editbidstartprice").modal("hide")
                    //$("#msgSuccessEditEvent").find("span").html('Data Successfully saved.')
                    //$("#msgSuccessEditEvent").show();
                    //$("#msgSuccessEditEvent").fadeOut(5000);
                }
                else {
                    alert("error vickrant")
                }

                jQuery.unblockUI();
            },
            error: function (xhr, status, error) {

                var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }

                return false;
                jQuery.unblockUI();
            }
        });
    }
}

function saveBidSurrogate() {
    if ($('#bidSurrogateToName').val() == '') {
        error1.find("span").html('Please Fill name.');
        error1.show();
        App.scrollTo(error1, -200);
        error1.fadeOut(4000);
        return false;

    }
    if ($('#bidSurrogateToEmail').val() == '' || validateEmail($('#bidSurrogateToEmail').val()) == false) {
        error1.find("span").html('Please Fill Valid Email.');
        error1.show();
        App.scrollTo(error1, -200);
        error1.fadeOut(4000);
        return false;

    }
    if ($('#bidSurrogateReason').val() == '') {
        error1.find("span").html('Please Fill Surrogate Reason.');
        error1.show();
        App.scrollTo(error1, -200);
        error1.fadeOut(4000);
        return false;

    }
   
    var Data = {
        "Name": $("#bidSurrogateToName").val(),
        "BidId": sessionStorage.getItem('hdnbid'),
        "EmailId": $("#bidSurrogateToEmail").val(),
        "Reason": $("#bidSurrogateReason").val(),
        "vendorEmailId": sessionStorage.getItem("hdnselectedEmail"),
        "vendorID": sessionStorage.getItem("hdnselectedvendor"),
        "EncryptedLink": "BidID=" + sessionStorage.getItem('hdnbid')
    }
   // alert(JSON.stringify(Data))
    if (Data != '' || Data != null) {

        jQuery.ajax({
            url: sessionStorage.getItem("APIPath") + "RegisterParticipants/BidSurrogateSave",
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            type: "POST",
            data: JSON.stringify(Data),
            contentType: "application/json; charset=utf-8",
            success: function (data, status, jqXHR) {

                if (data[0].BidId == "1") {
                    success1.show();
                    $('#spansuccess1').html("Data Successfully saved");
                    success1.fadeOut(6000);
                    App.scrollTo(success1, -200);
                    clearSurrogateForm();
                }
                else {
                    alert("Error.")
                }

                jQuery.unblockUI();
            },
            error: function (xhr, status, error) {

                var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }

                return false;
                jQuery.unblockUI();
            }
        });
    }
}

function clearSurrogateForm(){
    $('#bidSurrogateToName').val('')
    $('#bidSurrogateToEmail').val('')
    $('#bidSurrogateReason').val('')
    sessionStorage.setItem('hdnselectedvendor', '0');
    sessionStorage.setItem('hdnselectedEmail', '');
    jQuery("#txtvendorSurrogateBid").val('')
    $(".surrogateFormElements").hide();
}
