﻿$("#cancelBidBtn").hide();
$("#spnParamAttach").hide();
var error = $('.alert-danger');

var success = $('.alert-success');

var form = $('#submit_form');
var Vehicleerror = $('#errordiv');
var Vehiclesuccess = $('#successdiv');
var Vehicleerror1 = $('#errordiv1');
var Vehiclesuccess1 = $('#successdiv1');

var currentdate = new Date();

$(".thousandseparated").inputmask({
    alias: "decimal",
    rightAlign: false,
    groupSeparator: ",",
    radixPoint: ".",
    autoGroup: true,
    integerDigits: 40,
    digitsOptional: true,
    allowPlus: false,
    allowMinus: false,
    'removeMaskOnSubmit': true

});
$('#txtshortname,#txtItemCode,#txtbiddescriptionP,#txtItemRemarks,#txtConversionRate,#txtPono,#txtItemCode,#txttat').maxlength({
    limitReachedClass: "label label-danger",
    alwaysShow: true
});
var totalFileSize = 0;
var FormWizard = function () {

    return {

        init: function () {

            if (!jQuery().bootstrapWizard) {

                return;

            }

            function format(state) {

                if (!state.id) return state.text; // optgroup

                return "<img class='flag' src='assets/global/img/flags/" + state.id.toLowerCase() + ".png'/>&nbsp;&nbsp;" + state.text;

            }


            form.validate({

                doNotHideMessage: true, //this option enables to show the error/success messages on tab switch.

                errorElement: 'span', //default input error message container

                errorClass: 'help-block help-block-error', // default input error message class

                focusInvalid: false, // do not focus the last invalid input

                rules: {

                    //First Tab
                    txtrfqSubject: {
                        required: true
                    },
                    txtenddatettime: {
                        required: true
                       
                    },
                    txtrfqdescription: {
                        required: true
                    },
                    dropCurrency: {
                        required: true
                    },
                    txtConversionRate: {
                        required: true,
                        number: true,
                        minlength: 1,
                        maxlength: 3
                    },

                    file1: {
                        required: true
                    },
                  
                 
                   

                    //Second Tab
                    
                    txtbiddescriptionP: {
                        required: true
                       
                    },
                    txtedelivery: {
                        required: true
                    },
                    dropuom: {
                        required: true
                    },
                    txtUOM:{
                        required: true
                    },
                     txttargetprice: {
                         number: true
                    },
                    //txtlastinvoiceprice: {
                    //    number: true
                    //},
                     txtquantitiy: {
                         required: true
                     },
                     txtshortname: {
                         required: true,
                         maxlength:200
                     },
                     txtItemCode: {
                        // required: true,
                         maxlength: 50
                     },
                    txtItemRemarks: {
                        required: true,
                        maxlength:200
                     },
                     txttat: {
                         number: true,
                         maxlength: 4
                     },
                     txtPono: {
                         maxlength:20
                        // required: true
                     },
                     txtunitrate: {
                        // required: true,
                         number:true
                     },
                     txtvendorname: {
                        // required: true
                     },
                     txtPODate: {
                        // required: true
                     },
                     txtpovalue:{
                        // required: true,
                         number:true
                     },
                    //Thord Tab
                    AttachDescription1:{
                        required: true
                    }

                },

                messages: {                    

                },

                errorPlacement: function (error, element) {

                    if (element.attr("name") == "gender") {

                        error.insertAfter("#form_gender_error");

                    } else if (element.attr("name") == "payment[]") {

                        error.insertAfter("#form_payment_error");

                    } else if (element.attr("name") == "txtPODate") {
                        error.insertAfter("#daterr");
                    }
                    else {

                        error.insertAfter(element);

                    }

                    if ($("#txtPODate").closest('.input-group').attr('class') == 'input-group has-error') {

                        $("#btncal").css("margin-top", "-22px");

                    }

                },

                invalidHandler: function (event, validator) {

                },

                highlight: function (element) {

                    $(element)

                        .closest('.inputgroup').removeClass('has-success').addClass('has-error');

                    $(element)

                         .closest('.col-md-4,.xyz').removeClass('has-success').addClass('has-error');

                },

                unhighlight: function (element) {

                    $(element)

                        .closest('.inputgroup').removeClass('has-error');
                    $(element)

                        .closest('.col-md-4,.xyz').removeClass('has-error');

                },

                success: function (label) {

                    if (label.attr("for") == "gender" || label.attr("for") == "payment[]") {

                        label

                            .closest('.inputgroup').removeClass('has-error').addClass('has-success');
                        label

                        .closest('.col-md-4,.xyz').removeClass('has-error').addClass('has-success');

                        label.remove();

                    } else {

                        label

                            .addClass('valid') // mark the current input as valid and display OK icon

                        .closest('.inputgroup').removeClass('has-error').addClass('has-success'); // set success class to the control group
                        label.closest('.col-md-4,.xyz').removeClass('has-error').addClass('has-success'); // set success class to the control group

                    }

                   

                },

            submitHandler: function (form) {
                    // success.show();
                         error.hide();
                    }
             });



            var displayConfirm = function () {
                     $('#tab4 .form-control-static', form).each(function () {

                    var input = $('[name="' + $(this).attr("data-display") + '"]', form);

                    if (input.is(":radio")) {

                        input = $('[name="' + $(this).attr("data-display") + '"]:checked', form);

                    }

                    if (input.is(":text") || input.is("textarea")) {

                        $(this).html(input.val());

                    } else if (input.is("select")) {

                        $(this).html(input.find('option:selected').text());

                    } else if (input.is(":radio") && input.is(":checked")) {

                        $(this).html(input.attr("data-title"));

                    } else if ($(this).attr("data-display") == 'payment') {

                        var payment = [];

                        $('[name="payment[]"]:checked').each(function () {

                            payment.push($(this).attr('data-title'));

                        });

                        $(this).html(payment.join("<br>"));

                    }

                });

            }



            var handleTitle = function (tab, navigation, index) {

                var total = navigation.find('li').length;

                var current = index + 1;

                // set wizard title

                $('.step-title', $('#form_wizard_1')).text('Step ' + (index + 1) + ' of ' + total);

                // set done steps

                jQuery('li', $('#form_wizard_1')).removeClass("done");

                var li_list = navigation.find('li');

                for (var i = 0; i < index; i++) {

                    jQuery(li_list[i]).addClass("done");

                }



                if (current == 1) {
                         $('#form_wizard_1').find('.button-previous').hide();

                } else {
                        $('#form_wizard_1').find('.button-previous').show();

                }

               if (current >= total) {
                    $('#form_wizard_1').find('.button-next').hide();
                    $('#form_wizard_1').find('.button-submit').show();

                    displayConfirm();

                } else {

                    $('#form_wizard_1').find('.button-next').show();

                    $('#form_wizard_1').find('.button-submit').hide();

                }

                Metronic.scrollTo($('.page-title'));

            }



            // default form wizard

            $('#form_wizard_1').bootstrapWizard({

                'nextSelector': '.button-next',
                'previousSelector': '.button-previous',

                onTabClick: function (tab, navigation, index, clickedIndex) {
                    return false;
                 },

                onNext: function (tab, navigation, index) {
                    success.hide();
                    error.hide();
                    if (index == 1) {
                       
                        var StartDT = new Date($('#txtstartdatettime').val().replace('-', ''));
                        var EndDT = new Date($('#txtenddatettime').val().replace('-', ''));
                        var CurDateonly = new Date(currentdate.toDateString())
                        var StartDTdateonly = new Date(StartDT.toDateString())
                       if (form.valid() == false) {
                            return false;

                        }
                           else if ($('#txtstartdatettime').val() != '' && StartDTdateonly < CurDateonly) {
                            $('.alert-danger').show();
                            $('#txtstartdatettime').closest('.inputgroup').addClass('has-error');
                            $('#spandanger').html('Start Date Time must greater than Current Date Time.');
                            Metronic.scrollTo($(".alert-danger"), -200);
                            $('.alert-danger').fadeOut(7000);
                            $('#txtstartdatettime').val();
                            return false;
                        }
                        else if ($('#txtstartdatettime').val() != '' && EndDT < StartDT) {
                            $('.alert-danger').show();
                            $('#txtenddatettime').closest('.inputgroup').addClass('has-error');
                            $('#spandanger').html('End Date Time must greater than Start Date Time ');
                            Metronic.scrollTo($(".alert-danger"), -200);
                            $('.alert-danger').fadeOut(7000);
                            $('#txtenddatettime').val('')
                            return false;
                        }
                        else if (EndDT < currentdate) {
                            $('.alert-danger').show();
                            $('#txtenddatettime').closest('.inputgroup').addClass('has-error');
                            $('#spandanger').html('End Date Time must greater than Current Date Time.');
                            Metronic.scrollTo($(".alert-danger"), -200);
                            $('.alert-danger').fadeOut(7000);
                            $('#txtenddatettime').val('')
                            return false;
                        }
                        else if ($('#tblapprovers >tbody >tr').length ==0) {
                                $('.alert-danger').show();
                                $('#spandanger').html('Please Map Approver.');
                                Metronic.scrollTo($(".alert-danger"), -200);
                                $('.alert-danger').fadeOut(5000);
                                return false;

                            }
                        else {
                            InsUpdRFQDEtailTab1()
                            //$('#currencyparam').val(jQuery('#dropCurrency option:selected').text());
                        }

                    } else if (index == 2) {
                        if ($('#tblServicesProduct >tbody >tr').length == 0) {
                            $('.alert-danger').show();
                            $('#spandanger').html('Please Configure RFQ Parameters.');
                            Metronic.scrollTo($(".alert-danger"), -200);
                            $('.alert-danger').fadeOut(5000);
                            return false;

                        }
                        
                    }
                    else if (index == 3) {
                        if ($('#tblServicesProduct >tbody >tr').length == 0) {
                            $('.alert-danger').show();
                            $('#spandanger').html('Please Configure RFQ Parameters.');
                            Metronic.scrollTo($(".alert-danger"), -200);
                            $('.alert-danger').fadeOut(5000);
                            return false;

                        }
                        else if (jQuery('#fileToUpload1').val() != "") {
                            $('.alert-danger').show();
                            $('#spandanger').html('Your file is not attached. Please do press "+" button after uploading the file.');
                            Metronic.scrollTo($(".alert-danger"), -200);
                            $('.alert-danger').fadeOut(7000);
                            return false;
                        }
                        else {
                            fnsavetermscondition('N');
                        }
                    }
                     handleTitle(tab, navigation, index);

                },

                onPrevious: function (tab, navigation, index) {
                    success.hide();
                    error.hide();
                    handleTitle(tab, navigation, index);

                },

                onTabShow: function (tab, navigation, index) {

                    var total = navigation.find('li').length;
                    var current = index + 1;
                    var $percent = (current / total) * 100;

                    $('#form_wizard_1').find('.progress-bar').css({
                         width: $percent + '%'
                    });
                 }

            });

            $('#form_wizard_1').find('.button-previous').hide();

            $('#form_wizard_1 .button-submit').click(function () {        
                 if ($('#tblServicesProduct > tbody >tr').length == 0) {
                    $('#form_wizard_1').bootstrapWizard('previous');
                    error.show();

                    $('#spandanger').html('Please Configure RFQ Parameters.')

                    error.fadeOut(3000)

                    return false;

                }
               

                else if (ValidateVendor() == 'false') {
                         return false;

                }

                else {
                    fetchPSBidDetailsForPreview()
                    $('#BidPreviewDiv').show();
                    $('#form_wizard_1').hide();
                    
                  //  RFQInviteVendorTab3();

                    return true;

                }

            }).hide();



            //unblock code
            jQuery.unblockUI();
        }

    };

}();


sessionStorage.setItem('hddnRFQID', 0)

function InsUpdRFQDEtailTab1() {
   jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
	var TermsConditionFileName = '';
    var AttachementFileName = '';
    if ($('#attach-file').html() != '' && $('#file1').val() == '') {
        TermsConditionFileName = $.trim(jQuery('#attach-file').html());
    } else {
        TermsConditionFileName = jQuery('#file1').val().substring(jQuery('#file1').val().lastIndexOf('\\') + 1);
    }
   TermsConditionFileName = TermsConditionFileName.replace(/[&\/\\#,+$~%'":*?<>{}]/g, '_'); //Replace special Characters
    


    var Tab1Data = {
      
        "RFQId": sessionStorage.getItem('hddnRFQID'),
        "RFQSubject": jQuery("#txtrfqSubject").val(),
        "RFQStartDate": jQuery("#txtstartdatettime").val(),
        "RFQEndDate": jQuery("#txtenddatettime").val(),
        "RFQDescription": jQuery("#txtrfqdescription").val(),
        "RFQCurrencyId": jQuery("#dropCurrency").val(),
        "RFQConversionRate": jQuery("#txtConversionRate").val(),
        "RFQTermandCondition": TermsConditionFileName,
        "RFQAttachment": '',
        "UserId": sessionStorage.getItem('UserID'),
        "CustomerID": sessionStorage.getItem('CustomerID'),
        "RFQReference": $("#txtRFQReference").val()

    };
    //alert(JSON.stringify(Tab1Data))
    jQuery.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "eRequestForQuotation/eInsUpdRequestForQuotation",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        crossDomain: true,
        async: false,
        data: JSON.stringify(Tab1Data),
        dataType: "json",
        success: function (data) {
          
           sessionStorage.setItem('hddnRFQID', data[0].RFQId)
           fileUploader(sessionStorage.getItem('hddnRFQID'))
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }


    });
    jQuery.unblockUI();
}
function fetchReguestforQuotationDetails() {
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    var replaced1 = '';
    var replaced2 = '';

    jQuery.ajax({
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "eRequestForQuotation/fetchReguestforQuotationDetails/?UserID=" + encodeURIComponent(sessionStorage.getItem('UserID')) + "&RFQID=" + sessionStorage.getItem('hddnRFQID'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "GET",
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (RFQData) {

            sessionStorage.setItem('hddnRFQID', RFQData[0].RFQId)
            jQuery('#txtrfqSubject').val(RFQData[0].RFQSubject)
            setTimeout(function () { $('#dropCurrency').val(RFQData[0].RFQCurrencyId).attr("selected", "selected"); }, 1000)
            jQuery('#txtrfqdescription').val(RFQData[0].RFQDescription)
            jQuery('#txtrfqDuration').val(RFQData[0].RFQDeadline)
            jQuery('#txtConversionRate').val(RFQData[0].RFQConversionRate);
            jQuery('#txtRFQReference').val(RFQData[0].RFQReference)
            $("#cancelBidBtn").show();
            if (RFQData[0].RFQTermandCondition != '') {
                $('#file1').attr('disabled', true);
                $('#closebtn').removeClass('display-none');
                replaced1 = RFQData[0].RFQTermandCondition.replace(/\s/g, "%20")
                if (RFQData[0].RFQAttachment != '') {
                    $('#file2').attr('disabled', true);
                    $('#closebtn2').removeClass('display-none');
                    replaced2 = RFQData[0].RFQAttachment.replace(/\s/g, "%20")
                }

            }
            jQuery('#attach-file').attr('href', 'PortalDocs/RFQ/' + sessionStorage.getItem('hddnRFQID') + '/' + replaced1).html(RFQData[0].RFQTermandCondition)
            jQuery('#attach-file2').attr('href', 'PortalDocs/RFQ/' + sessionStorage.getItem('hddnRFQID') + '/' + replaced2).html(RFQData[0].RFQAttachment)

            
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }

    });
    jQuery.unblockUI();
}


function fileUploader(RFQID) {

    var fileTerms = $('#file1');
    if ($('#file1').is('[disabled=disabled]')) {

        var fileDataTerms = $('#file1').prop("files")[0];

    }
    else {
        var fileDataTerms = fileTerms.prop("files")[0];
    }
   
    var fileRFQAttachments = $('#fileToUpload1');
    var fileDataAnyRFQAttachments = fileRFQAttachments.prop("files")[0];


    var formData = new window.FormData();

    formData.append("fileTerms", fileDataTerms);
    formData.append("fileAnyOther", '');
    formData.append("fileRFQAttach", fileDataAnyRFQAttachments);
    formData.append("AttachmentFor", 'eRFQ');
    formData.append("BidID", RFQID);
    formData.append("VendorID", '');
    formData.append("Version", '');
    
    $.ajax({

        url: 'ConfigureFileAttachment.ashx',
        data: formData,
        processData: false,
        contentType: false,
        asyc: false,
        type: 'POST',
        success: function (data) {

        },

        error: function () {

            //jQuery.unblockUI();

        }

    });

}

function fileUploaderTab2(RFQID) {

    var fileTerms = $('#file3');
    //change pooja
    

    var fileDataTerms = fileTerms.prop("files")[0];
    
    var formData = new window.FormData();

    formData.append("fileTerms", fileDataTerms);
    formData.append("fileAnyOther", '');
    formData.append("AttachmentFor", 'RFQ');
    formData.append("BidID", RFQID);
    formData.append("VendorID", '');


    $.ajax({

        url: 'ConfigureFileAttachment.ashx',

        data: formData,

        processData: false,

        contentType: false,

        asyc: false,

        type: 'POST',

        success: function(data) {
        resetfun();
        jQuery.unblockUI();
        },

        error: function() {

            //jQuery.unblockUI();

        }

    });
    

}

function fnGetTermsCondition() {
   
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "eRequestForQuotation/efetchRFQTermsANDCondition/?ConditionType=" + $('#ddlConditiontype option:selected').val() + "&CustomerID=" + sessionStorage.getItem('CustomerID') + "&RFQID=" + sessionStorage.getItem('hddnRFQID'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
            jQuery("#tblTermsCondition").empty();
            jQuery("#tbltermsconditionprev").empty();
            if (data.length > 0) {
                $('#btnS').removeAttr('disabled')
                jQuery('#tbltermsconditionprev').append("<thead><tr><th class='bold hide'>Type</th><th class='bold'>Name</th><th>Level</th></tr></thead>");
                for (var i = 0; i < data.length; i++) {
                    
                    var str = "<tr id=tr" + i + "><td class=hide>"+data[i].ID+"</td><td class=hide>"+data[i].Level+"</td>";
                    str += "<td style='width:10%'><div class=\"checker\" id=\"uniform-chkbidTypesTerms\"><span  class='checked' id=\"spancheckedTerms" + data[i].ID + "\"><input type=\"checkbox\" Onclick=\"CheckTerms(this,\'" + data[i].ID + "'\)\"; id=\"chkTerms" + data[i].ID + "\" value=" + (data[i].ID) + " style=\"cursor:pointer\" name=\"chkvenderTerms\" checked /></span></div></td>";
                    str += "<td>" + data[i].Name + "</td>";
                   
                   // var strPrev = "<td>" + data[i].ConditionType + "</td>";
                   var strPrev = "<tr><td>" + data[i].Name + "</td>";
                   
                   str += "<td style='width:20%'><div class='md-radio-list'><label class='md-radio-inline'><input style='width:16px!important;height:16px!important;' type='radio' name=level" + i + " id=levelR" + i + " class='md-radio' disabled/></label> &nbsp;<span>RFQ</span><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><label class='md-radio-inline'><input style='width:16px!important;height:16px!important;' type='radio' class='md-radio' name=level" + i + " id=levelI" + i + " disabled/></label> &nbsp;<span>Item</span></div></td>"
                   str += "<td><input type='text' name=rem" + i + " id=rem" + i + " class='form-control' placeholder='Your requirement' value='" + data[i].Requirement + "' disabled /></td></tr>"
                    
                   
                    if (data[i].isDefault == "N" || data[i].isDefault == "Y") {
                        jQuery('#tblTermsCondition').append(str);
                        //jQuery('#tbltermsconditionprev').append(strPrev);
                    }
                   
                    if (data[i].Level == "R") {
                        strPrev += "<td>RFQ</td></tr>";
                        $("#levelR" + i).attr("checked", "checked");
                        $("#levelI" + i).removeAttr("checked");
                        $("#rem" + i).removeAttr("disabled");
                    }
                    else {
                        strPrev += "<td>Item</td></tr>";
                        $("#levelR" + i).removeAttr("checked");
                        $("#levelI" + i).prop("checked", true);
                        $("#rem" + i).prop("disabled");
                    }
                    
                        if (data[i].IsChecked == "Y") {
                            $("#spancheckedTerms" + data[i].ID).addClass("checked");
                            jQuery('#tbltermsconditionprev').append(strPrev);
                        }
                        else {
                            $("#spancheckedTerms" + data[i].ID).removeClass("checked");
                        }
                        if (data[i].isDefault == "Y") {

                            $("#spancheckedTerms" + data[i].ID).addClass("checked");
                            $("#chkTerms"+ data[i].ID).attr("disabled", "disabled");
                          //  $("#levelR" + i).attr("disabled", "disabled");
                          //  $("#levelI" + i).attr("disabled", "disabled");

                        }
                       // $("#chkTerms" + data[i].ID).removeAttr("disabled");
                       
                   // }
               
               
                }
            }
            else {
                jQuery('#tblTermsCondition').append('<tr><td>No Terms & Condition</td></tr>')
               // jQuery('#tblTermsCondition').append('<tr><td>No attachments</td></tr>')
                $('#btnS').attr('disabled', 'disabled')
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else{
                jQuery("#error").text(xhr.d);
            }
            return false;
            jQuery.unblockUI();
        }

        
    })
}
function fnheckAllTerms() {

    if ($("#chkAllTerms").is(':checked') == true) {
        //$('#displayTable').find('span#spandynamic').hide();
        $('table#tblTermsCondition').closest('.inputgroup').removeClass('has-error');
        $("#spancheckedTermsall").addClass("checked");

        $("#tblTermsCondition> tbody > tr").each(function (index) {
            $(this).find("span#spancheckedTerms").addClass("checked");
            $('input[name="chkvenderTerms"]').prop('disabled', true);


        });
    }
    else {
         $("#spancheckedTermsall").removeClass("checked");
        $("#tblTermsCondition> tbody > tr").each(function (index) {
            $(this).find("span#spancheckedTerms").removeClass("checked");
            $('input[name="chkvenderTerms"]').prop('disabled', false);

        });

    }


}
function CheckTerms(event,ID) {
  
    if ($('#spancheckedTerms' + ID).attr('class') == 'checked') {
        $('#spancheckedTerms' + ID).removeClass("checked")
    }
    else {
        $('#spancheckedTerms' + ID).addClass("checked")
        
    }



}
function fnsavetermscondition(isbuttonclick) {
    var checkedValue = '';
    $("#tblTermsCondition> tbody > tr").each(function (index) {
        var this_row = $(this);
        if ($(this).find('span').attr('class') == 'checked') {
           
            checkedValue = checkedValue + "  select " + sessionStorage.getItem('hddnRFQID') + ",'" + jQuery("#ddlConditiontype").val() + "'," + $.trim(this_row.find('td:eq(0)').html()) + ",'" + $.trim(this_row.find('td:eq(1)').html()) + "','" + $.trim(this_row.find('td:eq(5) input[type="text"]').val()) + "' union all ";
        }
    });
    if (checkedValue != '') {
        checkedValue = 'insert into eRFQTermsCondition(RFQID,ConditionType,TermsCondition,Level,Requirement) ' + checkedValue
        checkedValue = checkedValue.substring(0, checkedValue.length - 11);
      
        var Attachments = {

            "RFQId": sessionStorage.getItem('hddnRFQID'),
            "QueryString": checkedValue

        }
       // alert(JSON.stringify(Attachments))
        jQuery.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: sessionStorage.getItem("APIPath") + "eRequestForQuotation/eInsTermsCondition",
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            crossDomain: true,
            async: false,
            data: JSON.stringify(Attachments),
            dataType: "json",
            success: function (data) {

                if (data.length > 0) {
                    if (data[0].RFQID > 0) {
                        fnGetTermsCondition();
                        if (isbuttonclick == 'Y') {
                            $('.alert-success').show();
                            $('#spansuccess1').html('Terms & Condition saved successfully!');
                            Metronic.scrollTo($(".alert-success"), -200);
                            $('.alert-success').fadeOut(7000)
                        }

                    }
                    else {
                        $('.alert-danger').show();
                        $('#spandanger').html('You have some error.');
                        Metronic.scrollTo($(".alert-danger"), -200);
                        $('.alert-danger').fadeOut(7000);
                        return false;

                    }

                }

            },
            error: function (xhr, status, error) {

                var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }
                
                return false;
                jQuery.unblockUI();
            }

        });
    }
}

function addmoreattachments() {
    if (jQuery("#AttachDescription1").val() == "") {
        $('.alert-danger').show();
        $('#spandanger').html('Please Enter Attachment Description');
        Metronic.scrollTo($(".alert-danger"), -200);
        $('.alert-danger').fadeOut(7000);
        return false;
    }
    else if (jQuery('#fileToUpload1').val() == "") {
        $('.alert-danger').show();
        $('#spandanger').html('Please Attach File Properly');
        Metronic.scrollTo($(".alert-danger"), -200);
        $('.alert-danger').fadeOut(7000);
        return false;
    }
    else {
        var attchname = jQuery('#fileToUpload1').val().substring(jQuery('#fileToUpload1').val().lastIndexOf('\\') + 1)
        attchname = attchname.replace(/[&\/\\#,+$~%'":*?<>{}]/g, '_');
        var Attachments = {

            "RFQId": sessionStorage.getItem('hddnRFQID'),
            "RFQAttachmentDescription": jQuery("#AttachDescription1").val(),
            "RFQAttachment": attchname,
            "RFQEndDate": jQuery("#txtenddatettime").val()
        }
        jQuery.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: sessionStorage.getItem("APIPath") + "eRequestForQuotation/eInsRFQAttachments",
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            crossDomain: true,
            async: false,
            data: JSON.stringify(Attachments),
            dataType: "json",
            success: function (data) {

                if (data.length > 0) {

                    if (data[0].OutPut == "1") {
                        fileUploader(sessionStorage.getItem('hddnRFQID'))
                       // fileUploader(1)
                        fetchAttachments()
                        jQuery("#AttachDescription1").val('')
                        jQuery('#fileToUpload1').val('')
                        $('.alert-success').show();
                        $('#spansuccess1').html('Attachment saved successfully!');
                        Metronic.scrollTo($(".alert-success"), -200);
                        $('.alert-success').fadeOut(7000);
                        return false;

                    }
                    else if (data[0].OutPut == "2") {
                        $('.alert-danger').show();
                        $('#spandanger').html('Attachment is already Exists.');
                        Metronic.scrollTo($(".alert-danger"), -200);
                        $('.alert-danger').fadeOut(7000);
                        return false;
                    }
                }

            },
            error: function (xhr, status, error) {

                var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }

                return false;
                jQuery.unblockUI();
            }

        });
    }
}
function fetchAttachments() {
   jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "eRequestForQuotation/eRFQDetails/?RFQID=" + sessionStorage.getItem('hddnRFQID') + "&CustomerID=" + sessionStorage.getItem('CustomerID') + "&UserID=" + sessionStorage.getItem('UserID'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
            var attach = "";
            jQuery("#tblAttachments").empty();
            jQuery("#tblAttachmentsPrev").empty();
            if (data[0].Attachments.length > 0)
            {

                jQuery('#tblAttachmentsPrev').append("<thead><tr><th class='bold'>Attachment Description</th><th class='bold'>Attachment</th></tr></thead>");
                for (var i = 0; i < data[0].Attachments.length; i++) {
                    attach = data[0].Attachments[i].RFQAttachment.replace(/\s/g, "%20");
                    var str = "<tr><td style='width:47%!important'>" + data[0].Attachments[i].RFQAttachmentDescription + "</td>";
                    str += '<td class=style="width:47%!important"><a style="pointer:cursur;text-decoration:none;" target=_blank href=PortalDocs/eRFQ/' + sessionStorage.getItem("hddnRFQID") + '/' + attach + '>' + data[0].Attachments[i].RFQAttachment + '</a></td>';
                    jQuery('#tblAttachmentsPrev').append(str);
                    str += "<td style='width:5%!important'><button type='button' class='btn btn-xs btn-danger' id=Removebtnattach" + i + " onclick=fnRemoveAttachmentQues(\'" + data[0].Attachments[i].SrNo + "'\,\'Attachment'\)><i class='glyphicon glyphicon-remove-circle'></i></button></td></tr>";
                    jQuery('#tblAttachments').append(str);
                }
            }
          
            else {
                jQuery('#tblAttachmentsPrev').append("<tr><td>No Attachments!!</td></tr>")
            }
            
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
    })
}
function fnRemoveAttachmentQues(srno, deletionfor) {
    
   
    var Attachments = {
        "SrNo": srno,
        "DeletionFor": deletionfor,
        "RFQID": sessionStorage.getItem('hddnRFQID')
           
    }
    jQuery.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "eRequestForQuotation/eRFQAttachmentQuesremove",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        crossDomain: true,
        async: false,
        data: JSON.stringify(Attachments),
        dataType: "json",
        success: function (data) {
            if (data.length > 0) {
                if (data[0].OutPut == "1") {
                    fetchAttachments();
                    GetQuestions();
                    $('.alert-success').show();
                    $('#spansuccess1').html('Record deleted successfully!');
                        
                    Metronic.scrollTo($(".alert-success"), -200);
                    $('.alert-success').fadeOut(7000);

                    return false;
                }
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
        })
}
function addApprovers() {
    if ($("#ddlapprovertype").val() =="") {
        $('.alert-danger').show();
        $('#spandanger').html('Please Select Approver Type');
        Metronic.scrollTo($(".alert-danger"), -200);
        $('.alert-danger').fadeOut(7000);
        return false;
    }
    else if (sessionStorage.getItem('hdnApproverid') == "0" || $('#txtApprover').val()=="") {
        $('.alert-danger').show();
        $('#spandanger').html('Approver not selected. Please press + Button after selecting Approver');
        Metronic.scrollTo($(".alert-danger"), -200);
        $('.alert-danger').fadeOut(7000);
        return false;
    }
    else {

        var Approvers = {
            "ApproverType": jQuery("#ddlapprovertype").val(),
            "UserID": sessionStorage.getItem('hdnApproverid'),
            "RFQID": sessionStorage.getItem('hddnRFQID'),
            "CreatedBy": sessionStorage.getItem('UserID'),
            "ShowQuotedPrice":"N",
            "CustomerID": sessionStorage.getItem('CustomerID')
           
        }
       // alert(JSON.stringify(Approvers))
        jQuery.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: sessionStorage.getItem("APIPath") + "eRequestForQuotation/eRFQInsApprover",
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            crossDomain: true,
            async: false,
            data: JSON.stringify(Approvers),
            dataType: "json",
            success: function (data) {
                 if (data.length > 0) {

                    if (data[0].OutPut == "1") {
                        
                        fnGetApprovers();
                        //$('.alert-success').show();
                        //$('#spansuccess1').html('Approver mapped successfully!');
                        //Metronic.scrollTo($(".alert-success"), -200);
                        //$('.alert-success').fadeOut(7000);
                       
                        //return false;

                    }
                    else {
                        $('.alert-danger').show();
                        $('#spandanger').html('Approver is already mapped for this RFQ.');
                        Metronic.scrollTo($(".alert-danger"), -200);
                        $('.alert-danger').fadeOut(7000);
                        return false;
                    }
                   // jQuery("#txtApprover").val('')
                   // sessionStorage.setItem('hdnApproverid', '0')
                   // jQuery("#ddlapprovertype").val('')
                }

            },
            error: function (xhr, status, error) {

                var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }

                return false;
                jQuery.unblockUI();
            }

        });
    }
}
function addquestions() {
    if (jQuery("#txtquestions").val() == "") {
        $('.alert-danger').show();
        $('#spandanger').html('Please Enter Questions');
        Metronic.scrollTo($(".alert-danger"), -200);
        $('.alert-danger').fadeOut(7000);
        return false;
    }
    else if (jQuery("#txtreq").val() == "") {
        $('.alert-danger').show();
        $('#spandanger').html('Please Enter Requirement');
        Metronic.scrollTo($(".alert-danger"), -200);
        $('.alert-danger').fadeOut(7000);
        return false;
    }
    else {

        var Questions = {
            "RFQID": sessionStorage.getItem('hddnRFQID'),
            "RFQQuestions": jQuery("#txtquestions").val(),
            "RFQQuestionsRequirement": jQuery("#txtreq").val()
        }
        // alert(JSON.stringify(Approvers))
        jQuery.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: sessionStorage.getItem("APIPath") + "eRequestForQuotation/eInsQuestions",
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            crossDomain: true,
            async: false,
            data: JSON.stringify(Questions),
            dataType: "json",
            success: function (data) {
                if (data.length > 0) {

                    if (data[0].OutPut == "1") {
                        GetQuestions();
                        $('.alert-success').show();
                        $('#spansuccess1').html('Questions mapped successfully!');
                        Metronic.scrollTo($(".alert-success"), -200);
                        $('.alert-success').fadeOut(7000);
                        jQuery("#txtquestions").val('')
                        jQuery("#txtreq").val('')
                       
                        return false;

                    }
                }

            },
            error: function (xhr, status, error) {

                var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }

                return false;
                jQuery.unblockUI();
            }

        });
    }
}
function GetQuestions() {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "eRequestForQuotation/eRFQDetails/?RFQID=" + sessionStorage.getItem('hddnRFQID') + "&CustomerID=" + sessionStorage.getItem('CustomerID') + "&UserID=" + sessionStorage.getItem('UserID'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data) {
            jQuery("#tblquestions").empty();
            jQuery("#tblQuestionsPrev").empty();
            if (data[0].Questions.length > 0) {
                jQuery('#tblquestions').append("<thead><tr><th class='bold' style='width:54.9%!important'>Questions</th><th class='bold' style='width:35%!important'>Requirement</th><th style='width:5%!important'></th></tr></thead>");
                jQuery('#tblQuestionsPrev').append("<thead><tr><th class='bold' style='width:50%!important'>Questions</th><th class='bold' style='width:50%!important'>Requirement</th></tr></thead>");
                for (var i = 0; i < data[0].Questions.length; i++) {
                    str = "<tr><td>" + data[0].Questions[i].RFQQuestions + "</td>";
                    str += "<td>" + data[0].Questions[i].RFQQuestionsRequirement + "</td>";
                    jQuery('#tblQuestionsPrev').append(str);
                    str += "<td><button type='button' class='btn btn-xs btn-danger' id=Removebtn" + i + " onclick=fnRemoveAttachmentQues(\'" + data[0].Questions[i].ID + "'\,\'Question'\)><i class='glyphicon glyphicon-remove-circle'></i></button></td></tr>";
                    jQuery('#tblquestions').append(str);
                }
            }
            else {
                jQuery('#tblQuestionsPrev').append("<tr><td>No Questions Mapped!!</td></tr>")
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
        })
}
function fnGetApprovers() {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "eRequestForQuotation/eRFQDetails/?RFQID=" + sessionStorage.getItem('hddnRFQID') + "&CustomerID=" + sessionStorage.getItem('CustomerID') + "&UserID=" + sessionStorage.getItem('UserID'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data) {
            var str="";
            var strT = "";
            var count = 0;
            var countT = 0;
            jQuery("#tblapprovers").empty();
            jQuery("#tblapproversPrev").empty();
            if (data[0].Approvers.length > 0) {
                if (sessionStorage.getItem('CustomerID') == 32) {
                    $('#Addbtn1').attr('disabled','disabled')
                }
                else {
                    $('#Addbtn1').removeAttr('disabled')
                }
                var approvertype = "";
                $('#wrap_scrollerPrevApp').show();
               jQuery('#tblapprovers').append("<thead><tr><th class='bold' style='width:30%!important'>Approver</th><th class='bold' style='width:30%!important'>Email</th><th class='bold' style='width:20%!important'>ApproverType</th><th class='bold' style='width:15%!important'>Sequence</th><th style='width:5%!important'></th></tr></thead>");
               jQuery('#tblapproversPrev').append("<thead><tr><th class='bold' style='width:30%!important'>Approver</th><th class='bold' style='width:30%!important'>Email</th><th class='bold' style='width:20%!important'>ApproverType</th><th class='bold' style='width:15%!important'>Sequence</th></tr></thead>");
               
                for (var i = 0; i < data[0].Approvers.length; i++) {

                    if (data[0].Approvers[i].ApproverType == "C") {
                        approvertype = "Commercial";
                        
                    }
                    else {
                        approvertype = "Technical";
                       
                    }
                    str = "<tr><td>" + data[0].Approvers[i].UserName + "</td>";
                    str += "<td>" + data[0].Approvers[i].EmailID + "</td>";
                    str += "<td>" + approvertype + "</td>";
                    str += "<td>" + data[0].Approvers[i].AdminSrNo + "</td>";
                    jQuery('#tblapproversPrev').append(str);
                    str += "<td><button type='button' class='btn btn-xs btn-danger' id=Removebtn" + i + " onclick=fnRemoveApprover(\'" + data[0].Approvers[i].SrNo + "'\,\'" + data[0].Approvers[i].ApproverType + "'\)><i class='glyphicon glyphicon-remove-circle'></i></button></td></tr>";
                    jQuery('#tblapprovers').append(str);
                   
                }
            }
            else{
               // jQuery('#tblapprovers').append("<tr><td colspan=4>Map Approvers</td></tr>")
            }
            
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
    })
}

function fnRemoveApprover(rowsrno, approvertype) {
    var Approvers = {
        "ApproverType": approvertype,
        "SrNo": rowsrno,
        "RFQID": sessionStorage.getItem('hddnRFQID')
     }
    jQuery.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "eRequestForQuotation/eRFQApproveRemove",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        crossDomain: true,
        async: false,
        data: JSON.stringify(Approvers),
        dataType: "json",
        success: function (data) {
            if (data[0].OutPut == "1") {
               
                fnGetApprovers();
                $('.alert-success').show();
                $('#spansuccess1').html('Approver removed successfully!');
                Metronic.scrollTo($(".alert-success"), -200);
                $('.alert-success').fadeOut(7000);
                return false;

            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
    })
}
var allUsers
function fetchRegisterUser(bidtypeid) {
    jQuery.ajax({
         type: "GET",
         contentType: "application/json; charset=utf-8",
         url: sessionStorage.getItem("APIPath") + "RegisterUser/fetchRegisterUser/?CustomerID=" + sessionStorage.getItem("CustomerID") + "&UserID=0&BidTypeID=" + bidtypeid + "&LoginUserID=" + encodeURIComponent(sessionStorage.getItem('UserID')) + "&AuthenticationToken=" + sessionStorage.getItem('AuthenticationToken'),
         beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
         cache: false,
         crossDomain: true,
        dataType: "json",
         success: function (data) {
             if (data.length > 0) {
                 allUsers = data;
             }
             else {
                 allUsers = '';
             }

         },
         error: function (xhr, status, error) {

             var err = eval("(" + xhr.responseText + ")");
             if (xhr.status === 401) {
                 error401Messagebox(err.Message);
             }

             return false;
             jQuery.unblockUI();
         }

    });

}
jQuery("#txtApprover").keyup(function () {
    sessionStorage.setItem('hdnApproverid', '0');

});
sessionStorage.setItem('hdnApproverid', 0);
jQuery("#txtApprover").typeahead({
    source: function (query, process) {
        var data = allUsers;
        usernames = [];
        map = {};
        var username = "";
        jQuery.each(data, function (i, username) {
            map[username.UserName] = username;
            usernames.push(username.UserName);
        });

        process(usernames);

    },
    minLength: 2,
    updater: function (item) {
        if (map[item].UserID != "0") {
            sessionStorage.setItem('hdnApproverid', map[item].UserID);
            addApprovers();
        }
        else {
            gritternotification('Approver not selected. Please press + Button after selecting Approver');
        }

        return item;
    }

});


sessionStorage.setItem('CurrentRFQParameterId', 0)
function InsUpdProductSevices() {
    
   // var AttachementFileName = "";
   // var attachmentSize = 0;
   // if ($("#file3").val() != '') {
   //     totalFileSize += $("#file3")[0].files[0].size;
   //     if (totalFileSize < 10000000000) {
   //         $("#validattachmentSize").val(totalFileSize)
   //     } else {
   //         $('.alert-danger').show();
   //         $('#spandanger').html('Attachments should not exceed more than 10mb.');
   //         Metronic.scrollTo($(".alert-danger"), -200);
   //         $('.alert-danger').fadeOut(7000);
   //         return false;
            
   //     }
        
   // }
    if ($('#dropuom').val() == '') {
        $('.alert-danger').show();
        $('#spandanger').html('Please Select UOM Properly');
        Metronic.scrollTo($(".alert-danger"), -200);
        $('.alert-danger').fadeOut(7000);
        return false;
    } 
   else { 
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />Please Wait...</h5>' });
    if (form.valid() == true) {
        
        var Description = $('#txtbiddescriptionP').val().replace(/\n/g, '<br />').replace(/'/g, " ");
        var Remark = '';
        var data = {
            "RFQParameterId": sessionStorage.getItem('CurrentRFQParameterId'),
            "RFQId": sessionStorage.getItem('hddnRFQID'),
            "RFQShortName": $('#txtshortname').val(),
            "RFQTargetPrice": removeThousandSeperator($('#txttargetprice').val()),
            "RFQItemCode":$('#txtItemCode').val(),
            "RFQuantity": removeThousandSeperator($('#txtquantitiy').val()),
            "RFQUomId": $('#dropuom').val(),
            "RFQRemark": $('#txtItemRemarks').val(),
            "RFQDescription": Description,
            "TAT": $("#txttat").val(),
            "RFQDelivery": $("#txtedelivery").val(),
            "RFQPoNo": $("#txtPono").val(),
            "RFQUnitRate": $("#txtunitrate").val(),
            "RFQVendorName": $("#txtvendorname").val(),
            "RFQPODate": $("#txtPODate").val(),
            "RFQPOValue": $("#txtpovalue").val(),
            "UserId": sessionStorage.getItem('UserID')
        }
       
  //  alert(JSON.stringify(data))
        jQuery.ajax({
            url: sessionStorage.getItem("APIPath") + "eRequestForQuotation/eInsUpdRFQParameter",
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            data: JSON.stringify(data),
            type: "POST",
            cache: false,
            crossDomain: true,
            processData: true,
            dataType: "json",
            contentType: "application/json",
            success: function(data) {
              
                if (data[0].GetMsz == "1") {

                    fetchRFIParameteronload()
                    $('.alert-success').show();
                    $('#spansuccess1').html('RFQ Item Parameter saved successfully!');
                    Metronic.scrollTo($(".alert-success"), -200);
                    $('.alert-success').fadeOut(7000);
                    resetfun();
                    return false;
                  
                }
                else if (data[0].GetMsz == '2') {

                    fetchRFIParameteronload()
                    $('.alert-success').show();
                    $('#spansuccess1').html('RFQ Item Parameter updated successfully!');
                    Metronic.scrollTo($(".alert-success"), -200);
                    $('.alert-success').fadeOut(7000);
                    resetfun();
                    return false;
                   
                }
                else if (data[0].GetMsz == '3') {
                    $('.alert-danger').show();
                    $('#spandanger').html('RFQ Item Parameter with same name already exists.!');
                    Metronic.scrollTo($(".alert-danger"), -200);
                    $('.alert-danger').fadeOut(7000);
                    return false;
                }
                

            },
            error: function (xhr, status, error) {

                var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }

                return false;
                jQuery.unblockUI();
            }
        });
    //    fileUploaderTab2(sessionStorage.getItem("hddnRFQID"));
        
        jQuery.unblockUI();
         
    }
    else {
        form.validate()
        jQuery.unblockUI();
        return false;
    }
  }
}



function editRow(RFQParameterId,rowid) {
    Metronic.scrollTo($("body"), 200);
   
    var Descriptiontxt = $("#" + rowid).find("td:eq(6)").text().replace(/<br>/g, '\n') //RFQDeccription.replace(/<br>/g, '\n')
    var RFQRemark = $("#" + rowid).find("td:eq(9)").text().replace(/<br>/g, '\n')
	
	sessionStorage.setItem('CurrentRFQParameterId', RFQParameterId)
    //$('#rowid').val(rowid.id)

    $('#txtshortname').val($("#" + rowid).find("td:eq(2)").text())
    $('#txtItemCode').val($("#" + rowid).find("td:eq(1)").text())
    $('#txttargetprice').val($("#" + rowid).find("td:eq(3)").text())

    $('#txtquantitiy').val($("#" + rowid).find("td:eq(4)").text())
    

    $('#txtUOM').val($("#" + rowid).find("td:eq(5)").text())
    $('#dropuom').val($("#" + rowid).find("td:eq(5)").text())
    //$('#txtRemark').val(RFQRemark)
    $('#txtItemRemarks').val(RFQRemark)

    $('#txtbiddescriptionP').val(Descriptiontxt)

    $('#txtedelivery').val($("#" + rowid).find("td:eq(7)").text())
    $("#txttat").val($("#" + rowid).find("td:eq(8)").text())
    $('#txtPono').val($("#" + rowid).find("td:eq(10)").text())
    $('#txtunitrate').val($("#" + rowid).find("td:eq(12)").text())
    $('#txtvendorname').val($("#" + rowid).find("td:eq(11)").text())
    $('#txtPODate').val($("#" + rowid).find("td:eq(13)").text())
    $('#txtpovalue').val($("#" + rowid).find("td:eq(14)").text())
    $('#add_or').text('Modify');
    
    
}
function mapQuestion(RFQParameterId, RFQId) {
   
    $('#txtParentRFQParameterId').val(RFQParameterId);
    fetchRFIParameterComponent();

}
function deleterow(RFQParameterId) {
   
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "eRequestForQuotation/edeleteRowRFQParameter/?RFQParameterId=" + RFQParameterId,
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        data: "{}",
        cache: false,
        dataType: "json",
        success: function (data) {
          
            fetchRFIParameteronload();

        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else {
                alert('error')
            }
            return false;
            jQuery.unblockUI();
        }
    });
}

function resetfun() {
    sessionStorage.setItem('CurrentRFQParameterId', 0)
    $('#add_or').text('Add');
    $('#txtshortname').val('');
    $('#txttargetprice').val('');
    $('#txtquantitiy').val('');
    $('#dropuom').val('');
    $('#txtItemRemarks').val('');
    $('#txtbiddescriptionP').val('');
    $('#txtedelivery').val('');
    $("#txtItemCode").val('');
    $("#txtPono").val('');
    $("#txtunitrate").val('');
    $("#txtvendorname").val('');
    $("#txtPODate").val(''); 
    $("#txtpovalue").val('');


    //$("#mapsections").validate().resetForm()

}
function FormValidate() {

    $('#mapsections').validate({
        errorElement: 'span', //default input error message container
        errorClass: 'help-block', // default input error message class
        focusInvalid: false, // do not focus the last invalid input

        rules: {
            txtmodelshortname: {
                required: true
            },
            
            txtmodelquantity: {
                required: true,
                number: true
            },
            ddlropuom: {
                required: true
            }, txtmodeltargetprice: {
                number: true
            }

        },
        messages: {

           
            txtmodelshortname: {
                required: "Short Name is required."
            },
            txtmodelquantity: {
                required: "Quantity is required."
            },
            ddlropuom: {
                required: "UOM is required."
            }


        },
        invalidHandler: function (event, validator) { //display error alert on form submit   
            
        },

        highlight: function (element) { // hightlight error inputs
            $(element).closest('.col-md-4').addClass('has-error'); // set error class to the control group
            $(element).closest('.col-md-10').addClass('has-error'); // set error class to the control group
            
        },
        unhighlight: function (element) { // revert the change done by hightlight
            $(element).closest('.col-md-4').removeClass('has-error'); // set error class to the control group
            $(element).closest('.col-md-10').removeClass('has-error');
        },

        success: function (label) {
            label.closest('.col-md-4').removeClass('has-error');
            label.closest('.col-md-10').removeClass('has-error');
            label.remove();
        },


        submitHandler: function (form) {
            insboqvalues();
        }
    });


}

var flag = 'insert';
var allUOM = '';
function FetchUOM(CustomerID) {

    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "UOM/fetchUOMCust/?CustomerID=" + CustomerID,//  fetchUOM
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        dataType: "json",
        success: function (data) {
            jQuery("#txtUOM").empty();
            if (data.length > 0) {
                allUOM = data;
            }
            else {
                allUOM = '';
            }
            //jQuery("#dropuom").append(jQuery("<option ></option>").val("").html("Select UOM"));
            //for (var i = 0; i < data.length; i++) {
            //    jQuery("#dropuom").append(jQuery("<option></option>").val(data[i].UOM).html(data[i].UOM));
            //}

        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
           
            return false;
            jQuery.unblockUI();
        }

    });

}
jQuery("#txtUOM").keyup(function () {
    $('#dropuom').val('')

});
jQuery("#txtUOM").typeahead({
    source: function (query, process) {
        var data = allUOM;
        usernames = [];
        map = {};
        var username = "";
        jQuery.each(data, function (i, username) {
            map[username.UOM] = username;
            usernames.push(username.UOM);
        });

        process(usernames);

    },
    minLength: 2,
    updater: function (item) {
        if (map[item].UOM != "") {
          $('#dropuom').val(map[item].UOM)

        }
        else {
            gritternotification('Please select UOM  properly!!!');
        }

        return item;
    }

});
function FetchUOMforpop(CustomerID) {

    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "UOM/FetchUOM/?CustomerID=" + CustomerID,
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        dataType: "json",
        success: function (data) {
            jQuery("#ddlropuom").empty();
            jQuery("#ddlropuom").append(jQuery("<option ></option>").val("").html("Select"));
            for (var i = 0; i < data.length; i++) {
                jQuery("#ddlropuom").append(jQuery("<option></option>").val(data[i].UOM).html(data[i].UOM));
            }

        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }

    });

}
function displayUOM() {
    if (jQuery('#dropuom').val() != '') {
        var uomcaption = '/ ' + jQuery('#dropuom').val()
        jQuery('#lblUOM').text(uomcaption)
    }
    else {
        jQuery('#lblUOM').text('')
    }
   
}



jQuery("#txtSearch").keyup(function () {
    _this = this;
    // Show only matching TR, hide rest of them
    jQuery.each($("#tblvendorlist tbody").find("tr"), function () {
        console.log($(this).text());
        if (jQuery(this).text().toLowerCase().indexOf(jQuery(_this).val().toLowerCase()) == -1)
            jQuery(this).hide();
        else
            jQuery(this).show();
    });
});

function FetchCurrency(CurrencyID) {

    jQuery.ajax({

        type: "GET",

        contentType: "application/json; charset=utf-8",

        url: sessionStorage.getItem("APIPath") + "ConfigureBid/FetchCurrency/?CurrencyID=" + CurrencyID + "&excludeStatus=N",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },

        cache: false,

        dataType: "json",

        success: function (data) {

            jQuery("#dropCurrency").empty();

            jQuery("#dropCurrency").append(jQuery("<option ></option>").val("").html("Select"));

            for (var i = 0; i < data.length; i++) {

                jQuery("#dropCurrency").append(jQuery("<option></option>").val(data[i].CurrencyId).html(data[i].CurrencyNm));

            }

        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }

    });

}

function RFQInviteVendorTab3() {
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    var vendorID = sessionStorage.getItem('UserID');
    var InsertQuery = '';

    $("#selectedvendorlistsPrev> tbody > tr").each(function(index) {
       // if ($(this).find("span#spanchecked").attr('class') == 'checked') {

        InsertQuery = InsertQuery + " select " + sessionStorage.getItem("hddnRFQID") + "," + $.trim($(this).find('td:eq(0)').html()) + ",'" + $('#txtrfqSubject').val() + "',dbo.Decrypt('" + vendorID + "')," + $.trim($(this).find('td:eq(0)').html()) + ",'eRFQVendor.html?RFQID=" + sessionStorage.getItem("hddnRFQID") + "','N'," + sessionStorage.getItem('CustomerID') + ",getdate() union all "; //(convert(nvarchar(11),b.RFQClosureDate,103 )
        //}
        //else {
           // InsertQuery = InsertQuery;
        //}

    });

    if (InsertQuery != '') {

        InsertQuery = "Insert into ActivityDetails(eRFQId,VendorId,ActivityDescription,FromUserId,ToUserId,LinkURL,Status,CustomerID,ReceiptDt)" + InsertQuery;
        InsertQuery = InsertQuery.substring(0, InsertQuery.length - 11);

    }
    else {
        InsertQuery = "Print 1";
    }

    var Tab3data = {
        "BidVendors": InsertQuery,       
        "RFQId": sessionStorage.getItem("hddnRFQID"),
        "UserID": sessionStorage.getItem('UserID'),
        "subject": jQuery('#txtrfqSubject').val(),
        "Deadline": jQuery('#txtenddatettime').val(),
        "RFQDescription":jQuery('#txtrfqdescription').val()
    };
   // alert(JSON.stringify(Tab3data))
    jQuery.ajax({

        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "eRequestForQuotation/eRFQInviteVendors/",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        crossDomain: true,
        async: false,
        data: JSON.stringify(Tab3data),
        dataType: "json",
        success: function (data) {
            if (data[0].RFQId > 0) {
                jQuery.unblockUI();
                bootbox.alert("Request for Quotation Submitted Successfully.", function () {
                    sessionStorage.removeItem('CurrentBidID');
                    window.location = sessionStorage.getItem("HomePage")

                    return false;

                });
                return true;

            }
            else {
                jQuery.unblockUI();
                alert('error')
                return false;

            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
    });   
}


//function FetchVenderForrfirfq() {
//    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
//    jQuery.ajax({

//        type: "GET",

//        contentType: "application/json; charset=utf-8",

//        url: sessionStorage.getItem("APIPath") + "ConfigureBid/FetchVendorsForRFIRFQ/?CustomerID="+sessionStorage.getItem('CustomerID'),

//        cache: false,

//        dataType: "json",

//        success: function (data) {

//            jQuery("#tblvendorlist > tbody").empty();
//            var vName = '';
//            for (var i = 0; i < data.length; i++) {
//                vName = data[i].VendorName;
//                var str = "<tr><td class='display-none'>" + data[i].UserID + "</td><td><div class=\"checker\" id=\"uniform-chkbidTypes\"><span  id=\"spanchecked\"><input type=\"checkbox\" Onclick=\"Check(this,\'" + vName + "'\,\'" + data[i].VendorID + "'\)\"; id=\"chkvender" + i + "\" value=" + data[i].VendorID + " style=\"cursor:pointer\" name=\"chkvender\"/></span></div></td><td> " + data[i].VendorName + " </td></tr>";

//                jQuery('#tblvendorlist > tbody').append(str);

//            }

//        }

//    });
//    jQuery.unblockUI();
//}

function FetchVender(ByBidTypeID) {

    jQuery.ajax({
        type: "GET",

        contentType: "application/json; charset=utf-8",

        url: sessionStorage.getItem("APIPath") + "ConfigureBid/FetchVendor/?ByBidTypeID=" + ByBidTypeID + "&CustomerID=" + sessionStorage.getItem('CustomerID'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,

        dataType: "json",

        success: function(data) {
        if (data.length > 0) {
            $("#txtSearch").show();
        }
            jQuery("#tblvendorlist > tbody").empty();
            var vName = '';
            for (var i = 0; i < data.length; i++) {
                vName = data[i].VendorName;
                var str = "<tr><td><div class=\"checker\" id=\"uniform-chkbidTypes\"><span  id=\"spanchecked\"><input type=\"checkbox\" Onclick=\"Check(this,\'" + vName + "'\,\'" + data[i].VendorID + "'\)\"; id=\"chkvender" + i + "\" value=" + data[i].VendorID + " style=\"cursor:pointer\" name=\"chkvender\"/></span></div></td><td> " + data[i].VendorName + " </td></tr>";

                jQuery('#tblvendorlist > tbody').append(str);

            }

        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }

    });

}

var vCount = 0;
$("#chkAll").click(function() {

    if ($("#chkAll").is(':checked') == true) {
        $('#divvendorlist').find('span#spandynamic').hide();
        $('table#tblvendorlist').closest('.inputgroup').removeClass('has-error');
        jQuery('#selectedvendorlists> tbody').empty()
        jQuery('#selectedvendorlistsPrev> tbody').empty()
        vCount = 0;
        $("#tblvendorlist> tbody > tr").each(function(index) {
            $(this).find("span#spanchecked").addClass("checked");
            $('#chkvender' + vCount).prop("disabled", true);
            var vendorid = $('#chkvender' + vCount).val()
            var v = vCount;
            vCount = vCount + 1;
            var vname = $.trim($(this).find('td:eq(2)').html())
            jQuery('#selectedvendorlists').append('<tr id=SelecetedVendor' + vendorid + '><td class=hide>' + vendorid + '</td><td>' + vname + '</td><td><a href="javascript:;" class="btn btn-xs btn-danger" onclick="removevendor(SelecetedVendor' + vendorid + ',' + 'chkvender' + v + ',SelecetedVendorPrev' + vendorid + ')"><i class="glyphicon glyphicon-remove-circle"></i></a></td></tr>')
            jQuery('#selectedvendorlistsPrev').append('<tr id=SelecetedVendorPrev' + vendorid + '><td class=hide>' + vendorid + '</td><td>' + vname + '</td></tr>')

        });
    }
    else {
        $("#tblvendorlist> tbody > tr").each(function(index) {
            $(this).find("span#spanchecked").removeClass("checked");
            vCount = 0;
            $('input[name="chkvender"]').prop('disabled', false);
            jQuery('#selectedvendorlists> tbody').empty()
            jQuery('#selectedvendorlistsPrev> tbody').empty()
        });

    }
    if (vCount > 0) {
        jQuery('#selectedvendorlists').show()
        jQuery('#selectedvendorlistsPrev').show()
    }
    else {
        jQuery('#selectedvendorlists').hide()
        jQuery('#selectedvendorlistsPrev').hide()
    }

});

function Check(event, vname, vendorID) {

    if ($(event).closest("span#spanchecked").attr('class') == 'checked') {

        $(event).closest("span#spanchecked").removeClass("checked")

    }

    else {

        vCount = vCount + 1;
        
        var EvID = event.id;
        $(event).prop("disabled", true);
        $(event).closest("span#spanchecked").addClass("checked")
        jQuery('#selectedvendorlists').append('<tr id=SelecetedVendor' + vendorID + '><td class=hide>' + vendorID + '</td><td>' + vname + '</td><td><a href="javascript:;" class="btn btn-xs btn-danger" onclick="removevendor(SelecetedVendor' + vendorID + ',' + EvID + ',SelecetedVendorPrev' + vendorID + ')"><i class="glyphicon glyphicon-remove-circle"></i></a></td></tr>')
        jQuery('#selectedvendorlistsPrev').append('<tr id=SelecetedVendorPrev' + vendorID + '><td class=hide>' + vendorID + '</td><td>' + vname + '</td></tr>')
        $('#divvendorlist').find('span#spandynamic').hide();

        $('table#tblvendorlist').closest('.inputgroup').removeClass('has-error');

    }
    if (vCount > 0) {
        jQuery('#selectedvendorlists').show()
        jQuery('#selectedvendorlistsPrev').show()
    }
    else {
        jQuery('#selectedvendorlists').hide()
        jQuery('#selectedvendorlistsPrev').hide()
    }

}

function removevendor(trid, chkid, trprevid) {
    
    vCount = vCount - 1;

    $('#' + trid.id).remove()
    $('#' + trprevid.id).remove()
    $(chkid).closest("span#spanchecked").removeClass("checked")
    $(chkid).prop("disabled", false);
    if (vCount > 0) {
        jQuery('#selectedvendorlists').show()
        jQuery('#selectedvendorlistsPrev').show()
    }
    else {

        $('#chkAll').closest("span").removeClass("checked")
        $('#chkAll').prop("checked", false);
        jQuery('#selectedvendorlists').hide()
        jQuery('#selectedvendorlistsPrev').hide()

    }
}

function ValidateVendor() {

    var status = "false";

   
  //  var i = 0;
   // $('#divvendorlist').find('span#spandynamic').hide();

    $("#tblvendorlist> tbody > tr").each(function (index) {
        
       if ($(this).find("span#spanchecked").attr('class') == 'checked') {
                //i = i + 1;                
                //if (i >= 2) {
                   
                    status = "True";
                //}
                
       }
       else {
           status == "false";
       }
    
   });

    if (status == "false") {        
        $('.alert-danger').show();
        $('#spandanger').html('Please select atleast one vendors');
        Metronic.scrollTo($('.alert-danger'), -200);
        $('.alert-danger').fadeOut(5000);
        $('table#tblvendorlist').closest('.inputgroup').addClass('has-error');
        
        status = "false";

    }

    return status;

}






function fetchReguestforQuotationDetails() {
   // jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    var replaced1 = '';
    //var replaced2 = '';
    
jQuery.ajax({
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "eRequestForQuotation/eRFQDetails/?RFQID=" + sessionStorage.getItem('hddnRFQID') + "&CustomerID=" + sessionStorage.getItem('CustomerID') + "&UserID=" + sessionStorage.getItem('UserID'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "GET",
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (RFQData) {
        
            sessionStorage.setItem('hddnRFQID', RFQData[0].General[0].RFQId)
            jQuery('#txtrfqSubject').val(RFQData[0].General[0].RFQSubject)
            setTimeout(function () { $('#dropCurrency').val(RFQData[0].General[0].RFQCurrencyId).attr("selected", "selected"); }, 1000)
            jQuery('#txtrfqdescription').val(RFQData[0].General[0].RFQDescription)
           // jQuery('#txtrfqDuration').val(RFQData[0].General[0].RFQDeadline)
            jQuery('#txtConversionRate').val(RFQData[0].General[0].RFQConversionRate);
            jQuery('#txtRFQReference').val(RFQData[0].General[0].RFQReference)
            jQuery('#txtstartdatettime').val(RFQData[0].General[0].RFQStartDate)
            jQuery('#txtenddatettime').val(RFQData[0].General[0].RFQEndDate)
            $("#cancelBidBtn").show();
            if (RFQData[0].General[0].RFQTermandCondition != '') {
				 $('#file1').attr('disabled', true);
                $('#closebtn').removeClass('display-none');
                replaced1 = RFQData[0].General[0].RFQTermandCondition.replace(/\s/g, "%20")
                if (RFQData[0].General[0].RFQAttachment != '') {
                    $('#file2').attr('disabled', true);
                    $('#closebtn2').removeClass('display-none');

                    //replaced2 = RFQData[0].General[0].RFQAttachment.replace(/\s/g, "%20")
                }
            
			}
            jQuery('#attach-file').attr('href', 'PortalDocs/eRFQ/' + sessionStorage.getItem('hddnRFQID') + '/' + replaced1).html(RFQData[0].General[0].RFQTermandCondition)
           // jQuery('#attach-file2').attr('href', 'PortalDocs/RFQ/' + sessionStorage.getItem('hddnRFQID') + '/' + replaced2).html(RFQData[0].General[0].RFQAttachment)
           
            //if (RFQData.length > 0) {
            //    for (var i = 0; i < RFQData.length; i++) {
            //        jQuery('#mapedapprover').append(jQuery('<option selected></option>').val(RFQData[i].UserID).html(RFQData[i].UserName))
            //    }
            //}

         
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
    });
    jQuery.unblockUI();
}

function fetchRFIParameteronload() {
   
    //jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    //alert(sessionStorage.getItem("APIPath") + "eRequestForQuotation/eRFQDetails/?RFQID=" + sessionStorage.getItem('hddnRFQID') + "&CustomerID=" + sessionStorage.getItem('CustomerID') + "&UserID=" + sessionStorage.getItem('UserID'))
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "eRequestForQuotation/eRFQDetails/?RFQID=" + sessionStorage.getItem('hddnRFQID') + "&CustomerID=" + sessionStorage.getItem('CustomerID') + "&UserID=" + sessionStorage.getItem('UserID'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        data: "{}",
        cache: false,
        dataType: "json",
        success: function(data) {
            jQuery('#icon').html('<i class="fa fa-list-ul"></i>');
            jQuery("#tblServicesProduct").empty();
            jQuery("#tblRFQPrev").empty()
            $('#scrolr').show();
        
            if (data[0].Parameters.length > 0) {
                jQuery("#tblServicesProduct").append("<thead><tr style='background: gray; color: #FFF;'><th style='width:100px;'></th><th>Item Code</th><th>Item/Service</th><th>Target Price</th><th>Quantity</th><th>UOM</th><th>Description</th><th>Delivery Location</th><th>TAT</th><th>Remarks</th><th>PO No.</th><th>Vendor Name</th><th>Unit Rate</th><th>PO Date</th><th>PO Value</th></tr></thead>");
                jQuery('#tblRFQPrev').append('<thead><tr style="background: grey; color:light black;"><th>Item Code</th><th>Item/Service</th><th>Target Price</th><th>Quantity</th><th>UOM</th><th>Description</th><th>Delivery Location</th><th>TAT</th><th>Remarks</th><th>PO No.</th><th>Vendor Name</th><th>Unit Rate</th><th>PO Date</th><th>PO Value</th></tr></thead>');
              
                for (var i = 0; i < data[0].Parameters.length; i++)
                {
                    //alert(data[0].Parameters[i].RFQVendorName)
                    jQuery('<tr id=trid' + i + '><td style="width:100px;"><button type=button class="btn btn-xs btn-success" onclick="editRow(\'' + data[0].Parameters[i].RFQParameterId + '\',\'trid' + i + '\')" ><i class="fa fa-pencil" style="margin-top: 0px !important;"></i></button>&nbsp<button type=button class="btn  btn-xs btn-danger" onclick="deleterow(\'' + data[0].Parameters[i].RFQParameterId + '\',\'' + data[0].Parameters[i].BOQparentId + '\')" ><i class="glyphicon glyphicon-remove-circle" style="margin-top: 0px !important;"></i></button></td><td>' + data[0].Parameters[i].RFQItemCode + '</td><td>' + data[0].Parameters[i].RFQShortName + '</td><td class=text-right>' + thousands_separators(data[0].Parameters[i].RFQTargetPrice) + '</td><td class=text-right>' + thousands_separators(data[0].Parameters[i].RFQuantity) + '</td><td>' + data[0].Parameters[i].RFQUomId + '</td><td>' + data[0].Parameters[i].RFQDescription + '</td><td>' + data[0].Parameters[i].RFQDelivery + '</td><td class=text-right>' + data[0].Parameters[i].TAT + '</td><td>' + data[0].Parameters[i].RFQRemark + '</td><td>' + data[0].Parameters[i].RFQPoNo + '</td><td>' + data[0].Parameters[i].RFQVendorName + '</td><td class=text-right>' + thousands_separators(data[0].Parameters[i].RFQUnitRate) + '</td><td>' + data[0].Parameters[i].RFQPODate + '</td><td>' + thousands_separators(data[0].Parameters[i].RFQPOValue) + '</td></tr>').appendTo("#tblServicesProduct");
                    jQuery('<tr id=trid' + i + '><td>' + data[0].Parameters[i].RFQItemCode + '</td><td>' + data[0].Parameters[i].RFQShortName + '</td><td class=text-right>' + thousands_separators(data[0].Parameters[i].RFQTargetPrice) + '</td><td class=text-right>' + thousands_separators(data[0].Parameters[i].RFQuantity) + '</td><td>' + data[0].Parameters[i].RFQUomId + '</td><td>' + data[0].Parameters[i].RFQDescription + '</td><td>' + data[0].Parameters[i].RFQDelivery + '</td><td class=text-right>' + data[0].Parameters[i].TAT + '</td><td>' + data[0].Parameters[i].RFQRemark + '</td><td>' + data[0].Parameters[i].RFQPoNo + '</td><td>' + data[0].Parameters[i].RFQVendorName + '</td><td class=text-right>' + thousands_separators(data[0].Parameters[i].RFQUnitRate) + '</td><td>' + data[0].Parameters[i].RFQPODate + '</td><td>' + thousands_separators(data[0].Parameters[i].RFQPOValue )+ '</td></tr>').appendTo("#tblRFQPrev");
                }

                   //for previe table
                $('#wrap_scrollerPrev').show();
                    
                    
                }

            

        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else{
                alert("error");
            }
            return false;
            jQuery.unblockUI();
        }
        
    });


    jQuery.unblockUI();
    
}



function ajaxFileDelete(closebtnid, fileid, filepath, deletionFor) {
   
    var formData = new window.FormData();
    formData.append("Path", filepath);

    $.ajax({
         url: 'ConfigureFileAttachment.ashx',
         data: formData,
         processData: false,
         contentType: false,
         asyc: false,
         type: 'POST',

         success: function (data) {
            
            if (deletionFor == '2') {
                totalFileSize = (totalFileSize - $("#hddnattachmentSize").html());
                $("#validattachmentSize").val(totalFileSize)
                fileDeletefromdbForItem(closebtnid, fileid, filepath, deletionFor);
            }
            else {
                fileDeletefromdb(closebtnid, fileid, filepath, deletionFor);
            }

            
        },
          error: function() {
             bootbox.alert("Attachment error.");
         }

    });




    jQuery.unblockUI();

}

function fileDeletefromdb(closebtnid, fileid, filepath, deletionFor) {
    
    $('#'+closebtnid).remove();
    $('#'+filepath).html('')
    $('#'+filepath).attr('href', 'javascript:;').addClass('display-none');
    $('#' + fileid).attr('disabled', false);
   
    var Attachments = {
        "SrNo": sessionStorage.getItem('hddnRFQID'),
        "DeletionFor": deletionFor,
        "RFQID": sessionStorage.getItem('hddnRFQID')
    }
   // alert(JSON.stringify(Attachments))
    jQuery.ajax({

        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "eRequestForQuotation/eRFQAttachmentQuesremove",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        crossDomain: true,
        async: false,
        data: JSON.stringify(Attachments),
        dataType: "json",
        success: function (data) {
            if (data[0].OutPut == '1') {
                $('#spansuccess1').html('File Deleted Successfully');
                success.show();
                Metronic.scrollTo(success, -200);
                success.fadeOut(5000);
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
           
            return false;
            jQuery.unblockUI();
        }

    });
}

//File Dete for 2nd tab
function fileDeletefromdbForItem(closebtnid, fileid, filepath, deletionFor) {

    $('#' + closebtnid).hide();
    $('#' + filepath).html('')
    $('#' + filepath).attr('href', 'javascript:;').addClass('display-none');
    $('#' + fileid).attr('disabled', false);
    var BidData = {

        "BidId": deletionFor,
        "BidTypeID": 0,
        "UserId": sessionStorage.getItem('UserID'),
        "RFQRFIID": sessionStorage.getItem('hddnRFQID'),
        "RFIRFQType": 'RFQ',
        "RFQParameterID":sessionStorage.getItem('CurrentRFQParameterId')
    }

    jQuery.ajax({

        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ConfigureBid/FileDeletionRFQParameter/",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        crossDomain: true,
        async: false,
        data: JSON.stringify(BidData),
        dataType: "json",
        success: function(data) {
            if (data[0].IsSuccess == '1') {
                $('#spansuccess1').html('File Deleted Successfully');
                $("#txtAttachmentDescription").val('');
                success.show();
                Metronic.scrollTo(success, -200);
                success.fadeOut(5000);
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }


    });
}
$('#back_prev_btn').click(function() {
    $('#BidPreviewDiv').hide();
    $('#form_wizard_1').show();
});

function fetchPSBidDetailsForPreview() {
    var TermsConditionFileName = '';
   
    jQuery('#lblRfqsubject').html($('#txtrfqSubject').val())
    //jQuery('#lblrfqdeadline').html($('#txtrfqDuration').val())
    jQuery('#lblrfqstartdate').html($('#txtstartdatettime').val())
    jQuery('#lblrfqenddate').html($('#txtenddatettime').val())
    jQuery('#lblrfqdescription').html($('#txtrfqdescription').val())
    
    jQuery("#dropCurrencyPrev").html($('#dropCurrency option:selected').text())
    jQuery('#lblConversionRatePrev').html($('#txtConversionRate').val())
    jQuery("#txtRFQReferencePrev").html($('#txtRFQReference').val());


    if ($('#attach-file').html() != '' && ($('#file1').val() == '')) {
        $('#filepthtermsPrev').attr('href', 'PortalDocs/eRFQ/' + sessionStorage.getItem('hddnRFQID') + '/' + $('#attach-file').html().replace(/\s/g, "%20")).html($('#attach-file').html());

    }
    else {
        TermsConditionFileName = jQuery('#file1').val().substring(jQuery('#file1').val().lastIndexOf('\\') + 1);

        $('#filepthtermsPrev').attr('href', 'PortalDocs/eRFQ/' + sessionStorage.getItem('hddnRFQID') + '/' + TermsConditionFileName.replace(/\s/g, "%20")).html(TermsConditionFileName);
    }


    jQuery.unblockUI();

}




$("#btninstructionexcelparameter").click(function () {
    var ErrorUOMMsz = '<ul class="col-md-5 text-left">';
    var ErrorUOMMszRight = '<ul class="col-md-5 text-left">'
    var quorem = (allUOM.length / 2) + (allUOM.length % 2);
    for (var i = 0; i < parseInt(quorem) ; i++) {
        ErrorUOMMsz = ErrorUOMMsz + '<li>' + allUOM[i].UOM + '</li>';
        var z = (parseInt(quorem) + i);
        if (z <= allUOM.length - 1) {
            ErrorUOMMszRight = ErrorUOMMszRight + '<li>' + allUOM[z].UOM + '</li>';
        }
    }
    ErrorUOMMsz = ErrorUOMMsz + '</ul>'
    ErrorUOMMszRight = ErrorUOMMszRight + '</ul>'

    // alert(ErrorUOMMsz + ErrorUOMMszRight)
    $("#ULUOM_instructions").html(ErrorUOMMsz + ErrorUOMMszRight);
    if ($('#ddlbidclosetype').val() == "S") {
        $('#libidduraion').show()

    }
    $("#instructionsDivParameter").show();
    $("#instructionSpanParameter").show();
});
$('#RfqParameterexcel').on("hidden.bs.modal", function () {
    $("#instructionsDivParameter").hide();
    $("#instructionSpanParameter").hide();
    $("#error-excelparameter").hide();
    $("#success-excelparameter").hide();
    $('#btnsforYesNo').show()
    $("#file-excelparameter").val('');
    $('#modalLoaderparameter').addClass('display-none');
    $("#temptableForExcelDataparameter").empty();
})
function fnNoExcelUpload() {
    $("#temptableForExcelDataparameter").empty();
    $('#modalLoaderparameter').addClass('display-none');
    $("#instructionsDivParameter").hide();
    $("#instructionSpanParameter").hide();
    $("#error-excelparameter").hide();
    $("#success-excelparameter").hide();
    $('#btnsforYesNo').show()
    $("#file-excelparameter").val('');
    $('#RfqParameterexcel').modal('hide');
}



function handleFileparameter(e) {
    //Get the files from Upload control
    var files = e.target.files;
    var i, f;
    //Loop through files
    for (i = 0, f = files[i]; i != files.length; ++i) {
        var reader = new FileReader();
        var name = f.name;
        reader.onload = function (e) {
            var data = e.target.result;

            var result;
            var workbook = XLSX.read(data, { type: 'binary' });

            var sheet_name_list = workbook.SheetNames;
            sheet_name_list.forEach(function (y) { /* iterate through sheets */
                //Convert the cell value to Json
                var roa = XLSX.utils.sheet_to_json(workbook.Sheets[y]);
                if (roa.length > 0) {
                    result = roa;
                }
            });
            //Get the first column first cell value
            //alert(JSON.stringify(result))
            printDataparameter(result)
        };
        reader.readAsArrayBuffer(f);
    }
}
var Rowcount = 0;
function printDataparameter(result) {
    var loopcount = result.length; //getting the data length for loop.
   
    var i;
   // var numberOnly = /^[0-9]+$/;
    var numberOnly = /^[0-9]\d*(\.\d+)?$/;
    $("#temptableForExcelDataparameter").empty();
    $("#temptableForExcelDataparameter").append("<tr><th>ItemService</th><th>ItemCode</th><th>TargetPrice</th><th>Quantity</th><th>UOM</th><th>Description</th><th>TAT</th><th>DeliveryLocation</th><th>Remarks</th><th>PoNo</th><th>VendorName</th><th>UnitRate</th><th>PoDate</th><th>PoValue</th></tr>");
    // checking validat  alert(loopcount)
    var targetPrice = 0;
    var TAT = 0;
    var unitrate = 0
    var povalue = 0;
    var pono = ''
    var podate = ''
    var povendorname = ''
    var itemcode = ''
    for (i = 0; i < loopcount; i++) {
        itemcode = '', povendorname = '', podate = '', pono = '', povalue = 0, unitrate = 0, TAT = 0, targetPrice=0;
        if ($.trim(result[i].TAT) == '') {
            TAT = 0;
        }
        else {
            TAT = $.trim(result[i].TAT);
        }
        if ($.trim(result[i].UnitRate) == '') {
            unitrate = 0;
        }
        else {
            unitrate = $.trim(result[i].UnitRate);
        }
        if ($.trim(result[i].PoValue) == '') {
            povalue = 0;
        }
        else {
            povalue = $.trim(result[i].PoValue);
        }
        if ($.trim(result[i].TargetPrice) == '') {
            targetPrice = 0;
        }
        else {
            targetPrice = $.trim(result[i].TargetPrice);
        }
     if ($.trim(result[i].PoDate) != '') {
            podate = $.trim(result[i].PoDate);
            
        }
     if ($.trim(result[i].PoNo) != '') {
            pono = $.trim(result[i].PoNo);
           
        }
     if ($.trim(result[i].PoVendorName) != '') {
            povendorname = $.trim(result[i].PoVendorName);
            
        }
     if ($.trim(result[i].ItemCode) != '') {
            itemcode = $.trim(result[i].ItemCode);
           
        }
        //alert($.trim(result[i].Remarks))
        if ($.trim(result[i].ItemService) == '' && $.trim(result[i].ItemService) > 200) {
            $("#error-excelparameter").show();
            $("#errspan-excelparameter").html('Item/Service can not be blank or length should be 200 characters of item no '+(i+1)+'. Please fill and upload the file again.');
            $("#file-excelparameter").val('');
            return false;
        }
        //if ($.trim(result[i].ItemCode) == '' ) {
        //    $("#error-excelparameter").show();
        //    $("#errspan-excelparameter").html('ItemCode can not be blank of item no ' + (i + 1) + '. Please fill and upload the file again.');
        //    $("#file-excelparameter").val('');
        //    return false;
            //}
            
        else if ($.trim(result[i].Remarks) == '') {
            $("#error-excelparameter").show();
            $("#errspan-excelparameter").html('Remarks can not be blank of item no ' + (i + 1) + '. Please fill and upload the file again.');
            $("#file-excelparameter").val('');
            return false;
        }
        else if ($.trim(result[i].Quantity) == '') {
            $("#error-excelparameter").show();
            $("#errspan-excelparameter").html('Quantity can not be blank of item no ' + (i + 1) + '. Please fill and upload the file again.');
            $("#file-excelparameter").val('');
            return false;
        }
        else if ($.trim(result[i].Description) == '') {
            $("#error-excelparameter").show();
            $("#errspan-excelparameter").html('Description can not be blank of item no ' + (i + 1) + '. Please fill and upload the file again.');
            $("#file-excelparameter").val('');
            return false;
        }
        else if (!result[i].Quantity.trim().match(numberOnly)) {

            $("#error-excelparameter").show();
            $("#errspan-excelparameter").html('Quantity should be in numbers only of item no ' + (i + 1) + '.');
            $("#file-excelparameter").val('');
            return false;
        }
        else if ($.trim(result[i].UOM) == '') {
            $("#error-excelparameter").show();
            $("#errspan-excelparameter").html('UOM can not be blank of item no ' + (i + 1) + '. Please fill and upload the file again.');
            $("#file-excelparameter").val('');
            return false;
        }
        else if ( TAT != '' && (!TAT.match(numberOnly) || TAT.length > 4) ) {
                 $("#error-excelparameter").show();
                 $("#errspan-excelparameter").html('TAT should be in numbers only and maximum 4 digits allowed of item no ' + (i + 1) + '.');
                 $("#file-excelparameter").val('');
                return false;
           
        }
        else if (!$.trim(result[i].UnitRate).match(numberOnly) && unitrate != 0) {
            $("#error-excelparameter").show();
            $("#errspan-excelparameter").html('Unit Rate should be in numbers only of item no ' + (i + 1) + '.');
            $("#file-excelparameter").val('');
            return false;

        }
        else if (!$.trim(result[i].PoValue).match(numberOnly) && povalue != 0) {
            $("#error-excelparameter").show();
            $("#errspan-excelparameter").html('PO Value should be in numbers only of item no ' + (i + 1) + '.');
            $("#file-excelparameter").val('');
            return false;

        }
        
        else if ($.trim(result[i].DeliveryLocation) == '') {
            $("#error-excelparameter").show();
            $("#errspan-excelparameter").html('Delivery Location can not be blank of item no ' + (i + 1) + '. Please fill and upload the file again.');
            $("#file-excelparameter").val('');
            return false;
        }
        else if (targetPrice != '' && (!targetPrice.match(numberOnly))) {

            $("#error-excelparameter").show();
            $("#errspan-excelparameter").html('Target Price should be in numbers only of item no ' + (i + 1) + '.');
            $("#file-excelparameter").val('');
            return false;
        }
       
            //else {
            //    targetPrice = result[i].TargetPrice;
            //}
        else {
            // if values are correct then creating a temp table
           
            $("<tr><td>" + replaceQuoutesFromStringFromExcel(result[i].ItemService) + "</td><td>" + replaceQuoutesFromStringFromExcel(itemcode) + "</td><td>" + targetPrice + "</td><td>" + result[i].Quantity + "</td><td>" + result[i].UOM + "</td><td>" + replaceQuoutesFromStringFromExcel(result[i].Description) + "</td><td>" + TAT + "</td><td>" + replaceQuoutesFromStringFromExcel(result[i].DeliveryLocation) + "</td><td>" + replaceQuoutesFromStringFromExcel(result[i].Remarks) + "</td><td>" + replaceQuoutesFromStringFromExcel(pono) + "</td><td>" + replaceQuoutesFromStringFromExcel(povendorname) + "</td><td>" + unitrate + "</td><td>" + podate + "</td><td>" + povalue + "</td></tr>").appendTo("#temptableForExcelDataparameter");
        }

        


    } // for loop ends
    var excelCorrect = 'N';
    var ErrorUOMMsz = '';
    var ErrorUOMMszRight = '';
     Rowcount = 0;
    // check for UOM
    $("#temptableForExcelDataparameter tr:gt(0)").each(function () {
        var this_row = $(this);
        excelCorrect = 'N';
        Rowcount = Rowcount + 1;
       
        for (var i = 0; i < allUOM.length; i++) {
            if ($.trim(this_row.find('td:eq(4)').html()).toLowerCase() == allUOM[i].UOM.trim().toLowerCase()) {//allUOM[i].UOMID
                excelCorrect = 'Y';
            }
           
        }
        var quorem = (allUOM.length / 2) + (allUOM.length % 2);
        if (excelCorrect == "N") {
            $("#error-excelparameter").show();
            ErrorUOMMsz = 'UOM not filled properly at row no ' + Rowcount + '. Please choose UOM from given below: <br><ul class="col-md-3 text-left">';
            ErrorUOMMszRight = '<ul class="col-md-3 text-left">'
            for (var i = 0; i < parseInt(quorem); i++) {
                ErrorUOMMsz = ErrorUOMMsz + '<li>' + allUOM[i].UOM + '</li>';
                var z = (parseInt(quorem) + i);
                if (z <= allUOM.length - 1) {
                    ErrorUOMMszRight = ErrorUOMMszRight + '<li>' + allUOM[z].UOM + '</li>';
                }
            }
            ErrorUOMMsz = ErrorUOMMsz + '</ul>'
            ErrorUOMMszRight = ErrorUOMMszRight + '</ul><div class=clearfix></div><br/>and upload the file again.'
          
           // alert(ErrorUOMMsz + ErrorUOMMszRight)
            $("#errspan-excelparameter").html(ErrorUOMMsz + ErrorUOMMszRight);
           // $("#errspan-excelparameter").html('UOM not filled properly at row no ' + Rowcount + '. Please choose UOM from given below:');//at row no ' + Rowcount + '.
            return false;
        }
       
    });
   // alert(excelCorrect)
     if (excelCorrect == "Y") {
            $("#error-excelparameter").hide();
            // $("#errspan-excelparameter").html('');
            $("#success-excelparameter").show();
            $('#btnsforYesNo').show()
            $("#succspan-excelparameter").html('Excel file is found ok. Do you want to upload? ')
            $("#file-excelparameter").val('');
            excelCorrect = '';
        }
    
            //case 'Kilogram':
            //    excelCorrect = 'Y';
            //    break;
            //case 'Litre':
            //    excelCorrect = 'Y';
            //    break;
            //case 'Number':
            //    excelCorrect = 'Y';
            //    break;
            //case 'Roll':
            //    excelCorrect = 'Y';
            //    break;
            //case 'Sq. Ft.':
            //    excelCorrect = 'Y';
            //    break;
            //case 'Ton':
            //    excelCorrect = 'Y';
            //    break;
            //case 'Meter':
            //    excelCorrect = 'Y';
            //    break;
            //case 'Gallon':
            //    excelCorrect = 'Y';
            //    break;
            //case 'Grams':
            //    excelCorrect = 'Y';
            //    break;
            //case 'Pound':
            //    excelCorrect = 'Y';
            //    break;
            //case 'KiloMeter':
            //    excelCorrect = 'Y';
            //    break;
            //case 'Set':
            //    excelCorrect = 'Y';
            //    break;
            //case 'Package':
            //    excelCorrect = 'Y';
            //    break;
            //case 'cm3':
            //    excelCorrect = 'Y';
            //    break;
            //case 'cm':
            //    excelCorrect = 'Y';
            //    break;
            //case 'Sq cm':
            //    excelCorrect = 'Y';
            //    break;
            //case 'Sq m':
            //    excelCorrect = 'Y';
            //    break;
            //case 'm3':
            //    excelCorrect = 'Y';
            //    break;
            //case 'Each':
            //    excelCorrect = 'Y';
            //    break;
            //case 'Hour':
            //    excelCorrect = 'Y';
            //    break;
            //case 'Day':
            //    excelCorrect = 'Y';
            //    break;
            //case 'Inch':
            //    excelCorrect = 'Y';
            //    break;
            //case 'Sq Inch':
            //    excelCorrect = 'Y';
            //    break;
            //case 'Month':
            //    excelCorrect = 'Y';
            //    break;
            //case 'Per Ton Per km':
            //    excelCorrect = 'Y';
            //    break;
            //case 'Running Meter':
            //    excelCorrect = 'Y';
            //    break;
            //case 'Bag':
            //    excelCorrect = 'Y';
            //    break;
           

            //default:
            //    excelCorrect = 'F';
            //    $("#error-excelparameter").show();
            //    $("#errspan-excelparameter").html('UOM not filled properly. Please choose UOM from given below: <br/><br/>'
            //        + '<ul class="col-md-2 text-left">'
            //        + '<li>Kilogram</li>'
            //        + '<li>Litre</li>'
            //        + '<li>Roll</li>'
            //        + '<li>Sq. Ft.</li>'
            //        + '<li>Number</li>'
            //        + '<li>Ton</li>'
            //        + '<li>Set</li>'
            //        + '<li> cm3</li >'
            //        + '<li>cm</li>'
            //        + '<li>Sq cm</li>'
            //        + '<li>Sq m</li>'
            //        + '<li>m3</li>'
            //        + '<li>Each</li>'
            //        + '<li>Trips</li>'
            //        + '<li>Bag</li>'
            //        + '</ul>'

            //        + '<ul class="col-md-2 text-left">'
            //        + '<li> Hour</li>'
            //        + '<li>Day</li>'
            //        + '<li>Inch</li>'
            //        + '<li>Sq Inch</li>'
            //        + '<li>Month</li>'
            //        + '<li>Per Ton Per km</li>'
            //        + '<li>Running Meter</li>'
            //        + '<li>Meter</li>'
            //        + '<li>Gallon</li>'
            //        + '<li>Grams</li>'
            //        + '<li>Pound</li>'
            //        + '<li>KiloMeter</li>'
            //        + '<li>Package</li>'
            //        + '<li>Year</li>'
            //        + '</ul><div class=clearfix></div>'
            //        + '<br/>and upload the file again.');
            //    $("#file-excelparameter").val('');
            //    return false;
        
    
    
}


function InsupdRFQParameterfromExcelparameter() {
    $("#success-excelparameter").hide();
    $('#btnsforYesNo').show()
    $("#error-excelparameter").hide();
    $('#loader-msgparameter').html('Processing. Please Wait...!');
    $('#modalLoaderparameter').removeClass('display-none');
    removeRFQitemsForExcel(); // // remove all rfq existing parameter
    var rowCount = jQuery('#temptableForExcelDataparameter tr').length;
    var i = 0;
    if (rowCount > 0) {
       $("#temptableForExcelDataparameter tr:gt(0)").each(function () {
        //$("#temptableForExcelDataparameter> tbody > tr").each(function (index) {
       // $("#temptableForExcelDataparameter TBODY TR").each(function () {
            
           
                var this_row = $(this);
                i = i + 1;

                var data = {
                    "RFQParameterId": sessionStorage.getItem('CurrentRFQParameterId'),
                    "RFQId": sessionStorage.getItem('hddnRFQID'),
                    "RFQShortName": $.trim(this_row.find('td:eq(0)').html()),
                    "RFQTargetPrice": $.trim(this_row.find('td:eq(2)').html()),
                    "RFQItemCode":$.trim(this_row.find('td:eq(1)').html()),
                    "RFQuantity": $.trim(this_row.find('td:eq(3)').html()),
                    "RFQUomId": $.trim(this_row.find('td:eq(4)').html()),
                    "RFQRemark": $.trim(this_row.find('td:eq(8)').html()),
                    "RFQDescription": $.trim(this_row.find('td:eq(5)').html()),
                    "TAT": $.trim(this_row.find('td:eq(6)').html()),
                    "RFQDelivery": $.trim(this_row.find('td:eq(7)').html()),
                    "RFQPoNo": $.trim(this_row.find('td:eq(9)').html()),
                    "RFQUnitRate": $.trim(this_row.find('td:eq(11)').html()),
                    "RFQVendorName": $.trim(this_row.find('td:eq(10)').html()),
                    "RFQPODate": $.trim(this_row.find('td:eq(12)').html()),
                    "RFQPOValue": $.trim(this_row.find('td:eq(13)').html()),
                    "UserId": sessionStorage.getItem('UserID')

                }
           //alert(JSON.stringify(data))
           setTimeout(function () {
           
                jQuery.ajax({
                    url: sessionStorage.getItem("APIPath") + "eRequestForQuotation/eInsUpdRFQParameter",
                    beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
                    data: JSON.stringify(data),
                    type: "POST",
                    cache: false,
                    crossDomain: true,
                    processData: true,
                    dataType: "json",
                    contentType: "application/json",
                    success: function (data) {
                        //alert(data[0].GetMsz)
                        if (data[0].GetMsz == 1) {
                            $("#success-excelparameter").show()
                            $('#btnsforYesNo').hide()
                            $("#succspan-excelparameter").html('Excel file uploaded sucessfully')
                            return true; 
                        }
                        else if (data[0].GetMsz == 3) {
                            $("#error-excelparameter").show();
                            $("#errspan-excelparameter").html('RFQ Item with same name already exists at row no ' + i + ' . Item will not insert.!')

                        }
                       
                    },
                    error: function (xhr, status, error) {

                        var err = eval("(" + xhr.responseText + ")");
                        if (xhr.status === 401) {
                            error401Messagebox(err.Message);
                        }
                        else{
                            $('#modalLoaderparameter').addClass('display-none');
                            $('#btnsforYesNo').hide()
                            $("#error-excelparameter").show();
                            $("#errspan-excelparameter").html('You have error. Please try again.');
                        }
           
                        return false;
                        jQuery.unblockUI();
                    }

                   
                });
           
           }, 500 * i)

         
       });
        setTimeout(function () {
           
            
            fetchRFIParameteronload();
            $('#RfqParameterexcel').modal('hide');
           
        }, 500 * rowCount)
    }

    else {
        $("#error-excelparameter").show();
        $("#errspan-excelparameter").html('No Items Found in Excel');
    }
   
}

function removeRFQitemsForExcel() {
    var data = {
        "RFQParameterId": sessionStorage.getItem('hddnRFQID')
       

    }
   // alert(JSON.stringify(data))
    jQuery.ajax({
        url: sessionStorage.getItem("APIPath") + "eRequestForQuotation/eRemoveRFQParameterForExcel",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        data: JSON.stringify(data),
        type: "POST",
        cache: false,
        crossDomain: true,
        processData: true,
        dataType: "json",
        contentType: "application/json",
        success: function (data) {
            //alert(data[0].GetMsz)
            if (data[0].GetMsz > 0) {
                return true;
            }
            else if (data[0].GetMsz == 0) {
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            
            return false;
            jQuery.unblockUI();
        }
    });
}




$("#btninstructionexcel").click(function() {
    
    $("#instructionsDiv").show();
    $("#instructionSpan").show();
});

function fetchVendorGroup(categoryFor, vendorId) {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ProductandServiceCategory/fetchProductCategory/?CustomerID=" + sessionStorage.getItem('CustomerID') + "&For=" + categoryFor + "&MappedBy=" + sessionStorage.getItem('UserID') + "&VendorID=" + vendorId,
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        data: "{}",
        cache: false,
        dataType: "json",
        success: function (data) {
            if (data.length > 0) {
                vendorsForAutoComplete = data;
            }

            jQuery.unblockUI();
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else{
                alert("error");
            }
           
            return false;
            jQuery.unblockUI();
        }
       
    });
}

jQuery("#txtVendorGroup").typeahead({
    source: function (query, process) {
        var data = vendorsForAutoComplete
        usernames = [];
        map = {};
        var username = "";
        jQuery.each(data, function (i, username) {
            map[username.CategoryName] = username;
            usernames.push(username.CategoryName);
        });

        process(usernames);

    },
    minLength: 2,
    updater: function (item) {
        if (map[item].CategoryID != "0") {
            getCategoryWiseVendors(map[item].CategoryID);
        }
        else {
            gritternotification('Please select Vendor  properly!!!');
        }

        return item;
    }

});


function getCategoryWiseVendors(categoryID) {

    jQuery.ajax({

        type: "GET",

        contentType: "application/json; charset=utf-8",

        url: sessionStorage.getItem("APIPath") + "ConfigureBid/FetchVendorCategoryWise_PEV2/?CustomerID=" + sessionStorage.getItem('CustomerID') + "&CategoryID=" + categoryID,
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },

        cache: false,

        dataType: "json",

        success: function (data) {

            jQuery("#tblvendorlist > tbody").empty();
            var vName = '';
            for (var i = 0; i < data.length; i++) {
                vName = data[i].VendorName;
                var str = "<tr><td class='hide'>" + data[i].VendorID + "</td><td><div class=\"checker\" id=\"uniform-chkbidTypes\"><span  id=\"spanchecked\"><input type=\"checkbox\" Onclick=\"Check(this,\'" + vName + "'\,\'" + data[i].VendorID + "'\)\"; id=\"chkvender" + data[i].VendorID + "\" value=" + data[i].VendorID + " style=\"cursor:pointer\" name=\"chkvender\"/></span></div></td><td> " + data[i].VendorName + " </td></tr>";

                jQuery('#tblvendorlist > tbody').append(str);

            }
            //$("#selectedvendorlistsPrev> tbody > tr").each(function (index) {
            //    InsertQuery = InsertQuery + "select " + sessionStorage.getItem('CurrentBidID') + "," + $.trim($(this).find('td:eq(0)').html()) + "," + $.trim($(this).find('td:eq(2)').html()) + " union all ";
            //});
            if ($("#selectedvendorlists > tbody > tr").length > 0) {
                $("#selectedvendorlists> tbody > tr").each(function (index) {
                    console.log("vendID > ", $.trim($(this).find('td:eq(0)').html()))
                    $("#chkvender" + $.trim($(this).find('td:eq(0)').html())).prop("disabled", true);
                    $("#chkvender" + $.trim($(this).find('td:eq(0)').html())).closest("span#spanchecked").addClass("checked")

                });
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            
            return false;
            jQuery.unblockUI();
        }

    });


}

function showFileName(fileid) {
    var filename = '';
    filename = $('#' + fileid.id)[0].files[0].name
    $("#spnParamAttach").html(filename).show();
}


