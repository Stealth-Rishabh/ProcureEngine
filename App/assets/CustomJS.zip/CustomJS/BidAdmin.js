﻿
var BidID = "";
var BidTypeID = "";
var BidForID = "";
var Duration = '0.00';

$(document).ready(function () {
    if (window.location.search) {

        var param = getUrlVars()["param"];
        var decryptedstring = fndecrypt(param);
        BidID = getUrlVarsURL(decryptedstring)["BidID"];
        var BidTypeID = getUrlVarsURL(decryptedstring)["BidTypeID"];
        var BidForID = getUrlVarsURL(decryptedstring)["BidForID"];
        fetchBidTime()
       
    }
    
});
function fetchBidTime() {
    var display = document.querySelector('#lblTimeLeft');
    
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        //url: sessionStorage.getItem("APIPath") + "VendorParticipation/FetchBidDetails/?BidID=" + sessionStorage.getItem("BidID") + "&VendorID=" + sessionStorage.getItem("UserID"),
        url: sessionStorage.getItem("APIPath") + "VendorParticipation/FetchBidTimeLeft/?BidID=" + BidID,
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
            if (data.length > 0) {
                //alert(data[0].TimeLeft)
                // alert(data[0].BidDuration)
              // jQuery("#lblbidduration").text(data[0].BidDuartion + ' mins');
                startTimer((parseInt(data[0].TimeLeft)), display);
                $('#tmleft').html($('#lblTimeLeft').text())
				//startTimer((data[0].TimeLeft), display);
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
    });
}
var mytime = 0;
function startTimer(duration, display) {
   clearInterval(mytime)
   var  timer = duration;
    var hours, minutes, seconds;
    mytime = setInterval(function () {
        fetchBidTime();
        hours = parseInt(timer / 3600, 10)
        minutes = parseInt(timer / 60, 10) - (hours * 60)
        seconds = parseInt(timer % 60, 10);

        hours = hours < 10 ? "0" + hours : hours;
        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;

        if (hours > 0) {
            display.textContent = hours + ":" + minutes + ":" + seconds;
        }
        else {
            display.textContent = minutes + ":" + seconds;
        }


        if ((seconds.toString().substring(1, 2) == '0') || (seconds.toString().substring(1, 2) == '5')) {
            fetchBidSummaryDetails(BidID, BidTypeID, BidForID);
            fetchBidTime()
            //drawSeriesChart()
            if (sessionStorage.getItem("UserType") == 'E') {
                fetchUserChats($('#hddnVendorId').val(),'S');
            } else {
                fetchUserChats(sessionStorage.getItem('UserID'),'S');
            }
        }
        //if (seconds.toString().substring(0, 2) == '02') {
        //    fetchVendorDetails();

        //}
        fetchBidTime();
        console.log(timer)
        setTimeout(function () {
            if (--timer <= 0) {
                timer = 0;
                if (timer == 0) {
                    window.location = "index.html";
                    return;
                }
            }
       }, 5000);
        //if (--timer <= 0) {
        //    //timer = 0;
        //    window.location = "index.html";
        //    return;
        //}
    }, 1000);
}
//function refreshColumnsStaus() {
//    clearInterval(mytime)
//    var url = '';

//    url: sessionStorage.getItem("APIPath") + "BidVendorSummary/FetchBidSummary/?BidID=" + BidID + "&BidTypeID=" + BidTypeID + "&BidForID=" + BidForID + "&UserID=" + encodeURIComponent(sessionStorage.getItem("UserID")) + "&AuthenticationTonken=" + sessionStorage.getItem("AuthenticationToken"),

//    jQuery.ajax({
//        type: "GET",
//        contentType: "application/json; charset=utf-8",
//        url: url,
//        cache: false,
//        crossDomain: true,
//        dataType: "json",
//        success: function (data, status, jqXHR) {

//            if (data.length > 0) {
//                for (var i = 0; i < data.length; i++) {
//                    if (data[i].NoOfExtension >= 1) {

//                        jQuery('#lblTimeLeft').css('color', 'red');
//                        jQuery('#lblTimeLeftTxt').removeClass('display-none');
//                        jQuery('#lblTimeLeftTxt').html('<b>Bid Time Extended.</b>').css('color', 'red')
//                    }
//                    else {
//                        jQuery('#lblTimeLeftTxt').addClass('display-none');
//                        jQuery('#lblTimeLeft').css('color', '');
//                    }

//                    if (data[i].ItemStatus == "Close" || data[i].ItemStatus == "Inactive") {
//                        $("#itemleft" + i).html('')
//                        jQuery("#txtquote" + i).attr("disabled", true)
//                        jQuery("#itembtn" + i).attr("disabled", true)

//                    }
//                    else {
//                        jQuery("#lblbidduration").text(data[0].BidDuration);
//                        $("#itemleft" + i).html(data[i].ItemTimeLeft)
//                        jQuery("#txtquote" + i).attr("disabled", false)
//                        jQuery("#itembtn" + i).attr("disabled", false)
//                    }
//                    jQuery("#lblbidduration").text(data[0].BidDuration);
//                    //alert(data[i].ItemTimeLeft)
//                    display = document.querySelector('#lblTimeLeft');
//                    startTimer(data[i].TimeLeft, display);

//                    $("#iqquote" + i).html(data[i].IQQuotedPrice == '0' ? '' : thousands_separators(data[i].IQQuotedPrice))
//                    $("#lastQuote" + i).html(data[i].LQQuotedPrice == '0' ? '' : thousands_separators(data[i].LQQuotedPrice))
//                    $("#lblstatus" + i).html(thousands_separators(data[i].LOQuotedPrice))
//                    $("#L1Price" + i).html(thousands_separators(data[i].L1Quote))
//                    if (data[i].MaskL1Price == 'N') {
//                        $("#L1Price" + i).html('Not Disclosed');
//                    }
//                    if (data[i].LOQuotedPrice == 'L1') {
//                        jQuery('#lblstatus' + i).css('color', 'Blue');
//                    }
//                    else {

//                        jQuery('#lblstatus' + i).css('color', 'Red');

//                    }




//                }
//            }

//        }
//    });

//}