﻿jQuery(document).ready(function () {
    jQuery("#btnsumbit").click(function () {
        dynamiccontrolvalidation();
    });
});

$('#txtUI,txtPanNo,#txtTINNo').maxlength({
    limitReachedClass: "label label-danger",
    alwaysShow: true
});
var FormValidation = function () {
    var ValidateParticipants = function () {
        var form1 = $('#entryForm');
        var error1 = $('.alert-danger', form1);
        var success1 = $('.alert-success', form1);

        form1.validate({
            errorElement: 'span',
            errorClass: 'help-block',
            focusInvalid: false,
            ignore: "",

            rules: {
                txtAddress: {
                    required: true
                },
                ParticipantName: {
                    required: true
                },
                ContactName: {
                    required: true
                },
                txtCity: {
                    required: true
                },
                txtPanNo: {
                    required: true
                },
                txtTINNo: {
                    required: true
                },
                txtPhoneNo: {
                    required: true,
                    maxlength: 50

                },
                txtMobileNo: {
                    required: true,
                    number:true,
                    maxlength: 50,
                },
                txtcompanyemail: {
                    required: true,
                    email: true
                },
               
                txteMailID: {
                    required: true
                },
                txtAlternateeMailID: {
                    required: true
                }
            },
            messages: {
                txtAddress: {
                    required: "Please enter company name"
                },
                ParticipantName: {
                    required: "Please enter the address"
                },
                txtCity: {
                    required: "Please enter city name"
                },
                txtPanNo: {
                    required: "Please enter pan no"
                },
                txtTINNo: {
                    required: "Please enter gst no"
                },
                txtPhoneNo: {
                    required: "Please enter phone no"
                },
                txtMobileNo: {
                    required: "Please enter mobile no"
                },
                txtcompanyemail: {
                    required: "Please enter company e-mail"
                },
                ContactName: {
                    required: "Please enter contact person name"
                }
                //txtContactPerson: {
                //    required: "Please enter contact person name"
                //},
                //txteMailID: {
                //    required: "Please enter the email id"
                //},
                //txtAlternateeMailID: {
                //    required: "Please enter the alternate Email Id"
                //}
            },

            invalidHandler: function (event, validator) { //display error alert on form submit              
                success1.hide();
               // error1.show();
                App.scrollTo(error1, -300);
            },

            highlight: function (element) { // hightlight error inputs
                $(element)
                        .closest('.form-group').addClass('has-error'); // set error class to the control group
              
            },

            unhighlight: function (element) { // revert the change done by hightlight
                $(element)
                        .closest('.form-group').removeClass('has-error'); // set error class to the control group

                
            },

            success: function (label) {
                label
                        .closest('.form-group').removeClass('has-error'); // set success class to the control group
               
            },

            submitHandler: function (form) {
                //var state = dynamiccontrolvalidation();
                var flag = "T";
               
               
                if (validateVendorCategory() == 'false') {
                    jQuery('#divalerterr').html('Please select at least one Group')
                    jQuery('#divalerterr').slideDown('show');
                    App.scrollTo(jQuery('#divalerterr'), -200);
                    setTimeout(function () {

                        jQuery('#divalerterr').css('display', 'none');
                    }, 5000);
                }
                else {//if (state == "True" && flag=="T") {
                   
                    if ($('#hdnFlagType').val() == "Extend") {
                        ExtendParticipants();
                    }
                    else {
                        RegisterParticipants();
                    }
                   
                } 
               
                App.scrollTo(error1, -100);
            }
        });



    }


    var handleWysihtml5 = function () {
        if (!jQuery().wysihtml5) {
            return;
        }
        if ($('.wysihtml5').size() > 0) {
            $('.wysihtml5').wysihtml5({
                "stylesheets": ["assets/plugins/bootstrap-wysihtml5/wysiwyg-color.css"]
            });
        }
    }

    return {
        init: function () {
            handleWysihtml5();
            ValidateParticipants();
        }
    };

} ();


function RegisterParticipants() {
    var status = "";
    if (jQuery('#chkIsActiveparticipant').is(':checked') == true) {
        status = 'Y';
    }
    else {
        status = 'N';
    }
    var RegisterParticipants = {
        "CustomerID": sessionStorage.getItem('CustomerID'),
        "ParticipantID": jQuery("#hdnParticipantID").val(),
        "ParticipantName": jQuery("#ParticipantName").val(),
        "Address": jQuery("#txtAddress").val(),
        "City": jQuery("#txtCity").val(),
        "PanNo": jQuery("#txtPanNo").val(),
        "TinNo": jQuery("#txtTINNo").val(),
        "PhoneNo": jQuery("#txtPhoneNo").val(),
        "CompanyEmail": jQuery("#txtcompanyemail").val().trim().toLowerCase(),
        "IsActive": status,
        "UserID": sessionStorage.getItem('UserID'),
        "MobileNo": jQuery("#txtMobileNo").val(),
        "ActionType": $('#hdnFlagType').val(),
        "ContactPerson": $('#ContactName').val()

       // "BidtypesDecription": BidtypesDecription()
    };
  //alert(JSON.stringify(RegisterParticipants))
    jQuery.ajax({
       // url: sessionStorage.getItem("APIPath") + "RegisterParticipants/RegisterParticpants/",
        url: sessionStorage.getItem("APIPath") + "RegisterParticipants/RegParticpants_PEV2/",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "POST",
        data: JSON.stringify(RegisterParticipants),
        contentType: "application/json; charset=utf-8",
        success: function(data, status, jqXHR) {
           // alert(data[0].IsSuccess)
            $("#hdnParticipantID").val(data[0].ParticipantID)
            $("#hdnParticipantCode").val(data[0].VendorCode)

            if (data[0].IsSuccess == '1') {
               
                if ($("#hdnParticipantID").val() != '') {
                    MapVendorCategories();
                }
            }
            else if (data[0].IsSuccess == '2') {
                if ($("#hdnParticipantID").val() != '') {
                    MapVendorCategories();
                }
            }
            else {
                jQuery('#divalerterr').slideDown('show');
                App.scrollTo(jQuery('#divalerterr'), -200);
            }
            setTimeout(function() {
                jQuery('#divalertsucess').css('display', 'none');
                jQuery('#divalerterr').css('display', 'none');
            }, 5000);
            //fnfetchfoundVendors();
            fetchParticipantsVenderTable();
            //fetchParticipantsVenderForExport();
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else{
                jQuery("#error").text(xhr.d);
            }
            
            return false;
            jQuery.unblockUI();
        }
       
    });
   
}

function NotificationforExtendVendor() {
    bootbox.dialog({
        message: "Vendor is already Exists, Do you want to Extend for Your Company.",
        buttons: {
            confirm: {
                label: "Yes",
                className: "btn-success",
                callback: function () {
                    ExtendVendor('submit')
                }
            },
            cancel: {
                label: "No",
                className: "btn-default",
                callback: function () {
                    return;
                }
            }
        }
    });

}
///Createjosnobj//
function BidtypesDecription() {
    var bidtypes = {};
    var bidtype = []
    bidtypes.bidtype = bidtype;


    jQuery('div#divisactive div#divbidtypecontend').each(function() {
        if ($(this).find('span[id=spanchecked]').attr('class') == 'checked') {          

            bidtypes.bidtype.push({ "BidTypeID": $(this).find('input[type=hidden]').val(), "ContactPerson": $(this).find('div').eq(4).find('input[type=text]').val(), "PhoneNo": $(this).find('div').eq(5).find('input[type=text]').val(), "EmailID": $(this).find('div').eq(6).find('input[type=text]').val().trim().toLowerCase(), "AlternateEmailID": $(this).find('div').eq(7).find('input[type=text]').val().trim().toLowerCase() });
            //return JSON.stringify(bidtypes);	
        }
        //else {
        //    bidtypes.bidtype.push({ 'Print': '1' });
        //    //return JSON.stringify(bidtypes);
        //}

    });
	
	
	
	return JSON.stringify(bidtypes);
	
	
	
	
	
    
}


function validateDuplicateEmailId(elem) {
    if (elem.value == $("#txtcompanyemail").val()) {
        jQuery('#divalerterr').html('Comapny email id should be different from email id used in forward/reverse auction.')
        jQuery('#divalerterr').slideDown('show');
        App.scrollTo(jQuery('#divalerterr'), -200);
        elem.value = '';
        setTimeout(function () {

            jQuery('#divalerterr').css('display', 'none');
        }, 3000);
    }
}

function Validate(ctrl) {
    if (jQuery(ctrl).is(':checked') == true) {
        jQuery(ctrl).closest('div#divbidtypecontend').find('span[id=spanchecked]').attr('class','checked');
        //jQuery(ctrl).closest('div#divbidtypecontend').find('input[type=text]').eq(0).appendafter("<span class=\"help-block\">Please enter company e-mail</span>");
        jQuery(ctrl).closest('div#divbidtypecontend').find('input[type=text]').eq(0).prop("disabled", false);
        jQuery(ctrl).closest('div#divbidtypecontend').find('input[type=text]').eq(1).prop("disabled", false);
        jQuery(ctrl).closest('div#divbidtypecontend').find('input[type=text]').eq(2).prop("disabled", false);
        jQuery(ctrl).closest('div#divbidtypecontend').find('input[type=text]').eq(3).prop("disabled", false);
    }
    else {
        jQuery(ctrl).closest('div#divbidtypecontend').find('span[id=spanchecked]').attr('class', '');
        jQuery(ctrl).closest('div#divbidtypecontend').find('input[type=text]').eq(0).prop("disabled", true);
        jQuery(ctrl).closest('div#divbidtypecontend').find('input[type=text]').eq(1).prop("disabled", true);
        jQuery(ctrl).closest('div#divbidtypecontend').find('input[type=text]').eq(2).prop("disabled", true);
        jQuery(ctrl).closest('div#divbidtypecontend').find('input[type=text]').eq(3).prop("disabled", true);
    }

}

function validateVendorGroup(ctrl,categoryId) {
    if (jQuery(ctrl).is(':checked') == true) {
        //jQuery(ctrl).closest('div#divbidtypecontend').find('span[id=spanchecked]').attr('class', 'checked');
        jQuery(ctrl).closest('div#uniform-chkbidTypes').find('span#spancheckedvendorgroup').attr('class', 'checked');        

    } else {
        jQuery(ctrl).closest('div#uniform-chkbidTypes').find('span#spancheckedvendorgroup').attr('class', '');
    }
    

}

function fetchParticipantsVenderTable() {
   
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "RegisterParticipants/fetchParticipantsVender_PEV2/?CustomerID=" + sessionStorage.getItem("CustomerID") + "&CreatedBy=" + encodeURIComponent(sessionStorage.getItem('UserID')),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function(Venderdata) {
            jQuery("#tblParticipantsVender > tbody").empty();
            if (Venderdata.length > 0) {
                vendorsForAutoComplete = Venderdata;
                jQuery.each(Venderdata, function (key, value) {
                    var str = "";

                   // var addr1 = (value.Address).replace(/[^A-Za-z0-9$ ]/g, "");
                   var  addr1 = (value.Address).replace(/\n/g, " ");
                   // var addr2 = (value.City).replace(/[^A-Za-z0-9$ ]/g, "");
                    var addr2 = (value.City).replace(/\n/g, " ");
                    if (value.MapBtnRequired == 'N') {
                        str = "<tr><td style=\"text-align:center;width:10%!important;\">";
                        if (sessionStorage.getItem('UserID') == value.CreatedBy) {

                           if (value.ActionType == "EditVendor") {
                               str += "<a href=\"#\"   onclick =\"EditVendor(\'" + value.ParticipantID + "'\,\'" + value.ParticipantName + "'\,\'" + value.ContactPerson + "'\,\'" + value.CompanyEmail + "'\,\'" + value.PhoneNo + "'\,\'" + value.MobileNo + "'\,\'" + addr1 + "'\,\'" + addr2 + "'\,\'" + value.TinNo + "'\,\'" + value.IsActive + "'\,\'" + value.PanNo + "'\,\'" + value.ActionType + "'\,\'" + value.VendorCode + "'\)\" class=\"btn btn-xs purple\"><i class=\"fa fa-edit\"></i>Edit</a></td>";
                               str += "<td style=\"width:10%!important;\">" + value.CreatedByName + "</td>";
                               str += "<td style=\"width:10%!important;\">No</td>";
                              // $('#lbl_panmsz').addClass('hide')
                           }
                           else {
                               str += "<a href=\"#\"   onclick =\"EditVendor(\'" + value.ParticipantID + "'\,\'" + value.ParticipantName + "'\,\'" + value.ContactPerson + "'\,\'" + value.CompanyEmail + "'\,\'" + value.PhoneNo + "'\,\'" + value.MobileNo + "'\,\'" + addr1 + "'\,\'" + addr2 + "'\,\'" + value.TinNo + "'\,\'" + value.IsActive + "'\,\'" + value.PanNo + "'\,\'" + value.ActionType + "'\,\'" + value.VendorCode + "'\)\" class=\"btn btn-xs yellow\"><i class=\"fa fa-edit\"></i>Edit</a></td>";
                               str += "<td style=\"width:10%!important;\">" + value.CreatedByName + "</td>";
                               str += "<td style=\"width:10%!important;\">Yes</td>";
                               //$('#lbl_panmsz').removeClass('hide')
                            }

                            
                        
                       }
                       else {
                           if (value.ActionType == "EditVendor") {
                               str += "<a href=\"#\"   class=\"btn btn-xs grey\">Not Editable</a>&nbsp;&nbsp;";
                               str += "<td style=\"width:10%!important;\">" + value.CreatedByName +"</td>";
                               str += "<td style=\"width:10%!important;\">No</td>";
                              // $('#lbl_panmsz').addClass('hide')
                           }
                           else {
                               str += "<a href=\"#\"   onclick =\"EditVendor(\'" + value.ParticipantID + "'\,\'" + value.ParticipantName + "'\,\'" + value.ContactPerson + "'\,\'" + value.CompanyEmail + "'\,\'" + value.PhoneNo + "'\,\'" + value.MobileNo + "'\,\'" + addr1 + "'\,\'" + addr2 + "'\,\'" + value.TinNo + "'\,\'" + value.IsActive + "'\,\'" + value.PanNo + "'\,\'" + value.ActionType + "'\,\'" + value.VendorCode + "'\)\" class=\"btn btn-xs yellow\"><i class=\"fa fa-edit\"></i>Edit</a></td>";
                               str += "<td style=\"width:10%!important;\">External</td>";
                               str += "<td style=\"width:10%!important;\">Yes</td>";
                              // $('#lbl_panmsz').removeClass('hide')
                           }
                       }
                    }
                    else if (value.MapBtnRequired == 'Y') {
                        str= "<tr><td style=\"text-align:right;width:10%!important;\">";
                        str += "<a href=\"javascript:;\"  onclick=\"MapCategory(this)\" class=\"btn btn-xs green\"><i class=\"fa fa-edit\"></i>Map</a><a href=\"#\" href=\"#\"  onclick=\"EditProduct(this)\" class=\"btn btn-xs purple\"><i class=\"fa fa-edit\"></i>Edit</a></td>";
                    }
                    str += "<td style=\"display:none;\">" + value.ParticipantID + "</td><td style=\"width:10%!important;\">" + value.ParticipantName + "</td><td style=\"width:10%!important;\">" + value.ContactPerson + "</td><td style=\"width:10%!important;\">" + value.Address + "</td><td style=\"width:5%!important;\">" + value.City + "</td><td style=\"width:10%!important;\">" + value.PanNo.toUpperCase() + "</td><td style=\"width:10%!important;\">" + value.TinNo.toUpperCase() + "</td><td style=\"width:20%!important;\">" + value.MobileNo + "</td><td style=\"width:20%!important;\">" + value.PhoneNo + "</td><td style=\"width:10%!important;\">" + value.CompanyEmail + "</td>";
                    str += "<td style=\"width:5%!important;\">" + value.IsActive + "</td>";

                    
                    //str += "<a href=\"#\" onclick=\"DeleteProduct(this)\" class=\"btn default btn-xs black\"><i class=\"fa fa-trash-o\"></i>Delete</a>";
                    str += "</td></tr>";
                    jQuery('#tblParticipantsVender > tbody').append(str);
                });
            }
            else {
                jQuery('#tblParticipantsVender > tbody').append("<tr><td colspan='12' style='text-align: center; color:red;'>No Participant found</td></tr>");
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            
            return false;
            jQuery.unblockUI();
        }
    });
}
function fetchParticipantsVenderForExport() {

    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "RegisterParticipants/fetchParticipantsVenderForExport/?CustomerID=" + sessionStorage.getItem("CustomerID") + "&CreatedBy=" + encodeURIComponent(sessionStorage.getItem("UserID")),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function(Venderdata) {

            jQuery("#tblParticipantsExport").empty();
            if (Venderdata.length > 0) {
                var VendorID = 0;
               // $('#btnExport').show();
                for (var j = 0; j < Venderdata.length; j++) {
                    if (VendorID != Venderdata[j].ParticipantID) {
                        jQuery('<thead><tr style="font-weight: bold; color: rgb(60, 118, 61); background-color: rgb(223, 240, 216);"><td colspan=5>' + Venderdata[j].ParticipantName + ', ' + Venderdata[j].Address + ', ' + Venderdata[j].City + '</td></thead>').appendTo('#tblParticipantsExport')
                        VendorID = Venderdata[j].ParticipantID
                        jQuery('<thead><tr><th>Bid Type</th><th>Contact Person</th><th>Mobile</th><th>Email</th><th>Alternate email</th></thead>').appendTo('#tblParticipantsExport')
                        for (var i = 0; i < Venderdata.length; i++) {
                            if (VendorID == Venderdata[i].ParticipantID) {
                                
                                if ((Venderdata[i].BidtypesDecription != '') && (Venderdata[i].BidTypeID != '0')) {
                                    jQuery('<tbody><tr><td>' + Venderdata[i].BidtypesDecription + '</td><td> ' + Venderdata[i].ContactPersonName + '</td><td> ' + Venderdata[i].ContactPersonPhoneNo + '</td><td> ' + Venderdata[i].ContactPersonEmailID + '</td><td> ' + Venderdata[i].ContactPersonAlternateEmailID + '</td></tbody>').appendTo('#tblParticipantsExport');
                                }

                                else {
                                    jQuery('<tbody><tr><td colspan=5 style="color: red; text-align: center;">No user mapped for bid type.</td></tbody>').appendTo('#tblParticipantsExport');
                                }
                            }
                        }
                    }
                }





            }
            else {
                $('#btnExport').hide();
                jQuery('#tblParticipantsExport > tbody').append("<tr><td colspan='5' style='text-align: center; color:red;'>No Participant found</td></tr>");
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            
            return false;
            jQuery.unblockUI();
        }
    });
}

var tableToExcel = (function() {
    var uri = 'data:application/vnd.ms-excel;base64,'
      , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>'
      , base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
      , format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
    return function(table, name, filename) {
        if (!table.nodeType) table = document.getElementById(table)
        var ctx = { worksheet: name || 'Worksheet', table: table.innerHTML }
        document.getElementById("dlink").href = uri + base64(format(template, ctx));
        document.getElementById("dlink").download = filename;
        document.getElementById("dlink").click();
    }
})()


function EditProduct(ctrl) {
    clearform()
    jQuery("#ParticipantName").val(jQuery(ctrl).closest('tr').find("td").eq(3).html());
    jQuery("#ContactName").val(jQuery(ctrl).closest('tr').find("td").eq(4).html());
    jQuery("#ParticipantName").closest('.form-group').removeClass('has-error')//.find('span').hide()
    jQuery("#txtAddress").val(jQuery(ctrl).closest('tr').find("td").eq(5).text());
    jQuery("#txtAddress").closest('.form-group').removeClass('has-error')//.find('span').hide()
    jQuery("#txtCity").val(jQuery(ctrl).closest('tr').find("td").eq(6).html());
    jQuery("#txtCity").closest('.form-group').removeClass('has-error')//.find('span').hide()
    jQuery("#txtPanNo").val(jQuery(ctrl).closest('tr').find("td").eq(7).html());
    jQuery("#txtPanNo").closest('.form-group').removeClass('has-error')//.find('span').hide()
    jQuery("#txtTINNo").val(jQuery(ctrl).closest('tr').find("td").eq(8).html());
    jQuery("#txtTINNo").closest('.form-group').removeClass('has-error')//.find('span').hide()
    jQuery("#txtPhoneNo").val(jQuery(ctrl).closest('tr').find("td").eq(9).html());
    jQuery("#txtPhoneNo").closest('.form-group').removeClass('has-error')//.find('span').hide()
    jQuery("#txtcompanyemail").val(jQuery(ctrl).closest('tr').find("td").eq(10).html());
    jQuery("#txtcompanyemail").closest('.form-group').removeClass('has-error')//.find('span').hide()
    var VendorID = jQuery(ctrl).closest('tr').find("td").eq(2).html();
    $('#hdnParticipantID').val(VendorID);
    
    fetchMapCategory('Z', VendorID);

    
}


var vendorsForAutoComplete;
function fetchMapCategory(categoryFor, vendorId) {
    
    //var VendorID = jQuery(ctrl).closest('tr').find("td").eq(0).html();
    //$('#hdnParticipantIDForCategoryMap').val(VendorID);
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ProductandServiceCategory/fetchProductCategory/?CustomerID=" + sessionStorage.getItem('CustomerID') + "&For=" + categoryFor + "&MappedBy=" + encodeURIComponent(sessionStorage.getItem('UserID')) + "&VendorID=" + vendorId,
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        data: "{}",
        cache: false,
        dataType: "json",
        success: function (data) {
            //jQuery('#icon').html('<i class="fa fa-list-ul"></i>');
            jQuery("#tblCategoryMaster").empty();
           // $("#CategoryModal").modal("show");
            var count = 3;
            var str = '';
            if (data.length > 0) {   
                CategoryForAutoComplete = data;
                for (var i = 0; i < data.length; i++) {                    
                    if (data[i].Checked == 'Y') {
                        str += '<tr><td><div class=\"checker\" id=\"uniform-chkbidTypes\"><span class="checked"  id=\"spancheckedvendorgroup\"><input class=\"childchkbox\" type=\"checkbox\" style=\"cursor:pointer\"  onchange=\"validateVendorGroup(this, ' + data[i].CategoryID + ')\" value=\'' + data[i].CategoryID + '\' checked /></span></div></td><td>' + data[i].CategoryName + '</td></tr>';
                    } else {
                        str += '<tr><td><div class=\"checker\" id=\"uniform-chkbidTypes\"><span  id=\"spancheckedvendorgroup\"><input class=\"childchkbox\" type=\"checkbox\" style=\"cursor:pointer\"  onchange=\"validateVendorGroup(this,' + data[i].CategoryID + ')\" value=\'' + data[i].CategoryID + '\'  /></span></div></td><td>' + data[i].CategoryName + '</td></tr>';
                    }
                }                
                jQuery("#tblCategoryMaster").append(str);
            }
            else {
                jQuery("#tblCategoryMaster").append('<tr><td>No Information is there..</td></tr>');
            }
            jQuery.unblockUI();
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else{
                alert("error");
            }
            return false;
            jQuery.unblockUI();
        }
        
    });
}
var CategoryForAutoComplete;
sessionStorage.setItem('hdnCategoryGrpID',0);
jQuery("#txtsearchcat").typeahead({
    source: function (query, process) {
        var data = CategoryForAutoComplete
        usernames = [];
        map = {};
        var username = "";
        jQuery.each(data, function (i, username) {
            map[username.CategoryName] = username;
            usernames.push(username.CategoryName);
        });

        process(usernames);

    },
    minLength: 2,
    updater: function (item) {
        if (map[item].CategoryID != "0") {
            sessionStorage.setItem('hdnCategoryGrpID', map[item].CategoryID);
           // getCategoryWiseVendors(map[item].CategoryID);
        }
        else {
            gritternotification('Please select Group Category  properly!!!');
        }

        return item;
    }

});
sessionStorage.setItem('hdnVendorID', 0);

jQuery("#txtsearchvendor").typeahead({
    source: function (query, process) {
        var data = vendorsForAutoComplete
        usernames = [];
        map = {};
        var username = "";
        jQuery.each(data, function (i, username) {
            map[username.ParticipantName] = username;
            usernames.push(username.ParticipantName);
        });

        process(usernames);

    },
    minLength: 2,
    updater: function (item) {
        if (map[item].ParticipantID != "0") {
            sessionStorage.setItem('hdnVendorID', map[item].ParticipantID);

        }
        else {
            gritternotification('Please select Vendor  properly!!!');
        }

        return item;
    }

});
function fnfetchCatVendors() {
   // alert(sessionStorage.getItem("APIPath") + "RegisterParticipants/fetchCategoryVendorForAdvSearch/?CategoryID=" + sessionStorage.getItem("hdnCategoryGrpID") + "&VendorID=" + sessionStorage.getItem('hdnVendorID') + "&CustomerID=" + sessionStorage.getItem('CustomerID'))
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "RegisterParticipants/fetchCategoryVendorForAdvSearch_PEV2/?CategoryID=" + sessionStorage.getItem("hdnCategoryGrpID") + "&VendorID=" + sessionStorage.getItem('hdnVendorID') + "&CustomerID=" + sessionStorage.getItem('CustomerID'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data) {
            $('#div_table').removeClass('hide');
            $('#tbldetails').empty();
            if (data.length) {
                $('#tbldetails').append("<thead><tr><th>Vendor Code</th><th>Category</th><th>Vendor</th><th>Mobile</th><th>EmailID</th></tr></thead><tbody>")
                for (var i = 0; i < data.length; i++) {
                    $('#tbldetails').append("<tr><td>" + data[i].VendorCode + "</td><td>" + data[i].CategoryName + "</td><td>" + data[i].VendorName + "</td><td>" + data[i].MobileNo + "</td><td>" + data[i].EmailID +"</td></tr>");
                }
            }
            else{
                jQuery('#divalerterrsearch').slideDown('show');
                $('#spanerterrserach').text('No data found')
                $('#div_table').addClass('hide');
                App.scrollTo(jQuery('#divalerterrsearch'), -200);
                return false;
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else{
                jQuery('#divalerterrsearch').slideDown('show');
                $('#div_table').addClass('hide');
                $('#spanerterrserach').text('You have error .Please try again')
                App.scrollTo(jQuery('#divalerterrsearch'), -200);
            }
            return false;
            jQuery.unblockUI();
        }
       
    })
   
    setTimeout(function () {
        jQuery('#divalerterrsearch').css('display', 'none');
    }, 5000);
    clearsearchmodal();
}
$('#Advancesearch').on("hidden.bs.modal", function () {
    clearsearchmodal();
    $('#div_table').addClass('hide');
})
function clearsearchmodal() {
    sessionStorage.setItem('hdnCategoryGrpID', 0);
    sessionStorage.setItem('hdnVendorID', 0);
    jQuery("#txtsearchvendor").val('');
    jQuery("#txtsearchcat").val('');
}

jQuery("#txtSearchalldetails").keyup(function () {

    jQuery("#tbldetails tr:has(td)").hide(); // Hide all the rows.

    var iCounter = 0;
    var sSearchTerm = jQuery('#txtSearchalldetails').val(); //Get the search box value

    if (sSearchTerm.length == 0) //if nothing is entered then show all the rows.
    {
        jQuery("#tbldetails tr:has(td)").show();
        return false;
    }

    //Iterate through all the td.
    jQuery("#tbldetails tr:has(td)").children().each(function () {

        var cellText = jQuery(this).text().toLowerCase();
        if (cellText.indexOf(sSearchTerm.toLowerCase()) >= 0) //Check if data matches
        {

            jQuery(this).parent().show();
            iCounter++;

            return true;
        }

    });
});


$('div#divisactive').on('change', '.has-error', function () {
    if ($(this).find('input[type=text]').val() == '') {
        $(this).find('span').show();
        $(this).addClass('has-error');
    }
    else {
        $(this).find('span').hide();
        $(this).removeClass('has-error');
    }
});
function ValidateVendor() {
    var chkstatus = "false";
    var i = 0;
   // $('#div#divisactive #divbidtypecontend').find('span#spandynamic').hide();

    $('div#divbidtypecontend').each(function (index) {
        
        if ($(this).find("span#spanchecked").attr('class') == 'checked') {
            chkstatus = 'True';
            
        }

    });

   return chkstatus;
   
}

function validateVendorCategory() {
    var chkstatus = "false";
    var i = 0;
    

    $("#tblCategoryMaster> tbody > tr").each(function (index) {

        if ($(this).find("span#spancheckedvendorgroup").attr('class') == 'checked') {
            //i = i + 1;
            //if (i = 1) {

            //    chkstatus = "True";
            //}
            //else {
            //    chkstatus == "false";
            //}
            chkstatus = 'true';
        }

    });

    return chkstatus;
   
}

function dynamiccontrolvalidation() {
    var status = "True";
    
//  var evement = "";
//    jQuery('div#divisactive #divbidtypecontend ').each(function () {
//       
//        $(this).find('span#spandynamic').hide();
//        if ($(this).find('input[type=checkbox]').is(':checked') == true) {
//            if ($(this).find('div').eq(4).find('input[type=text]').val() == "") {
//                evement = "<span id=\"spandynamic\" style=\"color:#b94a48\">Please enter contact person name<span>";
//                $(this).find('div').eq(4).find('input[type=text]').closest('div').addClass('has-error').append(evement)
//                status= "False";
//            }
//            if ($(this).find('div').eq(5).find('input[type=text]').val() == "") {
//                evement = "<span id=\"spandynamic\" style=\"color:#b94a48\">Please enter mobile no<span>";
//                $(this).find('div').eq(5).find('input[type=text]').closest('div').addClass('has-error').append(evement);
//                status = "False";
//            }
//            if ($(this).find('div').eq(6).find('input[type=text]').val() == "") {
//                evement = "<span id=\"spandynamic\" style=\"color:#b94a48\">Please enter email id<span>";
//                $(this).find('div').eq(6).find('input[type=text]').closest('div').addClass('has-error').append(evement);
//                status = "False";
//            }
//            if ($(this).find('div').eq(7).find('input[type=text]').val() == "") {
//                evement = "<span id=\"spandynamic\" style=\"color:#b94a48\">Please enter alternate email<span>";
//                $(this).find('div').eq(7).find('input[type=text]').closest('div').addClass('has-error').append(evement);
//                status = "False";
//            }
//            
//           
//        }
//        
//    });
    return status;
}

jQuery("#txtSearch").keyup(function () {
    _this = this;
    // Show only matching TR, hide rest of them
    jQuery.each($("#tblParticipantsVender tbody").find("tr"), function () {
        console.log($(this).text());
        if (jQuery(this).text().toLowerCase().indexOf(jQuery(_this).val().toLowerCase()) == -1)
            jQuery(this).hide();
        else
            jQuery(this).show();
    });
});
function MapVendorCategories() {

    var InsertQuery = '';
    var UserID  = sessionStorage.getItem('UserID');
    
    $('.childchkbox').each(function() {
        if (this.checked) {
            InsertQuery = InsertQuery + "select " + $(this).val() + "," + $("#hdnParticipantID").val() + "," + sessionStorage.getItem('CustomerID') + ",dbo.Decrypt('" + UserID + "'),getdate() union all ";
        }
        else {
            InsertQuery = InsertQuery;
        }
    });

    if (InsertQuery != '') {
        InsertQuery = 'Insert into VendorCategoryTypeMapping(CategoryID,VendorID,CustomerID,MappedBy,MappedOn)' + InsertQuery;
        InsertQuery = InsertQuery.substring(0, InsertQuery.length - 11);
    } else {
        jQuery('#divalerterr').find('span').html('Please select atleast one group!');
        jQuery('#divalerterr').slideDown('show');
        App.scrollTo(jQuery('#divalerterr'), -200);
        return false;
        setTimeout(function() {
            jQuery('#divalerterr').css('display', 'none');
        }, 5000);
    }


    var MapParticipants = {
        "CustomerID":sessionStorage.getItem('CustomerID'),
        "InsertQuery": InsertQuery,
        "UserID": sessionStorage.getItem('UserID'),
        "VendorID": parseInt($("#hdnParticipantID").val())
        
    };
    //alert(JSON.stringify(MapParticipants))
    jQuery.ajax({
        url: sessionStorage.getItem("APIPath") + "RegisterParticipants/MapParticpantsCategory/",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "POST",
        data: JSON.stringify(MapParticipants),
        contentType: "application/json; charset=utf-8",
        success: function(data, status, jqXHR) {
          //  alert(data[0].OutMsg)
        if (data[0].OutMsg == '1') {
            jQuery('#divalertsucess').slideDown('show');
            App.scrollTo(jQuery('#divalertsucess'), -200);
            fetchParticipantsVenderTable();
            clearform();

            }
            else {

                jQuery('#divalerterr').slideDown('show');
                App.scrollTo(jQuery('#divalerterr'), -200);


            }
            setTimeout(function() {
                jQuery('#divalertsucess').css('display', 'none');
                jQuery('#divalerterr').css('display', 'none');
              
            }, 5000);
            
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else{
                jQuery("#error").text(xhr.d);
            }
            return false;
            jQuery.unblockUI();
        }
        
    });
}

jQuery("#txtSearchCategory").keyup(function () {

    jQuery("#tblCategoryMaster tr:has(td)").hide(); // Hide all the rows.

    var iCounter = 0;
    var sSearchTerm = jQuery('#txtSearchCategory').val(); //Get the search box value

    if (sSearchTerm.length == 0) //if nothing is entered then show all the rows.
    {
        jQuery("#tblCategoryMaster tr:has(td)").show();
        return false;
    }

    //Iterate through all the td.
    jQuery("#tblCategoryMaster tr:has(td)").children().each(function () {

        var cellText = jQuery(this).text().toLowerCase();
        if (cellText.indexOf(sSearchTerm.toLowerCase()) >= 0) //Check if data matches
        {

            jQuery(this).parent().show();
            iCounter++;

            return true;
        }

    });
});

jQuery("#ParticipantName").typeahead({
    source: function (query, process) {
        var data = vendorsForAutoComplete
        usernames = [];
        map = {};
        var username = "";
        jQuery.each(data, function (i, username) {
            map[username.ParticipantName] = username;
            usernames.push(username.ParticipantName);
        });

        process(usernames);

    },
    minLength: 2,
    updater: function (item) {
        if (map[item].ParticipantID != "0") {
            
            jQuery('#divalerterr').find('span').html('Vendor already exist.');
            jQuery('#divalerterr').slideDown('show');
            App.scrollTo(jQuery('#divalerterr'), -200);            
            setTimeout(function () {
                $("#ParticipantName").val('');
                jQuery('#divalerterr').css('display', 'none');
            },4000);
            
                       
        }
        else {
            gritternotification('Please select Vendor  properly!!!');
        }

        return item;
    }

});

function validatePanNumber(pan) {

    //let pannumber = $(pan).val();
    //var regex = /[a-zA-z]{5}\d{4}[a-zA-Z]{1}/;

    //if (pannumber.match(regex)) {
            
        fnfetchfoundVendors();
  //  }
  //else {
  //      jQuery('#divalerterr').slideDown('show');
  //      $('#div_tableVendor').addClass('hide');
  //      $('#spanerterr').text('Invalid PAN number')
  //      App.scrollTo(jQuery('#divalerterr'), -200);
  //      setTimeout(function () {

  //          jQuery('#divalerterr').css('display', 'none');
  //      }, 2000);
  //      return false;
  //  }

}
function fnfetchfoundVendors() {
   
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "RegisterParticipants/GetVendors/?FieldName=" + $('#ddlUI').val() + "&FieldValue=" + $('#txtUI').val() + "&UserID=" + encodeURIComponent(sessionStorage.getItem('UserID')) + "&CustomerID=" + sessionStorage.getItem('CustomerID'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data) {
            if ($('#txtUI').val().length == "15") {
                $('#divVendorForm').removeClass('hide')
                $('#div_tableVendor').removeClass('hide');
            }

            $('#tblVendorFoundDetails').empty();
            var addr1 = "";
            var addr2 = "";
            if (data.length>0) {
                $('#tblVendorFoundDetails').append("<thead><tr><th>VendorCode</th><th>Vendor</th><th>Contact Person</th><th>Mobile</th><th>EmailID</th><th></th></tr></thead><tbody>")
                for (var i = 0; i < data.length; i++) {
                    //if (sessionStorage.getItem('UserID') == data[i].EncryptedVendorCreatedBy) {
                    
                   // addr1 = data[i].Address1.replace(/[^A-Za-z0-9$ ]/g, "");
                    addr1 = data[i].Address1.replace(/\n/g, " ");
                   // addr2 = data[i].Address2.replace(/[^A-Za-z0-9$ ]/g, "");
                    addr2 = data[i].Address2.replace(/\n/g, " ");
                   
                    if (data[i].ButtonName == "Extend") {
                        $('#tblVendorFoundDetails').append("<tr><td>" + data[i].VendorCode + "</td><td>" + data[i].VendorName + "</td><td>" + data[i].ContactPerson + "</td><td>" + data[i].MobileNo + "</td><td>" + data[i].EmailID + "</td><td><a href=\"#\"   onclick=\"ExtendVendor(\'" + data[i].VendorID + "'\,\'" + data[i].VendorName + "'\,\'" + data[i].ContactPerson + "'\,\'" + data[i].EmailID + "'\,\'" + data[i].Phone + "'\,\'" + data[i].MobileNo + "'\,\'" + addr1 + "'\,\'" + addr2 + "'\,\'" + data[i].ServiceTaxNo.toUpperCase() + "'\,\'" + data[i].isActive + "'\,\'" + data[i].PanNo.toUpperCase() + "'\,\'" + data[i].ButtonName + "'\,\'" + data[i].VendorCode + "'\)\" class=\"btn btn-xs yellow\"><i class=\"fa fa-edit\"></i>Extend</a>&nbsp;<a href=\"#\"   onclick=\"AddVendor(\'" + data[i].VendorID + "'\,\'" + data[i].VendorName + "'\,\'" + data[i].ContactPerson + "'\,\'" + data[i].EmailID + "'\,\'" + data[i].Phone + "'\,\'" + data[i].MobileNo + "'\,\'" + addr1 + "'\,\'" + addr2 + "'\,\'" + data[i].ServiceTaxNo.toUpperCase() + "'\,\'" + data[i].isActive + "'\,\'" + data[i].PanNo.toUpperCase() + "'\,\'" + data[i].ButtonName + "'\,\'" + data[i].VendorCode + "'\)\" class=\"btn btn-xs green hide\"><i class=\"fa fa-plus\"></i>Add</a></td></tr>");
                        
                    }
                    else {
                        $('#tblVendorFoundDetails').append("<tr><td>" + data[i].VendorCode + "</td><td>" + data[i].VendorName + "</td><td>" + data[i].ContactPerson + "</td><td>" + data[i].MobileNo + "</td><td>" + data[i].EmailID + "</td><td><a href=\"#\"   onclick=\"EditVendor(\'" + data[i].VendorID + "'\,\'" + data[i].VendorName + "'\,\'" + data[i].ContactPerson + "'\,\'" + data[i].EmailID + "'\,\'" + data[i].Phone + "'\,\'" + data[i].MobileNo + "'\,\'" + addr1 + "'\,\'" + addr2 + "'\,\'" + data[i].ServiceTaxNo.toUpperCase() + "'\,\'" + data[i].isActive + "'\,\'" + data[i].PanNo.toUpperCase() + "'\,\'" + data[i].ButtonName + "'\,\'" + data[i].VendorCode + "'\)\" class=\"btn btn-xs purple\"><i class=\"fa fa-edit\"></i>Edit</a>&nbsp;<a href=\"#\"   onclick=\"AddVendor(\'" + data[i].VendorID + "'\,\'" + data[i].VendorName + "'\,\'" + data[i].ContactPerson + "'\,\'" + data[i].EmailID + "'\,\'" + data[i].Phone + "'\,\'" + data[i].MobileNo + "'\,\'" + addr1 + "'\,\'" + addr2 + "'\,\'" + data[i].ServiceTaxNo.toUpperCase() + "'\,\'" + data[i].isActive + "'\,\'" + data[i].PanNo.toUpperCase() + "'\,\'" + data[i].ButtonName + "'\,\'" + data[i].VendorCode + "'\)\" class=\"btn btn-xs green hide\"><i class=\"fa fa-plus\"></i>Add</a></td></tr>");
                       
                    }
                   
                }
            }
            else {
                
                
                if ($('#ddlUI').val() == "PanNo") {
                    $('#txtPanNo').val($('#txtUI').val().toUpperCase())
                    $('#txtPanNo').attr('disabled', 'disabled')
                }
                else {
                    var pan = $('#txtUI').val().substr(2, 10); //11
                    $('#txtPanNo').val(pan.toUpperCase());
                    $('#txtTINNo').val($('#txtUI').val().toUpperCase())
                    $('#txtPanNo').attr('disabled', 'disabled')
                    $('#txtTINNo').attr('disabled', 'disabled')
                }
                
               // $('').removeClass('hide')
               // jQuery('#divalerterrsearch').slideDown('show');
               // $('#spanerterrserach').text('No data found')
               // $('#div_tableVendor').addClass('hide');
               // App.scrollTo(jQuery('#divalerterrsearch'), -200);
                //return false;
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else{
                jQuery('#divalerterr').slideDown('show');
                $('#div_tableVendor').addClass('hide');
                $('#spanerterr').text('You have error .Please try again')
                App.scrollTo(jQuery('#divalerterr'), -200);
            }
            return false;
            jQuery.unblockUI();
        }
       
    })

    setTimeout(function () {
        jQuery('#divalerterr').css('display', 'none');
    }, 5000);
    
}
function AddVendor() {
    clearform();
    $('#divVendorForm').removeClass('hide')
    $('#ParticipantName').removeAttr('disabled')
    $('#txtAddress').removeAttr('disabled')
    $('#txtCity').removeAttr('disabled')
    $('#txtPanNo').removeAttr('disabled')
    $('#txtTINNo').removeAttr('disabled')
    $('#txtPhoneNo').removeAttr('disabled')
    $('#txtMobileNo').removeAttr('disabled')
    $('#txtcompanyemail').removeAttr('disabled')
    jQuery("#ContactName").removeAttr('disabled')
    $('#lbl_panmsz').addClass('hide')
    jQuery('#hdnParticipantID').val('0');
    if ($('#ddlUI').val() == "PanNo") {
        $('#txtPanNo').val($('#txtUI').val())
        $('#txtPanNo').attr('disabled', 'disabled')
    }
    else {
        var pan = $('#txtUI').val().substr(2, 10);//11
        $('#txtPanNo').val(pan);
        $('#txtTINNo').val($('#txtUI').val())
        $('#txtPanNo').attr('disabled', 'disabled')
        $('#txtTINNo').attr('disabled', 'disabled')
    }
}
$("#txtUI").keyup(function () {
   
    clearform();
});
function EditVendor(vendorid, vname,contactp, emailid, phone, mobile, addr1, addr2, gst, isactive, pan, buttonname, vendorcode) {
    //alert(isactive)
   
   
    $('#hdnFlagType').val(buttonname)
    jQuery("#hdnParticipantID").val(vendorid)
    $("#hdnParticipantCode").val(vendorcode)
    jQuery("#ParticipantName").val(vname)
    jQuery("#txtAddress").val(addr1)
    jQuery("#txtCity").val(addr2)
    jQuery("#txtPanNo").val(pan)
    jQuery("#txtTINNo").val(gst)
    jQuery("#txtPhoneNo").val(phone)
    jQuery("#txtMobileNo").val(mobile)
    jQuery("#ContactName").val(contactp)
    jQuery("#txtcompanyemail").val(emailid)
   // alert(isactive)
    if (isactive == "Y" || isactive.toLowerCase() == "yes") {
        jQuery('input:checkbox[name=chkIsActiveparticipant]').prop('checked', true);
        jQuery('#chkIsActiveparticipant').parents('div').addClass('checked');
    }
    else {
        jQuery('input:checkbox[name=chkIsActiveparticipant]').prop('checked', false);
        jQuery('#chkIsActiveparticipant').parents('div').removeClass('checked');
    }
    $('#divVendorForm').removeClass('hide')
    fetchMapCategory('Z', vendorid);
    if (buttonname == "EditCustomerVendor") {
        $('#ParticipantName').attr('disabled', 'disabled')
        $('#txtAddress').attr('disabled', 'disabled')
        $('#txtCity').attr('disabled', 'disabled')
        $('#txtPanNo').attr('disabled', 'disabled')
        $('#txtTINNo').attr('disabled', 'disabled')
        $('#txtPhoneNo').attr('disabled', 'disabled')
        $('#txtMobileNo').attr('disabled', 'disabled')
        $('#txtcompanyemail').attr('disabled', 'disabled')
        jQuery("#ContactName").attr('disabled', 'disabled')
        $('#lbl_panmsz').removeClass('hide')
    }
    else {
        $('#ParticipantName').removeAttr('disabled')
        $('#txtAddress').removeAttr('disabled')
        $('#txtCity').removeAttr('disabled')
        $('#txtPanNo').removeAttr('disabled')
        $('#txtTINNo').removeAttr('disabled')
        $('#txtPhoneNo').removeAttr('disabled')
        $('#txtMobileNo').removeAttr('disabled')
        $('#txtcompanyemail').removeAttr('disabled')
        jQuery("#ContactName").removeAttr('disabled')
        $('#lbl_panmsz').addClass('hide')
    }
}
function ExtendVendor(vendorid, vname,contactp, emailid, phone, mobile, addr1, addr2, gst, isactive, pan, buttonname,vendorcode) {
   
    jQuery("#hdnParticipantID").val(vendorid)
    $("#hdnParticipantCode").val(vendorcode)
    $('#hdnFlagType').val(buttonname)
     jQuery("#ParticipantName").val(vname)
     jQuery("#txtAddress").val(addr1)
      jQuery("#txtCity").val(addr2)
     jQuery("#txtPanNo").val(pan)
    jQuery("#txtTINNo").val(gst)
    jQuery("#txtPhoneNo").val(phone)
    jQuery("#txtMobileNo").val(mobile)
    jQuery("#ContactName").val(contactp)

    jQuery("#txtcompanyemail").val(emailid)
    $('#ParticipantName').attr('disabled', 'disabled')
    $('#txtAddress').attr('disabled', 'disabled')
    $('#txtCity').attr('disabled', 'disabled')
    $('#txtPanNo').attr('disabled', 'disabled')
    $('#txtTINNo').attr('disabled', 'disabled')
    $('#txtPhoneNo').attr('disabled', 'disabled')
    $('#txtMobileNo').attr('disabled', 'disabled')
    $('#txtcompanyemail').attr('disabled', 'disabled')
    jQuery("#ContactName").attr('disabled', 'disabled')
    $('#divVendorForm').removeClass('hide')
    $('#lbl_panmsz').removeClass('hide')
    if (isactive == "Y") {
        jQuery('input:checkbox[name=chkIsActiveparticipant]').prop('checked', true);
        jQuery('#chkIsActiveparticipant').parents('div').addClass('checked');
    }
    else {
        jQuery('input:checkbox[name=chkIsActiveparticipant]').prop('checked', false);
        jQuery('#chkIsActiveparticipant').parents('div').removeClass('checked');
    }
   
}
function ExtendParticipants() {
    var RegisterParticipants = {
        "CustomerID": sessionStorage.getItem('CustomerID'),
        "VendorCode": jQuery("#hdnParticipantCode").val(),
        "UserID": sessionStorage.getItem('UserID')
    }
    // alert(JSON.stringify(RegisterParticipants))
    jQuery.ajax({

        url: sessionStorage.getItem("APIPath") + "RegisterParticipants/RegisterParticipanttoCustomer_PEV2/",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "POST",
        data: JSON.stringify(RegisterParticipants),
        contentType: "application/json; charset=utf-8",
        success: function (data, status, jqXHR) {
            
            if (data[0].IsSuccess == '1') {
                $("#hdnParticipantID").val(data[0].ParticipantID)
                MapVendorCategories();
            }
            else {
                jQuery('#divalerterr').html('Vendor is already exists for this customer.')
                jQuery('#divalerterr').slideDown('show');
                App.scrollTo(jQuery('#divalerterr'), -200);
            }

            setTimeout(function () {
                jQuery('#divalertsucess').css('display', 'none');
                jQuery('#divalerterr').css('display', 'none');
            }, 5000);
           fnfetchfoundVendors();
            fetchParticipantsVenderTable();
           // fetchParticipantsVenderForExport();
        },
        
        error: function (xhr, status, error) {

        var err = eval("(" + xhr.responseText + ")");
        if (xhr.status === 401) {
            error401Messagebox(err.Message);
        }
        else{
            jQuery("#error").text(xhr.d);
        }
        return false;
        jQuery.unblockUI();
    }
    });


}

function clearform() {

    jQuery("#ParticipantName").val('');
    jQuery("#txtAddress").val('');
    jQuery("#txtCity").val('');
    jQuery("#txtPanNo").val('');
    jQuery("#txtTINNo").val('');
    jQuery("#txtPhoneNo").val('');
    jQuery("#txtMobileNo").val('');
    jQuery("#ContactName").val('');
    jQuery("#txtcompanyemail").val('');
    jQuery('#hdnParticipantID').val('0');
   // jQuery('#txtUI').val('');
   
    $('.childchkbox').each(function () {
        jQuery(this).closest('span#spancheckedvendorgroup').removeAttr('class');
    })
    status = "True"
    $('#ParticipantName').removeAttr('disabled')
    $('#txtAddress').removeAttr('disabled')
    $('#txtCity').removeAttr('disabled')
    $('#txtPanNo').removeAttr('disabled')
    $('#txtTINNo').removeAttr('disabled')
    $('#txtPhoneNo').removeAttr('disabled')
    $('#txtMobileNo').removeAttr('disabled')
    $('#txtcompanyemail').removeAttr('disabled')
    jQuery("#hdnParticipantID").val(0)
    jQuery("#hdnParticipantCode").val(0)
    jQuery("#hdnFlagType").val(0)
    $('#divVendorForm').addClass('hide')
    $('#lbl_panmsz').addClass('hide')
    $('#div_tableVendor').addClass('hide');
}
function fnchangeplaceholder() {
    clearform();
    $('#txtUI').val('');
    $('#txtUI').attr("placeholder", $('#ddlUI  option:selected').text())
    if ($('#ddlUI  option:selected').val() =="PanNo") {
        $("#txtUI").attr('maxlength', '10');
    }
    else{
        $("#txtUI").attr('maxlength', '15');
    }
}
jQuery("#txtSVendor").keyup(function () {

    jQuery("#tblVendorFoundDetails tr:has(td)").hide(); // Hide all the rows.

    var iCounter = 0;
    var sSearchTerm = jQuery('#txtSVendor').val(); //Get the search box value

    if (sSearchTerm.length == 0) //if nothing is entered then show all the rows.
    {
        jQuery("#tblVendorFoundDetails tr:has(td)").show();
        return false;
    }

    //Iterate through all the td.
    jQuery("#tblVendorFoundDetails tr:has(td)").children().each(function () {

        var cellText = jQuery(this).text().toLowerCase();
        if (cellText.indexOf(sSearchTerm.toLowerCase()) >= 0) //Check if data matches
        {

            jQuery(this).parent().show();
            iCounter++;

            return true;
        }

    });
});
