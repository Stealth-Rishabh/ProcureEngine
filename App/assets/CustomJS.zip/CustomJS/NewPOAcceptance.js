﻿var form = $('#frmremarks');
var Type = getUrlVars()["Type"];
var status = '';
if (Type == 'P') {
    $('#rejectPO').removeClass('hide')
    $('#acceptPO').removeClass('hide')
    $('#div_status').addClass('hide')
}
else {
    $('#rejectPO').addClass('hide')
    $('#acceptPO').addClass('hide')
    $('#div_status').removeClass('hide')
    if (Type == 'R') {
        $('#POStatus').css("color", "red")
        $('#POStatus').html("Reverted")
    }
    else {
        $('#POStatus').css("color","green")
        $('#POStatus').html("Accepted")
    }
}

function formvalidate() {

    form.validate({

        doNotHideMessage: true, //this option enables to show the error/success messages on tab switch.

        errorElement: 'span', //default input error message container

        errorClass: 'help-block help-block-error', // default input error message class

        focusInvalid: false, // do not focus the last invalid input

        rules: {
            
                txtremarks: {
                     required: true
                },

        },

        messages: {
            txtremarks: {
                required: "Please Enter Remarks."
            }
        },



        invalidHandler: function (event, validator) {

        },

        highlight: function (element) {

            $(element).closest('.col-md-8').addClass('has-error');

        },

        unhighlight: function (element) {

            $(element).closest('.col-md-8').removeClass('has-error');

        },

        success: function (label) {


        },
        submitHandler: function (form) {

            RevertPO();

        }

    });

}
function fetchPODetails(flag) {
    //alert(sessionStorage.getItem("APIPath") + "POUpload/PODetails/?CustomerID=" + sessionStorage.getItem('CustomerID') + "&VendorID=" + sessionStorage.getItem('VendorId') + "&UserID=" + sessionStorage.getItem('UserID') + "&Flag=" + flag + "&POHeaderID=" + sessionStorage.getItem('hddnPOHID'))
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "POUpload/PODetails/?CustomerID=" + sessionStorage.getItem('CustomerID') + "&VendorID=" + sessionStorage.getItem('VendorId') + "&UserID=" + encodeURIComponent(sessionStorage.getItem('UserID')) + "&Flag=" + flag + "&POHeaderID=" + sessionStorage.getItem('hddnPOHID'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
            var attach = "";
           
            if (data.length > 0) {
                if (flag == "Details") {
                    jQuery("#tblServicesProduct").empty();
                    jQuery('#tblServicesProduct').append("<thead><tr style='background: gray; color: #FFF;'><th>Item Code</th><th>Item/Service</th><th>Delivery Location</th><th>Po No</th><th>Delivery/Completion Date</th><th>Quantity</th><th>UOM</th></tr></thead>");
                    for (var i = 0; i < data.length; i++) {
                        jQuery("#tblServicesProduct").append('<tr><td  style="width:20%!important;">' + data[i].ItemCode + '</td><td>' + data[i].ItemServiceName + '</td><td>' + data[i].DeliveryLocation + '</td><td>' + data[i].PONo + '</td><td class=text-right>' + data[i].PODeliveryDate + '</td><td class=text-right>' + thousands_separators(data[i].Quantity) + '</td><td>' + data[i].UOM + '</td></tr>');
                    }
                }
                else {
                    jQuery("#tblAttachments").empty();
                    $('#spnsentbyname').html("<b>" + data[0].CreatedByName + "</b>")
                    $('#PODate').html("<b>" + data[0].ActionTakenOn + "</b>")
                    $('#txtvendorremarks').html("<b>" + data[0].UserRemarks + "</b>")
                    $('#headerotherrfqattach').removeClass('hide')
                    $('#div_POAttach').removeClass('hide')
                    jQuery('#tblAttachments').append("<thead><tr style='background: gray; color: #FFF;'><th class='bold'>Attachment</th></tr></thead>");
                    for (var i = 0; i < data.length; i++) {
                        attach = data[i].POAttachment.replace(/\s/g, "%20");
                        var str = "<tr><td class=style='width:47%!important'><a style='pointer:cursur;text-decoration:none;' target=_blank href=PortalDocs/PO/" + sessionStorage.getItem('hddnPOHID') + '/' + attach + '>' + data[i].POAttachment + "</a></td></tr>";
                        
                        jQuery('#tblAttachments').append(str);
                    }
                }
            }

            else {
                if (flag == "Details") {
                }
                else {
                    $('#headerotherrfqattach').addClass('hide')
                    $('#div_POAttach').addClass('hide')
                    jQuery('#tblAttachments').append("<tr><td>No Attachments!!</td></tr>")
                }
            }

        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else {
                alert(xhr.status + ' ' + xhr.statusText);
                jQuery.unblockUI();
            }

            return false;
            jQuery.unblockUI();
        }
    })
}
function fnacceptPO() {
    
    var Approvers = {
        "POHeaderID": sessionStorage.getItem('hddnPOHID'),
        "VendorID": sessionStorage.getItem('VendorId'),
        "Remarks": '',
        "CustomerID": sessionStorage.getItem('CustomerID'),
        "ActionType": "Vendor",
        "Action": 'Accept',
        "UserID":''
    }
    // alert(JSON.stringify(Approvers))
    jQuery.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "POUpload/acceptPO",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        crossDomain: true,
        async: false,
        data: JSON.stringify(Approvers),
        dataType: "json",
        success: function (data) {
            if (data.length > 0) {
                bootbox.alert("Thanks for the PO Acceptance..", function () {
                    window.location = "VendorHome.html";
                    return false;
                });


            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else {
                alert(xhr.status + ' ' + xhr.statusText);
                jQuery.unblockUI();
            }

            return false;
            jQuery.unblockUI();
        }
    });
}
function RevertPO() {
    var Approvers = {
        "POHeaderID": sessionStorage.getItem('hddnPOHID'),
        "VendorID": sessionStorage.getItem('VendorId'),
        "Remarks": $('#txtremarks').val(),
        "CustomerID": sessionStorage.getItem('CustomerID'),
        "ActionType": "Vendor",
        "Action": 'Revert',
        "UserID": sessionStorage.getItem('UserID')
    }
     //alert(JSON.stringify(Approvers))
    jQuery.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "POUpload/acceptPO",
        crossDomain: true,
        async: false,
        data: JSON.stringify(Approvers),
        dataType: "json",
        success: function (data) {
            if (data.length > 0) {
                bootbox.alert("This PO is now reverted to Admin.", function () {
                    window.location = "VendorHome.html";
                    return false;
                });


            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else {
                alert(xhr.status + ' ' + xhr.statusText);
                jQuery.unblockUI();
            }

            return false;
            jQuery.unblockUI();
        }
    });
}
function FetchRecomendedVendor() {
    // alert(sessionStorage.getItem("APIPath") + "ApprovalAir/FetchRecommendedVendor/?BidID=" + bidid + "&UserID=" + encodeURIComponent(sessionStorage.getItem("UserID")) + "&AuthenticationTonken=" + sessionStorage.getItem("AuthenticationToken"))
    jQuery.ajax({
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "PoUpload/POHistory/?POHeaderID=" + sessionStorage.getItem('hddnPOHID') + "&UserID=" + (sessionStorage.getItem("VendorId")) + "&AuthenticationTonken=" + sessionStorage.getItem("AuthenticationToken"),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "GET",
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data) {
            $('#tblremarksforward').empty()
           
            if (data.length > 0) {
                $('#HDHistory').removeClass('hide')
                $('#frmdivforward').removeClass('hide')
                $('#tblremarksforward').append('<tr><th>Action Taken By</th><th>Remarks</th><th>Action Type</th><th class=hide id=thforward>Recommended Vendor</th><th>Completion DT</th></tr>')
               // if (AppStatus == 'Reverted') {
                  
                    $('#frmdivforward').show();
                    for (var i = 0; i < data.length; i++) {
                        if (data[i].VendorName != "") {
                            $('#tblremarksforward').append('<tr><td>' + data[i].ActionTakenBy + '</td><td>' + data[i].Remarks + '</td><td>' + data[i].FinalStatus + '</td><td>' + data[i].VendorName + '</td><td>' + data[i].ReceiptDt + '</td></tr>')
                            $('#thforward').removeClass('hide')
                        }
                        else {
                            $('#tblremarksforward').append('<tr><td>' + data[i].ActionTakenBy + '</td><td>' + data[i].Remarks + '</td><td>' + data[i].FinalStatus + '</td><td>' + data[i].ReceiptDt + '</td></tr>')
                            $('#thforward').addClass('hide')
                        }


                    }
               // }
              
            }
            else {
                $('#HDHistory').addClass('hide')
                $('#frmdivforward').addClass('hide')
                $('#tblapprovalprocess').append('<tr><td colspan="15" style="text-align: center; color: Red">No record found</td></tr>')
            }

        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else {
                alert(xhr.status + ' ' + xhr.statusText);
                jQuery.unblockUI();
            }

            return false;
            jQuery.unblockUI();
        }
    });

}