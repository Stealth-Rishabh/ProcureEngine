﻿var APIPath = sessionStorage.getItem("APIPath");
function onload() {
    fetchMenuItemsFromSession(9, 31);
    setCommonData();
    //FormValidation.init();
    fetchUserBids()
    
   
}
var error1 = $('.alert-danger');
var success1 = $('.alert-success');
function fetchUserBids() {

    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });

    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: APIPath + "ConfigureBid/fetchSeaExportBids/?UserID=" + encodeURIComponent(sessionStorage.getItem("UserID")) + "&CustomerID=" + sessionStorage.getItem('CustomerID'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        data: "{}",
        cache: false,
        dataType: "json",
        success: function (data) {
           
            jQuery('#ddlbid').empty();
            if (data.length > 0) {

                sessionStorage.setItem('hdnAllBids', JSON.stringify(data));
                jQuery('#ddlbid').append(jQuery("<option ></option>").val("").html("Select Bid"));
                for (var i = 0; i < data.length; i++) {
                    jQuery('#ddlbid').append(jQuery("<option ></option>").val(data[i].BidId).html(data[i].BidSubject));
                }
            }
            else {
                $('#ddlbid').append(jQuery("<option ></option>").val("").html("Select Bid"));
                error1.show();
                $('#spanerror1').html('No pending bids for which you can manage.!');
                error1.fadeOut(6000);
                App.scrollTo(error1, -200);

            }
            //  alert(sessionStorage.getItem('hdnAllBids'))
            jQuery.unblockUI();

        },
        error: function (result) {
            alert("error");
            jQuery.unblockUI();

        }
    });
}
var SeId=0;
function fetchallexportdetails() {
    $('#extendedDurationPara').hide();
    var replaced1 = '';
    var replaced2 = '';
    jQuery.ajax({
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ConfigureBid/fetchSeaExportConfigurationData/?UserID=" + encodeURIComponent(sessionStorage.getItem('UserID')) + "&BidID=" + jQuery('#ddlbid').val() + "&AuthenticationToken=" + sessionStorage.getItem('AuthenticationToken'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "GET",
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (BidData) {
          
            $('#BidPreviewDiv').show()
            jQuery('#mapedapproverPrev').html('');
           
            jQuery('#txtBidSubjectPrev').html(BidData[0].BidDetails[0].BidSubject)
            //jQuery('#txtBidDurationPrev').val(BidData[0].BidDetails[0].BidDuration)
            jQuery('#txtbiddescriptionPrev').html(BidData[0].BidDetails[0].BidDetails)
            jQuery('#txtbidDatePrev').html(BidData[0].BidDetails[0].BidDate)
            jQuery('#txtbidTimePrev').html(BidData[0].BidDetails[0].BidTime)
            jQuery("#dropCurrencyPrev").html(BidData[0].BidDetails[0].CurrencyID)
            jQuery('#txtConversionRatePrev').html(BidData[0].BidDetails[0].ConversionRate)
           //var ClosingType=''
            $('#hdnClosingval').val(BidData[0].BidDetails[0].BidClosingType)
            //alert(BidData[0].BidDetails[0].BidClosingType)
            if (BidData[0].BidDetails[0].BidClosingType == "A") {
            SeId=0;
                $('#spinner4').show()
                $('#btndiv').show()
                $('#txtbidduration').hide()
                $('#spinner4').spinner({ value: BidData[0].BidDetails[0].BidDuration, step: 1, min: 0, max: 200 });
                jQuery('#ddlbidclosetypePrev').html('All items in one go')
               
            }
            else {
                $('#spinner4').hide()
                $('#btndiv').hide()
                $('#txtbidduration').show()
                $('#txtbidduration').html(BidData[0].BidDetails[0].BidDuration)
                jQuery('#ddlbidclosetypePrev').html('Stagger at: Item level')
            }

            if (BidData[0].BidDetails[0].TermsConditions != '') {

                $('#file1').attr('disabled', true);
                $('#closebtn').removeClass('display-none');

                replaced1 = BidData[0].BidDetails[0].TermsConditions.replace(/\s/g, "%20")

                if (BidData[0].BidDetails[0].Attachment != '') {
                    if (BidData[0].BidDetails[0].Attachment != null) {
                        $('#file2').attr('disabled', true);
                        $('#closebtn2').removeClass('display-none');

                        replaced2 = BidData[0].BidDetails[0].Attachment.replace(/\s/g, "%20")
                    }
                }



            }
            $('#filepthtermsPrev').attr('href', 'PortalDocs/Bid/' + sessionStorage.getItem('CurrentBidID') + '/' + replaced1).html(BidData[0].BidDetails[0].TermsConditions);
            $('#filepthattachPrev').attr('href', 'PortalDocs/Bid/' + sessionStorage.getItem('CurrentBidID') + '/' + replaced2).html(BidData[0].BidDetails[0].Attachment);

            if (BidData[0].BidApproverDetails.length > 0) {
                for (var i = 0; i < BidData[0].BidApproverDetails.length; i++) {
                    
                    jQuery('#mapedapproverPrev').append(jQuery('<option selected></option>').val(BidData[0].BidApproverDetails[i].UserID).html(BidData[0].BidApproverDetails[i].ApproverName))
                }
            }

            
            jQuery("#tblServicesProductPrev").empty();
            if (BidData[0].BidSeaExportDetails.length > 0) {


               
                $('#wrap_scrollerPrev').show();

                if ($('#hdnClosingval').val() == "S") {

                    jQuery("#tblServicesProductPrev").append("<thead><tr style='background: gray; color: #FFF;'><th>Destination Port</th><th>Remarks</th><th>TargetRate</th><th>Quantity</th><th>Bid start price</th><th class=hide>Mask Vendor</th><th style='width:60px !important'>Minimum Decrement</th><th>Decrement On</th><th>Last InvoicePrice</th><th>Item Duration(Min)</th><th>Closing Time</th><th style=width:200px>Bid Duration (in minutes)</th></tr></thead>");
                }
                else {
                   
                    jQuery("#tblServicesProductPrev").append("<thead><tr style='background: gray; color: #FFF;'><th>Destination Port</th><th>Remarks</th><th>TargetRate</th><th>Quantity</th><th>Bid start price</th><th class=hide>Mask Vendor</th><th>Minimum Decrement</th><th>Decrement On</th><th>Last InvoicePrice</th></tr></thead>");
                }

                for (var i = 0; i < BidData[0].BidSeaExportDetails.length; i++) {


                    var decrementon = ''

                    if (BidData[0].BidSeaExportDetails[i].DecreamentOn == 'A')
                        decrementon = 'Price'
                    else
                        decrementon = '%age'


                    if ($('#hdnClosingval').val() == "S") {
                        //alert(BidData[0].BidSeaExportDetails[i].ItemBidDuration)
                        jQuery("#tblServicesProductPrev").append('<tr id=tridPrev' + i + '><td>' + BidData[0].BidSeaExportDetails[i].DestinationPort + '</td><td>' + BidData[0].BidSeaExportDetails[i].Remarks + '</td><td>' + BidData[0].BidSeaExportDetails[i].Targetprice + '</td><td>' + BidData[0].BidSeaExportDetails[i].Quantity + '</td><td>' + BidData[0].BidSeaExportDetails[i].CeilingPrice + '</td><td class=hide>' + BidData[0].BidSeaExportDetails[i].MaskVendor + '</td><td>' + BidData[0].BidSeaExportDetails[i].MinimumDecreament + '</td><td>' + decrementon + '</td><td class=hide>' + BidData[0].BidSeaExportDetails[i].DecreamentOn + '</td><td>' + BidData[0].BidSeaExportDetails[i].LastInvoicePrice + '</td><td>' + BidData[0].BidSeaExportDetails[i].ItemBidDuration + '</td><td>' + BidData[0].BidSeaExportDetails[i].ItemClosingTime + '</td><td><div class="pull-left"> <div id=spinner' + i + ' class="pull-left"><div class="input-group" style="width:131px;"><div class="spinner-buttons input-group-btn"><button type="button" class="btn spinner-up blue"><i class="fa fa-plus"></i></button></div><input type=text class="spinner-input form-control" id=txtitemBidDuration' + i + ' maxlength="3" readonly><div class="spinner-buttons input-group-btn"><button type="button" class="btn spinner-down red"><i class="fa fa-minus"></i></button> </div></div></div><div class="pull-left"><button id="btnextendA" type="button" class="btn green" onclick="fnTimeUpdateS(\'' + i + '\',\'' + BidData[0].BidSeaExportDetails[i].SEID + '\')">Go</button></div><p class="form-control-static col-md-4" id=extendedDuration' + i + ' style="color:#3c763d; font-weight: 600; display: none;">Time&nbsp;Extended&nbsp;Successfully</p></td></tr>');
                        $('#spinner' + i).spinner({ value: 0, step: 1, min: 0, max: 200 }); //BidData[0].BidSeaExportDetails[i].ItemBidDuration
                    }
                    else {
                        
                        jQuery("#tblServicesProductPrev").append("<tr id=tridPrev" + i + "><td>" + BidData[0].BidSeaExportDetails[i].DestinationPort + "</td><td>" + BidData[0].BidSeaExportDetails[i].Remarks + "</td><td>" + BidData[0].BidSeaExportDetails[i].Targetprice + "</td><td>" + BidData[0].BidSeaExportDetails[i].Quantity + "</td><td>" + BidData[0].BidSeaExportDetails[i].CeilingPrice + "</td><td class=hide>" + BidData[0].BidSeaExportDetails[i].MaskVendor + "</td><td>" + BidData[0].BidSeaExportDetails[i].MinimumDecreament + "</td><td>" + decrementon + "</td><td class=hide>" + BidData[0].BidSeaExportDetails[i].DecreamentOn + "</td><td>" + BidData[0].BidSeaExportDetails[i].LastInvoicePrice + '</td></tr>');
                    }
                   
                    //+ BidData[0].BidSeaExportDetails[i].ItemBidDuration + 
                }
                jQuery('#selectedvendorlistsPrev> tbody').empty()
                
                for (var i = 0; i < BidData[0].BidVendorDetails.length; i++) {
                    
                    jQuery('#selectedvendorlistsPrev').append('<tr ><td class=hide>' + BidData[0].BidVendorDetails[i].VendorID + '</td><td>' + BidData[0].BidVendorDetails[i].EmailId + '</td></tr>')
                }

            }
        }
    });


}
function fnTimeUpdateS(index, seaid) {

    SeId = seaid
    

    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    var Data = {
        "BidClosingType": $('#hdnClosingval').val(),
        "BidID": jQuery('#ddlbid').val(),
        "BidDuration": jQuery('#txtitemBidDuration'+index).val(),
        "SEID":SeId
    }
   // alert(JSON.stringify(Data))
    jQuery.ajax({
        url: sessionStorage.getItem("APIPath") + "ConfigureBid/UpdateBidTime/",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "POST",
        data: JSON.stringify(Data),
        contentType: "application/json; charset=utf-8",
        success: function(data, status, jqXHR) {
        
            if (data[0].Status == "1") {
                $('#extendedDuration' + index).show()
                
            }
            else if (data[0].Status == "-1") {
                $('#extendedDuration' + index).text("This Item is already expired.").css('color', 'red')
                $('#extendedDuration' + index).show()

            }
            setTimeout(function(){fetchallexportdetails()},5000)
            jQuery.unblockUI();
        },
        error: function(result) {
            jQuery.unblockUI();
        }
    })
}


function fnTimeUpdate() {
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    var Data = {
        "BidClosingType":   $('#hdnClosingval').val(),
        "BidID": jQuery('#ddlbid').val(),
        "BidDuration": jQuery('#txtBidDurationPrev').val(),
        "SEID":0
        

    }
     //alert(JSON.stringify(Data))
    jQuery.ajax({
        url: sessionStorage.getItem("APIPath") + "ConfigureBid/UpdateBidTime/",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "POST",
        data: JSON.stringify(Data),
        contentType: "application/json; charset=utf-8",
        success: function (data, status, jqXHR) {
        
            if (data[0].Status == "1") {
                $('#extendedDurationPara').show()
            }
           
            jQuery.unblockUI();
        },
        error: function (result) {
            jQuery.unblockUI();
        }
    })
}