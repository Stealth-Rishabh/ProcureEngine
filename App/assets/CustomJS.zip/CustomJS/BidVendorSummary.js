﻿var BidID = "";
var BidTypeID = "";
var BidForID = "";



$(document).ready(function () {
    
    fetchBidTypeMapping();
    FetchContinent('0');
    formvalidate()
    fetchregisterusers();
   // fetchBidVendorSummary();
    // BidID = getUrlVars()["BidID"];
     //BidTypeID = getUrlVars()["BidTypeID"];
    //    BidForID = getUrlVars()["BidForID"];
    if (window.location.search) {
        var param = getUrlVars()["param"]
        var decryptedstring = fndecrypt(param)
       
        BidID = getUrlVarsURL(decryptedstring)["BidID"]
        BidTypeID = getUrlVarsURL(decryptedstring)["BidTypeID"]
        BidForID = getUrlVarsURL(decryptedstring)["BidForID"]
    }
     
});
function fetchregisterusers() {
    
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "RegisterUser/fetchAllregisteredusersRolebased/?CustomerID=" + sessionStorage.getItem("CustomerID") + "&UserID=" + encodeURIComponent(sessionStorage.getItem("UserID")),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        dataType: "json",
        success: function (data) {
            jQuery("#ddlconfiguredby").empty();
            jQuery("#ddlconfiguredby").append(jQuery("<option ></option>").val("0").html("Select"));
            for (var i = 0; i < data.length; i++) {
                jQuery("#ddlconfiguredby").append(jQuery("<option></option>").val(data[i].UserID).html(data[i].UserName));
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
    });
}

function FetchContinent(ContinentID) {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ConfigureBid/FetchContinent/?ContinentID=" + ContinentID + "&excludeStatus=N",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        dataType: "json",
        success: function (data) {
            jQuery("#ddlsector").empty();
            jQuery("#ddlsector").append(jQuery("<option ></option>").val("").html("Select"));
            for (var i = 0; i < data.length; i++) {
                jQuery("#ddlsector").append(jQuery("<option></option>").val(data[i].ContinentId).html(data[i].ContinentNm));
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
    });
}

jQuery("#ddlBidtype").change(function () {
    var BidTypeID = $("#ddlBidtype option:selected").val();
    jQuery("#ddlBidFor").empty();
    // jQuery("#ddlBidFor").append(jQuery("<option ></option>").val("0").html("Select"));
    
    if (BidTypeID == 6) {
        $('#opntionRFQ').addClass('hide')
        jQuery("#ddlBidFor").append(jQuery("<option></option>").val("81").html("English"));
        jQuery("#ddlBidFor").append(jQuery("<option></option>").val("82").html("Dutch(RA)"));
    }
    else {
        $('#opntionRFQ').removeClass('hide')
        jQuery("#ddlBidFor").append(jQuery("<option ></option>").val("0").html("Select"));
        jQuery("#ddlBidFor").append(jQuery("<option ></option>").val("81").html("English"));
        jQuery("#ddlBidFor").append(jQuery("<option ></option>").val("83").html("Japanese"));
    }
   
   // fetchBidFor(BidTypeID);
});

jQuery("#ddlsector").change(function () {
    var continentID = $("#ddlsector option:selected").val();
    var countryID = "0";
    fetchCountry(continentID, countryID)
});

function fetchCountry(continentID, countryID) {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ConfigureBid/fetchCountry/?ContinentId=" + continentID + "&CountryID=" + countryID + "&excludeStatus=N",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        dataType: "json",
        success: function (data) {
            jQuery("#ddlcountry").empty();
            jQuery("#ddlcountry").append(jQuery("<option ></option>").val("").html("Select"));
            for (var i = 0; i < data.length; i++) {
                jQuery("#ddlcountry").append(jQuery("<option ></option>").val(data[i].CountryId).html(data[i].CountryNm));
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
    });
}
function fetchBidTypeMapping() {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ConfigureBid/fetchBidTypeMapping/?CustomerID=" + sessionStorage.getItem("CustomerID") + "&BidTypeID=0",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        dataType: "json",
        success: function (data) {
            jQuery("#ddlBidtype").empty();
            jQuery("#ddlBidtype").append(jQuery("<option ></option>").val("").html("Select"));
            for (var i = 0; i < data.length; i++) {
                jQuery("#ddlBidtype").append(jQuery("<option ></option>").val(data[i].BidTypeID).html(data[i].BidTypeName));
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
    });
    jQuery("#ddlBidFor").append(jQuery("<option ></option>").val("").html("Select"));
    jQuery("#ddlsector").append(jQuery("<option ></option>").val("").html("Select"));
    jQuery("#ddlcountry").append(jQuery("<option ></option>").val("").html("Select"));
}

function fetchBidFor(BidTypeID) {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ConfigureBid/fetchBidFor/?BidTypeID=" + BidTypeID,
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        dataType: "json",
        success: function (data) {
            jQuery("#ddlBidFor").empty();
            jQuery("#ddlBidFor").append(jQuery("<option ></option>").val("").html("Select"));
            for (var i = 0; i < data.length; i++) {
                jQuery("#ddlBidFor").append(jQuery("<option></option>").val(data[i].BidForID).html(data[i].BidFor));
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
    });
}

//jQuery('#btnSubject').click(function () {
//    fetchBidVendorSummary();
//});
var form = $('#frmbidsummaryreport');
function formvalidate() {

    form.validate({

        doNotHideMessage: true, //this option enables to show the error/success messages on tab switch.

        errorElement: 'span', //default input error message container

        errorClass: 'help-block help-block-error', // default input error message class

        focusInvalid: false, // do not focus the last invalid input

        rules: {

        ddlBidtype: {
                required: true
            }

        },

        messages: {

    },



    invalidHandler: function(event, validator) {

    },

    highlight: function(element) {

        $(element).closest('.col-md-8').addClass('has-error');

    },

    unhighlight: function(element) {

        $(element).closest('.col-md-8').removeClass('has-error');

    },

    success: function(label) {


    },


    submitHandler: function(form) {
       // fetchBidVendorSummary()
        if ($('#ddlBidtype option:selected').val() == 7) {
            if ($('#ddlreporttype option:selected').val() == "List" || $('#ddlreporttype').val() == "ListRFQ") {
                fetchBidVendorSummary();
                $('#tblVendorSummary_wrapper').removeClass('hide');
                $('#tblVendorSummary').removeClass('hide');
                $('#tblVendorSummarydetails').addClass('hide');
                $('#tblVendorSummarydetails_wrapper').addClass('hide');
                $('#tblVendorSummarySUmzation').addClass('hide');
                $('#tblVendorSummarySUmzation_wrapper').addClass('hide');
            }
           
            else if ($('#ddlreporttype').val() == "SDetail") {
                fetchBidVendorSummaryDetail()
                $('#tblVendorSummary').addClass('hide');
                $('#tblVendorSummary_wrapper').addClass('hide');
                $('#tblVendorSummarydetails').removeClass('hide');
                $('#tblVendorSummarydetails_wrapper').removeClass('hide');
                $('#tblVendorSummarySUmzation').addClass('hide');
                $('#tblVendorSummarySUmzation_wrapper').addClass('hide');
            }
            else {
                fetchBidVendorSummarySummarization()
                $('#tblVendorSummary').addClass('hide');
                $('#tblVendorSummary_wrapper').addClass('hide');
                $('#tblVendorSummarydetails').addClass('hide');
                $('#tblVendorSummarydetails_wrapper').addClass('hide');
                $('#tblVendorSummarySUmzation').removeClass('hide');
                $('#tblVendorSummarySUmzation_wrapper').removeClass('hide');
            }
        }
        else {
            if ($('#ddlreporttype option:selected').val() == "List") {
                fetchBidVendorSummary();
                $('#tblVendorSummary_wrapper').removeClass('hide');
                $('#tblVendorSummary').removeClass('hide');
                $('#tblVendorSummarydetails').addClass('hide');
                $('#tblVendorSummarydetails_wrapper').addClass('hide');
                $('#tblVendorSummarySUmzation').addClass('hide');
                $('#tblVendorSummarySUmzation_wrapper').addClass('hide');
            }
            else if ($('#ddlreporttype').val() == "SDetail") {
                fetchBidVendorSummaryDetailFA()
                $('#tblVendorSummary').addClass('hide');
                $('#tblVendorSummary_wrapper').addClass('hide');
                $('#tblVendorSummarydetails').removeClass('hide');
                $('#tblVendorSummarydetails_wrapper').removeClass('hide');
                $('#tblVendorSummarySUmzation').addClass('hide');
                $('#tblVendorSummarySUmzation_wrapper').addClass('hide');
            }
            else {
                fetchBidVendorSummarySummarizationFA()
                $('#tblVendorSummary').addClass('hide');
                $('#tblVendorSummary_wrapper').addClass('hide');
                $('#tblVendorSummarydetails').addClass('hide');
                $('#tblVendorSummarydetails_wrapper').addClass('hide');
                $('#tblVendorSummarySUmzation').removeClass('hide');
                $('#tblVendorSummarySUmzation_wrapper').removeClass('hide');
            }

        }
       
    }

});

}

//function fetchbidType() {
//     if $('#ddlBidtype option:selected').val() == "7") {
//    }
//}
var BidDate = "";
function fetchBidVendorSummary() {
    var url = '';
    var BidTypeID = $("#ddlBidtype option:selected").val();
    if (BidTypeID == 7) {
        if (jQuery("#ddlBidFor option:selected").val() == 81) {
            jQuery("#ddlBidFor option:selected").val(0)
        }
    }
    if ($('#ddlreporttype option:selected').val() == "List") {
        url = sessionStorage.getItem("APIPath") + "BidVendorSummary/fetchAdminBidSummary/?BidTypeID=" + jQuery("#ddlBidtype option:selected").val() + "&BidForID=" + jQuery("#ddlBidFor option:selected").val() + "&ContinentId=" + 0 + "&CountryId=" + 0 + "&VendorId=" + jQuery("#hdnVendorID").val() + "&FromDate=" + jQuery("#txtFromDate").val() + "&ToDate=" + jQuery("#txtToDate").val() + "&BidSubject=" + jQuery("#txtbidsubject").val() + "&FinalStatus=" + jQuery("#ddlbidstatus option:selected").val() + "&UserID=" + encodeURIComponent(sessionStorage.getItem('UserID')) + "&CustomerID=" + sessionStorage.getItem('CustomerID') + "&ConfiguredBy=" + jQuery("#ddlconfiguredby option:selected").val();
    }
    else {
        url = sessionStorage.getItem("APIPath") + "BidVendorSummary/fetchAdminBidSummaryRFQ/?BidTypeID=" + jQuery("#ddlBidtype option:selected").val() + "&BidForID=" + jQuery("#ddlBidFor option:selected").val() + "&ContinentId=" + 0 + "&CountryId=" + 0 + "&VendorId=" + jQuery("#hdnVendorID").val() + "&FromDate=" + jQuery("#txtFromDate").val() + "&ToDate=" + jQuery("#txtToDate").val() + "&BidSubject=" + jQuery("#txtbidsubject").val() + "&FinalStatus=" + jQuery("#ddlbidstatus option:selected").val() + "&UserID=" + encodeURIComponent(sessionStorage.getItem('UserID')) + "&CustomerID=" + sessionStorage.getItem('CustomerID') + "&ConfiguredBy=" + jQuery("#ddlconfiguredby option:selected").val();
    }
    var BidSummary = {
        "BidTypeID": jQuery("#ddlBidtype option:selected").val(),
        "BidForID": 0,
        "ContinentId": 0,
        "CountryId": 0,
        "VendorId": jQuery("#hdnVendorID").val(),
        "FromDate": jQuery("#txtFromDate").val(),
        "ToDate": jQuery("#txtToDate").val(),
        "BidSubject": jQuery("#txtbidsubject").val(),
        "FinalStatus": jQuery("#ddlbidstatus option:selected").val(),
        "UserID": sessionStorage.getItem('UserID'),
        "CustomerID": sessionStorage.getItem('CustomerID'),
        "ConfiguredBy": jQuery("#ddlconfiguredby option:selected").val()
    };
    
        jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        url: url,
       // data: JSON.stringify(BidSummary),
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (BidData) {
  
            jQuery("#tblVendorSummary").empty();
            jQuery('#tblVendorSummary').append("<thead><tr><th class='bold'>Event ID</th><th class='bold'>Bid Subject</th><th class='bold'>Configured By</th><th class='bold'>Bid Date</th><th class='bold'>Bid Time</th><th class='bold'>Bid Duration</th><th class='bold'>Currency</th><th class='bold'>Bid Status</th></tr></thead>");
            if (BidData.length > 0) {
                //jQuery('#displayTable').show();
                for (var i = 0; i < BidData.length; i++) {
                    if ($('#ddlreporttype option:selected').val() == "List") {
                        var str = "<tr><td  class=text-right><a onclick=getSummary(\'" + BidData[i].BidID + "'\,\'" + BidData[i].BidForID + "'\,\'0'\) href='javascript:;' >" + BidData[i].BidID + "</a></td>";
                    }
                    else {
                       
                        var str = "<tr><td  class=text-right><a onclick=getSummary(\'" + BidData[i].BidID + "'\,\'" + BidData[i].BidForID + "'\,\'" + BidData[i].RFQID + "'\) href='javascript:;' >" + BidData[i].BidID + "</a></td>";
                    }
                    str += "<td>" + BidData[i].BidSubject + "</td>";
                    str += "<td>" + BidData[i].ConfiguredBy + "</td>";
                   
                    var datearray = BidData[i].BidDate.split("/");
                   // BidDate = datearray[1] + '/' + datearray[0] + '/' + datearray[2];
                    BidDate = datearray[2] + '/' + datearray[1] + '/' + datearray[0];
                  //  var millisecond = Date.parse(new Date(BidDate));
                    //str += "<td><span style='display: none;'>" + millisecond + "</span >" + BidData[i].BidDate + "</td>";
                    str += "<td>" + BidDate + "</td>";

                    str += "<td class=text-right>" + BidData[i].BidHour + ' : ' + BidData[i].BidMinute + '  ' + BidData[i].AMPM + "</td>";
                    str += "<td class=text-right>" + BidData[i].BidDuartion + "</td>";
                    str += "<td>" + BidData[i].CurrencyName + "</td>";
                    str += "<td>" + BidData[i].FinalStatus + "</td>";
                  
                    str += "</tr>";
                    jQuery('#tblVendorSummary').append(str);
                }
                    var table = $('#tblVendorSummary');
                     table.removeAttr('width').dataTable({
                        "bDestroy": true,
                        responsive: false,
                        //"scrollX": true,
                        // "scrollY": "800px",
                       // columnDefs: [
                       //     { width: 200, targets: 0 }
                        //],

                         fixedColumns: true,
                         "oLanguage": { "sSearch": "", "sLengthMenu": "\_MENU_" },
                        
                         "bAutoWidth": false,
                         
                         "aaSorting": [[0, 'asc']],
                         //"bPaginate": true,

                         //"sPaginationType": "full_numbers",<'col-xs-1'l>
                         "iDisplayLength": 10,
                         "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                         dom: 'Bfrtip',
                         buttons: [
                             'pageLength',
                             // 'excelHtml5',
                             {
                                 extend: 'excelHtml5',
                                 text: '<i class="fa fa-file-excel-o"></i> Excel'
                                 
                             },
                             {
                                 extend: 'pdfHtml5',
                                 text: '<i class="fa fa-file-pdf-o"></i> PDF',
                                 orientation: 'landscape',
                                 pageSize: 'LEGAL'
                             }
                             //{
                             //    extend: 'print',
                             //    text: '<i class="fa fa-print"></i> Print',
                             //    title: $('h1').text(),
                             //    exportOptions: {
                             //        columns: ':not(.no-print)'
                             //    },
                             //    footer: true,
                             //    autoPrint: false
                             //}, 
                             //{
                             //    extend: 'pdf',
                             //    text: '<i class="fa fa-file-pdf-o"></i> PDF',
                             //    title: $('h1').text(),
                             //    exportOptions: {
                             //        columns: ':not(.no-print)'
                             //    },
                             //    footer: true
                             //}
                         ],
                        // "bSortable": true,
                        //"aLengthMenu": [
                        //    [5, 10, 15, 20, -1],
                        //    [5, 10, 15, 20, "All"] // change per page values here
                        //],
                        // set the initial value
                       // "iDisplayLength": 10,
                       // "oLanguage": { "sSearch": "", "sLengthMenu": "\_MENU_" },
                       
                        //"bPaginate": true,

                        //"sPaginationType": "full_numbers",<'col-xs-1'l>
                        //buttons: [
                        //    { extend: 'print', className: 'btn dark btn-outline' },
                        //    { extend: 'copy', className: 'btn red btn-outline' },
                        //    { extend: 'pdf', className: 'btn green btn-outline' },
                        //    { extend: 'excel', className: 'btn yellow btn-outline ' },
                        //    { extend: 'csv', className: 'btn purple btn-outline ' },
                        //    { extend: 'colvis', className: 'btn dark btn-outline', text: 'Columns' }
                        //],
                        //dom:
                        //    "<'row'<'col-xs-2'l><'col-xs-6'f>>" +
                        //    "<'row'<'col-xs-12'tr>>", 
                        //"bFilter": false

                        initComplete: function () {

                        //    $('.dataTables_filter input[type="search"]').removeClass('input-sm')
                            $('.dataTables_filter input[type="search"]').removeClass('input-small')
                            $('.dataTables_filter input[type="search"]').attr('placeholder', 'Search  ....').css({ 'width': '450px' });
                        //    $("div.toolbar").
                        //        html('<a id="btn_NewNFA" class="btn btn-circle btn-icon-only btn-danger popovers" style="height:25px;width:26px;padding-top:2px" data-trigger="hover" data-placement="top" data-container="body" data-content="New NFA" href="NewNF.html?NFAID=0"><i class="fa fa-plus"></i></a>&nbsp;<a id="btn_Excel" data-action=3 class="btn btn-circle btn-icon-only btn-success popovers" style="height:25px;width:26px;padding-top:2px"  data-trigger="hover" data-placement="down" data-container="body" data-content="Export To Excel" href="javascript:;" onclick="fnExportExcel()"><i class="fa fa-file-excel-o"></i></a>');

                        //    $("div.cationicon")
                        //        .html('<i id="iconclass"></i>&nbsp;<span id="spanPanelCaption" style="font-size:15px"></span>');
                         }
                         

                     });
                    var tableWrapper = $('#tblVendorSummary_wrapper'); // datatable creates the table wrapper by adding with id {your_table_jd}_wrapper
                   
                   
                
            }
            else {
                jQuery('#tblVendorSummary > tbody').append("<tr><td colspan='8' style='text-align: center; color:red;'>No record found</td></tr>");
                $('#tblVendorSummary').dataTable({
                    "bDestroy": true,
                    "bPaginate": false,
                    "bLengthChange": false,
                    "bFilter": false,
                    "bInfo": false,
                    "bAutoWidth": false,
                    "bSort": true
                   
                   
                });
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
    });
}
function fetchBidVendorSummaryDetail() {
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    if (jQuery("#ddlBidFor option:selected").val() == 81) {
        jQuery("#ddlBidFor option:selected").val(0)
    }
    //alert(sessionStorage.getItem("APIPath") + "BidVendorSummary/fetchAdminBidSummaryDetailed/?BidTypeID=" + jQuery("#ddlBidtype option:selected").val() + "&BidForID=" + jQuery("#ddlBidFor option:selected").val() + "&ContinentId=" + 0 + "&CountryId=" + 0 + "&VendorId=" + jQuery("#hdnVendorID").val() + "&FromDate=" + jQuery("#txtFromDate").val() + "&ToDate=" + jQuery("#txtToDate").val() + "&BidSubject=" + jQuery("#txtbidsubject").val() + "&FinalStatus=" + jQuery("#ddlbidstatus option:selected").val() + "&UserID=" + encodeURIComponent(sessionStorage.getItem('UserID')) + "&CustomerID=" + sessionStorage.getItem('CustomerID') + "&ConfiguredBy=" + jQuery("#ddlconfiguredby option:selected").val())
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "BidVendorSummary/fetchAdminBidSummaryDetailed/?BidTypeID=" + jQuery("#ddlBidtype option:selected").val() + "&BidForID=" + jQuery("#ddlBidFor option:selected").val() + "&ContinentId=" + 0 + "&CountryId=" + 0 + "&VendorId=" + jQuery("#hdnVendorID").val() + "&FromDate=" + jQuery("#txtFromDate").val() + "&ToDate=" + jQuery("#txtToDate").val() + "&BidSubject=" + jQuery("#txtbidsubject").val() + "&FinalStatus=" + jQuery("#ddlbidstatus option:selected").val() + "&UserID=" + encodeURIComponent(sessionStorage.getItem('UserID')) + "&CustomerID=" + sessionStorage.getItem('CustomerID') + "&ConfiguredBy=" + jQuery("#ddlconfiguredby option:selected").val(),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        data: '',
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (BidData) {
            var LastHD = stringDivider("Last Invoice Price (LIP)", 15, "<br/>\n");
            var savinfLIP = stringDivider("Total Saving wrt LIP", 12, "<br/>\n");
            var savinfstart = stringDivider("Total Saving wrt SP", 12, "<br/>\n");
            var savinfTR = stringDivider("Total Saving wrt TP", 12, "<br/>\n");
            jQuery("#tblVendorSummarydetails").empty();
           
            jQuery('#tblVendorSummarydetails').append("<thead><tr><th class='bold'>Event ID</th><th class='bold'>Bid Subject</th><th class='bold'>Configured By</th><th class='bold'>Bid Date</th><th class='bold'>Item/Service</th><th class='bold'>Quantity</th><th class='bold'>UOM</th><th class='bold'>Currency</th><th>Vendor</th><th class='bold'>" + LastHD + "</th><th class='bold'>Start Price (SP)</th><th class='bold'>Target Price (TP)</th><th class='bold'>Initial Quote</th><th class='bold'>L1 Price</th><th class='bold'>" + savinfLIP + "</th><th class='bold'>" + savinfstart + "</th><th class='bold'>" + savinfTR + "</th><th>Bid Status</th></tr></thead>");
            if (BidData.length > 0) {
                var bID = 0;
                
                for (var i = 0; i < BidData.length; i++) {
                    var encrypdata = fnencrypt("BidID=" + BidData[i].BidID + "&BidTypeID=" + BidData[i].BidTypeID + "&BidForID=" + BidData[i].BidForID)
                    //var str = "<tr><td><a href='BidSummary.html?param=" + encrypdata + "' target='_blank'>" + BidData[i].BidSubject + "</a></td>";
                    var str = "<tr><td class=text-right><a onclick=getSummary(\'" + BidData[i].BidID + "'\,\'" + BidData[i].BidForID + "'\,\'0'\) href='javascript:;' >" + BidData[i].BidID + "</a></td>";
                   
                    str += "<td>" + BidData[i].BidSubject + "</td>";
                    str += "<td>" + BidData[i].ConfiguredBy + "</td>";
                   
                    //str += "<td>" + BidData[i].BidDate + "</td>";
                    var datearray = BidData[i].BidDate.split("/");
                   // BidDate = datearray[1] + '/' + datearray[0] + '/' + datearray[2];
                    BidDate = datearray[2] + '/' + datearray[1] + '/' + datearray[0];
                   // var millisecond = Date.parse(new Date(BidDate));
                   // str += "<td><span style='display: none;'>" + millisecond + "</span >" + BidData[i].BidDate + "</td>";
                    str += "<td>" + BidDate + "</td>";

                   
                   // var desitinationport = BidData[i].DestinationPort.replace(/  +/g, ' ');//remove end line and tab space
                   // var desitinationport = BidData[i].DestinationPort.replace(/[\n\r\t]/g, " ");//remove end line and tab space
                    var desitinationport = BidData[i].DestinationPort.replace(/<br\s*\/?>/gi, ' '); //remove br
                    //desitinationport=decodeEntities(desitinationport)
                   
                    str += "<td>" + desitinationport + "</td>";

                    str += "<td class=text-right>" + thousands_separators( BidData[i].Quantity) + "</td>";
                    str += "<td>" + BidData[i].UOM + "</td>";
                    str += "<td>" + BidData[i].CurrencyName + "</td>";
                    str += "<td>" + BidData[i].VendorName + "</td>";

                    ///////////////LIP//////////////////
                    if (BidData[i].LastInvoicePrice != 0) {
                        if (BidData[i].Role == "Administrator") {
                            str += '<td class=text-right><a href="javascript:;" style="text-decoration:none" onclick="editLIP(\'' + BidData[i].BidID + '\',\'' + BidData[i].SEID + '\',\'' + thousands_separators(BidData[i].LastInvoicePrice) + '\',\'LIP\')"> ' + thousands_separators(BidData[i].LastInvoicePrice) + '</a></td>';
                        }
                        else {
                            str += "<td class=text-right>" + thousands_separators(BidData[i].LastInvoicePrice) + "</td>";
                        }
                        
                    }
                    else {
                        str += '<td class=text-right><a href="javascript:;" style="text-decoration:none" onclick="editLIP(\'' + BidData[i].BidID + '\',\'' + BidData[i].SEID + '\',\''+0+'\',\'LIP\')"> ' + 0 + '</a></td>';
                    }
                  

                    ///////////////LIP//////////////////
                    str += "<td class=text-right>" + thousands_separators(BidData[i].StartPrice) + "</td>";

                    if (BidData[i].Targetprice != 0) {
                        if (BidData[i].Role == "Administrator") {
                            str += '<td class=text-right><a href="javascript:;" style="text-decoration:none" onclick="editLIP(\'' + BidData[i].BidID + '\',\'' + BidData[i].SEID + '\',\'' + thousands_separators(BidData[i].Targetprice) + '\',\'TP\')"> ' + thousands_separators(BidData[i].Targetprice) + '</a></td>';
                        }
                        else {
                            str += "<td class=text-right>" + thousands_separators(BidData[i].Targetprice) + "</td>";
                        }
                    }
                    else {
                        str += '<td class=text-right><a href="javascript:;" style="text-decoration:none" onclick="editLIP(\'' + BidData[i].BidID + '\',\'' + BidData[i].SEID + '\',\''+0+'\',\'TP\')"> ' + 0 + '</a></td>';
                    }
                  
                    str += "<td class=text-right>" + thousands_separators(BidData[i].InitialQuote) + "</td>";
                    str += "<td class=text-right>" + thousands_separators(BidData[i].MinPrice) + "</td>";
                    if (BidData[i].LastInvoicePrice != 0) {
                     
                        str += "<td class=text-right>" + thousands_separators(((BidData[i].LastInvoicePrice - BidData[i].MinPrice) * BidData[i].Quantity).round(2)) + "</td>"
                    }
                    else {
                        
                        str += '<td class=text-right>'+0+'</td>';
                    }
                    
                   
                    str += "<td class=text-right>" + thousands_separators(((BidData[i].StartPrice - BidData[i].MinPrice) * BidData[i].Quantity).round(2)) + "</td>";
                    if (BidData[i].Targetprice != 0) {
                        str += "<td class=text-right>" + thousands_separators(((BidData[i].Targetprice - BidData[i].MinPrice) * BidData[i].Quantity).round(2)) + "</td>";
                    }
                    else {
                        str += "<td class=text-right>" + 0 + "</td>";
                    }
                    str += "<td>" + BidData[i].FinalStatus + "</td>";
                    str += "</tr>";
                    jQuery('#tblVendorSummarydetails').append(str);
                }
                var table = $('#tblVendorSummarydetails');
                table.removeAttr('width').dataTable({
                    "bDestroy": true,
                    responsive: false,
                   // "scrollX": true,
                    // "scrollY": "800px",
                    //columnDefs: [
                    //    { width: 100, targets: 0 }
                    //],

                   
                    // "bSortable": true,
                    //"aLengthMenu": [
                    //    [5, 10, 15, 20, -1],
                    //    [5, 10, 15, 20, "All"] // change per page values here
                    //],
                    // set the initial value
                    
                    "oLanguage": { "sSearch": "", "sLengthMenu": "\_MENU_" },
                    fixedColumns: true,
                    "bAutoWidth": false,
                    "aaSorting": [[0, 'asc']],
                    //"bPaginate": true,

                    //"sPaginationType": "full_numbers",<'col-xs-1'l>
                    "iDisplayLength": 10,
                    "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                    dom: 'Bfrtip',
                    buttons: [
                        'pageLength',
                       // 'excelHtml5',
                        {
                            extend: 'excelHtml5',
                            exportOptions: {
                                columns: ':visible',
                                format: {
                                    body: function(data, column, node) {              
                                        return column === 4 ?
                                         data.replace(/[$,.]/g, '') : data.replace(/(&nbsp;|<([^>]+)>)/ig, "");
                                         data.replace(/<br\s*\/?>/ig, "\r\n");
                                         data;
 
                                    }
                                   
                                }
                            },
                            text: '<i class="fa fa-file-excel-o"></i> Excel',
                        },
                        {
                            extend: 'pdfHtml5',
                            text: '<i class="fa fa-file-pdf-o"></i> PDF',
                            orientation: 'landscape',
                            pageSize: 'LEGAL'
                        }
                        //{
                        //    extend: 'print',
                        //    text: '<i class="fa fa-print"></i> Print',
                        //    title: $('h1').text(),
                        //    exportOptions: {
                        //        columns: ':not(.no-print)'
                        //    },
                        //    footer: true,
                        //    autoPrint: false
                        //}, 
                        //{
                        //    extend: 'pdf',
                        //    text: '<i class="fa fa-file-pdf-o"></i> PDF',
                        //    title: $('h1').text(),
                        //    exportOptions: {
                        //        columns: ':not(.no-print)'
                        //    },
                        //    footer: true
                        //}
                    ],
                    //dom:
                    //    "<'row'<'col-xs-2'l><'col-xs-6'f>>" +
                    //    "<'row'<'col-xs-12'tr>>", 
                    //"bFilter": false

                    initComplete: function () {

                        //    $('.dataTables_filter input[type="search"]').removeClass('input-sm')
                        $('.dataTables_filter input[type="search"]').removeClass('input-small')
                       
                        $('.dataTables_filter input[type="search"]').attr('placeholder', 'Search  ....').css({ 'width': '450px' });
                        //    $("div.toolbar").
                        //        html('<a id="btn_NewNFA" class="btn btn-circle btn-icon-only btn-danger popovers" style="height:25px;width:26px;padding-top:2px" data-trigger="hover" data-placement="top" data-container="body" data-content="New NFA" href="NewNF.html?NFAID=0"><i class="fa fa-plus"></i></a>&nbsp;<a id="btn_Excel" data-action=3 class="btn btn-circle btn-icon-only btn-success popovers" style="height:25px;width:26px;padding-top:2px"  data-trigger="hover" data-placement="down" data-container="body" data-content="Export To Excel" href="javascript:;" onclick="fnExportExcel()"><i class="fa fa-file-excel-o"></i></a>');

                        //    $("div.cationicon")
                        //        .html('<i id="iconclass"></i>&nbsp;<span id="spanPanelCaption" style="font-size:15px"></span>');
                    }


                });
                var tableWrapper = $('#tblVendorSummarydetails_wrapper'); // datatable creates the table wrapper by adding with id {your_table_jd}_wrapper



            }
            else {
                jQuery('#tblVendorSummarydetails > tbody').append("<tr><td colspan='17' style='text-align: center; color:red;'>No record found</td></tr>");
                $('#tblVendorSummarydetails').dataTable({
                    "bDestroy": true,
                    "bPaginate": false,
                    "bLengthChange": false,
                    "bFilter": false,
                    "bInfo": false,
                    "bAutoWidth": false,
                    "bSort": true


                });
            }
            jQuery.unblockUI();
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
        
    });
   
}
function fetchBidVendorSummarySummarization() {
    if (jQuery("#ddlBidFor option:selected").val() == 81) {
        jQuery("#ddlBidFor option:selected").val(0)
    }
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "BidVendorSummary/fetchAdminBidSummaryfull/?BidTypeID=" + jQuery("#ddlBidtype option:selected").val() + "&BidForID=" + jQuery("#ddlBidFor option:selected").val() + "&ContinentId=" + 0 + "&CountryId=" + 0 + "&VendorId=" + jQuery("#hdnVendorID").val() + "&FromDate=" + jQuery("#txtFromDate").val() + "&ToDate=" + jQuery("#txtToDate").val() + "&BidSubject=" + jQuery("#txtbidsubject").val() + "&FinalStatus=" + jQuery("#ddlbidstatus option:selected").val() + "&UserID=" + encodeURIComponent(sessionStorage.getItem('UserID')) + "&CustomerID=" + sessionStorage.getItem('CustomerID') + "&ConfiguredBy=" + jQuery("#ddlconfiguredby option:selected").val(),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        data: '',
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (BidData) {
            var BidLIP = stringDivider("Bid Value as per Last Invoice Price(LIP)", 15, "<br/>\n");
            var BidSP = stringDivider("Bid Value at Start Price(SP)", 15, "<br/>\n");
            var BidTP = stringDivider("Bid Value at Target Price(TP)", 15, "<br/>\n");
            var BidFinal = stringDivider("Bid Value as per L1", 15, "<br/>\n");
            var savinfLIP = stringDivider("Total Saving wrt LIP", 12, "<br/>\n");
            var savinfstart = stringDivider("Total Saving wrt SP", 12, "<br/>\n");
            var savinfTR = stringDivider("Total Saving wrt TP", 12, "<br/>\n");
            jQuery("#tblVendorSummarySUmzation").empty();

            jQuery('#tblVendorSummarySUmzation').append("<thead><tr><th class='bold'>Event ID</th><th class='bold'>Bid Subject</th><th class='bold'>Configured By</th><th class='bold'>Bid Date</th><th class='bold'>Currency</th><th class='bold'>" + BidLIP + "</th><th class='bold'>" + BidSP + "</th><th class='bold'>" + BidTP + "</th><th class='bold'>" + BidFinal + "</th><th class='bold'>" + savinfLIP + "</th><th class='bold'>" + savinfstart + "</th><th class='bold'>" + savinfTR + "</th></tr></thead>");
            if (BidData.length > 0) {
                var bID = 0;
                for (var i = 0; i < BidData.length; i++) {
                   
                    var str = "<tr><td class=text-right><a onclick=getSummary(\'" + BidData[i].BidID + "'\,\'" + BidData[i].BidForID + "'\,\'0'\) href='javascript:;' >" + BidData[i].BidID + "</a></td>";
                    str += "<td>" + BidData[i].BidSubject + "</td>";
                    str += "<td>" + BidData[i].ConfiguredBy + "</td>";
                   
                    //str += "<td>" + BidData[i].BidDate + "</td>";
                    var datearray = BidData[i].BidDate.split("/");
                   // BidDate = datearray[1] + '/' + datearray[0] + '/' + datearray[2];
                    BidDate = datearray[2] + '/' + datearray[1] + '/' + datearray[0];
                   // var millisecond = Date.parse(new Date(BidDate));
                   // str += "<td><span style='display: none;'>" + millisecond + "</span >" + BidData[i].BidDate + "</td>";
                    str += "<td>" + BidDate + "</td>";

                    str += "<td>" + BidData[i].CurrencyName + "</td>";

                   
                    str += "<td class=text-right>" + thousands_separators(BidData[i].BidValueAsLIP) + "</td>";
                    str += "<td class=text-right>" + thousands_separators(BidData[i].BidValueAsStartPrice) + "</td>";
                    str += "<td class=text-right>" + thousands_separators(BidData[i].BidValueAsTargetPrice) + "</td>";
                    str += "<td class=text-right>" + thousands_separators(BidData[i].BidValueAsPrice) + "</td>";
                   
                    if (BidData[i].BidValueAsLIP != 0) {

                        str += "<td class=text-right>" + thousands_separators((BidData[i].BidValueAsLIP - BidData[i].BidValueAsPrice).round(2)) + "</td>"
                    }
                    else {
                        str += "<td class=text-right>" + 0 + "</td>"
                    }


                    str += "<td class=text-right>" + thousands_separators((BidData[i].BidValueAsStartPrice - BidData[i].BidValueAsPrice).round(2)) + "</td>";
                    if (BidData[i].BidValueAsTargetPrice != 0) {

                        str += "<td class=text-right>" + thousands_separators((BidData[i].BidValueAsTargetPrice - BidData[i].BidValueAsPrice).round(2)) + "</td>";
                    }
                    else {
                        str += "<td class=text-right>" + 0 + "</td>"
                    }
                   
                    str += "</tr>";
                    jQuery('#tblVendorSummarySUmzation').append(str);
                }
                var table = $('#tblVendorSummarySUmzation');
                table.removeAttr('width').dataTable({
                    "bDestroy": true,
                    //  responsive: true,
                    // "scrollX": true,
                    // "scrollY": "800px",
                    //columnDefs: [
                    //    { width: 100, targets: 0 }
                    //],


                    // "bSortable": true,
                    //"aLengthMenu": [
                    //    [5, 10, 15, 20, -1],
                    //    [5, 10, 15, 20, "All"] // change per page values here
                    //],
                    // set the initial value

                    "oLanguage": { "sSearch": "", "sLengthMenu": "\_MENU_" },
                    fixedColumns: true,
                    "bAutoWidth": false,
                    "aaSorting": [[0, 'asc']],
                    //"bPaginate": true,

                    //"sPaginationType": "full_numbers",<'col-xs-1'l>
                    "iDisplayLength": 10,
                    "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                    dom: 'Bfrtip',
                    buttons: [
                        'pageLength',
                        // 'excelHtml5',
                        {
                            extend: 'excelHtml5',
                            text: '<i class="fa fa-file-excel-o"></i> Excel',
                            
                        },
                        {
                            extend: 'pdfHtml5',
                            text: '<i class="fa fa-file-pdf-o"></i> PDF',
                            orientation: 'landscape',
                            pageSize: 'LEGAL'
                        }
                        
                    ],
                    
                    initComplete: function () {

                        $('.dataTables_filter input[type="search"]').removeClass('input-small')
                        $('.dataTables_filter input[type="search"]').attr('placeholder', 'Search  ....').css({ 'width': '450px' });
                       
                    }


                });
                var tableWrapper = $('#tblVendorSummarySUmzation_wrapper'); // datatable creates the table wrapper by adding with id {your_table_jd}_wrapper



            }
            else {
                jQuery('#tblVendorSummarySUmzation > tbody').append("<tr><td colspan='11' style='text-align: center; color:red;'>No record found</td></tr>");
                $('#tblVendorSummarySUmzation').dataTable({
                    "bDestroy": true,
                    "bPaginate": false,
                    "bLengthChange": false,
                    "bFilter": false,
                    "bInfo": false,
                    "bAutoWidth": false,
                    "bSort": true


                });
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
   })

}
function fetchBidVendorSummaryDetailFA() {

    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "BidVendorSummary/fetchAdminBidSummaryDetailedFA/?BidTypeID=" + jQuery("#ddlBidtype option:selected").val() + "&BidForID=" + jQuery("#ddlBidFor option:selected").val() + "&ContinentId=" + 0 + "&CountryId=" + 0 + "&VendorId=" + jQuery("#hdnVendorID").val() + "&FromDate=" + jQuery("#txtFromDate").val() + "&ToDate=" + jQuery("#txtToDate").val() + "&BidSubject=" + jQuery("#txtbidsubject").val() + "&FinalStatus=" + jQuery("#ddlbidstatus option:selected").val() + "&UserID=" + encodeURIComponent(sessionStorage.getItem('UserID')) + "&CustomerID=" + sessionStorage.getItem('CustomerID') + "&ConfiguredBy=" + jQuery("#ddlconfiguredby option:selected").val(),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        data: '',
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (BidData) {


            var PriceFor = "";
            var LastHD = stringDivider("Last Invoice Price (LIP)", 15, "<br/>\n");
            var savinfLIP = stringDivider("Total Saving wrt LIP", 12, "<br/>\n");
            var savinfTR = stringDivider("Total Saving wrt TP", 12, "<br/>\n");


            if (jQuery("#ddlBidFor option:selected").val() == "81") {

                PriceFor = 'H1 Price';
                var savinfstart = stringDivider("Total Saving wrt SP", 12, "<br/>\n");
                var startPrice = 'Start Price (SP)'
            }
            else {
                PriceFor = 'L1 Price';
                var savinfstart = stringDivider("Total Saving wrt CP", 12, "<br/>\n");
                var startPrice = 'Ceiling/ Max. Price (CP)'
            }

            // $('#tblVendorSummarydetails').DataTable().clear().destroy();
            // jQuery("#tblVendorSummarydetails >thead").empty();
            jQuery("#tblVendorSummarydetails").empty();



            // jQuery("#tblVendorSummarydetails >tbody").empty();
            
            jQuery('#tblVendorSummarydetails').append("<thead><tr><th class='bold'>Event ID</th><th class='bold'>Bid Subject</th><th class='bold'>Configured By</th><th class='bold'>Bid Date</th><th class='bold'>Item/Product</th><th class='bold'>Quantity</th><th class='bold'>UOM</th><th class='bold'>Currency</th><th>Vendor</th><th class='bold'>" + LastHD + "</th><th class='bold'>" + startPrice + "</th><th class='bold'>Target Price (TP)</th><th class='bold'>Initial Quote</th><th class='bold'>" + PriceFor + "</th><th class='bold'>" + savinfLIP + "</th><th class='bold'>" + savinfstart + "</th><th class='bold'>" + savinfTR + "</th><th>Bid Status</th></tr></thead>");
            if (BidData.length > 0) {
                var bID = 0;
                for (var i = 0; i < BidData.length; i++) {

                    var str = "<tr><td class=text-right><a onclick=getSummary(\'" + BidData[i].BidID + "'\,\'" + BidData[i].BidForID + "'\,\'0'\) href='javascript:;'>" + BidData[i].BidID + "</a></td>";
                    str += "<td>" + BidData[i].BidSubject + "</td>";
                    str += "<td>" + BidData[i].ConfiguredBy + "</td>";

                    //str += "<td>" + BidData[i].BidDate + "</td>";
                    var datearray = BidData[i].BidDate.split("/");
                   // BidDate = datearray[1] + '/' + datearray[0] + '/' + datearray[2];
                    BidDate = datearray[2] + '/' + datearray[1] + '/' + datearray[0];
                   // var millisecond = Date.parse(new Date(BidDate));
                    //str += "<td><span style='display: none;'>" + millisecond + "</span >" + BidData[i].BidDate + "</td>";
                    str += "<td>" + BidDate + "</td>";


                    // var desitinationport = BidData[i].DestinationPort.replace(/[\n\r\t]/g, " ");//remove end line and tab space
                    var desitinationport = BidData[i].DestinationPort.replace(/<br\s*\/?>/gi, ' '); //remove br
                    str += "<td>" + desitinationport + "</td>";

                    str += "<td class=text-right>" + thousands_separators(BidData[i].Quantity) + "</td>";
                    str += "<td>" + BidData[i].UOM + "</td>";
                    str += "<td>" + BidData[i].CurrencyName + "</td>";
                    str += "<td>" + BidData[i].VendorName + "</td>";

                    if (BidData[i].LastInvoicePrice != 0) {
                        if (BidData[i].Role == "Administrator") {
                            str += '<td class=text-right><a href="javascript:;" style="text-decoration:none" onclick="editLIP(\'' + BidData[i].BidID + '\',\'' + BidData[i].SEID + '\',\'' + thousands_separators(BidData[i].LastInvoicePrice) + '\',\'LIP\')"> ' + thousands_separators(BidData[i].LastInvoicePrice) + '</a></td>';
                        }
                        else {
                            str += "<td class=text-right>" + thousands_separators(BidData[i].LastInvoicePrice) + "</td>";
                        }

                    }
                    else {
                        str += '<td class=text-right><a href="javascript:;" style="text-decoration:none" onclick="editLIP(\'' + BidData[i].BidID + '\',\'' + BidData[i].SEID + '\',\'' + 0 + '\',\'LIP\')"> ' + 0 + '</a></td>';
                    }

                    str += "<td class=text-right>" + thousands_separators(BidData[i].StartPrice) + "</td>";

                    if (BidData[i].Targetprice != 0) {
                        if (BidData[i].Role == "Administrator") {
                            str += '<td class=text-right><a href="javascript:;" style="text-decoration:none" onclick="editLIP(\'' + BidData[i].BidID + '\',\'' + BidData[i].SEID + '\',\'' + thousands_separators(BidData[i].Targetprice) + '\',\'TP\')"> ' + thousands_separators(BidData[i].Targetprice) + '</a></td>';
                        }
                        else {
                            str += "<td class=text-right>" + thousands_separators(BidData[i].Targetprice) + "</td>";
                        }
                    }
                    else {
                        str += '<td class=text-right><a href="javascript:;" style="text-decoration:none" onclick="editLIP(\'' + BidData[i].BidID + '\',\'' + BidData[i].SEID + '\',\'' + 0 + '\',\'TP\')"> ' + 0 + '</a></td>';
                    }
                    str += "<td class=text-right>" + thousands_separators(BidData[i].InitialQuote) + "</td>";
                    str += "<td class=text-right>" + thousands_separators(BidData[i].MinPrice) + "</td>";

                    if (jQuery("#ddlBidFor option:selected").val() == "81") {
                        if (BidData[i].LastInvoicePrice != 0) {

                            str += "<td class=text-right>" + thousands_separators(((BidData[i].MinPrice - BidData[i].LastInvoicePrice) * BidData[i].Quantity).round(2)) + "</td>"
                        }
                        else {
                            str += "<td class=text-right>" + 0 + "</td>"
                        }


                        str += "<td class=text-right>" + thousands_separators(((BidData[i].MinPrice - BidData[i].StartPrice) * BidData[i].Quantity).round(2)) + "</td>";
                        if (BidData[i].Targetprice != 0) {
                            str += "<td class=text-right>" + thousands_separators(((BidData[i].MinPrice - BidData[i].Targetprice) * BidData[i].Quantity).round(2)) + "</td>";
                        }
                        else {
                            str += "<td class=text-right>" + 0 + "</td>";
                        }
                    }
                    else {
                        if (BidData[i].LastInvoicePrice != 0) {

                            str += "<td class=text-right>" + thousands_separators(((BidData[i].LastInvoicePrice - BidData[i].MinPrice) * BidData[i].Quantity).round(2)) + "</td>"
                        }
                        else {
                            str += "<td class=text-right>" + 0 + "</td>"
                        }


                        str += "<td class=text-right>" + thousands_separators(((BidData[i].StartPrice - BidData[i].MinPrice) * BidData[i].Quantity).round(2)) + "</td>";
                        if (BidData[i].Targetprice != 0) {
                            str += "<td class=text-right>" + thousands_separators(((BidData[i].Targetprice - BidData[i].MinPrice) * BidData[i].Quantity).round(2)) + "</td>";
                        }
                        else {
                            str += "<td class=text-right>" + 0 + "</td>";
                        }

                    }
                    str += "<td>" + BidData[i].FinalStatus + "</td>";
                    str += "</tr>";
                    jQuery('#tblVendorSummarydetails').append(str);
                }
                var table = $('#tblVendorSummarydetails');
                table.removeAttr('width').dataTable({
                    "bDestroy": true,

                    "oLanguage": { "sSearch": "", "sLengthMenu": "\_MENU_" },
                    fixedColumns: false,
                    "bAutoWidth": false,
                    "aaSorting": [[0, 'asc']],
                    //"bPaginate": true,

                    //"sPaginationType": "full_numbers",<'col-xs-1'l>
                    "iDisplayLength": 10,
                    "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                    dom: 'Bfrtip',
                    buttons: [
                        'pageLength',
                        // 'excelHtml5',
                        {
                            extend: 'excelHtml5',
                            text: '<i class="fa fa-file-excel-o"></i> Excel',
                        },
                        {
                            extend: 'pdfHtml5',
                            text: '<i class="fa fa-file-pdf-o"></i> PDF',
                            orientation: 'landscape',
                            pageSize: 'LEGAL'
                        }

                    ],

                    initComplete: function () {

                        //    $('.dataTables_filter input[type="search"]').removeClass('input-sm')
                        $('.dataTables_filter input[type="search"]').removeClass('input-small')

                        $('.dataTables_filter input[type="search"]').attr('placeholder', 'Search  ....').css({ 'width': '450px' });

                    }


                });
                var head_item = table.api().columns(13).header();
                $(head_item).html(PriceFor);

                var head_itemSP = table.api().columns(10).header();
                $(head_itemSP).html(startPrice);

                var head_itemsavingSP = table.api().columns(15).header();
                $(head_itemsavingSP).html(savinfstart);

                var tableWrapper = $('#tblVendorSummarydetails_wrapper'); // datatable creates the table wrapper by adding with id {your_table_jd}_wrapper
                // $(table.column(10).header()).text(PriceFor);



            }
            else {
                jQuery('#tblVendorSummarydetails > tbody').append("<tr><td colspan='17' style='text-align: center; color:red;'>No record found</td></tr>");
                $('#tblVendorSummarydetails').dataTable({
                    "bDestroy": true,
                    "bPaginate": false,
                    "bLengthChange": false,
                    "bFilter": false,
                    "bInfo": false,
                    "bAutoWidth": false,
                    "bSort": true


                });
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
    });
}
function fetchBidVendorSummarySummarizationFA() {
    
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "BidVendorSummary/fetchAdminBidSummaryfullFA/?BidTypeID=" + jQuery("#ddlBidtype option:selected").val() + "&BidForID=" + jQuery("#ddlBidFor option:selected").val() + "&ContinentId=" + 0 + "&CountryId=" + 0 + "&VendorId=" + jQuery("#hdnVendorID").val() + "&FromDate=" + jQuery("#txtFromDate").val() + "&ToDate=" + jQuery("#txtToDate").val() + "&BidSubject=" + jQuery("#txtbidsubject").val() + "&FinalStatus=" + jQuery("#ddlbidstatus option:selected").val() + "&UserID=" + encodeURIComponent(sessionStorage.getItem('UserID')) + "&CustomerID=" + sessionStorage.getItem('CustomerID') + "&ConfiguredBy=" + jQuery("#ddlconfiguredby option:selected").val(),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        data: '',
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (BidData) {
            var BidLIP = stringDivider("Bid Value as per Last Invoice Price(LIP)", 15, "<br/>\n");

            var BidTP = stringDivider("Bid Value at Target Price(TP)", 15, "<br/>\n");
            var BidFinal = stringDivider("Bid Value as per L1", 15, "<br/>\n");
            var savinfLIP = stringDivider("Total Saving wrt LIP", 12, "<br/>\n");

            var savinfTR = stringDivider("Total Saving wrt TP", 12, "<br/>\n");

            if (jQuery("#ddlBidFor option:selected").val() == "81") {

                var BidFinal = stringDivider("Bid Value as per H1", 15, "<br/>\n");
                var BidSP = stringDivider("Bid Value at Start Price(SP)", 15, "<br/>\n");
                var savinfstart = stringDivider("Total Saving wrt SP", 12, "<br/>\n");
            }
            else {
                var BidFinal = stringDivider("Bid Value as per L1", 15, "<br/>\n");
                var BidSP = stringDivider("Bid Value at Ceiling/ Max. Price(CP)", 15, "<br/>\n");
                var savinfstart = stringDivider("Total Saving wrt CP", 12, "<br/>\n");
            }

            jQuery("#tblVendorSummarySUmzation").empty();

            jQuery('#tblVendorSummarySUmzation').append("<thead><tr><th class='bold'>Event ID</th><th class='bold'>Bid Subject</th><th class='bold'>Configured By</th><th class='bold'>Bid Date</th><th class='bold'>Currency</th><th class='bold'>" + BidLIP + "</th><th class='bold'>" + BidSP + "</th><th class='bold'>" + BidTP + "</th><th class='bold'>" + BidFinal + "</th><th class='bold'>" + savinfLIP + "</th><th class='bold'>" + savinfstart + "</th><th class='bold'>" + savinfTR + "</th></tr></thead>");
            if (BidData.length > 0) {
                var bID = 0;
                for (var i = 0; i < BidData.length; i++) {

                    var str = "<tr><td class=text-right><a onclick=getSummary(\'" + BidData[i].BidID + "'\,\'" + BidData[i].BidForID + "'\,\'0'\) href='javascript:;'>" + BidData[i].BidID + "</a></td>";
                    str += "<td>" + BidData[i].BidSubject + "</td>";
                    str += "<td>" + BidData[i].ConfiguredBy + "</td>";

                    // str += "<td>" + BidData[i].BidDate + "</td>";
                    var datearray = BidData[i].BidDate.split("/");
                    //BidDate = datearray[1] + '/' + datearray[0] + '/' + datearray[2];
                    //var millisecond = Date.parse(new Date(BidDate));
                    BidDate = datearray[2] + '/' + datearray[1] + '/' + datearray[0];
                   // str += "<td><span style='display: none;'>" + millisecond + "</span >" + BidData[i].BidDate + "</td>";
                    str += "<td>" + BidDate + "</td>";

                    str += "<td>" + BidData[i].CurrencyName + "</td>";
                    str += "<td class=text-right>" + thousands_separators(BidData[i].BidValueAsLIP) + "</td>";
                    str += "<td class=text-right>" + thousands_separators(BidData[i].BidValueAsStartPrice) + "</td>";
                    str += "<td class=text-right>" + thousands_separators(BidData[i].BidValueAsTargetPrice) + "</td>";
                    str += "<td class=text-right>" + thousands_separators(BidData[i].BidValueAsPrice) + "</td>";
                    if (jQuery("#ddlBidFor option:selected").val() == "81") {
                        if (BidData[i].BidValueAsLIP != 0) {

                            str += "<td class=text-right>" + thousands_separators((BidData[i].BidValueAsPrice - BidData[i].BidValueAsLIP).round(2)) + "</td>"
                        }
                        else {
                            str += "<td class=text-right>" + 0 + "</td>"
                        }


                        str += "<td class=text-right>" + thousands_separators((BidData[i].BidValueAsPrice - BidData[i].BidValueAsStartPrice).round(2)) + "</td>";
                        if (BidData[i].BidValueAsTargetPrice != 0) {

                            str += "<td class=text-right>" + thousands_separators((BidData[i].BidValueAsPrice - BidData[i].BidValueAsTargetPrice).round(2)) + "</td>";
                        }
                        else {
                            str += "<td class=text-right>" + 0 + "</td>"
                        }
                    }
                    else {
                        if (BidData[i].BidValueAsLIP != 0) {

                            str += "<td class=text-right>" + thousands_separators((BidData[i].BidValueAsLIP - BidData[i].BidValueAsPrice).round(2)) + "</td>"
                        }
                        else {
                            str += "<td class=text-right>" + 0 + "</td>"
                        }


                        str += "<td class=text-right>" + thousands_separators((BidData[i].BidValueAsStartPrice - BidData[i].BidValueAsPrice).round(2)) + "</td>";
                        if (BidData[i].BidValueAsTargetPrice != 0) {

                            str += "<td class=text-right>" + thousands_separators((BidData[i].BidValueAsTargetPrice - BidData[i].BidValueAsPrice).round(2)) + "</td>";
                        }
                        else {
                            str += "<td class=text-right>" + 0 + "</td>"
                        }

                    }

                    str += "</tr>";
                    jQuery('#tblVendorSummarySUmzation').append(str);
                }
                var table = $('#tblVendorSummarySUmzation');
                table.removeAttr('width').dataTable({
                    "bDestroy": true,
                    //  responsive: true,
                    // "scrollX": true,
                    // "scrollY": "800px",
                    //columnDefs: [
                    //    { width: 100, targets: 0 }
                    //],


                    // "bSortable": true,
                    //"aLengthMenu": [
                    //    [5, 10, 15, 20, -1],
                    //    [5, 10, 15, 20, "All"] // change per page values here
                    //],
                    // set the initial value

                    "oLanguage": { "sSearch": "", "sLengthMenu": "\_MENU_" },
                    fixedColumns: true,
                    "bAutoWidth": false,
                    "aaSorting": [[0, 'asc']],
                    //"bPaginate": true,

                    //"sPaginationType": "full_numbers",<'col-xs-1'l>
                    "iDisplayLength": 10,
                    "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
                    dom: 'Bfrtip',
                    buttons: [
                        'pageLength',
                        // 'excelHtml5',
                        {
                            extend: 'excelHtml5',
                            text: '<i class="fa fa-file-excel-o"></i> Excel',
                        },
                        {
                            extend: 'pdfHtml5',
                            text: '<i class="fa fa-file-pdf-o"></i> PDF',
                            orientation: 'landscape',
                            pageSize: 'LEGAL'
                        }

                    ],

                    initComplete: function () {

                        $('.dataTables_filter input[type="search"]').removeClass('input-small')
                        $('.dataTables_filter input[type="search"]').attr('placeholder', 'Search  ....').css({ 'width': '450px' });

                    }


                });
                var head_item = table.api().columns(8).header();
                $(head_item).html(BidFinal);
                var head_itemCP = table.api().columns(6).header();
                $(head_itemCP).html(BidSP);
                var head_itemsavingCP = table.api().columns(10).header();
                $(head_itemsavingCP).html(savinfstart);
                var tableWrapper = $('#tblVendorSummarySUmzation_wrapper'); // datatable creates the table wrapper by adding with id {your_table_jd}_wrapper



            }
            else {
                jQuery('#tblVendorSummarySUmzation > tbody').append("<tr><td colspan='11' style='text-align: center; color:red;'>No record found</td></tr>");
                $('#tblVendorSummarySUmzation').dataTable({
                    "bDestroy": true,
                    "bPaginate": false,
                    "bLengthChange": false,
                    "bFilter": false,
                    "bInfo": false,
                    "bAutoWidth": false,
                    "bSort": true


                });
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
    })

}
function getSummary(bidid, bidforid, RFQID) {

    if (RFQID == 0) {
        var encrypdata = fnencrypt("BidID=" + bidid + "&BidTypeID=" + jQuery("#ddlBidtype option:selected").val() + "&BidForID=" + bidforid)
        window.open("BidSummary.html?param=" + encrypdata, "_blank")
        //  window.open("BidSummary.html?BidID=" + bidid + "&BidTypeID=" + jQuery("#ddlBidtype option:selected").val() + "&BidForID=" + bidforid, "_blank")

    }
    else {
        var encrypdata = fnencrypt("RFQID=" + RFQID + "&BidID=" + bidid)
        window.open("eRARFQReport.html?param=" + encrypdata, "_blank")
        //if (sessionStorage.getItem("APIPath") == 32) {
        //    window.open("AzeRFQAnalysis.html?BidID=" + bidid + "&RFQID=" + RFQID+ "&RFQSubject=" + subject, "_blank")
        //}
        //else {
        //    window.open("eRFQAnalysis.html?RFQID=" + RFQID+ "&RFQSubject=" + subject, "_blank")
        //}
    }
}


function editLIP(bidid, seid, price,fieldName) {
    
    if(fieldName == "TP"){
        $('#lblfieldName').html("Target Price <span class='required'>*</span>")
    }
    else{
        $('#lblfieldName').html("Last Invoice Price <span class='required'>*</span>")
    }
    $('#txtlastinvoiceprice').val(price)
    $('#hddfieldName').val(fieldName);
    $('#hddnBidID').val(bidid);
    $('#hddnItemID').val(seid);
    
    $("#editLastInvoiceprice").modal("show")
}
var error = $('#msgErrorEditEvent');
function updlastinvoiceprice() {

    if ($('#txtlastinvoiceprice').val() == "") {//|| $('#txtlastinvoiceprice').val()==0
        error.find("span").html('Please Enter Last Invoice Price value.');
        error.show();
        Metronic.scrollTo(error, -200);
        error.fadeOut(3000);
        return false;

    }
    var Data = {
        "BidTypeID": jQuery("#ddlBidtype option:selected").val() ,
        "BidID": $('#hddnBidID').val(),
        "ItemID": $("#hddnItemID").val(),
        "LastInvoicePrice": removeThousandSeperator($('#txtlastinvoiceprice').val()),
        "For": $('#hddfieldName').val()
       
    }

      //  alert(JSON.stringify(Data))
        jQuery.ajax({
            url: sessionStorage.getItem("APIPath") + "ConfigureBid/UpdateLastInvoicePrice/",
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            type: "POST",
            data: JSON.stringify(Data),
            contentType: "application/json; charset=utf-8",
            success: function (data, status, jqXHR) {
                if (data[0].Success == "1") {
                    
                    //fetchallexportdetails();
                    if (jQuery("#ddlBidtype option:selected").val() == 7) {
                        fetchBidVendorSummaryDetail();
                    }
                    else {
                        fetchBidVendorSummaryDetailFA();
                    }
                        $("#editLastInvoiceprice").modal("hide")
                    
                } 

                jQuery.unblockUI();
            },
            error: function (xhr, status, error) {

                var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }

                return false;
                jQuery.unblockUI();
            }
        });
    
}
$('#editLastInvoiceprice').on("hidden.bs.modal", function () {
    $('#txtlastinvoiceprice').val('')
     $('#hddnBidID').val(0),
      $("#hddnItemID").val(0),
       
      $('#hddfieldName').val('')
})
$('.datepicker .datepicker-dropdown').css("left", "1000px");
jQuery("#search").keyup(function () {

    jQuery("#tblvendorlist tr:has(td)").hide(); // Hide all the rows.

    var iCounter = 0;
    var sSearchTerm = jQuery('#search').val(); //Get the search box value

    if (sSearchTerm.length == 0) //if nothing is entered then show all the rows.
    {
        jQuery("#tblvendorlist tr:has(td)").show();
        return false;
    }

    //Iterate through all the td.
    jQuery("#tblvendorlist tr:has(td)").children().each(function () {

        var cellText = jQuery(this).text().toLowerCase();
        if (cellText.indexOf(sSearchTerm.toLowerCase()) >= 0) //Check if data matches
        {

            jQuery(this).parent().show();
            iCounter++;

            return true;
        }

    });
});
function FetchVenderNotInvited() {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ResetInviteVendor/fetchBidsAuto/?UserID=&BidID=" + BidID + "&CustomerID=" + sessionStorage.getItem('CustomerID'),
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        dataType: "json",
        success: function(data) {
            jQuery("#tblvendorlist > tbody").empty();
            if (data.length > 0) {
                $('#inviteVendorBody').show();
                for (var i = 0; i < data.length; i++) {
                    var str = "<tr><td><div class=\"checker\" id=\"uniform-chkbidTypes\"><span  id=\"spanchecked\"><input class=\"chkboxwithval\"  type=\"checkbox\" Onclick=\"Check(this)\"; id=\"chkvender\" value=" + (data[i].VendorID + ',' + data[i].EmailId) + " style=\"cursor:pointer\" name=\"chkvender\"/></span></div></td><td> " + data[i].VendorName + " </td></tr>";
                    jQuery('#tblvendorlist > tbody').append(str);
                }
            }
            else {
                $('#inviteVendorBody').hide();
            }


        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
    });
}

$("#chkAll").click(function() {
    if ($("#chkAll").is(':checked') == true) {
        
        $('table#tblvendorlist').closest('.inputgroup').removeClass('has-error');
        $("#tblvendorlist> tbody > tr").each(function(index) {
            $(this).find("span#spanchecked").addClass("checked");
        });
    }
    else {
        $("#tblvendorlist> tbody > tr").each(function(index) {
            $(this).find("span#spanchecked").removeClass("checked");
        });
    }
});

function Check(event) {
    if ($(event).closest("span#spanchecked").attr('class') == 'checked') {
        $(event).closest("span#spanchecked").removeClass("checked")
    }
    else {
        $(event).closest("span#spanchecked").addClass("checked")
        $('#divvendorlist').find('span#spandynamic').hide();
        $('table#tblvendorlist').closest('.inputgroup').removeClass('has-error');
    }
}

function ValidateVendor() {
    var status = "false";
   
    
    $("#tblvendorlist> tbody > tr").each(function(index) {
        if ($(this).find("span#spanchecked").attr('class') == 'checked') {
            status = "True";
        }
    });
    if (status == "false") {
        $('.alert-danger').show();
        $('#spandanger').html('Please select at least one vendor');
        $('.alert-danger').fadeOut(5000);
        Metronic.scrollTo($('.alert-danger'), -200);

        status = "false";
    }
    return status;
}

function invitevendors() {

    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    if (BidID == null || BidID == '') {
        $('.alert-danger').show();
        $('#spandanger').html('Cannot invite vendors without Bid...');
        $('.alert-danger').fadeOut(5000);
        Metronic.scrollTo($('.alert-danger'), -200);
        jQuery.unblockUI();
        return false;

    }
    else if (ValidateVendor() == 'false') {
        jQuery.unblockUI();
        return false;

    }
    else {
        var checkedValue = '';
        var temp = new Array();
        $("#tblvendorlist> tbody > tr").each(function(index) {
            if ($(this).find("span#spanchecked").attr('class') == 'checked') {
                temp = ($(this).find("#chkvender").val()).split(",");

                checkedValue = checkedValue + " select  " + BidID + ",'" + temp[1] + "','N','" + temp[0] + "' union";
            }
        });
        if (checkedValue != '') {
            checkedValue = 'insert into BidVendorDetails(BidId,EmailId,MailSent,VendorID) ' + checkedValue
            checkedValue = checkedValue.substring(0, checkedValue.length - 6);
        }

        var data = {
        "QueryString": checkedValue,
        "BidId": BidID,
            "BidTypeID": BidTypeID,
            "UserID": sessionStorage.getItem("UserID")
        }
       // alert(JSON.stringify(data)) 
         jQuery.ajax({
             url: sessionStorage.getItem("APIPath") + "ResetInviteVendor/Invitevendors",
             beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
             data: JSON.stringify(data),
             type: "POST",
             contentType: "application/json",
             success: function(data) {
                 if (data[0].Flag == "1") {
                     $('.alert-success').show();
                     $('#spansuccess1').html('Vendor Invited Successfully..');
                     FetchVenderNotInvited();
                     $('.alert-success').fadeOut(5000);
                     Metronic.scrollTo($('.alert-success'), -200);
                     jQuery.unblockUI();
                 }
             },
             error: function (xhr, status, error) {

                 var err = eval("(" + xhr.responseText + ")");
                 if (xhr.status === 401) {
                     error401Messagebox(err.Message);
                 }

                 return false;
                 jQuery.unblockUI();
             }
         });
        jQuery.unblockUI();
        return true;
    }
}