﻿//var VendorID = 0;
//var BidID = 0;
var BidTypeID = 0;
var BidForID = 0;
//var UserType = "";
var Duration = '0.00';

$(document).ready(function () {
    
    fetchVendorBidDetails()
    
});

function fetchVendorBidDetails() {
    var url = '';
    var tncAttachment = '';
    var anyotherAttachment = '';

    url = sessionStorage.getItem("APIPath") + "VendorParticipation/FetchBidDetailsSea_mq/?BidID=" + sessionStorage.getItem("hdnselectedBidSubjID") + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("VendorId"));

    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: url,
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
            if (data.length > 0) {
                if (data[0].BidForID == 6) {
                    jQuery('#divExWorks').show();
                }
                tncAttachment = data[0].TermsConditions.replace(/\s/g, "%20");
                anyotherAttachment = data[0].Attachment.replace(/\s/g, "%20");
                jQuery("#lblbidsubject").text(data[0].BidSubject);
                jQuery("#lblbidDetails").text(data[0].BidDetails);
                jQuery("#lblbiddate").text(data[0].BidDate);
                jQuery("#lblbidtime").text(data[0].BidTime);
                jQuery("a#lnkTermsAttachment").text(data[0].TermsConditions);
                jQuery("a#lnkTermsAttachment").attr("href", "PortalDocs/Bid/" + sessionStorage.getItem("BidID") + "/" + tncAttachment)
                jQuery("a#lnkAnyOtherAttachment").text(data[0].Attachment);
                jQuery("a#lnkAnyOtherAttachment").attr("href", "PortalDocs/Bid/" + sessionStorage.getItem("BidID") + "/" + anyotherAttachment)
                jQuery("#lblbidduration").text(data[0].BidDuration);
                jQuery("#lblcurrency").text(data[0].TargetRate + ' ' + data[0].CurrencyName);
                jQuery("#lblConvRate").text(data[0].ConversionRate);
                jQuery("#lblstatus").text(data[0].Status);

                BidTypeID = data[0].BidTypeID;
                BidForID = data[0].BidForID;

                fetchBidSummaryVendorSea(data[0].BidTypeID, data[0].BidForID);
                jQuery.unblockUI();
            }
        },
        error: function (xhr) {
            jQuery("#error").text(xhr.d);
            jQuery.unblockUI();
        }
    });
    
}


function fetchBidSummaryVendorSea(bidtypeid, bidforid) {
    var url = '';

    url = sessionStorage.getItem("APIPath") + "VendorParticipationSea/fetchBidSummaryVendorSea/?BidID=" + sessionStorage.getItem("hdnselectedBidSubjID") + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("VendorId")) + "&BidforID=" + BidForID + "&UserType=MQ";
    
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: url,
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function(data, status, jqXHR) {

            if (data.length > 0) {
                //alert(data[0].NoOfExtension)
                jQuery("#lblInitialQUote").text(data[0].InitialQuote);
                jQuery("#lblCurrentQuote").text(data[0].LowestQuote);
                
            }

        },
        error: function(xhr) {
            jQuery("#error").text(xhr.d);
            jQuery.unblockUI();
        }
    });
}

function InsUpdQuoteSea() {
	jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    var vendorID = 0;

    vendorID = sessionStorage.getItem('VendorId');    

	
		var QuoteSea = {
        "VendorID": vendorID,
        "BidID": sessionStorage.getItem("hdnselectedBidSubjID"),        
        "Price": jQuery("#txtFreight").val(),
        "ExWorks": jQuery("#txtExWorks").val(),
        "LoggedInID": sessionStorage.getItem("UserID"),
        "Remarks": ''
    }
    //alert(JSON.stringify(QuoteSea));
    jQuery.ajax({
    url: sessionStorage.getItem("APIPath") + "VendorParticipationSea/ParticipationSea_mq/",
        type: "POST",
        data: JSON.stringify(QuoteSea),
        contentType: "application/json; charset=utf-8",
        success: function (data, status, jqXHR) {
        bootbox.alert("<br /> Transaction successful. ", function() {
            window.location = sessionStorage.getItem('HomePage');
            return false;
        });
            //InsManualQuoteRecords();
            jQuery("#txtFreight").val('')
            jQuery("#txtExWorks").val('')
            jQuery.unblockUI();
        },
        error: function (xhr) {
            jQuery("#error").text(xhr.d);
            jQuery.unblockUI();
        }
    });

}

function InsManualQuoteRecords() {
    var data = {
        "UserID": vendorID,
        "BidID": sessionStorage.getItem("BidID"),
        "BidTypeID": BidTypeID,
        "BidForID": BidForID,
        "Price": jQuery("#txtFreight").val(),
        "ExWorks": jQuery("#txtExWorks").val()
    }
}








var FormValidation = function () {
    var ValidateUser = function () {
        var form1 = $('#FormparticipateSea');
        var error1 = $('.alert-danger', form1);
        var success1 = $('.alert-success', form1);

        form1.validate({
            errorElement: 'span',
            errorClass: 'help-block',
            focusInvalid: false,
            ignore: "",

            rules: {
                txtFreight: {
                    required: true,
                    number: true,
                    minlength: 1,
                    maxlength: 5
                }
            },
            messages: {
                txtFreight: {
                    required: "Please enter amount",
                    number: "number only"
                }
            },
            invalidHandler: function (event, validator) { //display error alert on form submit              
                success1.hide();
                error1.show();
                App.scrollTo(error1, -300);
            },
            highlight: function (element) { // hightlight error inputs
                $(element)
                        .closest('.form-group').addClass('has-error'); // set error class to the control group
            },
            unhighlight: function (element) { // revert the change done by hightlight
                $(element)
                        .closest('.form-group').removeClass('has-error'); // set error class to the control group
            },
            success: function (label) {
                label
                        .closest('.form-group').removeClass('has-error'); // set success class to the control group
            },
            submitHandler: function (form) {
            showreasonmq_modal();
            }
        });
    }
    var handleWysihtml5 = function () {
        if (!jQuery().wysihtml5) {
            return;
        }
        if ($('.wysihtml5').size() > 0) {
            $('.wysihtml5').wysihtml5({
                "stylesheets": ["assets/plugins/bootstrap-wysihtml5/wysiwyg-color.css"]
            });
        }
    }
    return {
        init: function () {
            handleWysihtml5();
            ValidateUser();
        }
    };
} ();


var form = $('#frm_remarks');
var error = $('.alert-success');
var success = $('.alert-danger');

function FormValidate() {
    form.validate({

        doNotHideMessage: true, //this option enables to show the error/success messages on tab switch.

        errorElement: 'span', //default input error message container

        errorClass: 'help-block help-block-error', // default input error message class

        focusInvalid: false, // do not focus the last invalid input

        rules: {

            txtremarks_mq: {

                required: true,
                maxlength: 100

            },
            file1: {

                required: true

            }


        },

        messages: {

    },



    invalidHandler: function(event, validator) {

    },

    highlight: function(element) {

        $(element).closest('.form-group').removeClass('has-success').addClass('has-error');

    },

    unhighlight: function(element) {

        $(element).closest('.form-group').removeClass('has-error');
    },

    success: function(label) {
    },
    submitHandler: function(form) {

        InsManualQuotesHisotry();
    }



});

}

function showreasonmq_modal() {
    $('#reasonmq_modal').modal('show');
}

function cancelmanualQuote() {
    window.location = sessionStorage.getItem('HomePage')
}


function InsManualQuotesHisotry() {

    var attachment = jQuery('#file1').val().substring(jQuery('#file1').val().lastIndexOf('\\') + 1);

    var mquotes = {

        "BidID": sessionStorage.getItem("hdnselectedBidSubjID"),
        "BidSubject": $.trim($('#lblbidsubject').html()),
        "CustomerID": sessionStorage.getItem('CustomerID'),
        "Remarks": $('#txtremarks_mq').val(),
        "Attachment": attachment,
        "BidtypeID": $.trim(BidTypeID),
        "ForVendorID": sessionStorage.getItem("VendorId"),
        "EnteredBy": sessionStorage.getItem("UserName")

    }

    //alert(JSON.stringify(mquotes))

    jQuery.ajax({
        type: "POST",

        contentType: "application/json; charset=utf-8",

        url: sessionStorage.getItem("APIPath") + "VendorParticipation/InsManualQuotesHisotry/",

        crossDomain: true,

        async: false,

        data: JSON.stringify(mquotes),


        success: function(data, status, jqXHR) {
            //alert(data[0].Success)
            if (data[0].Success == '1') {

                fileUploader(sessionStorage.getItem("hdnselectedBidSubjID"))

            } else {
                bootbox.alert("Error Connecting server. Please try later.");
            }


        },
        error: function(xhr) {
            jQuery("#error").text(xhr.d);
        }
    });


}


function fileUploader(bidID) {

    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });

    var fileTerms = $('#file1');

    var fileDataTerms = fileTerms.prop("files")[0];

    var formData = new window.FormData();

    formData.append("fileTerms", fileDataTerms);

    formData.append("fileAnyOther", '');

    formData.append("AttachmentFor", 'ManualBids');

    formData.append("BidID", bidID);
    formData.append("VendorID", '');



    $.ajax({

        url: 'ConfigureFileAttachment.ashx',

        data: formData,

        processData: false,

        contentType: false,

        asyc: false,

        type: 'POST',

        success: function(data) {
            $('#reasonmq_modal').modal('hide');
            jQuery.unblockUI();
            InsUpdQuoteSea()

        },

        error: function() {

            bootbox.alert("Attachment error.");
            jQuery.unblockUI();
        }

    });

}