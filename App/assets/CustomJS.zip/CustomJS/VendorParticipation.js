﻿$(document).ready(function () {
    fetchVendorDetails()
    fillhelp();
    if (sessionStorage.getItem("BidTypeID") == "2") {
        jQuery('#divAirImport').css('display', 'block');
        fetchVendorBeforeBidDetailsAir();
    }
    else if (sessionStorage.getItem("BidTypeID") == "3") {
        jQuery('#divSeaImport').css('display', 'block');
        fetchVendorBeforeBidDetails();
    }
    else if (sessionStorage.getItem("BidTypeID") == "1") {
        jQuery('#divproduct').css('display', 'block');
        fetchVendorBeforeBidDetailsproduct(BidForID);
    }
    

    jQuery('#divTotal').css('display', 'none');
});
var BidTypeID = 0;
var BidForID = 0;
function fetchVendorDetails() {
    var url = '';
    if (sessionStorage.getItem("ContactEmailID") == 'null' || sessionStorage.getItem("ContactEmailID") == '') {
        url = sessionStorage.getItem("APIPath") + "VendorParticipation/FetchBidDetailsForVendorMain/?BidID=" + sessionStorage.getItem("BidID") + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("UserID"));
    } else {
        url = sessionStorage.getItem("APIPath") + "VendorParticipation/FetchBidDetailsForVendorMain/?BidID=" + sessionStorage.getItem("BidID") + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("BidUserID"));
    }

	var tncAttachment = '';
    	var anyotherAttachment = '';
   
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: url,
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
           
            if (data.length > 0) {
		tncAttachment = data[0].TermsConditions.replace(/\s/g, "%20");
                 anyotherAttachment = data[0].Attachment.replace(/\s/g, "%20");
		
                jQuery("#lblbidsubject").text(data[0].BidSubject);
                jQuery("#lblbidDetails").text(data[0].BidDetails);
                jQuery("#lblbiddate").text(data[0].BidDate);
                jQuery("#lblbidtime").text(data[0].BidTime);

                jQuery("a#lnkTermsAttachment").text(data[0].TermsConditions);
                jQuery("a#lnkTermsAttachment").attr("href", "PortalDocs/Bid/" + sessionStorage.getItem("BidID") + "/" + tncAttachment)
                jQuery("a#lnkAnyOtherAttachment").text(data[0].Attachment);
                jQuery("a#lnkAnyOtherAttachment").attr("href", "PortalDocs/Bid/" + sessionStorage.getItem("BidID") + "/" + anyotherAttachment)
                //var duration = (data[0].BidDuration + data[0].Extension);
                jQuery("#lblbidduration").text(data[0].BidDuration);
                jQuery("#lblcurrency").text(data[0].CurrencyName);
                jQuery("#lblConvRate").text(data[0].ConversionRate);
                //jQuery("#lblstatus").text(data[0].Status);

                BidTypeID = data[0].BidTypeID;
                BidForID = data[0].BidForID;
                if (sessionStorage.getItem("BidTypeID") == "4") {
                    jQuery('#divdomestic').css('display', 'block');
                    fetchVendorBeforeBidDetailsDomestic(BidForID);
                }

                showHideDivtotal(data[0].BidForID);

            }
            else {
                bootbox.alert("Oops! Bid has been expired.", function () {
					window.location = sessionStorage.getItem('MainUrl');
                    return true;
                });
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else {
                jQuery("#error").text(xhr.d);
            }
            return false;
            jQuery.unblockUI();
        }
        
    });
}

function fetchVendorBeforeBidDetails() {   
    var url = '';
    if (sessionStorage.getItem("ContactEmailID") == 'null' || sessionStorage.getItem("ContactEmailID") == '') {
  
        url = sessionStorage.getItem("APIPath") + "VendorParticipationSea/fetchVendorBeforeBidDetails/?BidID=" + sessionStorage.getItem("BidID") + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("UserID"));
        
    }else{
        url = sessionStorage.getItem("APIPath") + "VendorParticipationSea/fetchVendorBeforeBidDetails/?BidID=" + sessionStorage.getItem("BidID") + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("BidUserID"));
    }
  
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: url,
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
            if (data.length > 0) {                
                //txtCeilingPrice
                jQuery("#txtBAF").val(data[0].BAF);
                jQuery("#txtCAF").val(data[0].CAF);
                jQuery("#txtFwdDOCharges").val(data[0].ForwardersDO);
                jQuery("#txtShipingLine").val(data[0].ShippingLine);
                jQuery("#txtSailingDays").val(data[0].SailingDays);
                jQuery("#txtOceanTransitTime").val(data[0].OceanTransitTime);
                jQuery("#txtHaulageCharges").val(data[0].InlandHaulage);
                jQuery("#txtDOCharges").val(data[0].ShippingLineDO);
                jQuery("#txtCleaningCharges").val(data[0].ContainerClgChg);
                jQuery("#txtOtherCharges").val(data[0].ShippingLineOther);
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else {
                jQuery("#error").text(xhr.d);
            }
            return false;
            jQuery.unblockUI();
        }
    });
}
function fetchVendorBeforeBidDetailsproduct() {
    var url = '';
    
    if (sessionStorage.getItem("ContactEmailID") == 'null' || sessionStorage.getItem("ContactEmailID") == '') {
  
        url = sessionStorage.getItem("APIPath") + "VendorParticipation/fetchBidProductServiceDetails/?BidID=" + sessionStorage.getItem("BidID") + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("UserID"));
        
    }else{
     
        url = sessionStorage.getItem("APIPath") + "VendorParticipation/fetchBidProductServiceDetails/?BidID=" + sessionStorage.getItem("BidID") + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("BidUserID"));
    }
    //alert(url);
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: url,
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
            jQuery("#tblproductservices").empty()
            
            jQuery("#tblproductservices").append("<thead><th class=hide></th><th class=hide></th><th>ShortName</th><th >Attachment</th><th>Quantity</th><th>UOM</th><th>Bid start price</th><th>TAT(days)</th><th>Validity(days)</th><th>Warranty(days)</th><th>VAT(%)</th><th>CST(%)</th><th>Excise(%)</th><th>Participation?</th></thead>");
            
            for (var i = 0; i < data.length; i++) {
            var attach = (data[i].Attachments).replace(/\s/g, "%20");
            
             if(attach==""){
                    jQuery('<tr id=trid' + i + '><td class=hide>' + data[i].PSHeaderID + '</td><td class=hide>' + data[i].ParticipationStatus + '</td><td id=td'+i+' class=popovers    data-trigger="hover" data-placement="top">' + data[i].ShortName + '</td><td>No Attachment</td><td>' + data[i].Quantity + '</td><td>' + data[i].UOM + '</td><td id=Ceilingprice' + i + '></td><td><input type=text class=form-control id=TAT' + i + ' autocomplete=off /><td><input type=text class=form-control id=validity' + i + ' autocomplete=off /><td><input type=text class=form-control id=warranty' + i + ' autocomplete=off /></td><td><input type=text class=form-control id=vat' + i + ' autocomplete=off onkeyup=disablenextControl(\'vat' + i + '\',\'cst' + i + '\') /></td><td><input type=text class=form-control id=cst' + i + ' autocomplete=off onkeyup=disablenextControl(\'cst' + i + '\',\'vat' + i + '\') /></td><td><input type=text class=form-control id=excise' + i + ' autocomplete=off /></td><td id=checktd' + i + '><div class=\"checker\" id=\"uniform-chkbidTypes\" style="width:80px"><span  id=\"spancheckedParticipationProduct\" ><input type=\"checkbox\" Onclick=\"CheckparticipationProductfn(this,' + i + ')\"; id=\"chkvechicle\"  style=\"cursor:pointer\" name=\"chkvendorparticipation\"/></span>&nbsp;<label>Yes</label></div></td><td id=psid' + i + ' class="display-none">' + data[i].PSID + '</td></tr>').appendTo("#tblproductservices");
             }
             else{
                jQuery('<tr id=trid' + i + '><td class=hide>' + data[i].PSHeaderID + '</td><td class=hide>' + data[i].ParticipationStatus + '</td><td  id=td'+i+' class=popovers    data-trigger="hover" data-placement="top">' + data[i].ShortName + '</td><td><a href=PortalDocs/Bid/' + sessionStorage.getItem('BidUserID') + '/' + data[i].AttachmentSeqID + '/' + attach + ' style=text-decoration:none; >' + data[i].Attachments + '</a></td><td>' + data[i].Quantity + '</td><td>' + data[i].UOM + '</td><td id=Ceilingprice' + i + '></td><td><input type=text class=form-control id=TAT' + i + ' autocomplete=off /><td><input type=text class=form-control id=validity' + i + ' autocomplete=off /><td><input type=text class=form-control id=warranty' + i + ' autocomplete=off /></td><td><input type=text class=form-control id=vat' + i + ' autocomplete=off onkeyup=disablenextControl(\'vat' + i + '\',\'cst' + i + '\') /></td><td><input type=text class=form-control id=cst' + i + ' autocomplete=off onkeyup=disablenextControl(\'cst' + i + '\',\'vat' + i + '\') /></td><td><input type=text class=form-control id=excise' + i + ' autocomplete=off /></td><td id=checktd' + i + '><div class=\"checker\" id=\"uniform-chkbidTypes\" style="width:80px"><span  id=\"spancheckedParticipationProduct\" ><input type=\"checkbox\" Onclick=\"CheckparticipationProductfn(this,' + i + ')\"; id=\"chkvechicle\"  style=\"cursor:pointer\" name=\"chkvendorparticipation\"/></span>&nbsp;<label>Yes</label></div></td><td id=psid' + i + ' class="display-none">' + data[i].PSID + '</td></tr>').appendTo("#tblproductservices");
                }
               $('#td' + i).popover({
                        html: true,
                        'container': 'body',
                        content: data[i].Description
                    });  

                if (data[i].MaskVendor == "Y") {
                    $('#Ceilingprice' + i).html('Not Disclosed')
                }
                else {
                    $('#Ceilingprice' + i).html(data[i].CeilingPrice)
                }
               
				if(data[i].Status=="N"){
					 $("#checktd" + i).find("span#spancheckedParticipationProduct").removeClass("checked")
				}
				else if(data[i].Status == "Y") {
					 $("#checktd" + i).find("span#spancheckedParticipationProduct").addClass("checked")
				}
				
                 if (data[i].PSHeaderID > 0) {

                    
					 if(data[i].VAT != 0 || data[i].VAT != '0' ){
						  $('#cst' + i).attr('disabled', 'disabled')
						 
					 }else if(data[i].CST != 0 || data[i].CST != '0' ){
						 $('#vat' + i).attr('disabled', 'disabled')
					 }
                 }
                $('#TAT' + i).val(data[i].TAT)
                $('#vat' + i).val(data[i].VAT)
                $('#cst' + i).val(data[i].CST)
                $('#validity' + i).val(data[i].Validity)
                $('#warranty' + i).val(data[i].Warranty)
                $('#excise' + i).val(data[i].Excise)

                if ($("#checktd" + i).find("span#spancheckedParticipationProduct").attr('class') == 'checked') {
                    $('#TAT' + i).attr("disabled", false)
                    $('#vat' + i).attr("disabled", false)
                    $('#cst' + i).attr("disabled", false)
                    $('#validity' + i).attr("disabled", false)
                    $('#warranty' + i).attr("disabled", false)
                    $('#excise' + i).attr("disabled", false)
                }
                else {
                    $('#TAT' + i).attr("disabled", true)
                    $('#vat' + i).attr("disabled", true)
                    $('#cst' + i).attr("disabled", true)
                    $('#validity' + i).attr("disabled", true)
                    $('#warranty' + i).attr("disabled", true)
                    $('#excise' + i).attr("disabled", true)
                }
                // if (data[i].VAT == 0) {
                    // $('#vat' + i).attr("disabled", true)
                // }
                // else {
                    // $('#vat' + i).attr("disabled", false)
                // }
                // if (data[i].CST == 0) {
                   
                    // $('#cst' + i).attr("disabled", true)
                // }
                // else {
                    // $('#cst' + i).attr("disabled", false)
                // }
                if (data[i].ParticipationStatus == "Yes") {
					if(data[i].VAT != 0 || data[i].VAT != '0' ){
						  $('#cst' + i).attr('disabled', 'disabled')
						 
					 }else if(data[i].CST != 0 || data[i].CST != '0' ){
						 $('#vat' + i).attr('disabled', 'disabledd')
					 }
					
                    $('#trid' + i).css('background-color', 'grey')
                    $("#checktd" + i).first().find('input[type="checkbox"]').prop("disabled", true);

                }
                else {
					if(data[i].VAT != 0 || data[i].VAT != '0' ){
						  $('#cst' + i).attr('disabled', 'disabled')
						 
					 }else if(data[i].CST != 0 || data[i].CST != '0' ){
						 $('#vat' + i).attr('disabled', 'disabledd')
					 }
                    $('#trid' + i).css('background-color', '')
                    $('#checktd' + i).attr("disabled", false)
                    $("#checktd" + i).first().find('input[type="checkbox"]').prop("disabled", false);

                }
               
            }
            
               
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else {
                jQuery("#error").text(xhr.d);
            }
            return false;
            jQuery.unblockUI();
        }
    });
}

function disablenextControl(inputID, nxtinputID) {
   
    if ($('#' + inputID).val() != '' || $('#' + inputID).val() > '0') {
        
        $('#' + nxtinputID).attr('disabled', true);
        $('#' + inputID).val().replace(0,'');
    } else  {
        $('#' + nxtinputID).attr('disabled', false);
        $('#' + inputID).val('0')
    }

    if ($('#' + inputID).val() != 0) {
        var text = $('#' + inputID).val();
        if (text.slice(0, 1) == 0) {
            $('#' + inputID).val(text.slice(1, text.length));
        }
    }
    
}

function CheckparticipationProductfn(event, p) {
    if ($(event).closest("span#spancheckedParticipationProduct").attr('class') == 'checked') {
        $(event).closest("span#spancheckedParticipationProduct").removeClass("checked")
        $('#TAT' + p).attr("disabled", true)
        $('#validity' + p).attr("disabled", true)
        $('#warranty' + p).attr("disabled", true)
        $('#excise' + p).attr("disabled", true)
        $('#vat' + p).attr("disabled", true)
        $('#cst' + p).attr("disabled", true)

        //if ($('#TAT' + p).val() == 0) {
        //    $('#TAT' + p).val(0)
        //    $('#validity' + p).val(0)
        //    $('#warranty' + p).val(0)
        //    $('#vat' + p).val(0)
        //    $('#cst' + p).val(0)
        //}

        $('#TAT' + p).css("border-color", "")
        $('#validity' + p).css("border-color", "")
        $('#warranty' + p).css("border-color", "")
        $('#vat' + p).css("border-color", "")
        $('#cst' + p).css("border-color", "")
        $('#excise' + p).css("border-color", "")


    }
    else {
        $(event).closest("span#spancheckedParticipationProduct").addClass("checked")
        $('#TAT' + p).attr("disabled", false)
        $('#validity' + p).attr("disabled", false)
        $('#warranty' + p).attr("disabled", false)
        $('#vat' + p).attr("disabled", false)
        $('#cst' + p).attr("disabled", false)
        $('#excise' + p).attr("disabled", false)


    }
}
function fnproceedforProduct() {
  jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
	var vendorID = 0;
    if (sessionStorage.getItem('ContactEmailID') == 'null' || sessionStorage.getItem('ContactEmailID') == '') {
        vendorID = sessionStorage.getItem('UserID');
    }
    else {
        vendorID = sessionStorage.getItem('BidUserID');
    }

    var i = 0;
    var insertquery = '';
    var updateQuery = '';
    var condition = "true";
    $("#tblproductservices> tbody > tr").each(function (index) {

        if ($(this).find("span#spancheckedParticipationProduct").attr('class') == 'checked') {
           
            if (($('#TAT' + i).val() == "") || (!/^[0-9]+$/.test($('#TAT' + i).val())) || ($('#validity' + i).val() == "")  || (!/^[0-9]+$/.test($('#validity' + i).val())) || ($('#warranty' + i).val() == "")  || (!/^[0-9]+$/.test($('#warranty' + i).val())) || ($('#vat' + i).val() == "") || (!/^[0-9]\d{0,9}(\.\d{1,3})??$/.test($('#vat' + i).val())) || ($('#cst' + i).val() == "") || (!/^[0-9]\d{0,9}(\.\d{1,3})??$/.test($('#cst' + i).val()))||($('#excise' + i).val() == "") || (!/^[0-9]\d{0,9}(\.\d{1,3})??$/.test($('#excise' + i).val()))) {
                condition = 'false';
               
                //if ($('#vat' + i).is(':disabled') && $('#vat' + i).val() == 0) {
                   
                //    condition = 'true';
                //}
                //else {
                   
                //    condition = 'false';
                    
                //}
                //if ($('#cst' + i).is(':disabled') && $('#cst' + i).val() == 0) {

                //    condition = 'true';
                //}
                //else {
                //   condition = 'false';
                // }
            }
            else {
                if (i == 0) {
                    insertquery = 'insert into VendorPSParticipationHeader(BIDID,VendorID,ShortName,TAT,Validity,Warranty,VAT,CST,Excise,Status,PSID,EntryDate)';
                }

                if ($.trim($(this).find('td:eq(1)').html()) == "No") {
                    insertquery = insertquery + " select " + sessionStorage.getItem('BidID') + ",dbo.Decrypt('" + vendorID + "'),'" + $.trim($(this).find('td:eq(2)').html()) + "'," + $('#TAT' + i).val().trim() + "," + $('#validity' + i).val().trim() + "," + $('#warranty' + i).val().trim() + "," + $('#vat' + i).val().trim() + "," + $('#cst' + i).val().trim()+"," + $('#excise' + i).val().trim() + ",'Y'," + $.trim($('#psid' + i).html()) + ",getdate() union"
                    i = i + 1;
                }
                else {

                    updateQuery = updateQuery + " update VendorPSParticipationHeader set TAT=" + $('#TAT' + i).val().trim() + ",Validity=" + $('#validity' + i).val().trim() + ",Warranty=" + $('#warranty' + i).val().trim() + ",VAT=" + $('#vat' + i).val().trim() + ",CST=" + $('#cst' + i).val().trim() + ",Excise="+$('#excise' + i).val().trim()+",PSID=" + $.trim($('#psid' + i).html()) + " where PSHeaderID=" + $.trim($(this).find('td:eq(0)').html())
                    i = i + 1;
                }
            }
           
            if (condition == "false") {
                
                if ($('#TAT' + i).val().trim() == "" || (!/^[0-9]+$/.test($('#TAT' + i).val()))) {

                    $('#TAT' + i).css("border-color", "#a94442")
                    
                }
                if ($('#validity' + i).val().trim() == "" || (!/^[0-9]+$/.test($('#validity' + i).val()))) {
                    $('#validity' + i).css("border-color", "#a94442")
                }
               
                if ($('#warranty' + i).val().trim() == "" || (!/^[0-9]+$/.test($('#warranty' + i).val()))) {
                    $('#warranty' + i).css("border-color", "#a94442")
                }
                
                if ($('#vat' + i).val().trim() == "" || (!/^[0-9]\d{0,9}(\.\d{1,3})??$/.test($('#vat' + i).val()))) { // 
                   
                        $('#vat' + i).css("border-color", "#a94442")
                                
                }

                if ($('#cst' + i).val().trim() == "" || (!/^[0-9]\d{0,9}(\.\d{1,3})??$/.test($('#cst' + i).val()))) { //  || $('#cst' + i).val() == 0
                  
                        $('#cst' + i).css("border-color", "#a94442")
                    
                }
            if ($('#excise' + i).val().trim() == "" || (!/^[0-9]\d{0,9}(\.\d{1,3})??$/.test($('#excise' + i).val()))) { //  || $('#cst' + i).val() == 0
                  
                        $('#excise' + i).css("border-color", "#a94442")
                    
                }
               
                jQuery.unblockUI();
                $('#divalerterrorproduct').show()
                $('#spanerrorproduct').html('Please Enter Data with Number only.')
                   return false;
            }
        }
        else {

            if (i == 0) {
                insertquery = 'insert into VendorPSParticipationHeader(BIDID,VendorID,ShortName,TAT,Validity,Warranty,VAT,CST,Excise,Status,PSID,EntryDate)';
            }

            if ($.trim($(this).find('td:eq(1)').html()) == "No") {
                insertquery = insertquery + " select " + sessionStorage.getItem('BidID') + ",dbo.Decrypt('" + vendorID + "'),'" + $.trim($(this).find('td:eq(2)').html()) + "'," + 0 + "," + 0 + "," + 0 + "," + 0 + "," + 0 + ","+0+",'N'," + $.trim($('#psid' + i).html()) + ",getdate() union"
                i = i + 1;
            }
            else {
                updateQuery = updateQuery + " update VendorPSParticipationHeader set TAT=" + $('#TAT' + i).val().trim() + ",Validity=" + $('#validity' + i).val().trim() + ",Warranty=" + $('#warranty' + i).val().trim() + ",VAT=" + $('#vat' + i).val().trim() + ",CST=" + $('#cst' + i).val().trim() + "Excise="+$('#excise' + i).val().trim()+",PSID=" + $.trim($('#psid' + i).html()) + " where PSHeaderID=" + $.trim($(this).find('td:eq(0)').html())
                i = i + 1;
            }
        }
    });
    setTimeout(function () {
        jQuery('#divalerterrorproduct').css('display', 'none');

    }, 2000);
    if (insertquery == 'insert into VendorPSParticipationHeader(BIDID,VendorID,ShortName,TAT,Validity,Warranty,VAT,CST,Excise,Status,PSID,EntryDate)') {
        insertquery = 'print 1'
    }
    else {

        insertquery = insertquery.substring(0, insertquery.length - 6);
    }
    if (condition == "true") {
        var data = {
            "BidID": sessionStorage.getItem('BidID'),
            "VendorID": vendorID,
            "insertQuery": insertquery,
            "updateQuery": updateQuery
        }

        //alert(JSON.stringify(data))
        jQuery.ajax({
            url: sessionStorage.getItem("APIPath") + "VendorParticipation/insUpdBidProductServiceDetails/",
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            type: "POST",
            data: JSON.stringify(data),
            contentType: "application/json; charset=utf-8",
            success: function (data, status, jqXHR) {

                if (data[0].BidID > 0) {
                    jQuery('#divalertsucessproduct').css('display', 'block');
                    window.location = "ParticipateBidOtherItem.html";
                }else{
					
					jQuery('#divalertsucessproduct').css('display', 'block');
                    bootbox.alert("Bid has not been started yet.");				
				}
				jQuery.unblockUI();	
            },
            error: function (xhr, status, error) {

                var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }
                else {
                    jQuery("#error").text(xhr.d);
                }
                return false;
                jQuery.unblockUI();
            }
        });
        setTimeout(function () {
            jQuery('#divalertsucessproduct').css('display', 'none');
            resetfn(i)
        }, 2000);
    }
}
function fetchVendorBeforeBidDetailsDomestic(BidForID) {

    var url = '';
    if (sessionStorage.getItem("ContactEmailID") == 'null' || sessionStorage.getItem("ContactEmailID") == '') {

        url = sessionStorage.getItem("APIPath") + "VendorParticipation/fetchBidDomesticOriginDestiDetails/?BidID=" + sessionStorage.getItem("BidID") + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("UserID"));

    } else {
        url = sessionStorage.getItem("APIPath") + "VendorParticipation/fetchBidDomesticOriginDestiDetails/?BidID=" + sessionStorage.getItem("BidID") + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("BidUserID")); 
            
    }
  
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: url,
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
            jQuery("#tbloriginDestination").empty()

            if (data.length > 0) {
                if (BidForID == 8 || BidForID == 7) {
                    jQuery("#tbloriginDestination").append("<thead><th>Vehicle</th><th>Origin</th><th>Destination</th><th>Docket Charges</th><th>FOV</th><th>FSC</th><th>CFT</th><th>Min. ChargeableWt</th><th>ODA</th><th>TAT(days)</th><th>Participation?</th></thead>");
                    for (var i = 0; i < data.length; i++) {

                        jQuery('<tr id=trid' + i + '><td class=hide>' + data[i].VDomesticHeaderID + '</td><td class=hide>' + data[i].ParticipationStatus + '</td><td class=hide id=vid' + i + '>' + data[i].VehicleTypeID + '</td><td class=hide id=oid' + i + '>' + data[i].OriginPlaceID + '</td><td class=hide id=did' + i + '>' + data[i].DestinationPlaceID + '</td><td>' + data[i].VehicleTypeName + '</td><td>' + data[i].Origin + '</td><td>' + data[i].Destination + '</td><td><input type=text class=form-control id=DoKch' + i + ' autocomplete=off /></td><td><input type=text class=form-control id=FOV' + i + ' autocomplete=off  /></td><td><input type=text class=form-control id=FSC' + i + '  autocomplete=off /></td><td><input type=text class=form-control id=CFT' + i + '  autocomplete=off /></td><td><input type=text class=form-control id=MinCharge' + i + '  autocomplete=off  /></td><td><input type=text class=form-control id=ODA' + i + '   value=' + data[i].ODA + '  autocomplete=off /></td><td><input type=text class=form-control id=TAT' + i + '  autocomplete=off  /></td><td id=checktd' + i + '><div class=\"checker\" id=\"uniform-chkbidTypes\"><span  id=\"spancheckedParticipation\"><input type=\"checkbox\" Onclick=\"Checkparticipationfn(this,' + i + ')\"; id=\"chkvechicle\"  style=\"cursor:pointer\" name=\"chkvendorparticipation\"/></span></div></td><td class=display-none id=DRouteID'+i+'>'+data[i].RouteID+'</td></tr>').appendTo("#tbloriginDestination");

                        if (data[i].DocketCharge != 0) {

                            $("#checktd" + i).find("span#spancheckedParticipation").addClass("checked")
                        }
                        if ($("#checktd" + i).find("span#spancheckedParticipation").attr('class') == 'checked') {
                            $('#DoKch' + i).attr("disabled", false)
                            $('#FOV' + i).attr("disabled", false)
                            $('#FSC' + i).attr("disabled", false)
                            $('#CFT' + i).attr("disabled", false)
                            $('#ODA' + i).attr("disabled", false)
                            $('#MinCharge' + i).attr("disabled", false)
                            $('#TAT' + i).attr("disabled", false)
                        }
                        else {
                            $('#DoKch' + i).attr("disabled", true)
                            $('#FOV' + i).attr("disabled", true)
                            $('#FSC' + i).attr("disabled", true)
                            $('#CFT' + i).attr("disabled", true)
                            $('#ODA' + i).attr("disabled", true)
                            $('#MinCharge' + i).attr("disabled", true)
                            $('#TAT' + i).attr("disabled", true)
                        }
                        $('#DoKch' + i).val(data[i].DocketCharge)
                        $('#FOV' + i).val(data[i].FOV)
                        $('#FSC' + i).val(data[i].FSC)
                        $('#CFT' + i).val(data[i].CFT)
                        $('#ODA' + i).val(data[i].ODA)
                        $('#MinCharge' + i).val(data[i].MinCharge)
                        $('#TAT' + i).val(data[i].TAT)

                        sessionStorage.setItem('vid' + i, data[i].VehicleTypeID)
                        sessionStorage.setItem('oid' + i, data[i].OriginPlaceID)
                        sessionStorage.setItem('did' + i, data[i].DestinationPlaceID)
                        if (data[i].ParticipationStatus == "Yes") {
                            $('#trid' + i).css('background-color', 'grey')
                            $("#checktd" + i).first().find('input[type="checkbox"]').prop("disabled", true);

                        }
                        else {
                            $('#trid' + i).css('background-color', '')
                            $('#checktd' + i).attr("disabled", false)
                            $("#checktd" + i).first().find('input[type="checkbox"]').prop("disabled", false);

                        }

                    }

                }
                else {
                    jQuery("#tbloriginDestination").append("<thead><th>Vehicle</th><th>Origin</th><th>Destination</th><th>TAT(days)</th><th>Participation?</th></thead>");
                    for (var i = 0; i < data.length; i++) {
                        jQuery('<tr id=trid' + i + '><td class=hide>' + data[i].VDomesticHeaderID + '</td><td class=hide>' + data[i].ParticipationStatus + '</td><td class=hide id=vid' + i + '>' + data[i].VehicleTypeID + '</td><td class=hide id=oid' + i + '>' + data[i].OriginPlaceID + '</td><td class=hide id=did' + i + '>' + data[i].DestinationPlaceID + '</td><td>' + data[i].VehicleTypeName + '</td><td>' + data[i].Origin + '</td><td>' + data[i].Destination + '</td><td><input type=text class=form-control id=TAT' + i + ' autocomplete=off /></td><td id=checktd' + i + '><div class=\"checker\" id=\"uniform-chkbidTypes\"><span  id=\"spancheckedParticipation\"><input type=\"checkbox\" Onclick=\"Checkparticipationfn(this,' + i + ')\";  style=\"cursor:pointer\" name=\"chkvendorparticipation\"/></span></div></td><td class=display-none id=DRouteID' + i + '>' + data[i].RouteID + '</td></tr>').appendTo("#tbloriginDestination");
                       
                        if (data[i].TAT != 0) {

                            $("#checktd" + i).find("span#spancheckedParticipation").addClass("checked")
                        }
                        if ($("#checktd" + i).find("span#spancheckedParticipation").attr('class') == 'checked') {
                            $('#TAT' + i).attr("disabled", false)
                        }
                        else {
                            $('#TAT' + i).attr("disabled", true)
                        }

                        $('#TAT' + i).val(data[i].TAT)
                        sessionStorage.setItem('vid' + i, data[i].VehicleTypeID)
                        sessionStorage.setItem('oid' + i, data[i].OriginPlaceID)
                        sessionStorage.setItem('did' + i, data[i].DestinationPlaceID)
                       
                        if (data[i].ParticipationStatus == "Yes") {
                           
                            $('#trid' + i).css('background-color', 'grey')
                            $("#checktd" + i).first().find('input[type="checkbox"]').prop("disabled", true);

                        }
                        else {
                            $('#trid' + i).css('background-color', '')
                            $('#checktd' + i).attr("disabled", false)
                            $("#checktd" + i).first().find('input[type="checkbox"]').prop("disabled", false);

                        }
                    }
                }
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else {
                jQuery("#error").text(xhr.d);
            }
            return false;
            jQuery.unblockUI();
        }
       
    })
}
$(document).on("keyup", ".form-control", function () {
    $(this).css("border-color", "")

});
function Checkparticipationfn(event, p) {

    if ($(event).closest("span#spancheckedParticipation").attr('class') == 'checked') {
        $(event).closest("span#spancheckedParticipation").removeClass("checked")
        $('#DoKch' + p).attr("disabled", true)
        $('#FOV' + p).attr("disabled", true)
        $('#FSC' + p).attr("disabled", true)
        $('#CFT' + p).attr("disabled", true)
        $('#ODA' + p).attr("disabled", true)
        $('#MinCharge' + p).attr("disabled", true)
        $('#TAT' + p).attr("disabled", true)

        //$('#DoKch' + p).val(0)
        //$('#FOV' + p).val(0)
        //$('#FSC' + p).val(0)
        //$('#CFT' + p).val(0)
        //$('#ODA' + p).val(0)
        //$('#MinCharge' + p).val(0)
        //$('#TAT' + p).val(0)
        $('#DoKch' + p).css("border-color", "")
        $('#FOV' + p).css("border-color", "")
        $('#FSC' + p).css("border-color", "")
        $('#CFT' + p).css("border-color", "")
        $('#ODA' + p).css("border-color", "")
        $('#MinCharge' + p).css("border-color", "")
        $('#TAT' + p).css("border-color", "")

    }
    else {
        $(event).closest("span#spancheckedParticipation").addClass("checked")
        $('#DoKch' + p).attr("disabled", false)
        $('#FOV' + p).attr("disabled", false)
        $('#FSC' + p).attr("disabled", false)
        $('#CFT' + p).attr("disabled", false)
        $('#ODA' + p).attr("disabled", false)
        $('#MinCharge' + p).attr("disabled", false)
        $('#TAT' + p).attr("disabled", false)



    }
}


function fnproceed() {
   var i = 0;
    var insertquery = '';
    var updateQuery = '';
    var condition = "true"

 
    $("#tbloriginDestination> tbody > tr").each(function (index) {

        if ($(this).find("span#spancheckedParticipation").attr('class') == 'checked') {

            if (BidForID == 7 || BidForID == 8) {
                if (($('#FOV' + i).val() == "0") || (!/^[0-9]\d{0,9}(\.\d{1,3})??$/.test($('#FOV' + i).val())) || ($('#FOV' + i).val() == " ") || ($('#FSC' + i).val() == "0") || ($('#FSC' + i).val() == " ") || (!/^[0-9]\d{0,9}(\.\d{1,3})??$/.test($('#FSC' + i).val())) || ($('#CFT' + i).val() == "0") || ($('#CFT' + i).val() == " ") || (!/^[0-9]\d{0,9}(\.\d{1,3})??$/.test($('#CFT' + i).val())) || ($('#MinCharge' + i).val() == "0") || ($('#MinCharge' + i).val() == " ") || (!/^[0-9]\d{0,9}(\.\d{1,3})??$/.test($('#MinCharge' + i).val())) || ($('#ODA' + i).val() == "0") || ($('#ODA' + i).val() == " ") || (!/^[0-9]\d{0,9}(\.\d{1,3})??$/.test($('#ODA' + i).val())) || ($('#TAT' + i).val() == "0") || ($('#TAT' + i).val() == " ") || (!/^[0-9]\d{0,9}(\.\d{1,3})??$/.test($('#TAT' + i).val())) || ($('#DoKch' + i).val() == "0") || (!/^[0-9]\d{0,9}(\.\d{1,3})??$/.test($('#DoKch' + i).val())) || ($('#DoKch' + i).val() == " ")) {
                    condition = "false"
                }
                else {
                    // if (i == 0) {
                        // insertquery = insertquery + 'insert into VendorDomesticParticipationHeader(BID,VendorID,VehicleTypeID,OriginID,DestinationID,FOV,FSC,CFT,MinChargeWt,ODA,TAT,DocketCharge,Status,EntryDate)';
                    // }

                    if ($.trim($(this).find('td:eq(1)').html()) == "No") {
						if(insertquery==''){
					insertquery = insertquery + 'insert into VendorDomesticParticipationHeader(BID,VendorID,VehicleTypeID,OriginID,DestinationID,FOV,FSC,CFT,MinChargeWt,ODA,TAT,DocketCharge,Status,EntryDate, RouteID)';		
						}
						insertquery = insertquery + " select " + sessionStorage.getItem('BidID') + ",'##VendorID##'," + sessionStorage.getItem('vid' + i) + "," + sessionStorage.getItem('oid' + i) + "," + sessionStorage.getItem('did' + i) + "," + $('#FOV' + i).val().trim() + "," + $('#FSC' + i).val().trim() + "," + $('#CFT' + i).val().trim() + "," + $('#MinCharge' + i).val().trim() + "," + $('#ODA' + i).val().trim() + "," + $('#TAT' + i).val().trim() + "," + $('#DoKch' + i).val().trim() + ",'Y',getdate()," + $.trim($('#DRouteID'+i).html()) + " union "
                        i = i + 1;
                    }
                    else {
                        updateQuery = updateQuery + " update VendorDomesticParticipationHeader set FOV=" + $('#FOV' + i).val().trim() + ",FSC=" + $('#FSC' + i).val().trim() + ",CFT=" + $('#CFT' + i).val().trim() + ",MinChargeWt=" + $('#MinCharge' + i).val().trim() + ",ODA=" + $('#ODA' + i).val().trim() + ",TAT=" + $('#TAT' + i).val().trim() + ",DocketCharge=" + $('#DoKch' + i).val().trim() + " ,RouteID=" + $.trim($('#DRouteID' + i).html()) + "where VDomesticHeaderID=" + $.trim($(this).find('td:eq(0)').html())
                        i = i + 1;
                    }
                }
            }
            else {

                if (($.trim($('#TAT' + i).val()) == "0") || ($.trim($('#TAT' + i).val()) == " ") || (!/^[0-9]\d{0,9}(\.\d{1,3})??$/.test($('#TAT' + i).val().trim()))) {

                    condition = "false"
                }
                else {
                   
                    // if (i == 0) {
                        // insertquery = insertquery + 'insert into VendorDomesticParticipationHeader(BID,VendorID,VehicleTypeID,OriginID,DestinationID,TAT,Status,EntryDate)';
                    // }

                    if ($.trim($(this).find('td:eq(1)').html()) == "No") {
						if(insertquery==''){
							insertquery = insertquery + 'insert into VendorDomesticParticipationHeader(BID,VendorID,VehicleTypeID,OriginID,DestinationID,TAT,Status,EntryDate,RouteID)';
						}
						insertquery = insertquery + " select " + sessionStorage.getItem('BidID') + ",'##VendorID##'," + sessionStorage.getItem('vid' + i) + "," + sessionStorage.getItem('oid' + i) + "," + sessionStorage.getItem('did' + i) + "," + $('#TAT' + i).val().trim() + ",'Y',getdate()," + $.trim($('#DRouteID' + i).html()) + " union "
                        i = i + 1;
                    }
                    else {
                        updateQuery = updateQuery + " update VendorDomesticParticipationHeader set TAT=" + $('#TAT' + i).val().trim() + ",RouteID=" + $.trim($('#DRouteID' + i).html()) + " where VDomesticHeaderID=" + $.trim($(this).find('td:eq(0)').html())
                        i = i + 1;
                    }
                }
            }


            if (condition == "false") {

                if ($('#DoKch' + i).val() == "0" || (!/^[0-9]\d{0,9}(\.\d{1,3})??$/.test($('#DoKch' + i).val())) || $('#DoKch' + i).val() == " ") {

                    $('#DoKch' + i).css("border-color", "#a94442")
                }
                if ($('#FOV' + i).val() == "0" || (!/^[0-9]\d{0,9}(\.\d{1,3})??$/.test($('#FOV' + i).val())) || $('#FOV' + i).val() == " ") {
                    $('#FOV' + i).css("border-color", "#a94442")
                }

                if ($('#FSC' + i).val() == "0" || (!/^[0-9]\d{0,9}(\.\d{1,3})??$/.test($('#FSC' + i).val())) || $('#FSC' + i).val() == "0") {
                    $('#FSC' + i).css("border-color", "#a94442")
                }
                if ($('#CFT' + i).val() == "0" || (!/^[0-9]\d{0,9}(\.\d{1,3})??$/.test($('#CFT' + i).val())) || $('#CFT' + i).val() == " ") {
                    $('#CFT' + i).css("border-color", "#a94442")
                }

                if ($('#MinCharge' + i).val() == "0" || (!/^[0-9]\d{0,9}(\.\d{1,3})??$/.test($('#MinCharge' + i).val())) || $('#MinCharge' + i).val() == " ") {
                    $('#MinCharge' + i).css("border-color", "#a94442")
                }

                if ($('#ODA' + i).val() == "0" || (!/^[0-9]\d{0,9}(\.\d{1,3})??$/.test($('#ODA' + i).val())) || $('#ODA' + i).val() == " ") {
                    $('#ODA' + i).css("border-color", "#a94442")
                }

                if ($('#TAT' + i).val() == "0" || (!/^[0-9]\d{0,9}(\.\d{1,3})??$/.test($('#TAT' + i).val())) || $('#TAT' + i).val() == " ") {

                    $('#TAT' + i).css("border-color", "#a94442")
                }
				jQuery.unblockUI();	
                $('#divalerterrordomestic').show()
                $('#spanerrordomestic').html('Please Enter Data with Number only.')
                return false;

            }

        }
        else {
            if (BidForID == 7 || BidForID == 8) {

                // if (i == 0) {
                    // insertquery = insertquery + 'insert into VendorDomesticParticipationHeader(BID,VendorID,VehicleTypeID,OriginID,DestinationID,FOV,FSC,CFT,MinChargeWt,ODA,TAT,DocketCharge,Status,EntryDate)';
                // }

                if ($.trim($(this).find('td:eq(1)').html()) == "No") {
					if(insertquery==''){
						insertquery = insertquery + 'insert into VendorDomesticParticipationHeader(BID,VendorID,VehicleTypeID,OriginID,DestinationID,FOV,FSC,CFT,MinChargeWt,ODA,TAT,DocketCharge,Status,EntryDate,RouteID)';
					}
					insertquery = insertquery + " select " + sessionStorage.getItem('BidID') + ",'##VendorID##'," + sessionStorage.getItem('vid' + i) + "," + sessionStorage.getItem('oid' + i) + "," + sessionStorage.getItem('did' + i) + "," + 0 + "," + 0 + "," + 0 + "," + 0 + "," + 0 + "," + 0 + "," + 0 + ",'N',getdate()," + $.trim($('#DRouteID' + i).html()) + " union "
                    i = i + 1;
                }
                else {
                    updateQuery = updateQuery + " update VendorDomesticParticipationHeader set FOV=" + $('#FOV' + i).val().trim() + ",FSC=" + $('#FSC' + i).val().trim() + ",CFT=" + $('#CFT' + i).val().trim() + ",MinChargeWt=" + $('#MinCharge' + i).val().trim() + ",ODA=" + $('#ODA' + i).val().trim() + ",TAT=" + $('#TAT' + i).val().trim() + ",DocketCharge=" + $('#DoKch' + i).val().trim() + ",RouteID=" + $.trim($('#DRouteID' + i).html()) + " where VDomesticHeaderID=" + $.trim($(this).find('td:eq(0)').html())
                    i = i + 1;
                }
            }
            else {

                // if (i == 0) {
                    // insertquery = insertquery + 'insert into VendorDomesticParticipationHeader(BID,VendorID,VehicleTypeID,OriginID,DestinationID,TAT,Status,EntryDate)';
                // }

                if ($.trim($(this).find('td:eq(1)').html()) == "No") {
					if(insertquery==''){
						insertquery = insertquery + 'insert into VendorDomesticParticipationHeader(BID,VendorID,VehicleTypeID,OriginID,DestinationID,TAT,Status,EntryDate,RouteID)';
					}
					insertquery = insertquery + " select " + sessionStorage.getItem('BidID') + ",'##VendorID##'," + sessionStorage.getItem('vid' + i) + "," + sessionStorage.getItem('oid' + i) + "," + sessionStorage.getItem('did' + i) + "," + 0 + ",'N',getdate()," + $.trim($('#DRouteID' + i).html()) + " union "
                    i = i + 1;
                }
                else {
                    updateQuery = updateQuery + " update VendorDomesticParticipationHeader set TAT=" + $('#TAT' + i).val().trim() + ",RouteID=" + $.trim($('#DRouteID' + i).html()) + " where VDomesticHeaderID=" + $.trim($(this).find('td:eq(0)').html())
                    i = i + 1;
                }
            }

        }

    });
    setTimeout(function () {
        jQuery('#divalerterrordomestic').css('display', 'none');

    }, 2000);

 
   

            insertquery = insertquery.substring(0, insertquery.length - 7);
  
 
   


    if (condition == "true") {
        var vendorID = 0;
     
        if (sessionStorage.getItem('ContactEmailID') == 'null' || sessionStorage.getItem('ContactEmailID') == '') {
            vendorID = sessionStorage.getItem('UserID');
        }
        else {
            vendorID = sessionStorage.getItem('BidUserID');
        }
        var data = {
            "BidID": sessionStorage.getItem('BidID'),
            "VendorID": vendorID,
            "insertQuery": insertquery,
            "UpdateQuery": updateQuery
        }

       //alert(JSON.stringify(data))
        jQuery.ajax({
            url: sessionStorage.getItem("APIPath") + "VendorParticipation/insUpdBidDomesticOriginDestiDetails/",
            beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
            type: "POST",
            data: JSON.stringify(data),
            contentType: "application/json; charset=utf-8",
            success: function (data, status, jqXHR) {

                if (data[0].BidID > 0) {

                    jQuery('#divalertsucessdomestic').css('display', 'block');
                    window.location = "ParticipationDomestic.html";
                }else{
		jQuery.unblockUI();					
					jQuery('#divalertsucessdomestic').css('display', 'block');
                    bootbox.alert("Bid has not been started yet.");
				}
            },
            error: function (xhr, status, error) {

                var err = eval("(" + xhr.responseText + ")");
                if (xhr.status === 401) {
                    error401Messagebox(err.Message);
                }
               
                return false;
                jQuery.unblockUI();
            }
        });
        setTimeout(function () {
            jQuery('#divalertsucessdomestic').css('display', 'none');
            resetfn(i)
        }, 2000);
    }
}

function resetfn(c) {

    for (var i = 0; i < c; i++) {
        sessionStorage.removeItem('vid' + i)
        sessionStorage.removeItem('oid' + i)
        sessionStorage.removeItem('did' + i)
    }
    i = 0;

}

function fetchVendorBeforeBidDetailsAir() {   
    var url = '';
    if (sessionStorage.getItem("ContactEmailID") == 'null' || sessionStorage.getItem("ContactEmailID") == '') {

        url = sessionStorage.getItem("APIPath") + "VendorParticipationAir/fetchVendorBeforeBidDetails/?BidID=" + sessionStorage.getItem("BidID") + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("UserID"));

    } else {
        url = sessionStorage.getItem("APIPath") + "VendorParticipationAir/fetchVendorBeforeBidDetails/?BidID=" + sessionStorage.getItem("BidID") + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("BidUserID"));
    }

    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        url: url,
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
            if (data.length > 0) {
                jQuery("#txtFSC").val(data[0].FSC);
                jQuery("#txtSSC").val(data[0].SSC);
                jQuery("#txtDOChargesAir").val(data[0].DOCharges);
                jQuery("#txtCareer").val(data[0].Career);
                jQuery("#txtLoadingAirport").val(data[0].LoadingAirport);
                jQuery("#txtConsDays").val(data[0].ConsolidationDays);
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else{
                jQuery("#error").text(xhr.d);
            } 
            return false;
            jQuery.unblockUI();
        }
       
    });
}
function showHideDivtotal(BidForID) {
    if (parseInt(BidForID) == 6 || parseInt(BidForID) == 5) {
        jQuery('#divTotal').css('display', 'block');
    }
    else {
        jQuery('#divTotal').css('display', 'none');
    }
}

function InsUpdVendorDetailsAir() {
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    var vendorID = 0;
    if (sessionStorage.getItem("ContactEmailID") == 'null' || sessionStorage.getItem("ContactEmailID") == '') {
        vendorID = sessionStorage.getItem('UserID');
    } else {
        vendorID =sessionStorage.getItem('BidUserID');
    }
    var ParticipationAir = {
        "BidID": sessionStorage.getItem("BidID"),
        "VendorID": vendorID,
        "FSC": jQuery("#txtFSC").val(),
        "SSC": jQuery("#txtSSC").val(),
        "DOCharges": jQuery("#txtDOChargesAir").val(),
        "Career": jQuery("#txtCareer").val(),
        "LoadingAirport": jQuery("#txtLoadingAirport").val(),
        "ConsolidationDays": jQuery("#txtConsDays").val()
    };

    //alert(JSON.stringify(ParticipationAir))
    jQuery.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "VendorParticipation/AddVendorParticipationAir/",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        data: JSON.stringify(ParticipationAir),
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data) {
            if (data.length > 0) {
                if (data[0].IsSuccess == 'Y' || data[0].IsSuccess == 'U') {
                    jQuery('#divalertsucessAir').css('display', 'block');
                    window.location = "ParticipateBidAir.html";
                } else if (data[0].IsSuccess == 'N') {
                    jQuery.unblockUI();
                    jQuery('#divalertsucessAir').css('display', 'block');
                    bootbox.alert("Bid has not been started yet.");
                }
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else {
                jQuery("#error").text(xhr.d);
            }
            return false;
            jQuery.unblockUI();
        }
    });
    jQuery.unblockUI();
    setTimeout(function () {
        jQuery('#divalertsucessAir').css('display', 'none');
    }, 2000);
}

function InsUpdVendorDetailsSea() {
jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    var vendorID = 0;
    if (sessionStorage.getItem("ContactEmailID") == 'null' || sessionStorage.getItem("ContactEmailID") == '') {
        vendorID = sessionStorage.getItem('UserID');
    } else {
        vendorID = sessionStorage.getItem('BidUserID');
    }
    var ParticipationSea = {
        "BidID": sessionStorage.getItem("BidID"),
        "VendorID": vendorID,
        "BAF": jQuery("#txtBAF").val(),
        "CAF": jQuery("#txtCAF").val(),
        "ForwardersDO": jQuery("#txtFwdDOCharges").val(),
        "ShippingLine": jQuery("#txtShipingLine").val(),
        "SailingDays": jQuery("#txtSailingDays").val(),
        "OceanTransitTime": jQuery("#txtOceanTransitTime").val(),
        "InlandHaulage": jQuery("#txtHaulageCharges").val(),
        "ShippingLineDO": jQuery("#txtDOCharges").val(),
        "ContainerClgChg": jQuery("#txtCleaningCharges").val(),
        "ShippingLineOther": jQuery("#txtOtherCharges").val()
    };
    jQuery.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "VendorParticipation/AddVendorParticipationSea",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        data: JSON.stringify(ParticipationSea),
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data) {
            if (data.length > 0) {
                if (data[0].IsSuccess == 'Y' || data[0].IsSuccess == 'U') {
                    jQuery('#divalertsucessSea').css('display', 'block');
                    window.location = "ParticipateBidSea.html";
                } else if (data[0].IsSuccess == 'N') {
                    jQuery.unblockUI();
                    jQuery('#divalertsucessSea').css('display', 'block');
                    bootbox.alert("Bid has not been started yet.");
                }
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else {
                jQuery("#error").text(xhr.d);
            }
            return false;
            jQuery.unblockUI();
        }
    });
    jQuery.unblockUI();
    setTimeout(function () {
        jQuery('#divalertsucessSea').css('display', 'none');
    }, 3000);
    
}


///validation//

var FormValidation = function () {
    var ValidateParticipationAir = function () {
        var form1 = $('#formAir');
        var error1 = $('.alert-danger', form1);
        var success1 = $('.alert-success', form1);

        form1.validate({
            errorElement: 'span',
            errorClass: 'help-block',
            focusInvalid: false,
            ignore: "",

            rules: {
                txtFSC: {
                    required: true,
                    number: true,
                    minlength: 1,
                    maxlength: 5
                },
                txtSSC: {
                    required: true,
                    number: true,
                    minlength: 1,
                    maxlength: 5
                },
                txtDOChargesAir: {
                    required: true,
                    number: true,
                    minlength: 1,
                    maxlength: 5
                },
                txtCareer:
                {
                    required: true
                },
                txtLoadingAirport:
                {
                    required: true
                },
                txtConsDays:
                {
                    required: true,
                    //                    number: true,
                    //                    minlength: 1,
                    //                    maxlength: 5
                }
            },
            messages: {
                txtFSC: {
                    required: "Please enter FSC"
                },
                txtSSC: {
                    required: "Please enter SSC"
                },
                txtDOChargesAir: {
                    required: "Please enter DO Charges"
                },
                txtCareer:
                {
                    required: "Please enter Career"
                },
                txtLoadingAirport:
                {
                    required: "Please enter Loading Airport"
                },
                txtConsDays:
                {
                    required: "Please enter Consolidation Days"
                }
            },

            invalidHandler: function (event, validator) { //display error alert on form submit              
                success1.hide();
                error1.show();
                App.scrollTo(error1, -200);
            },

            highlight: function (element) { // hightlight error inputs
                $(element)
                        .closest('.Validationgroup').addClass('has-error'); // set error class to the control group
            },

            unhighlight: function (element) { // revert the change done by hightlight
                $(element)
                        .closest('.Validationgroup').removeClass('has-error'); // set error class to the control group
            },

            success: function (label) {
                label
                        .closest('.Validationgroup').removeClass('has-error'); // set success class to the control group
            },

            submitHandler: function (form) {
                InsUpdVendorDetailsAir();
                App.scrollTo(error1, -100);
            }
        });
    }

    var ValidateParticipationSea = function () {
        var form1 = $('#formSea');
        var error1 = $('.alert-danger', form1);
        var success1 = $('.alert-success', form1);

        form1.validate({
            errorElement: 'span',
            errorClass: 'help-block',
            focusInvalid: false,
            ignore: "",
            rules: {
                txtBAF: {
                    required: true,
                    number: true,
                    minlength: 1,
                    maxlength: 5
                },
                txtCAF: {
                    required: true,
                    number: true,
                    minlength: 1,
                    maxlength: 5
                },
                txtFwdDOCharges: {
                    required: true,
                    number: true,
                    minlength: 1,
                    maxlength: 5
                },
                txtShipingLine: {
                    required: true
                },
                txtSailingDays: {
                    required: true
                },
                txtOceanTransitTime: {
                    required: true
                },
                txtHaulageCharges: {
                    required: function (element) {
                        if ($("#divTotal").is(":Visible") == true) {
                            return true;
                        }
                        else {
                            return false;
                        }
                    },
                    number: true,
                    minlength: 1,
                    maxlength: 5
                },
                txtDOCharges: {
                    required: function (element) {
                        if ($("#divTotal").is(":Visible") == true) {
                            return true;
                        }
                        else {
                            return false;
                        }
                    },
                    number: true,
                    minlength: 1,
                    maxlength: 5
                },
                txtCleaningCharges: {
                    required: function (element) {
                        if ($("#divTotal").is(":Visible") == true) {
                            return true;
                        }
                        else {
                            return false;
                        }
                    },
                    number: true,
                    minlength: 1,
                    maxlength: 5
                },
                txtOtherCharges: {
                    required: function (element) {
                        if ($("#divTotal").is(":Visible") == true) {
                            return true;
                        }
                        else {
                            return false;
                        }
                    },
                    number: true,
                    minlength: 1,
                    maxlength: 5
                }
            },
            messages: {
                txtBAF: {
                    required: "Please enter BAF"
                },
                txtCAF: {
                    required: "Please enter CAF"
                },
                txtFwdDOCharges: {
                    required: "Please enter Forwarders DO Charges"
                },
                txtShipingLine: {
                    required: "Please enter Shipping Line"
                },
                txtShipingLine: {
                    required: "Please enter Shipping Line"
                },
                txtSailingDays: {
                    required: "Please enter Sailing Days"
                },
                txtOceanTransitTime: {
                    required: "Please enter Ocean Transit Time"
                },
                txtHaulageCharges: {
                    required: "Please enter Inland Haulage Charges"
                },
                txtDOCharges: {
                    required: "Please enter Shipping Line's DO Charges"
                },
                txtCleaningCharges: {
                    required: "Please enter Container Cleaning Charges"
                },
                txtOtherCharges: {
                    required: "Please enter Shipping Line's Any Other Charges"
                }
            },

            invalidHandler: function (event, validator) { //display error alert on form submit              
                success1.hide();
                error1.show();
                App.scrollTo(error1, -200);
            },

            highlight: function (element) { // hightlight error inputs
                $(element)
                        .closest('.Validationgroup').addClass('has-error'); // set error class to the control group
            },

            unhighlight: function (element) { // revert the change done by hightlight
                $(element)
                        .closest('.Validationgroup').removeClass('has-error'); // set error class to the control group
            },

            success: function (label) {
                label
                        .closest('.Validationgroup').removeClass('has-error'); // set success class to the control group
            },

            submitHandler: function (form) {
                InsUpdVendorDetailsSea();
                App.scrollTo(error1, -100);
            }
        });
    }

    var handleWysihtml5 = function () {
        if (!jQuery().wysihtml5) {
            return;
        }
        if ($('.wysihtml5').size() > 0) {
            $('.wysihtml5').wysihtml5({
                "stylesheets": ["assets/plugins/bootstrap-wysihtml5/wysiwyg-color.css"]
            });
        }
    }
    return {
        init: function () {
            handleWysihtml5();
            ValidateParticipationAir();
            ValidateParticipationSea();
        }
    };
}();


function fillhelp() {

    if (sessionStorage.getItem("BidTypeID") == 1) {
        
        $('#product').show()
    }
    else if (sessionStorage.getItem("BidTypeID") == 2) {
       
        $('#Air').show()
    }
    else if (sessionStorage.getItem("BidTypeID") == 3) {
       
        $('#Sea').show()
    }
    else if (sessionStorage.getItem("BidTypeID") == 4) {
       
        $('#Demostic').show()
    }
    else if (sessionStorage.getItem("BidTypeID") == 5) {
        
        $('#Warehouse').show()
    }

}
