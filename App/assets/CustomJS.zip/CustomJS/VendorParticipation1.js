﻿$(document).ready(function () {
    fetchVendorDetails()
    if (sessionStorage.getItem("BidTypeID") == "2") {
        jQuery('#divAirImport').css('display', 'block');
        fetchVendorBeforeBidDetailsAir();
    }
    else if (sessionStorage.getItem("BidTypeID") == "3") {
        jQuery('#divSeaImport').css('display', 'block');
        fetchVendorBeforeBidDetails();
    }
    jQuery('#divTotal').css('display', 'none');
});
var BidTypeID = 0;
var BidForID = 0;
function fetchVendorDetails() {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "VendorParticipation/FetchBidDetails/?BidID=" + sessionStorage.getItem("BidID") + "&VendorID=" + sessionStorage.getItem("UserID"),
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
            if (data.length > 0) {
                jQuery("#lblbidsubject").text(data[0].BidSubject);
                jQuery("#lblbidDetails").text(data[0].BidDetails);
                jQuery("#lblbiddate").text(data[0].BidDate);
                jQuery("#lblbidtime").text(data[0].BidTime);
                
                jQuery("a#lnkTermsAttachment").text(data[0].TermsConditions);
                jQuery("a#lnkTermsAttachment").attr("href", "../TermsConditions/" + sessionStorage.getItem("BidID") + "/" + data[0].TermsConditions)
                jQuery("a#lnkAnyOtherAttachment").text(data[0].Attachment);
                jQuery("a#lnkAnyOtherAttachment").attr("href", "../TermsConditions/" + sessionStorage.getItem("BidID") + "/" + data[0].Attachment)
                //var duration = (data[0].BidDuration + data[0].Extension);
                jQuery("#lblbidduration").text(data[0].BidDuration);
                jQuery("#lblcurrency").text(data[0].CurrencyName);
                jQuery("#lblConvRate").text(data[0].ConversionRate);
                //jQuery("#lblstatus").text(data[0].Status);

                BidTypeID = data[0].BidTypeID;
                BidForID = data[0].BidForID;
                showHideDivtotal(data[0].BidForID);
            }
            else {
                bootbox.alert("Oops! Bid has been expired.", function () {
                     window.location = sessionStorage.getItem('MainUrl');
                    return false;
                });
            }
        },
        error: function (xhr) {
            jQuery("#error").text(xhr.d);
        }
    });
}

function fetchVendorBeforeBidDetails() {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "VendorParticipationSea/fetchVendorBeforeBidDetails/?BidID=" + sessionStorage.getItem("BidID") + "&VendorID=" + sessionStorage.getItem("UserID"),
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
            if (data.length > 0) {
                jQuery("#txtBAF").val(data[0].BAF);
                jQuery("#txtCAF").val(data[0].CAF);
                jQuery("#txtFwdDOCharges").val(data[0].ForwardersDO);
                jQuery("#txtShipingLine").val(data[0].ShippingLine);
                jQuery("#txtSailingDays").val(data[0].SailingDays);
                jQuery("#txtOceanTransitTime").val(data[0].OceanTransitTime);
                jQuery("#txtHaulageCharges").val(data[0].InlandHaulage);
                jQuery("#txtDOCharges").val(data[0].ShippingLineDO);
                jQuery("#txtCleaningCharges").val(data[0].ContainerClgChg);
                jQuery("#txtOtherCharges").val(data[0].ShippingLineOther);
            }
        },
        error: function (xhr) {
            jQuery("#error").text(xhr.d);
        }
    });
}


function fetchVendorBeforeBidDetailsAir() {
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "VendorParticipationAir/fetchVendorBeforeBidDetails/?BidID=" + sessionStorage.getItem("BidID") + "&VendorID=" + sessionStorage.getItem("UserID"),
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
            if (data.length > 0) {
                jQuery("#txtFSC").val(data[0].FSC);
                jQuery("#txtSSC").val(data[0].SSC);
                jQuery("#txtDOChargesAir").val(data[0].DOCharges);
                jQuery("#txtCareer").val(data[0].Career);
                jQuery("#txtLoadingAirport").val(data[0].LoadingAirport);
                jQuery("#txtConsDays").val(data[0].ConsolidationDays);
            }
        },
        error: function (xhr) {
            jQuery("#error").text(xhr.d);
        }
    });
}
function showHideDivtotal(BidForID) {
    if (parseInt(BidForID) == 2) {
        jQuery('#divTotal').css('display', 'block');
    }
    else {
        jQuery('#divTotal').css('display', 'none');
    }
}

function InsUpdVendorDetailsAir() {
    var ParticipationAir = {
        "BidID": sessionStorage.getItem("BidID"),
        "VendorID": sessionStorage.getItem("UserID"),
        "FSC": jQuery("#txtFSC").val(),
        "SSC": jQuery("#txtSSC").val(),
        "DOCharges": jQuery("#txtDOChargesAir").val(),
        "Career": jQuery("#txtCareer").val(),
        "LoadingAirport": jQuery("#txtLoadingAirport").val(),
        "ConsolidationDays": jQuery("#txtConsDays").val()
    };
    jQuery.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "VendorParticipation/AddVendorParticipationAir/",
        data: JSON.stringify(ParticipationAir),
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data) {
            if (data.length > 0) {
                if (data[0].IsSuccess == 'Y' || data[0].IsSuccess == 'U') {
                    jQuery('#divalertsucessAir').css('display', 'block');
                    window.location = "ParticipateBidAir.html";
                }
            }
        }
    });
    setTimeout(function () {
        jQuery('#divalertsucessAir').css('display', 'none');
    }, 2000);
}

function InsUpdVendorDetailsSea() {
    
    var ParticipationSea = {
        "BidID": sessionStorage.getItem("BidID"),
        "VendorID": sessionStorage.getItem("UserID"),
        "BAF": jQuery("#txtBAF").val(),
        "CAF": jQuery("#txtCAF").val(),
        "ForwardersDO": jQuery("#txtFwdDOCharges").val(),
        "ShippingLine": jQuery("#txtShipingLine").val(),
        "SailingDays": jQuery("#txtSailingDays").val(),
        "OceanTransitTime": jQuery("#txtOceanTransitTime").val(),
        "InlandHaulage": jQuery("#txtHaulageCharges").val(),
        "ShippingLineDO": jQuery("#txtDOCharges").val(),
        "ContainerClgChg": jQuery("#txtCleaningCharges").val(),
        "ShippingLineOther": jQuery("#txtOtherCharges").val()
    };
    jQuery.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "VendorParticipation/AddVendorParticipationSea",
        data: JSON.stringify(ParticipationSea),
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data) {
            if (data.length > 0) {
                if (data[0].IsSuccess == 'Y' || data[0].IsSuccess == 'U') {
                    jQuery('#divalertsucessSea').css('display', 'block');
                    window.location = "ParticipateBidSea.html";
                }
            }
        }
    });
    setTimeout(function () {
        jQuery('#divalertsucessSea').css('display', 'none');
    }, 2000);
}


///validation//

var FormValidation = function () {
    var ValidateParticipationAir = function () {
        var form1 = $('#formAir');
        var error1 = $('.alert-danger', form1);
        var success1 = $('.alert-success', form1);

        form1.validate({
            errorElement: 'span',
            errorClass: 'help-block',
            focusInvalid: false,
            ignore: "",

            rules: {
                txtFSC: {
                    required: true,
                    number: true,
                    minlength: 1,
                    maxlength: 5
                },
                txtSSC: {
                    required: true,
                    number: true,
                    minlength: 1,
                    maxlength: 5
                },
                txtDOChargesAir: {
                    required: true,
                    number: true,
                    minlength: 1,
                    maxlength: 5
                },
                txtCareer:
                {
                    required: true
                },
                txtLoadingAirport:
                {
                    required: true
                },
                txtConsDays:
                {
                    required: true,
//                    number: true,
//                    minlength: 1,
//                    maxlength: 5
                }
            },
            messages: {
                txtFSC: {
                    required: "Please enter FSC"
                },
                txtSSC: {
                    required: "Please enter SSC"
                },
                txtDOChargesAir: {
                    required: "Please enter DO Charges"
                },
                txtCareer:
                {
                    required: "Please enter Career"
                },
                txtLoadingAirport:
                {
                    required: "Please enter Loading Airport"
                },
                txtConsDays:
                {
                    required: "Please enter Consolidation Days"
                }
            },

            invalidHandler: function (event, validator) { //display error alert on form submit              
                success1.hide();
                error1.show();
                App.scrollTo(error1, -200);
            },

            highlight: function (element) { // hightlight error inputs
                $(element)
                        .closest('.Validationgroup').addClass('has-error'); // set error class to the control group
            },

            unhighlight: function (element) { // revert the change done by hightlight
                $(element)
                        .closest('.Validationgroup').removeClass('has-error'); // set error class to the control group
            },

            success: function (label) {
                label
                        .closest('.Validationgroup').removeClass('has-error'); // set success class to the control group
            },

            submitHandler: function (form) {
                InsUpdVendorDetailsAir();
                App.scrollTo(error1, -100);
            }
        });
    }

    var ValidateParticipationSea = function () {
        var form1 = $('#formSea');
        var error1 = $('.alert-danger', form1);
        var success1 = $('.alert-success', form1);

        form1.validate({
            errorElement: 'span',
            errorClass: 'help-block',
            focusInvalid: false,
            ignore: "",
            rules: {
                txtBAF: {
                    required: true,
                    number: true,
                    minlength: 1,
                    maxlength: 5
                },
                txtCAF: {
                    required: true,
                    number: true,
                    minlength: 1,
                    maxlength: 5
                },
                txtFwdDOCharges: {
                    required: true,
                    number: true,
                    minlength: 1,
                    maxlength: 5
                },
                txtShipingLine: {
                    required: true
                },
                txtSailingDays: {
                    required: true
                },
                txtOceanTransitTime: {
                    required: true
                },
                txtHaulageCharges: {
                    required: function (element) {
                        if ($("#divTotal").is(":Visible") == true) {
                            return true;
                        }
                        else {
                            return false;
                        }
                    },
                    number: true,
                    minlength: 1,
                    maxlength: 5
                },
                txtDOCharges: {
                    required: function (element) {
                        if ($("#divTotal").is(":Visible") == true) {
                            return true;
                        }
                        else {
                            return false ;
                        }
                    },
                    number: true,
                    minlength: 1,
                    maxlength: 5
                },
                txtCleaningCharges: {
                    required: function (element) {
                        if ($("#divTotal").is(":Visible") == true) {
                            return true;
                        }
                        else {
                            return false;
                        }
                    },
                    number: true,
                    minlength: 1,
                    maxlength: 5
                },
                txtOtherCharges: {
                    required: function (element) {
                        if ($("#divTotal").is(":Visible") == true) {
                            return true;
                        }
                        else {
                            return false;
                        }
                    },
                    number: true,
                    minlength: 1,
                    maxlength: 5
                }
            },
            messages: {
                txtBAF: {
                    required: "Please enter BAF"
                },
                txtCAF: {
                    required: "Please enter CAF"
                },
                txtFwdDOCharges: {
                    required: "Please enter Forwarders DO Charges"
                },
                txtShipingLine: {
                    required: "Please enter Shipping Line"
                },
                txtShipingLine: {
                    required: "Please enter Shipping Line"
                },
                txtSailingDays: {
                    required: "Please enter Sailing Days"
                },
                txtOceanTransitTime: {
                    required: "Please enter Ocean Transit Time"
                },
                txtHaulageCharges: {
                    required: "Please enter Inland Haulage Charges"
                },
                txtDOCharges: {
                    required: "Please enter Shipping Line's DO Charges"
                },
                txtCleaningCharges: {
                    required: "Please enter Container Cleaning Charges"
                },
                txtOtherCharges: {
                    required: "Please enter Shipping Line's Any Other Charges"
                }
            },

            invalidHandler: function (event, validator) { //display error alert on form submit              
                success1.hide();
                error1.show();
                App.scrollTo(error1, -200);
            },

            highlight: function (element) { // hightlight error inputs
                $(element)
                        .closest('.Validationgroup').addClass('has-error'); // set error class to the control group
            },

            unhighlight: function (element) { // revert the change done by hightlight
                $(element)
                        .closest('.Validationgroup').removeClass('has-error'); // set error class to the control group
            },

            success: function (label) {
                label
                        .closest('.Validationgroup').removeClass('has-error'); // set success class to the control group
            },

            submitHandler: function (form) {
                InsUpdVendorDetailsSea();
                App.scrollTo(error1, -100);
            }
        });
    }

    var handleWysihtml5 = function () {
        if (!jQuery().wysihtml5) {
            return;
        }
        if ($('.wysihtml5').size() > 0) {
            $('.wysihtml5').wysihtml5({
                "stylesheets": ["assets/plugins/bootstrap-wysihtml5/wysiwyg-color.css"]
            });
        }
    }
    return {
        init: function () {
            handleWysihtml5();
            ValidateParticipationAir();
            ValidateParticipationSea();
        }
    };
} ();


