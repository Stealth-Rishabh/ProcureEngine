﻿//var VendorID = 0;
//var BidID = 0;
var BidTypeID = 0;
var BidForID = 0;
//var UserType = "";
var Duration = '0.00';

$(document).ready(function () {
    
    fetchVendorBidDetails()
    
});

function fetchVendorBidDetails() {    
    var url = '';
    if (sessionStorage.getItem("ContactEmailID") == 'null' || sessionStorage.getItem("ContactEmailID") == '') {

        url = sessionStorage.getItem("APIPath") + "VendorParticipation/FetchBidDetails/?BidID=" + sessionStorage.getItem("BidID") + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("BidUserID"));

    } else {
        url = sessionStorage.getItem("APIPath") + "VendorParticipation/FetchBidDetails/?BidID=" + sessionStorage.getItem("BidID") + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("UserID"));
    }

    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: url,
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
            if (data.length > 0) {
                if (data[0].BidForID == 6) {
                    jQuery('#divExWorks').show();
                }
                //debugger;
                jQuery("#lblbidsubject").text(data[0].BidSubject);
                jQuery("#lblbidDetails").text(data[0].BidDetails);
                jQuery("#lblbiddate").text(data[0].BidDate);
                jQuery("#lblbidtime").text(data[0].BidTime);
                //var duration = (data[0].BidDuration + data[0].Extension);
                jQuery("#lblbidduration").text(data[0].BidDuration);
                jQuery("#lblcurrency").text(data[0].TargetRate + ' ' + data[0].CurrencyName);
                jQuery("#lblConvRate").text(data[0].ConversionRate);
                jQuery("#lblstatus").text(data[0].Status);

                BidTypeID = data[0].BidTypeID;
                BidForID = data[0].BidForID;

                

                display = document.querySelector('#lblTimeLeft');
                //timer = 0;
                startTimer((parseInt(data[0].TimeLeft)), display);
                //startTimer((60 * parseInt(data[0].BidDuration)), display);
                fetchBidSummaryVendorSea(data[0].BidTypeID, data[0].BidForID);
                jQuery.unblockUI();
            }
        },
        error: function (xhr) {
            jQuery("#error").text(xhr.d);
            jQuery.unblockUI();
        }
    });
    
}
//var timer = 0, hours = 0, minutes = 0, seconds = 0;
var mytime = 0;
function startTimer(duration, display) {
   
    
 clearInterval(mytime)
var timer = duration, hours, minutes, seconds;
   mytime = setInterval(function () {
        hours = parseInt(timer / 3600, 10)
        minutes = parseInt(timer / 60, 10) - (hours * 60)
        seconds = parseInt(timer % 60, 10);

        hours = hours < 10 ? "0" + hours : hours;
        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;

        if (hours > 0) {
            display.textContent = hours + ":" + minutes + ":" + seconds;
        }
        else {
            display.textContent = minutes + ":" + seconds;
        }


        if ((seconds.toString().substring(1, 2) == '0') || (seconds.toString().substring(1, 2) == '5')) {
            fetchBidSummaryVendorSea(BidTypeID, BidForID);
            
        }
        //if (seconds.toString().substring(0, 2) == '20') {
        //    fetchVendorBidDetails();
        //}
        if (--timer < 0) {
            timer = 0;
            closeBidSea();
        }
		
		 $('#hdnval').val(timer)
    }, 1000);
	
	
}
function closeBidSea() {
	clearInterval(mytime)
    jQuery.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "VendorParticipation/CloseBid/?BidID=" + sessionStorage.getItem("BidID"),
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
            bootbox.alert("Bid time has been over. Thanks for Participation.", function () {
            window.location = sessionStorage.getItem('MainUrl');
                return false;
            });
        }
    });
}
function fetchBidSummaryVendorSea(bidtypeid, bidforid) {
    var url = '';
    if (sessionStorage.getItem("ContactEmailID") == 'null' || sessionStorage.getItem("ContactEmailID") == '') {

        url = sessionStorage.getItem("APIPath") + "VendorParticipationSea/fetchBidSummaryVendorSea/?BidID=" + sessionStorage.getItem("BidID") + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("UserID")) + "&BidforID=" + BidForID + "&UserType=" + sessionStorage.getItem("UserType");

    } else {
        url = sessionStorage.getItem("APIPath") + "VendorParticipationSea/fetchBidSummaryVendorSea/?BidID=" + sessionStorage.getItem("BidID") + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("BidUserID")) + "&BidforID=" + BidForID + "&UserType=" + sessionStorage.getItem("UserType");
    }
   
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: url,
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function (data, status, jqXHR) {
           
            if (data.length > 0) {
				//alert(data[0].NoOfExtension)
                jQuery("#lblInitialQUote").text(data[0].InitialQuote);
                jQuery("#lblCurrentQuote").text(data[0].LowestQuote);
                jQuery("#lblPresentStatus").text(data[0].ParticipationStatus);
                if (data[0].ParticipationStatus == 'L1') {
                    jQuery('#lblPresentStatus').css('color', 'Blue');
                }
                else {
                    jQuery('#lblPresentStatus').css('color', 'Red');
                }
				display = document.querySelector('#lblTimeLeft');
                      startTimer(data[0].TimeLeft, display);
				 if (data[0].NoOfExtension >= 1) {
                          jQuery('#lblTimeLeft').css('color', 'red');
						  jQuery('#lblTimeLeftTxt').removeClass('display-none');
					jQuery('#lblTimeLeftTxt').html('<b>Bid Time Extended.</b>').css('color', 'red');
                      }
                      else {
						  jQuery('#lblTimeLeftTxt').addClass('display-none');
                          jQuery('#lblTimeLeft').css('color', '');
                      }
            }
        },
        error: function (xhr) {
            jQuery("#error").text(xhr.d);
            jQuery.unblockUI();
        }
    });
}

function InsUpdQuoteSea() {
	jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    var vendorID = 0;
    if (sessionStorage.getItem("ContactEmailID") == 'null' || sessionStorage.getItem("ContactEmailID") == '') {
        vendorID = sessionStorage.getItem('UserID');
    } else {
        vendorID = sessionStorage.getItem('BidUserID');
    }

	if ($('#hdnval').val() >= 60) {
		var QuoteSea = {
        "VendorID": vendorID,
        "BidID": sessionStorage.getItem("BidID"),
        "BidTypeID": BidTypeID,
        "BidForID": BidForID,
        "Price": jQuery("#txtFreight").val(),
        "ExWorks": jQuery("#txtExWorks").val()
    }
    //alert(JSON.stringify(QuoteSea));
    jQuery.ajax({
        url: sessionStorage.getItem("APIPath") + "VendorParticipationSea/ParticipationSea/",
        type: "POST",
        data: JSON.stringify(QuoteSea),
        contentType: "application/json; charset=utf-8",
        success: function (data, status, jqXHR) {            
            fetchBidSummaryVendorSea(BidTypeID, BidForID);
            jQuery("#txtFreight").val('')
            jQuery("#txtExWorks").val('')
            jQuery.unblockUI();
        },
        error: function (xhr) {
            jQuery("#error").text(xhr.d);
            jQuery.unblockUI();
        }
    });
		
	}else{
		
		var QuoteSea = {
        "VendorID": vendorID,
        "BidID": sessionStorage.getItem("BidID"),
        "BidTypeID": BidTypeID,
        "BidForID": BidForID,
        "Price": jQuery("#txtFreight").val(),
        "ExWorks": jQuery("#txtExWorks").val()
    }
    //alert(JSON.stringify(QuoteSea));
    jQuery.ajax({
        url: sessionStorage.getItem("APIPath") + "VendorParticipationSea/ParticipationSea/",
        type: "POST",
        data: JSON.stringify(QuoteSea),
        contentType: "application/json; charset=utf-8",
        success: function (data, status, jqXHR) {            
            fetchBidSummaryVendorSea(BidTypeID, BidForID);
            jQuery("#txtFreight").val('')
            jQuery("#txtExWorks").val('')
            jQuery.unblockUI();
        },
        error: function (xhr) {
            jQuery("#error").text(xhr.d);
            jQuery.unblockUI();
        }
    });
		
		var data = {
                "BidID": sessionStorage.getItem("BidID")

            }
            //alert(JSON.stringify(data))
            jQuery.ajax({
                url: sessionStorage.getItem("APIPath") + "VendorParticipation/ExtendDuration/",
                type: "POST",
                data: JSON.stringify(data),
                contentType: "application/json; charset=utf-8",
                success: function (data, status, jqXHR) {
                    //alert(data[0].TimeLeft)
                    //display = document.querySelector('#lblTimeLeft');
                   // startTimer((parseInt(data[0].TimeLeft)), display);
                    fetchVendorDetails()
                    return true
                },
                error: function (xhr) {
                    jQuery("#error").text(xhr.d);
                }
            });
	}
    
    
    
}








var FormValidation = function () {
    var ValidateUser = function () {
        var form1 = $('#FormparticipateSea');
        var error1 = $('.alert-danger', form1);
        var success1 = $('.alert-success', form1);

        form1.validate({
            errorElement: 'span',
            errorClass: 'help-block',
            focusInvalid: false,
            ignore: "",

            rules: {
                txtFreight: {
                    required: true,
                    number: true,
                    minlength: 1,
                    maxlength: 5
                }
            },
            messages: {
                txtFreight: {
                    required: "Please enter amount",
                    number: "number only"
                }
            },
            invalidHandler: function (event, validator) { //display error alert on form submit              
                success1.hide();
                error1.show();
                App.scrollTo(error1, -300);
            },
            highlight: function (element) { // hightlight error inputs
                $(element)
                        .closest('.form-group').addClass('has-error'); // set error class to the control group
            },
            unhighlight: function (element) { // revert the change done by hightlight
                $(element)
                        .closest('.form-group').removeClass('has-error'); // set error class to the control group
            },
            success: function (label) {
                label
                        .closest('.form-group').removeClass('has-error'); // set success class to the control group
            },
            submitHandler: function (form) {
                InsUpdQuoteSea();
                App.scrollTo(error1, -100);
            }
        });
    }
    var handleWysihtml5 = function () {
        if (!jQuery().wysihtml5) {
            return;
        }
        if ($('.wysihtml5').size() > 0) {
            $('.wysihtml5').wysihtml5({
                "stylesheets": ["assets/plugins/bootstrap-wysihtml5/wysiwyg-color.css"]
            });
        }
    }
    return {
        init: function () {
            handleWysihtml5();
            ValidateUser();
        }
    };
} ();