﻿





var FormValidation = function () {

    var ValidateUser = function () {
        var form1 = $('#entryForm');
        var error1 = $('.alert-danger', form1);
        var success1 = $('.alert-success', form1);

        form1.validate({
            errorElement: 'span',
            errorClass: 'help-block',
            focusInvalid: false,
            ignore: "",

            rules: {
                txtemailid: {
                    required: true,
                    email: true
                },
                txtmobileno: {
                    required: true,
                    number: true,
                    minlength: 10,
                    maxlength: 10
                },
                txtcompanyname: {
                    required: true
                },
                ddlcompanytype:
                {
                    required: true
                }
            },
            messages: {
                txtemailid: {
                    required: "Please enter email id"
                },
                txtmobileno: {
                    required: "Please enter mobile no"
                },
                txtcompanyname: {
                    required: "Please enter company name"
                },
                ddlcompanytype:
                {
                    required: "Please select type of company"
                }
            },

            invalidHandler: function (event, validator) { 
                success1.hide();
                error1.show();
                App.scrollTo(error1, -300);
            },
            highlight: function (element) {
                $(element)
                        .closest('.form-group').addClass('has-error'); 
            },
            unhighlight: function (element) { 
                $(element)
                        .closest('.form-group').removeClass('has-error'); 
            },
            success: function (label) {
                label
                        .closest('.form-group').removeClass('has-error'); 
            },
            submitHandler: function (form) {
                App.scrollTo(error1, -100);
            }
        });
    }
    var handleWysihtml5 = function () {
        if (!jQuery().wysihtml5) {
            return;
        }
        if ($('.wysihtml5').size() > 0) {
            $('.wysihtml5').wysihtml5({
                "stylesheets": ["assets/plugins/bootstrap-wysihtml5/wysiwyg-color.css"]
            });
        }
    }
    return {
        init: function () {
            handleWysihtml5();
            ValidateUser();
        }
    };
}();

jQuery("#txtSearch").keyup(function () {
    _this = this;
    // Show only matching TR, hide rest of them
    jQuery.each($("#tblRegisterUsers tbody").find("tr"), function () {
        console.log($(this).text());
        if (jQuery(this).text().toLowerCase().indexOf(jQuery(_this).val().toLowerCase()) == -1)
            jQuery(this).hide();
        else
            jQuery(this).show();
    });
});