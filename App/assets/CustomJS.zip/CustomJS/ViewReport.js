﻿var BidID = "";
var BidTypeID = "";
var BidForID = "";

var postfix = ''

$('#printed_by').html(sessionStorage.getItem('UserName'));
function getCurrenttime() {

    var dt = new Date();
    var day = dt.getDate();
    var month = dt.getMonth() + 1;
    var year = dt.getFullYear();
    var hour = dt.getHours();
    var mins = dt.getMinutes();
    postfix = day + "/" + month + "/" + year;
    
    $('#printed_on').html(postfix);
}




function saveAspdf() {

    var pdf = new jsPDF('p', 'mm', [297, 600]);
       
    pdf.addHTML(document.body, function() {
        pdf.save('BidSummary.pdf');
    });
    window.location = "BidSummary.html?BidID=" + getUrlVars()["BidID"] + "&BidTypeID=" + getUrlVars()["BidTypeID"] + "&BidForID=" + getUrlVars()["BidForID"]
}

function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

function ReportBind(Bidid, Bidtypeid, Bidforid) {

    var tncAttachment = '';
    var anyotherAttachment = '';
    //alert(sessionStorage.getItem("APIPath") + "BidVendorSummary/FetchBidDetails/?BidID=" + BidID + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("UserID")))
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "BidVendorSummary/FetchBidDetails/?BidID=" + BidID + "&VendorID=" + encodeURIComponent(sessionStorage.getItem("UserID")),
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function(data, status, jqXHR) {
            //alert(data.length)
            if (data.length > 0) {
                if (Bidtypeid != 7) {
                    if (data[0].FinalStatus != 'Awarded') {
                        $('#bid_status').html('Status: ' + data[0].FinalStatus)
                    }

                    else {
                        $('#bid_status').html('Status: ' + data[0].FinalStatus + ' to: ' + data[0].AwardedToName)
                    }
                }
                else {
                    $('#bid_status').html('Status: ' + data[0].FinalStatus)
                }

                if (data[0].FinalStatus == 'Cancel') {
                    $('#cancl_btn').hide();
                } else {
                    $('#cancl_btn').show();

                }

                if (data[0].Status == 'Close' || data[0].Status == 'CLOSE') {
                    $('#bid_status').show();

                } else {
                    $('#bid_status').hide();
                }


                BidID = data[0].BidID
                BidTypeID = data[0].BidTypeID
                BidForID = data[0].BidForID
               
                if (data[0].BidTypeID == "2") {
                    jQuery('#tblprice').css('display', 'block');
                    jQuery('#thmodelclass').css('display', 'block');
                    var Modelclass = data[0].ModelClass == "1" ? 'Min' : data[0].ModelClass == "2" ? '45+' : data[0].ModelClass == "3" ? '100+' : data[0].ModelClass == "4" ? '300+' : data[0].ModelClass == "5" ? '500+' : '1000';
                    var fmin = data[0].TargetFreightMin == null ? '' : data[0].TargetFreightMin
                    var f45 = data[0].TargetFreightPlus45 == null ? '' : data[0].TargetFreightPlus45
                    var f100 = data[0].TargetFreightPlus100 == null ? '' : data[0].TargetFreightPlus100
                    var f300 = data[0].TargetFreightPlus300 == null ? '' : data[0].TargetFreightPlus300
                    var f500 = data[0].TargetFreightPlus500 == null ? '' : data[0].TargetFreightPlus500
                    var f1000 = data[0].TargetFreightPlus1000 == null ? '' : data[0].TargetFreightPlus1000

                    jQuery('#tbldetails').append("<tr id=low><td>" + data[0].BidSubject + "</td><td>" + data[0].BidDetails + "</td><td>" + data[0].BidTime + "</td><td>" + data[0].BidTypeName + "</td><td>Price (" + data[0].BidFor + ")</td><td>" + data[0].BidDuration + " mins</td><td>" + data[0].CurrencyName + "</td><td id=tdmodal>" + Modelclass + "+</td><td id=tdtargetprive></td><tr>");
                    jQuery('#tblprice').append("<tr><td>Freight</td><td>" + fmin + "</td><td>" + f45 + "</td><td>" + f100 + "</td><td>" + f300 + "</td><td>" + f500 + "</td><td>" + f1000 + "</td></tr>");


                    if (data[0].BidForID == "3") {
                        var xmin = data[0].TargetExWorksMin == null ? '' : data[0].TargetExWorksMin
                        var x45 = data[0].TargetExWorksPlus45 == null ? '' : data[0].TargetExWorksPlus45
                        var x100 = data[0].TargetExWorksPlus100 == null ? '' : data[0].TargetExWorksPlus100
                        var x300 = data[0].TargetExWorksPlus300 == null ? '' : data[0].TargetExWorksPlus300
                        var x500 = data[0].TargetExWorksPlus500 == null ? '' : data[0].TargetExWorksPlus500
                        var x1000 = data[0].TargetExWorksPlus1000 == null ? '' : data[0].TargetExWorksPlus1000

                        jQuery('#tblprice').append("<tr><td>Exworks</td><td>" + xmin + "</td><td>" + x45 + "</td><td>" + x100 + "</td><td>" + x300 + "</td><td>" + x500 + "</td><td>" + x1000 + "</td></tr>")


                    }
                    
                }
                else {
                    
                    jQuery('#tdtargetprice').css('display', 'none');
                    jQuery('#tdmodal').css('display', 'none');
                    jQuery('#tblprice').css('display', 'none');
                    jQuery('#thmodelclass').css('display', 'none');
                    if (BidTypeID == 3) {


                        jQuery('#thtargetprice').css('display', 'block');
                        var tp = data[0].Targetfreight == null ? '' : data[0].Targetfreight;
                        jQuery('#tbldetails').append("<tr id=low><td>" + data[0].BidSubject + "</td><td>" + data[0].BidDetails + "</td><td>" + data[0].BidTime + "</td><td>" + data[0].BidTypeName + "</td><td>" + data[0].BidFor + "</td><td>" + data[0].BidDuration + " mins</td><td>" + data[0].CurrencyName + "</td><td id=tdmodal></td><td id=tdtargetprive>" + tp + "</td></tr>")
                    }
                    else {

                        jQuery('#tbldetails').append("<tr><td>" + data[0].BidSubject + "</td><td>" + data[0].BidDetails + "</td><td>" + data[0].BidTime + "</td><td>" + data[0].BidTypeName + "</td><td>" + data[0].BidFor + "</td><td>" + data[0].BidDuration + " mins</td><td>" + data[0].CurrencyName + "</td><td id=tdmodal></td><td id=tdtargetprive></td></tr>")
                    }


                    jQuery("#lblbidprice").show();
                    jQuery("#lblbidprice").text(data[0].Targetfreight == null ? '' : data[0].Targetfreight)
                }


            }

        },
        error: function(xhr) {
            jQuery("#error").text(xhr.d);
        }
    });

    if (BidTypeID == 1 || BidTypeID == 6) {
        $('#lnktotvalue').show()
        $('#btngraphbubble').show()
    }
    else {
        $('#lnktotvalue').hide()
        $('#btngraphbubble').show()
    }
}
function fetchBidSummaryDetails(BidID, BidTypeID, BidForID) {


    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "BidVendorSummary/FetchBidSummary/?BidID=" + BidID + "&BidTypeID=" + BidTypeID + "&BidForID=" + BidForID + "&UserID=" + encodeURIComponent(sessionStorage.getItem("UserID")) + "&AuthenticationTonken=" + sessionStorage.getItem("AuthenticationToken"),
        cache: false,
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function(data, status, jqXHR) {


            jQuery("#tblBidSummary > thead").empty();
            jQuery("#tblBidSummary > tbody").empty();
            
            _bidarray = [];

            if (data.length > 0) {
                if (parseInt(BidTypeID) == 1) {
                    


                    var TotalBidValue = ''; // TotalBidValueCeiling = '', TotalBidValueInvoice = '';

                    var Percentreduction = '', Percentreductionceiling = '', Percentreductioninvoice = '';
                    $('#divTarget').hide();
                    var sname = '';

                    var strHead = "<tr><th>Product</th><th>Target Price</th><th>Last Invoice Price</th><th>Bid start price</th><th>Quantity</th><th>UOM</th><th>Contract Duration</th><th>Delivery Location</th><th>Level</th><th>Vendor</th><th>Initial Quote</th><th>Lowest Quote</th><th>Bid Value</th><th>Percentage Reduction (Target Price)</th><th>Percentage Reduction (Last InvoicePrice)</th><th>Percentage Reduction (Bid start price)</th><th>TAT (Days)</th><th>Validity (Days)</th>";
                    strHead += "<th>Warranty (Days)</th><th>VAT %</th><th>CST %</th><th>Excise %</th></tr>";
                    

                    //
                    // strHead += "<th>Shipping Line</th><th>Sailling Days</th><th>Ocean Transit Time</th></tr>";
                    //  alert(strHead) 

                    jQuery('#tblBidSummary > thead').append(strHead);
                    
                    for (var i = 0; i < data.length; i++) {

                        TotalBidValue = parseInt(data[i].Quantity) * parseInt(data[i].LQuote);

                        if (TotalBidValue != 0) {
                            if (data[i].TargetPrice != 0) {
                                Percentreduction = parseFloat(100 - parseFloat(data[i].LQuote / data[i].TargetPrice) * 100).toFixed(2)+' %'
                            }
                            else {
                                Percentreduction = 'Not Specified';
                            }
                            if (data[i].LastInvoicePrice != 0) {
                                Percentreductioninvoice = parseFloat(100 - parseFloat(data[i].LQuote / data[i].LastInvoicePrice) * 100).toFixed(2)+' %'
                            }
                            else {
                                Percentreductioninvoice = 'Not Specified';
                            }

                            
                            Percentreductionceiling = parseFloat(100 - parseFloat(data[i].LQuote / data[i].CeilingPrice) * 100).toFixed(2)+' %'
                        } else {

                            Percentreduction = 'N/A';
                        Percentreductionceiling ='N/A';
                        Percentreductioninvoice = 'N/A';
                    }


                    if (sname != data[i].ShortName) {
                        sname = data[i].ShortName
                        var str = "<tr id=low" + i + "><td>" + data[i].ShortName + "</td><td>" + data[i].TargetPrice + "</td><td>" + data[i].LastInvoicePrice + "</td><td>" + data[i].CeilingPrice + "</td><td>" + data[i].Quantity + "</td><td>" + data[i].UOM + "</td><td>" + data[i].ContractDuration + "</td><td>" + data[i].DeliveryLocation + "</td>";
                            

                    }
                    else {
                        var str = "<tr id=low" + i + "><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>";
                            
                    }


                    str += "<td>" + data[i].SrNo + "</td><td>" + data[i].VendorName + "</td><td>" + (data[i].IQuote == '0' ? '' : data[i].IQuote) + "</td>";
                    str += "<td>" + (data[i].LQuote == '0' ? '' : data[i].LQuote) + "</td>";
                    str += "<td>" + TotalBidValue + "</td>";
                        
                    if (data[i].SrNo == 'L1') {
                        str += "<td style='background-color: #d9edf7; color: #31708f;'>" + Percentreduction + "</td>";
                        str += "<td style='background-color: #d9edf7; color: #31708f;'>" + Percentreductioninvoice + "</td>";
                        str += "<td style='background-color: #d9edf7; color: #31708f;'>" + Percentreductionceiling + "</td>";


                    } else {
                        str += "<td>" + Percentreduction + "</td>";
                        str += "<td>" + Percentreductioninvoice + "</td>";
                        str += "<td>" + Percentreductionceiling + "</td>";
                    }

                    str += "<td>" + (data[i].TAT == '0' ? '' : data[i].TAT) + "</td>";
                    str += "<td>" + (data[i].Validity == '0' ? '' : data[i].Validity) + "</td>";
                    str += "<td>" + (data[i].Warranty == '0' ? '' : data[i].Warranty) + "</td>";
                    str += "<td>" + (data[i].VAT == '0' ? '' : data[i].VAT) + "</td>";
                    str += "<td>" + (data[i].CST == '0' ? '' : data[i].CST) + "</td>";
                    str += "<td>" + (data[i].Excise == '0' ? '' : data[i].Excise) + "</td>";
                    //    //str += "<td>" + (data[i].ShippingLine == null ? '' : data[i].ShippingLine) + "</td><td>" + (data[i].SailingDays == null ? '' : data[i].SailingDays) + "</td><td>" + (data[i].OceanTransitTime == null ? '' : data[i].OceanTransitTime) + "</td>";
                    str += "</tr>";
                       
                    jQuery('#tblBidSummary > tbody').append(str);


                        
                    if (data[i].SrNo == 'L1') {
                        $('#low' + i).css({
                            'background-color': '#dff0d8',
                            'font-weight': 'bold',
                            'color': '#3c763d'
                        })

                    }
                }
            }
            else if (parseInt(BidTypeID) == 6) {
                $('#lnktotvalue').html('Detailed Report')
                if ($('#lnktotvalue').html() == "Detailed Report") {
                    jQuery("#tblBidSummary").hide()
                    jQuery("#tblbidsummarypercentagewise").show()
                    $('#divfordetailreport').show()
                    $('#divforBidsummary').hide()
                }


                var TotalBidValue = ''; // TotalBidValueCeiling = '', TotalBidValueInvoice = '';

                var Percentreduction = '', Percentreductionceiling = '', Percentreductioninvoice = '';
                $('#divTarget').hide();
                var sname = '';

                var strHead = "<tr><th>Product</th><th>Target Price</th><th>Last Sale Price</th><th>Bid start price</th><th>Quantity</th><th>UOM</th><th>Contract Duration</th><th>Dispatch Location</th><th>Level</th><th>Vendor</th><th>Initial Quote</th><th>Highest Quote</th><th>Bid Value</th><th>Percentage Reduction (Target Price)</th><th>Percentage Reduction (Last Sale Price)</th><th>Percentage Reduction (Bid start price)</th></tr>";

               // var strHeadsummary = "<tr><th>Product</th><th>Target Price</th><th>Last Sale Price</th><th>Bid start price</th><th>Quantity</th><th>UOM</th><th>Level</th><th>Vendor</th><th>Initial Quote</th><th>Highest Quote</th><th>Bid Value</th><th>Percentage Reduction (Target Price)</th><th>Percentage Reduction (Last Sale Price)</th><th>Percentage Reduction (Bid start price)</th></tr>";

                //                    strHead += "<th>Shipping Line</th><th>Sailling Days</th><th>Ocean Transit Time</th></tr>";

                jQuery('#tblBidSummary > thead').append(strHead);
                //jQuery('#tblbidsummarypercentagewise > thead').append(strHeadsummary);
                for (var i = 0; i < data.length; i++) {

                    TotalBidValue = parseInt(data[i].Quantity) * parseInt(data[i].LQuote);

                    if (TotalBidValue != 0) {
                        if (data[i].TargetPrice != 0) {
                            Percentreduction = parseFloat(100 - parseFloat(data[i].LQuote / data[i].TargetPrice) * 100).toFixed(2)+' %'
                        }
                        else {
                            Percentreduction = 'Not Specified';
                        }
                        if (data[i].LastInvoicePrice != 0) {
                            Percentreductioninvoice = parseFloat(100 - parseFloat(data[i].LQuote / data[i].LastInvoicePrice) * 100).toFixed(2)+' %'
                        }
                        else {
                            Percentreductioninvoice = 'Not Specified';
                        }

                            
                        Percentreductionceiling = parseFloat(100 - parseFloat(data[i].LQuote / data[i].CeilingPrice) * 100).toFixed(2)+' %'
                    } else {

                        Percentreduction = 'N/A';
                        Percentreductionceiling = 'N/A';
                        Percentreductioninvoice = 'N/A';
                    }
                    if (sname != data[i].ShortName) {
                        sname = data[i].ShortName
                        var str = "<tr id=low" + i + "><td>" + data[i].ShortName + "</td><td>" + data[i].TargetPrice + "</td><td>" + data[i].LastInvoicePrice + "</td><td>" + data[i].CeilingPrice + "</td><td>" + data[i].Quantity + "</td><td>" + data[i].UOM + "</td><td>" + data[i].ContractDuration + "</td><td>" + data[i].DeliveryLocation + "</td>";
                       // var strsumm = "<tr id=low" + i + "><td>" + data[i].ShortName + "</td><td>" + data[i].TargetPrice + "</td><td>" + data[i].LastInvoicePrice + "</td><td>" + data[i].CeilingPrice + "</td><td>" + data[i].Quantity + "</td><td>" + data[i].UOM + "</td>";

                    }
                    else {
                        var str = "<tr id=low" + i + "><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>";
                       // var strsumm = "<tr id=low" + i + "><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>";
                    }


                    str += "<td>" + data[i].SrNo + "</td><td>" + data[i].VendorName + "</td><td>" + (data[i].IQuote == '0' ? '' : data[i].IQuote) + "</td>";
                    str += "<td>" + (data[i].LQuote == '0' ? '' : data[i].LQuote) + "</td>";
                    str += "<td>" + TotalBidValue + "</td>";
                    //strsumm += "<td>" + data[i].SrNo + "</td><td>" + data[i].VendorName + "</td><td>" + (data[i].IQuote == '0' ? '' : data[i].IQuote) + "</td>";
                   // strsumm += "<td>" + (data[i].LQuote == '0' ? '' : data[i].LQuote) + "</td><td>" + TotalBidValue + "</td>";
                    if (data[i].SrNo == 'H1') {
                        str += "<td style='background-color: #d9edf7; color: #31708f;'>" + Percentreduction + "</td>";
                        str += "<td style='background-color: #d9edf7; color: #31708f;'>" + Percentreductioninvoice + "</td>";
                        str += "<td style='background-color: #d9edf7; color: #31708f;'>" + Percentreductionceiling + "</td>";
                            


                    } else {
                        str += "<td>" + Percentreduction + "</td>";
                        str += "<td>" + Percentreductioninvoice + "</td>";
                        str += "<td>" + Percentreductionceiling + "</td>";
                           
                    }


                    //    //str += "<td>" + (data[i].ShippingLine == null ? '' : data[i].ShippingLine) + "</td><td>" + (data[i].SailingDays == null ? '' : data[i].SailingDays) + "</td><td>" + (data[i].OceanTransitTime == null ? '' : data[i].OceanTransitTime) + "</td>";
                    str += "</tr>";
                       
                    jQuery('#tblBidSummary > tbody').append(str);


                    if (data[i].SrNo == 'L1') {
                        $('#low' + i).css({
                            'background-color': '#dff0d8',
                            'font-weight': 'bold',
                            'color': '#3c763d'
                        })

                    }
                    if (data[i].SrNo == 'H1') {
                        $('#low' + i).css({
                            'background-color': '#dff0d8',
                            'font-weight': 'bold',
                            'color': '#3c763d'
                        })

                    }
                }
            }
            else if (parseInt(BidTypeID) == 7) {

               
                var TotalBidValue = ''; // TotalBidValueCeiling = '', TotalBidValueInvoice = '';

                var Percentreduction = '', Percentreductionceiling = '', Percentreductioninvoice = '';
                $('#divTarget').hide();
                var sname = '';

                var strHead = "<tr><th>Port</th><th>Target Price</th><th>Last Invoice Price</th><th>Bid start price</th><th>Quantity</th><th>UOM</th><th>Level</th><th>Vendor</th><th>Initial Quote</th><th>Lowest Quote</th><th>Bid Value</th><th>Percentage Reduction (Target Price)</th><th>Percentage Reduction (Last Invoice Price)</th><th>Percentage Reduction (Bid start price)</th></tr>";

                jQuery('#tblBidSummary > thead').append(strHead);
                
                for (var i = 0; i < data.length; i++) {
                   
                    TotalBidValue = parseInt(data[i].Quantity) * parseInt(data[i].LQuote);

                    if (TotalBidValue != 0) {
                        if (data[i].TargetPrice != 0) {
                            Percentreduction = parseFloat(100 - parseFloat(data[i].LQuote / data[i].TargetPrice) * 100).toFixed(2) + ' %'
                        }
                        else {
                            Percentreduction = 'Not Specified';
                        }
                        if (data[i].LastInvoicePrice != 0) {
                            Percentreductioninvoice = parseFloat(100 - parseFloat(data[i].LQuote / data[i].LastInvoicePrice) * 100).toFixed(2) + ' %'
                        }
                        else {
                            Percentreductioninvoice = 'Not Specified';
                        }


                        Percentreductionceiling = parseFloat(100 - parseFloat(data[i].LQuote / data[i].CeilingPrice) * 100).toFixed(2) + ' %'
                    } else {

                        Percentreduction = 'N/A';
                        Percentreductionceiling = 'N/A';
                        Percentreductioninvoice = 'N/A';
                    }

                    if (sname != data[i].DestinationPort) {
                        sname = data[i].DestinationPort
                        var str= "<tr id=low" + i + "><td>" + data[i].DestinationPort + "</td><td>" + data[i].TargetPrice + "</td><td>" + data[i].LastInvoicePrice + "</td><td>" + data[i].CeilingPrice + "</td><td>" + data[i].Quantity + "</td><td>" + data[i].UOM + "</td>";
                        

                    }
                    else {
                        var str= "<tr id=low" + i + "><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>";
                       
                    }


                    str += "<td>" + data[i].SrNo + "</td><td>" + data[i].VendorName + "</td><td>" + (data[i].IQuote == '0' ? '' : data[i].IQuote) + "</td>";
                    str += "<td>" + (data[i].LQuote == '0' ? '' : data[i].LQuote) + "</td>";
                    str += "<td>" + TotalBidValue + "</td>";
                   
                    if (data[i].SrNo == 'L1') {
                        str += "<td style='background-color: #d9edf7; color: #31708f;'>" + Percentreduction + "</td>";
                        str += "<td style='background-color: #d9edf7; color: #31708f;'>" + Percentreductioninvoice + "</td>";
                        str += "<td style='background-color: #d9edf7; color: #31708f;'>" + Percentreductionceiling + "</td>";
                        


                    } else {
                        str += "<td>" + Percentreduction + "</td>";
                        str += "<td>" + Percentreductioninvoice + "</td>";
                        str += "<td>" + Percentreductionceiling + "</td>";
                       
                    }
                    str += "</tr>";
                   
                    jQuery('#tblBidSummary > tbody').append(str);
                   
                    if (data[i].SrNo == 'L1') {
                        $('#low' + i).css({
                            'background-color': '#dff0d8',
                            'font-weight': 'bold',
                            'color': '#3c763d'
                        })

                    }
                    
                }
            }
            else if (parseInt(BidTypeID) == 2) {
                if (parseInt(BidForID) == 2) {
                    var strHead = "<tr><th rowspan='2'>Level</th><th rowspan='2'>Vendor Name</th><th rowspan='2'>Carrier</th><th rowspan='2'>Loading Airport</th><th rowspan='2'>Consolidation Days</th>";
                    strHead += "<th colspan='6'>Freight</th><th colspan='6'>Ex-Works</th><th rowspan='2'>FSC</th><th rowspan='2'>SSC</th><th rowspan='2'>DO Charges</th><th colspan='6'>Total (Including surcharges)</th><th rowspan='2'>Total For Model Class</th>";
                    strHead += "</tr>";
                    strHead += "<tr><th>Min</th><th>45+</th><th>100+</th><th>300+</th><th>500+</th><th>1000+</th><th>Min</th><th>45+</th><th>100+</th><th>300+</th><th>500+</th><th>1000+</th><th>Min</th><th>45+</th><th>100+</th><th>300+</th><th>500+</th><th>1000+</th>";
                    strHead += "</tr>";
                    jQuery('#tblBidSummary > thead').append(strHead);
                    for (var i = 0; i < data.length; i++) {
                        var str = "<tr id=low2" + i + "><td>" + data[i].SrNo + "</td><td>" + data[i].VendorName + "</td><td>" + data[i].Carrier + "</td><td>" + data[i].LoadingAirport + "</td>";
                        str += "<td>" + data[i].ConsolidationDays + "</td><td>" + (data[i].FreightMin == null ? '' : data[i].FreightMin) + "</td>";
                        str += "<td>" + (data[i].FreightPlus45 == null ? '' : data[i].FreightPlus45) + "</td><td>" + (data[i].FreightPlus100 == null ? '' : data[i].FreightPlus100) + "</td><td>" + (data[i].FreightPlus300 == null ? '' : data[i].FreightPlus300) + "</td>";
                        str += "<td>" + (data[i].FreightPlus500 == null ? '' : data[i].FreightPlus500) + "</td><td>" + (data[i].FreightPlus1000 == null ? '' : data[i].FreightPlus1000) + "</td><td>" + (data[i].ExWorksMin == null ? '' : data[i].ExWorksMin) + "</td>";
                        str += "<td>" + (data[i].ExWorksPlus45 == null ? '' : data[i].ExWorksPlus45) + "</td><td>" + (data[i].ExWorksPlus100 == null ? '' : data[i].ExWorksPlus100) + "</td><td>" + (data[i].ExWorksPlus300 == null ? '' : data[i].ExWorksPlus300) + "</td>";
                        str += "<td>" + (data[i].ExWorksPlus500 == null ? '' : data[i].ExWorksPlus500) + "</td><td>" + (data[i].ExWorksPlus1000 == null ? '' : data[i].ExWorksPlus1000) + "</td><td>" + (data[i].FSC == '0' ? '' : data[i].FSC) + "</td><td>" + (data[i].SSC == '0' ? '' : data[i].SSC) + "</td><td>" + (data[i].DoCharges == null ? '' : data[i].DoCharges) + "</td>";
                        str += "<td>" + (data[i].TotMin == null ? '' : data[i].TotMin) + "</td><td>" + (data[i].Tot45 == null ? '' : data[i].Tot45) + "</td><td>" + (data[i].Tot100 == null ? '' : data[i].Tot100) + "</td><td>" + (data[i].Tot300 == null ? '' : data[i].Tot300) + "</td>";
                        str += "<td>" + data[i].Tot500 + "</td><td>" + data[i].Tot1000 + "</td><td>" + data[i].MinPrice + "</td>";
                        str += "</tr>";
                        jQuery('#tblBidSummary > tbody').append(str);
                        if (data[i].SrNo == 'L1') {
                            $('#low2' + i).css({
                                'background-color': '#dff0d8',
                                'font-weight': 'bold',
                                'color': '#3c763d'
                            });

                        }
                    }
                }
                if (parseInt(BidForID) == 3) {
                    var strHead = "<tr><th rowspan='2'>Level</th><th rowspan='2'>Vendor Name</th><th rowspan='2'>Carrier</th><th rowspan='2'>Loading Airport</th><th rowspan='2'>Consolidation Days</th>";
                    strHead += "<th colspan='6'>Freight</th><th colspan='6'>Ex-Works</th><th rowspan='2'>FSC</th><th rowspan='2'>SSC</th><th rowspan='2'>DO Charges</th><th colspan='6'>Total (Including surcharges)</th><th rowspan='2'>Total For Model Class</th>";
                    strHead += "</tr>";
                    strHead += "<tr><th>Min</th><th>45+</th><th>100+</th><th>300+</th><th>500+</th><th>1000+</th><th>Min</th><th>45+</th><th>100+</th><th>300+</th><th>500+</th><th>1000+</th><th>Min</th><th>45+</th><th>100+</th><th>300+</th><th>500+</th><th>1000+</th>";
                    strHead += "</tr>";
                    jQuery('#tblBidSummary > thead').append(strHead);
                    for (var i = 0; i < data.length; i++) {
                        var str = "<tr id=low3" + i + "><td>" + data[i].SrNo + "</td><td>" + data[i].VendorName + "</td><td>" + data[i].Carrier + "</td><td>" + (data[i].LoadingAirport == null ? '' : data[i].LoadingAirport) + "</td>";
                        str += "<td>" + (data[i].ConsolidationDays == null ? '' : data[i].ConsolidationDays) + "</td><td>" + (data[i].FreightMin == null ? '' : data[i].FreightMin) + "</td>";
                        str += "<td>" + (data[i].FreightPlus45 == null ? '' : data[i].FreightPlus45) + "</td><td>" + (data[i].FreightPlus100 == null ? '' : data[i].FreightPlus100) + "</td><td>" + (data[i].FreightPlus300 == null ? '' : data[i].FreightPlus300) + "</td>";
                        str += "<td>" + (data[i].FreightPlus500 == null ? '' : data[i].FreightPlus500) + "</td><td>" + (data[i].FreightPlus1000 == null ? '' : data[i].FreightPlus1000) + "</td><td>" + (data[i].ExWorksMin == null ? '' : data[i].ExWorksMin) + "</td>";
                        str += "<td>" + (data[i].ExWorksPlus45 == null ? '' : data[i].ExWorksPlus45) + "</td><td>" + (data[i].ExWorksPlus100 == null ? '' : data[i].ExWorksPlus100) + "</td><td>" + (data[i].ExWorksPlus300 == null ? '' : data[i].ExWorksPlus300) + "</td>";
                        str += "<td>" + (data[i].ExWorksPlus500 == null ? '' : data[i].ExWorksPlus500) + "</td><td>" + (data[i].ExWorksPlus1000 == null ? '' : data[i].ExWorksPlus1000) + "</td><td>" + (data[i].FSC == '0' ? '' : data[i].FSC) + "</td><td>" + (data[i].SSC == '0' ? '' : data[i].SSC) + "</td><td>" + (data[i].DoCharges == null ? '' : data[i].DoCharges) + "</td>";
                        str += "<td>" + (data[i].TotMin == null ? '' : data[i].TotMin) + "</td><td>" + (data[i].Tot45 == null ? '' : data[i].Tot45) + "</td><td>" + (data[i].Tot100 == null ? '' : data[i].Tot100) + "</td><td>" + (data[i].Tot300 == null ? '' : data[i].Tot300) + "</td>";
                        str += "<td>" + (data[i].Tot500 == null ? '' : data[i].Tot500) + "</td><td>" + (data[i].Tot1000 == null ? '' : data[i].Tot1000) + "</td><td>" + (data[i].MinPrice == null ? '' : data[i].MinPrice) + "</td>";
                        str += "</tr>";
                        jQuery('#tblBidSummary > tbody').append(str);
                        if (data[i].SrNo == 'L1') {
                            $('#low3' + i).css({
                                'background-color': '#dff0d8',
                                'font-weight': 'bold',
                                'color': '#3c763d'
                            });

                        }
                    }
                }
            }
            else if (parseInt(BidTypeID) == 3) {

                if (parseInt(BidForID) == 4) {
                    //Freight
                    var strHead = "<tr><th>Level</th><th>Vendor</th><th>Initial Quote</th><th>Lowest Quote</th>";
                    strHead += "<th>BAF</th><th>CAF</th><th>Total Value</th><th>Forwarder's Do Charges</th>";
                    strHead += "<th>Shipping Line</th><th>Sailling Days</th><th>Ocean Transit Time</th></tr>";
                    jQuery('#tblBidSummary > thead').append(strHead);
                    for (var i = 0; i < data.length; i++) {
                        var str = "<tr id=low4" + i + "><td>" + data[i].SrNo + "</td><td>" + data[i].VendorName + "</td>";
                        str += "<td>" + data[i].IQuote + "</td>";
                        str += "<td>" + (data[i].LQuote == null ? '' : data[i].LQuote) + "</td>";
                        //str += "<td>" + ((data[i].ExWorks == null || data[i].ExWorks == 0) ? '' : data[i].ExWorks) + "</td>";
                        str += "<td>" + ((data[i].BAF == null || data[i].BAF == 0) ? '' : data[i].BAF) + "</td>";
                        str += "<td>" + ((data[i].CAF == null || data[i].CAF == 0) ? '' : data[i].CAF) + "</td>";
                        str += "<td>" + (data[i].TotalValue == null ? '' : data[i].TotalValue) + "</td><td>" + (data[i].ForwardersDO == '0' ? '' : data[i].ForwardersDO) + "</td>";
                        str += "<td>" + (data[i].ShippingLine == null ? '' : data[i].ShippingLine) + "</td><td>" + (data[i].SailingDays == null ? '' : data[i].SailingDays) + "</td><td>" + (data[i].OceanTransitTime == null ? '' : data[i].OceanTransitTime) + "</td>";
                        str += "</tr>";
                        jQuery('#tblBidSummary > tbody').append(str);
                        if (data[i].SrNo == 'L1') {
                            $('#low4' + i).css({
                                'background-color': '#dff0d8',
                                'font-weight': 'bold',
                                'color': '#3c763d'
                            });

                        }
                    }
                }
                else if (parseInt(BidForID) == 5) {
                    // Total Value
                    var strHead = "<tr><th>Level</th><th>Vendor</th><th>Initial Quote (INR)</th><th>Lowest Quote (INR)</th><th>Freight</th>";
                    strHead += "<th>BAF</th><th>CAF</th><th>Inland Haulage (INR)</th><th>Shipping Line DO Charges (INR)</th><th>Container Cleaning Charges (INR)</th>";
                    strHead += "<th>Shipping Line Any Other Charges (INR)</th><th>Forwarder's DO Charges (INR)</th><th>Shipping Line</th><th>Sailling Days</th><th>Ocean Transit Time</th></tr>";
                    jQuery('#tblBidSummary > thead').append(strHead);
                    for (var i = 0; i < data.length; i++) {
                        var str = "<tr id=low5" + i + "><td>" + data[i].SrNo + "</td><td>" + data[i].VendorName + "</td><td>" + data[i].IQuote + "</td>";
                        str += "<td>" + (data[i].LQuote == '0' ? '' : data[i].LQuote) + "</td><td>" + (data[i].Freight == '0' ? '' : data[i].Freight) + "</td><td>" + (data[i].BAF == '0' ? '' : data[i].BAF) + "</td><td>" + (data[i].CAF == '0' ? '' : data[i].CAF) + "</td>";
                        str += "<td>" + (data[i].InlandHaulage == '0' ? '' : data[i].InlandHaulage) + "</td><td>" + (data[i].ShippingLineDO == '0' ? '' : data[i].ShippingLineDO) + "</td><td>" + (data[i].ContainerClgChg == '0' ? '' : data[i].ContainerClgChg) + "</td>";
                        str += "<td>" + (data[i].ShippingLineOther == '0' ? '' : data[i].ShippingLineOther) + "</td><td>" + (data[i].ForwardersDO == '0' ? '' : data[i].ForwardersDO) + "</td>";
                        str += "<td>" + data[i].ShippingLine + "</td><td>" + data[i].SailingDays + "</td><td>" + data[i].OceanTransitTime + "</td>";
                        str += "</tr>";
                        jQuery('#tblBidSummary > tbody').append(str);
                        if (data[i].SrNo == 'L1') {
                            $('#low5' + i).css({
                                'background-color': '#dff0d8',
                                'font-weight': 'bold',
                                'color': '#3c763d'
                            });

                        }
                    }
                }
                else if (parseInt(BidForID) == 6) {
                    // Freight & Exworks
                    var strHead = "<tr><th>Level</th><th>Vendor</th><th>Initial Quote (INR)</th><th>Lowest Quote (INR)</th><th>Freight</th><th>ExWorks</th>";
                    strHead += "<th>BAF</th><th>CAF</th><th>Inland Haulage (INR)</th><th>Shipping Line's DO Charges (INR)</th><th>Container Cleaning Charges (INR)</th><th>Shipping Line's Any Other Charges (INR)</th><th>Forwarder's Do Charges</th>";
                    strHead += "<th>Shipping Line</th><th>Sailling Days</th><th>Ocean Transit Time</th></tr>";
                    jQuery('#tblBidSummary > thead').append(strHead);
                    for (var i = 0; i < data.length; i++) {
                        var str = "<tr id=low6" + i + "><td>" + data[i].SrNo + "</td><td>" + data[i].VendorName + "</td><td>" + data[i].IQuote + "</td>";
                        str += "<td>" + (data[i].LQuote == '0' ? '' : data[i].LQuote) + "</td><td>" + (data[i].Freight == '0' ? '' : data[i].Freight) + "</td><td>" + (data[i].ExWorks == '0' ? '' : data[i].ExWorks) + "</td><td>" + (data[i].BAF == '0' ? '' : data[i].BAF) + "</td><td>" + (data[i].CAF == '0' ? '' : data[i].CAF) + "</td>";
                        str += "<td>" + (data[i].InlandHaulage == '0' ? '' : data[i].InlandHaulage) + "</td><td>" + (data[i].ShippingLineDO == '0' ? '' : data[i].ShippingLineDO) + "</td><td>" + (data[i].ContainerClgChg == '0' ? '' : data[i].ContainerClgChg) + "</td><td>" + (data[i].ShippingLineOther == '0' ? '' : data[i].ShippingLineOther) + "</td><td>" + (data[i].ForwardersDO == '0' ? '' : data[i].ForwardersDO) + "</td>";
                        str += "<td>" + data[i].ShippingLine + "</td><td>" + data[i].SailingDays + "</td><td>" + data[i].OceanTransitTime + "</td>";
                        str += "</tr>";
                        jQuery('#tblBidSummary > tbody').append(str);
                        if (data[i].SrNo == 'L1') {
                            $('#low6' + i).css({
                                'background-color': '#dff0d8',
                                'font-weight': 'bold',
                                'color': '#3c763d'
                            });

                        }
                    }
                }
            }

            else if (parseInt(BidTypeID) == 5) { // Warehouse
                var strHead = "<tr><th>Level</th><th>Vendor</th><th>Initial Quote</th><th>Lowest Quote</th><th>Warehouse Area</th><th>Rent Per Sq. Ft.</th>";
                strHead += "<th>Manpower Cost</th><th>Infrastructure Cost</th><th>Utilities Cost</th><th>Fixed Management Fee</th></tr>";
                //                    strHead += "<th>Shipping Line</th><th>Sailling Days</th><th>Ocean Transit Time</th></tr>";
                jQuery('#tblBidSummary > thead').append(strHead);
                for (var i = 0; i < data.length; i++) {
                    var str = "<tr id=low7" + i + "><td>" + data[i].SrNo + "</a></td><td>" + data[i].VendorName + "</td>";
                    str += "<td>" + data[i].IQuote + "</td>";
                    str += "<td>" + (data[i].LQuote == '0' ? '' : data[i].LQuote) + "</td><td>" + (data[i].WarehouseArea == '0' ? '' : data[i].WarehouseArea) + "</td>";
                    str += "<td>" + (data[i].PerSquareFeetRate == '0' ? '' : data[i].PerSquareFeetRate) + "</td>";
                    str += "<td>" + (data[i].ManPowerCost == '0' ? '' : data[i].ManPowerCost) + "</td>";
                    str += "<td>" + (data[i].InfrastructureCost == '0' ? '' : data[i].InfrastructureCost) + "</td>";
                    str += "<td>" + (data[i].UtilitiesCost == '0' ? '' : data[i].UtilitiesCost) + "</td><td>" + (data[i].FixedManagementFee == '0' ? '' : data[i].FixedManagementFee) + "</td>";
                    //str += "<td>" + (data[i].ShippingLine == null ? '' : data[i].ShippingLine) + "</td><td>" + (data[i].SailingDays == null ? '' : data[i].SailingDays) + "</td><td>" + (data[i].OceanTransitTime == null ? '' : data[i].OceanTransitTime) + "</td>";
                    str += "</tr>";
                    jQuery('#tblBidSummary > tbody').append(str);
                    if (data[i].SrNo == 'L1') {
                        $('#low7' + i).css({
                            'background-color': '#dff0d8',
                            'font-weight': 'bold',
                            'color': '#3c763d'
                        });

                    }
                }

            } else if (parseInt(BidTypeID) == 4) { // Domestic
                var Dname = '';
                var str = '';
                var strHead = "<tr><th>Vendor</th><th>Vehicle Type</th><th>Origin Name</th><th>Destination Name</th><th>Level</th><th>Initial Quote</th><th>Lowest Quote</th><th>TAT</th><th>DocketCharge</th><th>FOV</th><th>FSC</th><th>CFT</th><th>MinChargeWt</th><th>ODA </th></tr>";

                jQuery('#tblBidSummary > thead').append(strHead);
                for (var i = 0; i < data.length; i++) {
                    if (Dname != data[i].VendorName) {
                        Dname = data[i].VendorName
                        str = "<tr id=lowD" + i + "><td>" + data[i].VendorName + "</td><td>" + data[i].VehicleTypeName + "</td>";
                    }
                    else {
                        str = "<tr id=lowD" + i + "><td>&nbsp;</td><td>&nbsp;</td>";
                    }

                    str += "<td>" + data[i].OriginName + "</td>";
                    str += "<td>" + data[i].DestinationName + "</td>";
                    str += "<td>" + data[i].SrNo + "</td>";
                    str += "<td>" + data[i].IQuote + "</td>"
                    str += "<td>" + data[i].LQuote + "</td>";
                    str += "<td>" + data[i].TAT + "</td>";
                    str += "<td>" + data[i].DocketCharge + "</td>";
                    str += "<td>" + data[i].FOV + "</td>";
                    str += "<td>" + data[i].FSC + "</td>";
                    str += "<td>" + data[i].CFT + "</td>";
                    str += "<td>" + data[i].MinChargeWt + "</td>";
                    str += "<td>" + data[i].ODA + "</td>";
                    str += "</tr>";
                    jQuery('#tblBidSummary > tbody').append(str);
                    if (data[i].SrNo == 'L1') {
                        $('#lowD' + i).css({
                            'background-color': '#dff0d8',
                            'font-weight': 'bold',
                            'color': '#3c763d'
                        });

                    }
                }

            }
            _bidarray.push(['VendorID', 'Price', 'Time', 'VendorName'])


            _timelft = $('#lblTimeLeft').text();

            if (_timelft == null || _timelft == '') {
                _timelft = 0;
            }
            else {
                _timelft = _timelft.slice(0, _timelft.indexOf(':'))


            }

            //alert(_timelft)
            for (var prop = 0; prop < data.length; prop++) {
                //VendorName.slice(0, data[prop].VendorName.indexOf(' '))
                _bidarray.push([data[prop].ShortName, parseInt(data[prop].LQuote), parseInt(_timelft), data[prop].VendorName]) //]
            }




        }
    else {
                jQuery('#tblBidSummary > tbody').append("<tr><td colspan='18' style='text-align: center; color:red;'>No record found</td></tr>");
}
}
});
}


function FetchRecomendedVendor(bidid) {
    // alert(sessionStorage.getItem("APIPath") + "ApprovalAir/FetchRecomendedVendor/?BidID=" + bidid + "&UserID=" + encodeURIComponent(sessionStorage.getItem("UserID")) + "&AuthenticationTonken=" + sessionStorage.getItem("AuthenticationToken"))
    jQuery.ajax({
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "ApprovalAir/FetchRecomendedVendor/?BidID=" + bidid + "&UserID=" + encodeURIComponent(sessionStorage.getItem("UserID")) + "&AuthenticationTonken=" + sessionStorage.getItem("AuthenticationToken"),
        type: "GET",
        cache: false,
        crossDomain: true,
        dataType: "json",
        success: function(data) {

            $('#tblapprovalprocess').empty()
            if (data.length > 0) {
                $('#tblapprovalprocess').css('display', 'block');

                $('#tblapprovalprocess').append('<tr><th width="25%">Action Taken By</th><th width="25%">Remarks</th><th width="25%">Action Type</th><th style=display:none id=thvendor>Recomended Vendor</th><th width="25%">Completion DT</th></tr>')
                
                for (var i = 0; i < data.length; i++) {
                    if (data[i].VendorName != "") {
                        $('#tblapprovalprocess').append('<tr><td width="25%">' + data[i].ActionTakenBy + '</td><td width="25%">' + data[i].Remarks + '</td><td width="25%">' + data[i].FinalStatus + '</td><td>' + data[i].VendorName + '</td><td width="25%">' + data[i].ReceiptDt + '</td></tr>')
                        $('#thvendor').css('display', 'block')
                    }
                    else {
                        $('#tblapprovalprocess').append('<tr><td width="25%">' + data[i].ActionTakenBy + '</td><td width="25%">' + data[i].Remarks + '</td><td width="25%">' + data[i].FinalStatus + '</td><td width="25%">' + data[i].ReceiptDt + '</td></tr>')
                        $('#thvendor').css('display','none')
                    }
                }
            }
            else {
                $('#tblapprovalprocess').append('<tr><td colspan="15" style="text-align: center; color: Red">No record found</td></tr>')
                $('#tblapprovalprocess').css('display', 'none');
            }

        }
    });

}