﻿var APIPath = sessionStorage.getItem("APIPath");
var error = $('.alert-danger');
var success = $('.alert-success');
var form = $('#submit_form');

var FormWizard = function () {

    return {

        init: function () {

            if (!jQuery().bootstrapWizard) {

                return;

            }

            function format(state) {

                if (!state.id) return state.text; // optgroup

                return "<img class='flag' src='assets/global/img/flags/" + state.id.toLowerCase() + ".png'/>&nbsp;&nbsp;" + state.text;

            }

            form.validate({

                doNotHideMessage: true, //this option enables to show the error/success messages on tab switch.

                errorElement: 'span', //default input error message container

                errorClass: 'help-block help-block-error', // default input error message class

                focusInvalid: false, // do not focus the last invalid input

                rules: {

                    txtcustomername: {
                        required: true
                    },

                    txtAddress1: {
                        required: true
                    },
                    from: {
                        required: true

                    },
                    to: {
                        required: true
                        
                    },
                    txturlextension: {
                        required: true,
                        maxlength:30
                    },

                    txtnobids: {
                        required: true,
                        number:true
                    },

                    dropcurrency: {
                        required: true
                    },

                    file1: {
                        required: false
                    },
                    txttermscondition: {
                        required: true
                    },

                    //Second Tab
                    txtadminfirstname: {
                        required: true,
                        maxlength: 200
                    },
                    txtUserEmailID: {
                        required: true,
                        //Email:true,
                        maxlength: 100
                    },
                    txtmobileNo: {
                        maxlength: 10,
                        number:true
                    },

                },

                messages: {

                    'payment[]': {

                        required: "Please select at least one option",

                        minlength: jQuery.validator.format("Please select at least one option")

                    },
                    txtitembidduration: {
                        required: "Please Enter Bid Duration."
                    }

                },

                errorPlacement: function (error, element) {

                    if (element.attr("name") == "gender") {

                        error.insertAfter("#form_gender_error");

                    } else if (element.attr("name") == "payment[]") {

                        error.insertAfter("#form_payment_error");

                    } else {

                        error.insertAfter(element);

                    }

            },

                invalidHandler: function (event, validator) {
                    success.hide();
                    Metronic.scrollTo(error, -200);

                },

                highlight: function (element) {

                    $(element)
                        .closest('.inputgroup').removeClass('has-success').addClass('has-error');
                    $(element)
                        .closest('.col-md-4,.col-md-10').removeClass('has-success').addClass('has-error');
                    $(element).closest('.col-md-3,.col-md-10').removeClass('has-success').addClass('has-error');

                },

                unhighlight: function (element) {

                    $(element)
                        .closest('.inputgroup').removeClass('has-error');
                    $(element)
                        .closest('.col-md-4,.col-md-10').removeClass('has-error');
                    $(element)
                        .closest('.col-md-3,.col-md-10').removeClass('has-error');

                },

                success: function (label) {

                    if (label.attr("for") == "gender" || label.attr("for") == "payment[]") {

                        label.closest('.inputgroup').removeClass('has-error').addClass('has-success');
                        label.remove();

                    } else {

                        label

                            .addClass('valid') // mark the current input as valid and display OK icon

                            .closest('.inputgroup').removeClass('has-error').addClass('has-success'); // set success class to the control group

                    }


                },
             submitHandler: function (form) {

                    // success.show();

                    error.hide();

                }



            });
            var displayConfirm = function () {

                $('#tab4 .form-control-static', form).each(function () {

                    var input = $('[name="' + $(this).attr("data-display") + '"]', form);

                    if (input.is(":radio")) {

                        input = $('[name="' + $(this).attr("data-display") + '"]:checked', form);

                    }

                    if (input.is(":text") || input.is("textarea")) {

                        $(this).html(input.val());

                    } else if (input.is("select")) {

                        $(this).html(input.find('option:selected').text());

                    } else if (input.is(":radio") && input.is(":checked")) {

                        $(this).html(input.attr("data-title"));

                    } else if ($(this).attr("data-display") == 'payment') {

                        var payment = [];

                        $('[name="payment[]"]:checked').each(function () {

                            payment.push($(this).attr('data-title'));

                        });

                        $(this).html(payment.join("<br>"));

                    }

                });

            }

         var handleTitle = function (tab, navigation, index) {

             var total = navigation.find('li').length;
                 var current = index + 1;
             
                // set wizard title

                $('.step-title', $('#form_wizard_1')).text('Step ' + (index + 1) + ' of ' + total);

                // set done steps

                jQuery('li', $('#form_wizard_1')).removeClass("done");

                var li_list = navigation.find('li');

                for (var i = 0; i < index; i++) {

                    jQuery(li_list[i]).addClass("done");

                }



                if (current == 1) {

                    $('#form_wizard_1').find('.button-previous').hide();

                } else {

                    $('#form_wizard_1').find('.button-previous').show();

                }

            // alert(current)
            // alert(total)

                if (current >= total) {

                    $('#form_wizard_1').find('.button-next').hide();

                    $('#form_wizard_1').find('.button-submit').show();

                    displayConfirm();

                } else {

                    $('#form_wizard_1').find('.button-next').show();

                    $('#form_wizard_1').find('.button-submit').hide();

                }

                Metronic.scrollTo($('.page-title'));

            }




            // default form wizard

            $('#form_wizard_1').bootstrapWizard({

                'nextSelector': '.button-next',

                'previousSelector': '.button-previous',

                onTabClick: function (tab, navigation, index, clickedIndex) {

                    return false;

                },

                onNext: function (tab, navigation, index) {

                    success.hide();

                    error.hide();
                    var ulrlength = countWords($('#txturlextension').val());
                    var format = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;

                   
                    if (index == 1) {
                        if (form.valid() == false) {

                            form.validate();
                            return false;

                        }
                        else if (format.test($('#txturlextension').val())) {
                            $('#spandanger').html('URL Extension format not proper.')
                            $('.alert-danger').show();
                            Metronic.scrollTo($('.alert-danger'), -200);
                            $('.alert-danger').fadeOut(5000);

                            return false;
                        }
                        else if (ulrlength > 1) {
                            $('#spandanger').html('URL Extension should be only one word.')
                            $('.alert-danger').show();
                            Metronic.scrollTo($('.alert-danger'), -200);
                            $('.alert-danger').fadeOut(5000);

                            return false;
                        }
                    else {
                           // ins_updCustomer();
                           
                        }

                    }
                    else if (index == 2) {
                        if (form.valid() == false) {

                            form.validate();
                            return false;

                        }
                       
                        else {
                            ins_updCustomer();
                            

                        }
                       
                    }

                    handleTitle(tab, navigation, index);

                },

                onPrevious: function (tab, navigation, index) {
                   
                    success.hide();

                    error.hide();

                    handleTitle(tab, navigation, index);

                },

                onTabShow: function (tab, navigation, index) {

                    var total = navigation.find('li').length;

                    var current = index + 1;

                    var $percent = (current / total) * 100;

                    $('#form_wizard_1').find('.progress-bar').css({

                        width: $percent + '%'

                    });

                }

            });

            $('#form_wizard_1').find('.button-previous').hide();

            $('#form_wizard_1 .button-submit').click(function () {

                //if ($('#tblServicesProduct >tbody >tr').length == 0) {



                //    $('#form_wizard_1').bootstrapWizard('previous');

                //    error.show();

                //    $('#spandanger').html('please Configure Bid parameters..')

                //    error.fadeOut(3000)

                //    return false;

                //}

                //else if (ValidateVendor() == 'false') {

                //    return false;

                //}

                //else {
                   fnMapMenus()

                //}

            }).hide();



            //unblock code

        }

    };

}();

function countWords(str) {
    return str.trim().split(/\s+/).length;
}

function fillCountryDropDown(dropdownID, countryid) {

    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: APIPath + "CustomerRegistration/Country/?CountryID=0",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        processData: true,
        dataType: "json",
        success: function (data) {

            var appenddata;
            appenddata += "<option value=0>Select</option>";
            jQuery.each(data, function (key, value) {
                appenddata += "<option value = '" + value.CountryID + "'>" + value.CountryName + " </option>";

            });
            jQuery('#' + dropdownID).html(appenddata);


            if (countryid != '0') {
                jQuery('#' + dropdownID).val(countryid);
            }

        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            
            return false;
            jQuery.unblockUI();
        }


    });
}
$('#chkIsunlimitedbids').on('click', function (e) {//ifChanged
   
    if ($('#chkIsunlimitedbids').is(':checked')) {
        $('#divunlimitedbids').addClass('hide')
        $('#txtnobids').removeAttr('required');
    }
    else {
        $('#divunlimitedbids').removeClass('hide')
        $('#txtnobids').attr('required');
    }
})
function fillStateDropDown(dropdownID, stateid) {

    var countryid = '0';

    if (dropdownID == "dropState") {
        if (jQuery('#dropCountry').val() != null) {

            countryid = jQuery('#dropCountry').val();
        }
    }
    
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: APIPath + "CustomerRegistration/State/?CountryID=" + countryid + "&StateID=0",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        processData: true,
        dataType: "json",
        success: function (data) {
             var appenddata;
            appenddata += "<option value='0'>Select</option>";

            jQuery.each(data, function (key, value) {
                appenddata += "<option value = '" + value.StateID + "'>" + value.StateName + " </option>";

            });
            jQuery('#' + dropdownID).html(appenddata);


            if (stateid != '0') {
                jQuery('#' + dropdownID).val(stateid);

            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }

    });
}
function fillCityDropDown(dropdownID, cityid) {
    var stateid = '0';
    var url = '';
    if (dropdownID == "dropCity") {

        if (jQuery('#dropState').val() != null) {
            stateid = jQuery('#dropState').val();
            url = (APIPath + "CustomerRegistration/City/?StateID= " + stateid + "&CityID=0");
        }

    }
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: url,
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        processData: true,
        dataType: "json",
        success: function (data) {

            var appenddata;
            appenddata += "<option value='0'>Select</option>";

            jQuery.each(data, function (key, value) {
                appenddata += "<option value = '" + value.CityID + "'>" + value.CityName + " </option>";
            });
            jQuery('#' + dropdownID).html(appenddata);

            if (cityid != '0') {

                jQuery('#' + dropdownID).val(cityid);
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }

    });
}
function FetchCurrency(CurrencyID) {
    jQuery.ajax({

        type: "GET",

        contentType: "application/json; charset=utf-8",

        url: sessionStorage.getItem("APIPath") + "ConfigureBid/FetchCurrency/?CurrencyID=" + CurrencyID + "&excludeStatus=N",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,

        dataType: "json",

        success: function (data) {
           
            jQuery("#dropcurrency").empty();

            jQuery("#dropcurrency").append(jQuery("<option ></option>").val("").html("Select"));

            for (var i = 0; i < data.length; i++) {

                jQuery("#dropcurrency").append(jQuery("<option></option>").val(data[i].CurrencyId).html(data[i].CurrencyNm));

            }

        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }

    });

}
function fetchALLmenuitems() {
    
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    var url = APIPath + "RoleMenus/fetchALLMenus/?ActiveYNFlag=N&For=CustAdm&RoleID=0&CustomerID=" + sessionStorage.getItem("CustomerID") + "&UserID=" + encodeURIComponent(sessionStorage.getItem("UserID")) + "&MenuType=0";

    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: url,
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        crossDomain: true,
        processData: true,
        dataType: "json",

        success: function (data) {

            sessionStorage.setItem('AllMenus', JSON.stringify(data));
            setTimeout(function () {
                paintmenus();
            }, 1000);

        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }
    });

}

function paintmenus() {
    jQuery.blockUI({ message: '<h5><img src="assets_1/layouts/layout/img/loading.gif" />  Please Wait...</h5>' });
    var data = sessionStorage.getItem('AllMenus');
    var data1 = sessionStorage.getItem('AllMenus');
    $('#div_menus').empty();
    var i = 0;
    for (var y = 0; y < jQuery.parseJSON(data).length; y++) {
        if (jQuery.parseJSON(data)[y].ParentMenuID == '0') {

            $('#div_menus').append("<ul  id=ULmain" + y + ">");
            jQuery('#ULmain' + y).addClass('jstree-container-ul jstree-no-dots jstree-children jstree-wholerow-ul');
            $('#ULmain' + y).append('<li role=treeitem  id=j1_' + y + '><div role="presentation" unselectable=on id=div' + y + ' ></div ><i role="presentation" id=icon' + y + ' onclick="CollapseLi(this,j1_' + y + ')"></i>');
            jQuery('#j1_' + y).addClass('jstree-node  jstree-open');
            jQuery('#div' + y).addClass('jstree-wholerow');
            jQuery('#icon' + y).addClass('jstree-icon jstree-ocl');
            $('#j1_' + y).append('<a style="text-decoration:none" class=jstree-anchor href="javascript:;"><input id=chkAll' + y + ' onclick="CheckAll(this,div' + y + ')" value=' + jQuery.parseJSON(data)[y].MenuID + '  type=checkbox  name=chkAll  />&nbsp;&nbsp;' + jQuery.parseJSON(data)[y].MenuName + '</input></a>');
            $('#j1_' + y).append("<ul role=group class='jstree-children' id=childUL" + y + ">");
            for (var x = 0; x < jQuery.parseJSON(data1).length; x++) {
                i = i + jQuery.parseJSON(data)[x].MenuID;
                if (jQuery.parseJSON(data)[y].MenuID == jQuery.parseJSON(data1)[x].ParentMenuID) {
                   
                    $('#childUL' + y).append("<li role='treeitem' id=j1_" + (y + x+i) + " class='jstree-node jstree-leaf'><div class='jstree-wholerow'></div><i class='jstree-icon jstree-ocl'></i>");
                    $('#j1_' + (y + x+i)).append("<a style='text-decoration:none' class='jstree-anchor' href='javascript:;'><input id=checkbox" + x + " name=checkbox" + x + "  type='checkbox' value=" + jQuery.parseJSON(data1)[x].MenuID + " />&nbsp;&nbsp;" + jQuery.parseJSON(data1)[x].MenuName + "</a></li>");
                   
                }


            }
        }

    }

    jQuery.unblockUI();
}

sessionStorage.setItem("hdnCustomerID", 0)
sessionStorage.setItem("hdnAdminID", 0)
function ins_updCustomer() {
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    var logo = '';
    var noofbids = '';
    
    if ($('#filepthterms').html() != '' && ($('#file1').val() == '')) {
        logo = jQuery('#filepthterms').html();
    } else {
        logo = jQuery('#file1').val().substring(jQuery('#file1').val().lastIndexOf('\\') + 1);
    }

    
   // TermsConditionFile = jQuery('#file1').val().substring(jQuery('#file1').val().lastIndexOf('\\') + 1);
    var Cusstatus = "";
    if (jQuery("#checkboxcustomeractive").is(':checked')) {
        Cusstatus = "Y";
    }
    else {
        Cusstatus = "N";
    }
    if (jQuery("#chkboxadmin").is(':checked')) {
        adminstatus = "Y";
    }
    else {
        adminstatus = "N";
    }
    if ($('#chkIsunlimitedbids').is(':checked')) {
        noofbids = 0;
    }
    else {
        noofbids = $('#txtnobids').val();
    }
    if (checkimageExtension(logo)) {
        var data = {
            'CustomerName': $('#txtcustomername').val(),
            'CustomerAddress': $('#txtAddress1').val(),
            'CountryID': $('#dropCountry').val(),
            'StateID': $('#dropState').val(),
            'CityID': $('#dropCity').val(),
            'PinCode': $('#pincode').val(),
            'Website': $('#txtwebsite').val(),
            'PhoneNo': $('#phoneno').val(),
            'AdminName': $('#txtadminfirstname').val(),
            'AdminEmail': $('#txtUserEmailID').val(),
            'AdminMobile': $('#txtmobileNo').val(),
            'SubscriptionType': '',
            'SubscriptionFrom': $('#from').val(),
            'SubscriptionTo': $('#to').val(),
            'CustomerID': sessionStorage.getItem("hdnCustomerID"),
            'UserID': sessionStorage.getItem('UserID'),
            'AdminID': sessionStorage.getItem("hdnAdminID"),
            'NoOfBid': noofbids,
            "CustomerIsActive": Cusstatus,
            "AdminIsActive": adminstatus,
            "DefaultCurrency": $('#dropcurrency').val(),
            "LogoFileName": logo,
            "GeneralConditions": $('#txttermscondition').val(),
            "URLExtension": $('#txturlextension').val().trim()
    
        }
    }
    else {
        error.show();
        $('#spandanger').html('Please Select jpg/jpeg/png image...');
        Metronic.scrollTo(error, -200);
        error.fadeOut(3000);
       
       $('#file1').val('');
        jQuery.unblockUI();
        return false;

    }
    //alert(JSON.stringify(data))
    jQuery.ajax({
        url: APIPath + "CustomerRegistration/InsCustomerRegistration",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        data: JSON.stringify(data),
        type: "POST",
        contentType: "application/json",
        success: function (data) {
           // alert(data[0].IsSuccess)
            if (data[0].IsSuccess == '1') {
                
                sessionStorage.setItem("hdnCustomerID", data[0].CustomerID)
                sessionStorage.setItem("hdnAdminID", data[0].AdminID)
                error.hide();
                success.hide();
               
               // Metronic.scrollTo(success, -200);
                //success.fadeOut(7000);
                fileUploader($('#txturlextension').val())
                fnFetchMenusonRoleBased();
                return true;
               // FetchCustomerDetails();
            }
            else if (data[0].IsSuccess == '-1') {
                
                success.hide();
                error.show();
                $('#spandanger').html("This Admin Email ID already exists..")
                Metronic.scrollTo(error, -200);
                error.fadeOut(9000);
               
                setTimeout(function () {
                    $('#form_wizard_1').bootstrapWizard('previous');
                },1000)
             
               // $("#submit_form").get(0).click();
                //FormWizard.init();
                return false;
            }
           
            else if (data[0].IsSuccess == '0') {
                success.hide();
                error.show();
                error.fadeOut(7000);
                $('#spandanger').html("You have some error..")
                setTimeout(function () {
                    $('#form_wizard_1').bootstrapWizard('previous');
                }, 1000)
                return false;
            }
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }

    });
    jQuery.unblockUI();
   
}

function resetregistrationForm() {
    sessionStorage.setItem("hdnCustomerID", "0")
    sessionStorage.setItem("hdnAdminID", "0")
    $('#btn_submit').html('Submit');
   // $('#txtcustomername').val('');
    $('#txttermscondition').val('');
    $('#dropcurrency').val('');
    $('#txtnobids').val('');
    $('#from').val('');
    $('#to').val('');
    $('#txtmobileNo').val('');
    $('#txtAddress1').val('');
    $('#txtUserEmailID').val('');
    $('#txtadminfirstname').val('');
    $('#txtwebsite').val('');
    $('#phoneno').val('');
    $('#divunlimitedbids').addClass('hide')
    jQuery('input:checkbox[name=chkIsunlimitedbids]').prop('checked', true);
    jQuery('#chkIsunlimitedbids').parents('div').addClass('checked');
    $('#pincode').val('');
    $('#txturlextension').val('');
    $('#dropCity').val('0');
    $('#dropState').val('0');
    $('#dropCountry').val('0');
    fillCountryDropDown('dropCountry', 0);
    $('#dropState').empty();
    $('#dropCity').empty();
    $('#dropState').append('<option value="">Select</option>');
    $('#dropCity').append('<option value="">Select</option>');

}
function FetchAllCustomer() {
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });

    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "CustomerRegistration/FetchCustomerDetails/?CustomerID=0&IsActive=Y",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        dataType: "json",
        success: function (data) {
        
            if (data.length > 0) {
               
                sessionStorage.setItem('hdnAllCustomers', JSON.stringify(data))
            }
           
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }

            return false;
            jQuery.unblockUI();
        }

    });
    jQuery.unblockUI();

}
jQuery("#txtcustomername").typeahead({
    source: function (query, process) {
        var data = sessionStorage.getItem('hdnAllCustomers');
        usernames = [];
        map = {};
        var username = "";
        jQuery.each(jQuery.parseJSON(data), function (i, username) {
            map[username.CustomerName] = username;
            usernames.push(username.CustomerName);
        });

        process(usernames);

    },
    minLength: 2,
    updater: function (item) {

        if (map[item].CustomerID != '0') {

            sessionStorage.setItem('hdnCustomerID', map[item].CustomerID);
            fetchCustomerDetails(map[item].CustomerID);
        }
        else {
            gritternotification('Please select correct Customer  for Editing Details!!!');

        }
        return item;
    }

});
jQuery("#txtcustomername").keyup(function () {
    sessionStorage.setItem('hdnCustomerID', '0');
    resetregistrationForm();
});
function fetchCustomerDetails(customerid) {
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });

    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: sessionStorage.getItem("APIPath") + "CustomerRegistration/FetchCustomerDetails/?CustomerID=" + customerid + "&IsActive=Y",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        cache: false,
        dataType: "json",
        success: function (data) {
           //alert(data.length)
            if (data.length > 0) {
                sessionStorage.setItem("hdnCustomerID", data[0].CustomerID)
                sessionStorage.setItem("hdnAdminID", data[0].AdminID)
                $('#txtcustomername').val(data[0].CustomerName);
                $('#txttermscondition').val(data[0].GeneralConditions);
                $('#dropcurrency').val(data[0].DefaultCurrency);
                $('#txtnobids').val(data[0].NoOfBid);
                $('#from').val(data[0].SubscriptionFrom);
                $('#to').val(data[0].SubscriptionTo);
                $('#txtmobileNo').val(data[0].AdminMobile);
                $('#txtAddress1').val(data[0].CustomerAddress);
                $('#txtUserEmailID').val(data[0].AdminEmail);
                $('#txtadminfirstname').val(data[0].AdminName);
                $('#txtwebsite').val(data[0].Website);
                $('#txturlextension').val(data[0].URLExtension);
                $('#phoneno').val(data[0].PhoneNo);

                $('#pincode').val(data[0].PinCode);
                
                $('#dropCountry').val(data[0].CountryID);
                fillStateDropDown('dropState', '0')
                setTimeout(function () {
                   
                    $('#dropState').val(data[0].StateID);
                    fillCityDropDown('dropCity', '0')
                }, 700)
              
                setTimeout(function () {
                   
                    $('#dropCity').val(data[0].CityID);
                }, 1000)
                if (data[0].LogoImageName != '') {
                    $('#file1').removeAttr('required')
                }
                $('#filepthterms').attr('href', data[0].LogoImage).html(data[0].LogoImageName);
                //$('#file1').val(data[0].LogoImage);
               
               
                if (data[0].CustomerIsActive == "Y") {
                    jQuery('input:checkbox[name=checkboxcustomeractive]').attr('checked', true);

                    jQuery('#checkboxcustomeractive').parents('div').removeClass('bootstrap-switch-off');
                    jQuery('#checkboxcustomeractive').parents('div').addClass('bootstrap-switch-on');
                }
                else {
                    jQuery('input:checkbox[name=checkboxcustomeractive]').attr('checked', false);

                    jQuery('#checkboxcustomeractive').parents('div').removeClass('bootstrap-switch-on');
                    jQuery('#checkboxcustomeractive').parents('div').addClass('bootstrap-switch-off');
                }
                if (data[0].AdminIsActive == "Y") {
                    jQuery('input:checkbox[name=chkboxadmin]').attr('checked', true);

                    jQuery('#chkboxadmin').parents('div').removeClass('bootstrap-switch-off');
                    jQuery('#chkboxadmin').parents('div').addClass('bootstrap-switch-on');
                }
                else {
                    jQuery('input:checkbox[name=chkboxadmin]').attr('checked', false);

                    jQuery('#chkboxadmin').parents('div').removeClass('bootstrap-switch-on');
                    jQuery('#chkboxadmin').parents('div').addClass('bootstrap-switch-off');
                }
            }
            jQuery.unblockUI();
        }
         

    });
   

}
function fnFetchMenusonRoleBased() {
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
   
    var url = APIPath + "RoleMenus/fetchMenuCodeRoles/?UserID=" + sessionStorage.getItem("hdnAdminID") + "&CustomerID=" + sessionStorage.getItem("hdnCustomerID")+"&RoleID=0";
    //alert(url)
    jQuery.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: url,
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        data: "{}",
        cache: false,
        dataType: "json",

        success: function (data) {
            if (data.length > 0) {
                var chkId = '';
                var chk = '';

                $('#div_menus input[type=checkbox]').each(function () {
                    $('#' + this.id).prop("checked", false);
                    chk += $(this).val() + ",";
                    chkId += (this.id) + ",";
                });
                chk = chk.slice(0, -1);
                chkId = chkId.slice(0, -1);

                var temp = new Array();
                var temp1 = new Array();
                temp = chk.split(",");
                temp1 = chkId.split(",");

                for (var i = 0; i < temp.length; i++) {
                    for (var j = 0; j < data.length; j++) {
                        if (temp[i] == data[j].MenuID) {
                            $('#' + temp1[i]).prop("checked", true);

                        }

                    }

                }
            }
        }

    });
    jQuery.unblockUI();
}
function fileUploader(CustomerName) {
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
  
    var fileTerms = $('#file1');
    var fileDataTerms = fileTerms.prop("files")[0];

   // alert(CustomerName)
    var formData = new window.FormData();

    formData.append("fileTerms", fileDataTerms);
    formData.append("AttachmentFor", "Customer");

    formData.append("BidID", CustomerName);
    formData.append("VendorID", '');

     $.ajax({

        url: 'ConfigureFileAttachment.ashx',

        data: formData,

        processData: false,

        contentType: false,

        asyc: false,

        type: 'POST',

        success: function (data) {
            jQuery.unblockUI();
        },

        error: function () {

            bootbox.alert("Attachment error.");
            jQuery.unblockUI();
        }

    });

}
function CheckAll(qw, divid) {

    var checkedValue = "";
    var tab = qw.id; // table with id tbl1

    var len = tab.length;

    for (var i = 0; i < len; i++) {
        if ($('#' + qw.id).is(':checked')) {

            $('#' + qw.id).closest('ul').find(':checkbox').prop('checked', true);
            $('#' + divid.id).addClass('jstree-wholerow-clicked');
            // checkedValue = checkedValue + elems[i].value;

        }
        else {

            $('#' + qw.id).closest('ul').find(':checkbox').prop('checked', false);
            $('#' + divid.id).removeClass('jstree-wholerow-clicked');
        }


    }
}

function CollapseLi(iconid, wq) {

    $('#' + wq.id).toggleClass("jstree-node  jstree-open jstree-last").toggleClass("jstree-node  jstree-closed jstree-last");

}
function uncheck() {

    var tab = document.getElementById("div_menus"); // table with id tbl1
    var elems = tab.getElementsByTagName("input");
    var len = elems.length;
    for (var i = 0; i < len; i++) {
        if (elems[i].type == "checkbox") {
            elems[i].checked = false;

        }
    }
   

}
function fnMapMenus() {
    jQuery.blockUI({ message: '<h5><img src="assets/admin/layout/img/loading.gif" />  Please Wait...</h5>' });
    MenuList = '';

    $('#div_menus input[type=checkbox]:checked').each(function () {
        MenuList += $(this).val() + ",";
    });
    MenuList = MenuList.slice(0, -1);

    var Data = {
        "MenuList": MenuList,
        "CustomerID": sessionStorage.getItem("hdnCustomerID"),
        "UserID": sessionStorage.getItem("hdnAdminID"),
        "RoleID": "0",

    };
  //  alert(JSON.stringify(Data));
    jQuery.ajax({
        url: APIPath + "RoleMenus/MapMenusRole/",
        beforeSend: function (xhr, settings) { xhr.setRequestHeader('Authorization', 'Bearer ' + sessionStorage.getItem("Token")); },
        type: "POST",
        data: JSON.stringify(Data),
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (data[0].OutPut == '1') {
                bootbox.alert("Customer Regsitered Successfully.", function () {
                    sessionStorage.removeItem('hdnCustomerID');
                    sessionStorage.removeItem('hdnAdminID');
                    resetregistrationForm();
                    window.location = "RegisterCustomerRoleUser.html"; 
                    return false;
                });
            }

            else {
                jQuery("#diverror").text("Error");
                error.show();
                error.fadeOut(5000)
            }

            jQuery.unblockUI();
        },
        error: function (xhr, status, error) {

            var err = eval("(" + xhr.responseText + ")");
            if (xhr.status === 401) {
                error401Messagebox(err.Message);
            }
            else{
                jQuery("#diverror").text(xhr.d);
                error.show();
                error.fadeOut(5000);
               
            }
            return false;
            jQuery.unblockUI();
        }
       
    });
    // resetForm();

}